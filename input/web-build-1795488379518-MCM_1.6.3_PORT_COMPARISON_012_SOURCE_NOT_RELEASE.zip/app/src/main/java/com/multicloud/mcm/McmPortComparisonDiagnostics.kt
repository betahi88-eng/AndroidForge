package com.multicloud.mcm

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.ConnectException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException

/** Same-network, same-DNS TCP comparison for WinBox/REST/API-SSL. No service login is attempted. */
internal class McmPortComparisonDiagnostics {
    suspend fun inspect(rawHost: String, network: JSONObject): JSONObject = withContext(Dispatchers.IO) {
        val host = RouterHostValidator.normalize(rawHost)
        val started = System.currentTimeMillis()
        val resolution = try {
            RouterDnsResolver.resolveDetailed(host)
        } catch (error: Exception) {
            return@withContext JSONObject()
                .put("ok", false).put("kind", "PORT_COMPARISON")
                .put("host", host).put("stage", "DNS")
                .put("code", "DNS_FAILED")
                .put("message", "Không phân giải được DDNS; chưa thể so sánh TCP 8291, 443 và 8729.")
                .put("dnsError", safe(error)).put("networkContext", JSONObject(network.toString()))
                .put("ports", JSONArray()).put("elapsedMs", System.currentTimeMillis() - started)
        }
        val addresses = resolution.addresses.take(MAX_ADDRESSES_TO_PROBE)
        val addressJson = JSONArray().apply { addresses.forEach { put(it.hostAddress ?: "") } }
        val definitions = listOf(
            PortDef("WINBOX_TCP", 8291, "WinBox", "TCP only; không thực hiện WinBox protocol handshake"),
            PortDef("REST_HTTPS_TCP", 443, "REST HTTPS", "TCP only; không thực hiện TLS handshake"),
            PortDef("API_SSL_TCP", 8729, "API-SSL", "TCP only; không thực hiện TLS handshake")
        )
        val portResults = JSONArray()
        val summary = linkedMapOf<Int, String>()
        for (definition in definitions) {
            val attempts = JSONArray()
            var connected = false
            var finalCode = "TCP_UNREACHABLE"
            var duration = 0L
            for (address in addresses) {
                val attemptStart = System.currentTimeMillis()
                try {
                    Socket().use { socket ->
                        socket.connect(InetSocketAddress(address, definition.port), TCP_TIMEOUT_MS)
                        duration = System.currentTimeMillis() - attemptStart
                        connected = true
                        attempts.put(JSONObject().put("ip", address.hostAddress ?: "")
                            .put("result", "TCP_REACHABLE").put("tcpMs", duration)
                            .put("localSocketAddress", socket.localAddress?.hostAddress ?: JSONObject.NULL))
                    }
                    finalCode = "TCP_REACHABLE"
                    break
                } catch (error: Exception) {
                    duration = System.currentTimeMillis() - attemptStart
                    finalCode = when (error) {
                        is SocketTimeoutException -> "TCP_TIMEOUT"
                        is ConnectException -> "TCP_CONNECTION_REFUSED"
                        else -> "TCP_CONNECT_FAILED"
                    }
                    attempts.put(JSONObject().put("ip", address.hostAddress ?: "")
                        .put("result", finalCode).put("elapsedMs", duration)
                        .put("error", safe(error)))
                }
            }
            summary[definition.port] = finalCode
            portResults.put(JSONObject().put("service", definition.name)
                .put("serviceCode", definition.code).put("port", definition.port)
                .put("result", finalCode).put("reachable", connected)
                .put("tcpMs", if (connected) duration else JSONObject.NULL)
                .put("protocolCheck", definition.protocolNote)
                .put("attempts", attempts))
        }
        val winbox = summary[8291] == "TCP_REACHABLE"
        val rest = summary[443] == "TCP_REACHABLE"
        val api = summary[8729] == "TCP_REACHABLE"
        val code: String
        val message: String
        val confidence: String
        when {
            winbox && !rest && !api -> {
                code = "WINBOX_ONLY_TCP_REACHABLE"
                message = "TCP 8291 mở được nhưng TCP 443 và 8729 không mở được trên cùng DDNS/IP/mạng di động. Đường tới router không bị mất hoàn toàn; vấn đề tập trung ở hai endpoint REST/API-SSL hoặc quy tắc chuyển tiếp/lọc riêng cho chúng. TCP 8291 không chứng minh WinBox handshake trong phép thử này."
                confidence = "SUPPORTED_BY_TCP_COMPARISON"
            }
            winbox && (rest || api) -> {
                code = "MULTIPLE_PORTS_TCP_REACHABLE"
                message = "Ít nhất một endpoint MCM và TCP 8291 đều mở. Lỗi còn lại cần điều tra ở TLS, giao thức, chứng chỉ, SSH hoặc xác thực; phép thử này chỉ xác nhận TCP."
                confidence = "SUPPORTED_BY_TCP_COMPARISON"
            }
            !winbox && !rest && !api -> {
                code = "ALL_TESTED_PORTS_UNREACHABLE"
                message = "Cả TCP 8291, 443 và 8729 đều không mở được từ mạng hiện tại. Kết quả phù hợp với sự cố đường vào WAN, IP đích/DDNS, upstream filtering hoặc NAT/firewall chung; chưa xác định được thiết bị/hop gây chặn."
                confidence = "CANNOT_LOCALIZE_DROP_POINT"
            }
            else -> {
                code = "MIXED_PORT_REACHABILITY"
                message = "Kết quả các cổng không đồng nhất. So sánh từng IP/port trong attempts để xác định endpoint nào có TCP reachability; chưa thể kết luận trạng thái dịch vụ ứng dụng."
                confidence = "SUPPORTED_BY_TCP_COMPARISON"
            }
        }
        JSONObject().put("ok", true).put("kind", "PORT_COMPARISON").put("protocol", "TCP_PORT_COMPARISON")
            .put("host", host).put("stage", "TCP_PORT_COMPARISON")
            .put("code", code).put("message", message).put("confidence", confidence)
            .put("dns", JSONObject().put("source", resolution.source).put("addresses", addressJson))
            .put("networkContext", JSONObject(network.toString()))
            .put("addressProbeLimit", MAX_ADDRESSES_TO_PROBE)
            .put("unprobedAddressCount", (resolution.addresses.size - addresses.size).coerceAtLeast(0))
            .put("ports", portResults)
            .put("confirmed", JSONArray().put("DDNS_RESOLVED").put("SAME_DEVICE_NETWORK_USED_FOR_ALL_THREE_TCP_TESTS"))
            .put("notProven", JSONArray().put("Router WAN address matches DDNS resolved address")
                .put("Which router/firewall/NAT/ISP hop drops an unsuccessful TCP handshake")
                .put("WinBox application-layer handshake or authentication")
                .put("REST/API-SSL TLS handshake or RouterOS authentication"))
            .put("routerWanIp", JSONObject.NULL)
            .put("routerWanIpStatus", "NOT_READABLE_WITHOUT_ROUTER_ACCESS")
            .put("elapsedMs", System.currentTimeMillis() - started)
            .put("timestampEpochMs", System.currentTimeMillis())
    }

    private data class PortDef(val code: String, val port: Int, val name: String, val protocolNote: String)
    private fun safe(error: Throwable): String = (error.message ?: error.javaClass.simpleName)
        .replace(Regex("[\\r\\n\\t]+"), " ").take(240)

    companion object { private const val TCP_TIMEOUT_MS = 2_000; private const val MAX_ADDRESSES_TO_PROBE = 4 }
}
