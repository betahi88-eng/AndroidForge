package com.multicloud.mcm

import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.multicloud.mcm.data.McmDatabase
import com.multicloud.mcm.security.SecureCredentialStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.cancel
import org.json.JSONObject

/** Thin, allow-listed bridge; all database and network work runs off the WebView thread. */
class McmJavascriptBridge(
    private val webView: WebView,
    database: McmDatabase,
    credentials: SecureCredentialStore
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val profiles = McmRouterProfileService(database, credentials)
    private val connectionCoordinator = RouterConnectionCoordinator(database, credentials)
    private val sshConnectionCoordinator = SshConnectionCoordinator(database, credentials)
    private val monitor = McmMonitoringService(database, credentials)
    private val discovery = MikroTikNeighborDiscovery(webView.context)
    private val networkState = McmNetworkState(webView.context)
    private val diagnostics = McmConnectionDiagnostics()
    private val sshDiagnostics = McmSshEndpointDiagnostics()
    private val portComparisonDiagnostics = McmPortComparisonDiagnostics()
    private val diagnosticPrefs = webView.context.getSharedPreferences("mcm_diagnostic_traces", android.content.Context.MODE_PRIVATE)

    @JavascriptInterface
    fun listRouters(callbackId: String) = respond(callbackId) {
        JSONObject().put("ok", true).put("routers", profiles.listRouters())
    }

    @JavascriptInterface
    fun discoverMikroTik(callbackId: String) = respond(callbackId) {
        JSONObject().put("ok", true).put("devices", discovery.scan())
    }

    @JavascriptInterface
    fun getNetworkState(callbackId: String) = respond(callbackId) {
        JSONObject().put("ok", true).put("network", networkState.snapshot())
    }

    @JavascriptInterface
    fun inspectTls(host: String, port: Int, callbackId: String) = respond(callbackId) {
        JSONObject().put("ok", true).put("fingerprint", profiles.inspectTls(host, port))
    }

    @JavascriptInterface
    fun diagnoseEndpoint(host: String, port: Int, callbackId: String) = respond(callbackId) {
        diagnostics.inspect(host, port)
    }

    @JavascriptInterface
    fun diagnosePortComparison(host: String, callbackId: String) = respond(callbackId) {
        val result = portComparisonDiagnostics.inspect(host, networkState.snapshot())
        saveDiagnosticTrace(result)
        result
    }

    @JavascriptInterface
    fun diagnoseConnection(host: String, username: String, port: Int, connectionMode: String, callbackId: String) = respond(callbackId) {
        val mode = RouterServiceMode.fromUserInput(connectionMode)
        if (mode.hasPortProtocolMismatch(port)) {
            val blocked = JSONObject().put("ok", false).put("protocol", mode.storageValue)
                .put("transport", "NOT_STARTED").put("host", host).put("port", port)
                .put("stage", "CONFIG_VALIDATION").put("code", "PROTOCOL_PORT_MISMATCH")
                .put("message", "Cổng 22 là SSH; chọn SSH v2 thay vì AUTO/REST/API-SSL.")
                .put("restApiProbe", "NOT_RUN").put("sshProbe", "NOT_RUN")
            saveDiagnosticTrace(blocked)
            return@respond blocked
        }
        val result = if (mode == RouterServiceMode.SSH) {
            sshDiagnostics.inspect(host, port.takeIf { it > 0 } ?: 22, username.ifBlank { "mcm-diagnostic" })
        } else {
            val actualPort = port.takeIf { it > 0 } ?: when (mode) {
                RouterServiceMode.REST_HTTPS -> 443
                RouterServiceMode.API_SSL -> 8729
                else -> 443
            }
            diagnostics.inspect(host, actualPort).put("protocol", mode.storageValue)
                .put("transport", "TCP_ONLY_PRECHECK")
                .put("tlsHandshake", "NOT_RUN_BY_THIS_DIAGNOSTIC")
        }
        saveDiagnosticTrace(result)
        result
    }

    @JavascriptInterface
    fun diagnosticHistory(callbackId: String) = respond(callbackId) {
        val array = runCatching { org.json.JSONArray(diagnosticPrefs.getString("traces", "[]")) }.getOrDefault(org.json.JSONArray())
        JSONObject().put("ok", true).put("traces", array)
    }

    @JavascriptInterface
    fun connectRouter(host: String, username: String, password: String, port: Int, connectionMode: String, callbackId: String) = respond(callbackId) {
        if (RouterServiceMode.fromUserInput(connectionMode).hasPortProtocolMismatch(port)) {
            return@respond JSONObject().put("ok", false).put("state", "PROTOCOL_PORT_MISMATCH")
                .put("errorCode", "PROTOCOL_PORT_MISMATCH")
                .put("message", "Cổng 22 là endpoint SSH. Hãy chọn SSH v2; AUTO/REST HTTPS/API-SSL không được phép dò trên cổng 22.")
                .put("diagnostics", JSONObject().put("protocol", connectionMode).put("port", port)
                    .put("stage", "CONFIG_VALIDATION").put("code", "PROTOCOL_PORT_MISMATCH")
                    .put("ssh", "NOT_SELECTED").put("restApiProbe", "BLOCKED_TO_PREVENT_MISLABEL"))
        }
        val result = if (connectionMode.equals("SSH", true)) sshConnectionCoordinator.start(host, username, password, port)
        else connectionCoordinator.start(host, username, password, port, connectionMode)
        result.optJSONObject("diagnostics")?.let(::saveDiagnosticTrace)
        result
    }

    @JavascriptInterface
    fun confirmConnection(attemptId: String, decision: String, callbackId: String) = respond(callbackId) {
        val result = if (sshConnectionCoordinator.hasPending(attemptId)) sshConnectionCoordinator.confirm(attemptId, decision)
        else connectionCoordinator.confirm(attemptId, decision)
        result.optJSONObject("diagnostics")?.let(::saveDiagnosticTrace)
        result
    }

    @JavascriptInterface
    fun cancelConnection(attemptId: String, callbackId: String) = respond(callbackId) {
        if (sshConnectionCoordinator.hasPending(attemptId)) sshConnectionCoordinator.cancel(attemptId)
        else connectionCoordinator.cancel(attemptId)
    }

    @JavascriptInterface
    fun connectionLogs(routerId: String, callbackId: String) = respond(callbackId) {
        JSONObject().put("ok", true).put("logs", profiles.connectionLogs(routerId))
    }

    @JavascriptInterface
    fun saveRouter(payloadJson: String, callbackId: String) = respond(callbackId) {
        val routerId = profiles.saveRouter(payloadJson)
        JSONObject().put("ok", true).put("id", routerId).put("message", "Đã lưu router an toàn.")
    }

    @JavascriptInterface
    fun removeRouter(routerId: String, callbackId: String) = respond(callbackId) {
        profiles.removeRouter(routerId)
        JSONObject().put("ok", true)
    }

    @JavascriptInterface
    fun refreshRouter(routerId: String, target: String, callbackId: String) = respond(callbackId) {
        monitor.refreshRouter(routerId, target)
    }

    @JavascriptInterface
    fun refreshAllRouters(target: String, selectedRouterId: String, callbackId: String) = respond(callbackId) {
        monitor.refreshAll(target, selectedRouterId)
    }

    @JavascriptInterface
    fun metricHistory(routerId: String, metricKey: String, callbackId: String) = respond(callbackId) {
        monitor.metricHistory(routerId, metricKey)
    }

    fun close() {
        scope.cancel()
    }

    private fun saveDiagnosticTrace(trace: JSONObject) {
        if (!trace.has("networkContext")) trace.put("networkContext", networkState.snapshot())
        val existing = runCatching { org.json.JSONArray(diagnosticPrefs.getString("traces", "[]")) }.getOrDefault(org.json.JSONArray())
        val copy = org.json.JSONArray().put(JSONObject(trace.toString()))
        for (index in 0 until minOf(existing.length(), 19)) copy.put(existing.optJSONObject(index) ?: JSONObject())
        diagnosticPrefs.edit().putString("traces", copy.toString()).apply()
    }

    private fun respond(callbackId: String, operation: suspend () -> JSONObject) {
        if (!callbackId.matches(Regex("[A-Za-z0-9_-]{1,64}"))) return
        scope.launch {
            val result = try {
                operation()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                JSONObject().put("ok", false).put("error", error.message ?: "Thao tác thất bại.")
            }
            val quoted = JSONObject.quote(result.toString())
            webView.post {
                webView.evaluateJavascript("window.mcmReceive('$callbackId', $quoted)", null)
            }
        }
    }
}
