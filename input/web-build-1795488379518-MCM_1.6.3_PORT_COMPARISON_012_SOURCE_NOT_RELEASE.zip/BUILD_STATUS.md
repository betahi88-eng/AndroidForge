# MCM 1.6.3 — candidate 012 build and acceptance status

Source identity: `MCM-1.6.3-PORT-COMPARISON-012`

Status: `SOURCE_NOT_RELEASE`

Parent: candidate 011 (`MCM_1.6.3_SSH_DIAGNOSTICS_011_SOURCE_NOT_RELEASE.zip`)

Candidate 012 adds a same-network TCP comparison for ports 8291, 443, and 8729 to distinguish whether the WinBox TCP endpoint is reachable while the two MCM endpoints time out. It resolves DDNS once, uses the active Android network for all three probes, records per-IP outcomes and Android network context, and provides bounded interpretation. It does not claim WinBox application success, TLS success, authentication success, or actual router WAN IP when those facts are unavailable.

## Local verification

- Android project root and source identity: checked by AndroidForge preflight script.
- JavaScript syntax: checked with Node.js.
- UI DOM contract: checked.
- Historical build regression guards plus new port-comparison source assertions: checked.
- Room schema: unchanged from candidate 011 (schema v9).
- Source provenance hashes: regenerated and checked.
- ZIP structure/CRC: checked.

## Not verified here

- Android Gradle compile, unit tests, lint, APK/AAB build: not run in this environment.
- Actual TCP results on the user's cellular network: not run here.
- Actual RouterOS WAN address: not read because router access is not available during the failed TCP probes.

Do not describe candidate 012 as an APK-verified release until AndroidForge build logs for this exact ZIP show success.
