# MCM 1.6.3 — Build fix 006 / TCP port comparison candidate 012

## Purpose
The supplied mobile-network trace showed DNS success but TCP timeouts on REST HTTPS 443 and API-SSL 8729. A separate WinBox Android app was reported to reach the same DDNS host. Candidate 012 adds a controlled comparison instead of assuming why the other two ports fail.

## Integrated test
One DDNS resolution is performed, then the app probes TCP 8291 (WinBox), 443 (REST HTTPS), and 8729 (API-SSL) against the same resolved IP set (up to four addresses, 2-second TCP timeout per address/port) while remaining on the same active Android network. Each result records per-IP outcome, connect duration, exception category, and local socket address when a TCP connection succeeds. Android transport, VPN state, Internet validation, and network availability are attached to the report.

## Interpretation boundaries
- `WINBOX_ONLY_TCP_REACHABLE`: TCP 8291 accepted a connection while 443 and 8729 did not. This narrows the fault toward the two MCM endpoints or their specific forwarding/filtering; it does not prove a WinBox protocol handshake.
- `ALL_TESTED_PORTS_UNREACHABLE`: all three TCP tests failed from the current network. This is consistent with a common WAN/DDNS/upstream path issue, but cannot identify the exact dropping hop.
- `MULTIPLE_PORTS_TCP_REACHABLE` / `MIXED_PORT_REACHABILITY`: TCP is available on some endpoints; continue at the relevant protocol/TLS stage.
- Router WAN IP is deliberately reported as unavailable unless router access can supply it. The DDNS A/AAAA answer is not mislabeled as the router's actual WAN address.

## Safety
No passwords, SSH keys, WinBox login, TLS handshake, REST/API authentication, or RouterOS commands are used. This is a TCP-only read-only comparison.

## Verification boundary
JavaScript syntax, UI contract, source regression guards, provenance hashes, ZIP integrity, and source preflight are checked locally. Android Gradle/APK and live connectivity still require AndroidForge and the user's phone/network.
