# AndroidForge — MCM 1.6.3 candidate 012

Package: `MCM_1.6.3_PORT_COMPARISON_012_SOURCE_NOT_RELEASE.zip`
Source ID: `MCM-1.6.3-PORT-COMPARISON-012`

## Expected Android project
- Root project: `MikroTikMultiCloudMonitor`
- Application ID: `com.multicloud.mcm`
- Version: `1.6.3` (versionCode 12)
- JDK 17, Gradle 8.7, Android Gradle Plugin 8.6.1, Kotlin 2.0.21, compileSdk 35.

Upload the ZIP without nesting its contents in another folder. Android project files (`settings.gradle.kts`, `build.gradle.kts`, and `app/build.gradle.kts`) are at archive root.

Candidate 012 is source-only until AndroidForge builds it. After APK installation, open Advanced options and use **Đối chứng TCP 8291 / 443 / 8729** on the same cellular connection. Export/copy the JSON report. The test uses one DDNS resolution and one active Android network for all three TCP checks.

The test is TCP-only. It does not log into WinBox, perform TLS, authenticate to RouterOS, or read actual WAN IP. Send the full report to analyze the comparison.
