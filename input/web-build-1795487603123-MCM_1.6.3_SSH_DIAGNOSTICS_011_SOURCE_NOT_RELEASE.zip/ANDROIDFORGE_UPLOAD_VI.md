# AndroidForge — MCM 1.6.3 candidate 011

Gói: `MCM_1.6.3_SSH_DIAGNOSTICS_011_SOURCE_NOT_RELEASE.zip`
Source ID: `MCM-1.6.3-SSH-DIAGNOSTICS-011`

Giữ nguyên project root và toolchain đã dùng cho baseline 007: JDK 17, Gradle 8.7, AGP 8.6.1, Kotlin 2.0.21, Android SDK Platform 35. Không đổi toolchain.

Build tasks bắt buộc:
```bash
gradle --no-daemon clean
gradle --no-daemon :app:testDebugUnitTest
gradle --no-daemon :app:lintDebug
gradle --no-daemon :app:assembleDebug :app:bundleDebug
gradle --no-daemon :app:assembleRelease :app:bundleRelease
```

## Test tích hợp chẩn đoán sâu
1. Mở Tùy chọn nâng cao, chọn `SSH v2`, nhập WAN port `22` (hoặc cổng SSH đã cấu hình), bấm `Chạy chẩn đoán sâu`.
2. Kết quả phải ghi rõ `protocol=SSH`, `transport=TCP`, `tls=NOT_APPLICABLE_FOR_SSH`.
3. Nếu TCP timeout: `stage=TCP_CONNECT`, `code=TCP_CONNECT_TIMEOUT`, `sshKeyExchange=NOT_RUN`, `passwordSent=false`, `authenticationAttempted=false`.
4. Nếu TCP mở nhưng không phải SSH: `NON_SSH_SERVICE_ON_PORT` hoặc `SSH_BANNER_TIMEOUT`.
5. Nếu banner hợp lệ: phải ghi SSH key exchange và host-key SHA-256, nhưng chưa gửi password.
6. Sau khi người dùng đối chiếu và xác nhận host key, mới chạy authentication và read-only READ_CHECK.
7. Chọn AUTO/REST/API-SSL cùng WAN port 22 phải bị chặn bằng `PROTOCOL_PORT_MISMATCH`; không được ghi log REST/API-SSL trên cổng SSH.
8. Mở `Nhật ký kỹ thuật` để xem tối đa 20 trace gần nhất hoặc sao chép JSON gửi lại để phân tích.

Candidate 011 chưa được xác nhận build APK. Chỉ log AndroidForge của đúng gói 011 mới xác nhận build.
