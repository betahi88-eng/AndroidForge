# ANDROIDFORGE — đầu vào ZIP → APK MCM 1.6.3 candidate 009

- ZIP: `MCM_1.6.3_SSH_RECONCILED_009_SOURCE_NOT_RELEASE.zip`
- Source ID: `MCM-1.6.3-SSH-RECONCILED-009`
- Parent baseline: 007 (user-confirmed AndroidForge APK build success)
- Application ID: `com.multicloud.mcm`
- Version: `1.6.3` (`versionCode=12`)
- Room schema: v9
- Module: `:app`; native Kotlin/Gradle

Candidate 009 thêm SSH v2, SSH host-key pin độc lập, Room v9, SSH exec-channel allowlist và monitoring tuần tự. Đây là source candidate, không phải APK và chưa được xác nhận build thành công.

Toolchain phải giữ nguyên cấu hình của 007: JDK 17, Gradle 8.7, AGP 8.6.1, Kotlin 2.0.21, Android SDK Platform 35, Build Tools 35.0.0. Chạy từ đúng project root:

```bash
gradle --no-daemon clean
gradle --no-daemon :app:testDebugUnitTest
gradle --no-daemon :app:lintDebug
gradle --no-daemon :app:assembleDebug :app:bundleDebug
gradle --no-daemon :app:assembleRelease :app:bundleRelease
```

Tất cả exit code phải bằng 0. Xác minh package, version, source ID, APK/AAB và checksum. Tiếp đó chạy test SSH host-key first-use/change, password auth, RouterOS 6/7 CLI output và read-only allowlist. Không thay thế baseline 007 trước khi toàn bộ cổng nghiệm thu đạt.
