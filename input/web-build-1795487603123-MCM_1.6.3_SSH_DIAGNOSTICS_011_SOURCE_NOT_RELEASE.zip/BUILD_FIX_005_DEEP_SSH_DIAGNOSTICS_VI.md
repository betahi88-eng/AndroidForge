# MCM 1.6.3 — Build fix 005 / deep SSH diagnostic candidate 011

## Why this test was added
The supplied trace labels port 22 as REST_HTTPS and API_SSL. In RouterServiceMode, AUTO plus a custom port probes both TLS services on that port; SSH is a separate mode and must not be inferred from port number alone. Candidate 011 rejects port 22 unless SSH is explicitly selected.

## Integrated diagnostics
The new SSH diagnostic records: hostname, DNS resolver and resolved A/AAAA addresses; target IP; local socket source address when TCP connects; TCP connect duration and error class; SSH server banner and banner duration; SSH key-exchange outcome and duration; host-key SHA-256 when available; stage/code/message; elapsed time; whether password/authentication was attempted; and TLS applicability.

The diagnostic is read-only. Before host-key inspection it sends no password and issues no RouterOS command. A TCP timeout ends the test at TCP_CONNECT: SSH banner, key exchange, authentication and READ_CHECK are explicitly NOT_RUN.

## UI
Advanced settings gains “Chạy chẩn đoán sâu”. The result is shown as structured JSON with copy action. Up to 20 most recent diagnostic traces are retained locally in app-private SharedPreferences and surfaced under “Nhật ký kỹ thuật”. Passwords, private keys, auth headers and credential values are not recorded.

## Protocol correction
- SSH mode: SSH/TCP endpoint only (default 22). No REST_HTTPS/API_SSL labels and no TLS probe.
- AUTO/REST_HTTPS/API_SSL with custom port 22: rejected before network activity with PROTOCOL_PORT_MISMATCH.
- SSH preflight: DNS → TCP connect → SSH banner → SSH key exchange/host-key capture. Authentication is a separate subsequent step after host-key trust.

## Verification boundary
JS syntax, source contract, archive CRC and static assertions can be checked in this workspace. Android Gradle/APK and live RouterOS connectivity must be verified by AndroidForge and the user's network respectively. This candidate is not an APK-verified release.
