# MCM 1.6.3 — candidate 011 build and acceptance status

Source identity: `MCM-1.6.3-SSH-DIAGNOSTICS-011`
Parent: candidate 010; original known-good APK baseline remains 007 (user-confirmed)
Application ID: `com.multicloud.mcm`
Version: `1.6.3` (`versionCode=12`)
Room schema: `9` (unchanged)

## Purpose
Candidate 011 adds protocol-aware deep diagnostics for the observed DDNS connection failure. The provided trace showed both `REST_HTTPS` and `API_SSL` assigned to custom port 22. In this project's service mapping, that endpoint shape corresponds to AUTO/custom-port behavior, not the independent SSH mode. Candidate 011 blocks this mismatch and requires explicit SSH selection.

## Diagnostic stages
DNS resolution → per-address TCP connect → SSH server banner → SSH key exchange / host-key fingerprint → (only after explicit host-key trust) SSH authentication → read-only `/system/resource/print` READ_CHECK. Each failure reports the last reached stage and marks later stages `NOT_RUN`. No password or RouterOS command is sent during the deep preflight.

The Advanced UI has a “Chạy chẩn đoán sâu” action, structured JSON output/copy, and local rolling diagnostic history (20 entries). No credential values are stored in diagnostic traces.

## Verification status
- JavaScript syntax: PASS (Node `--check`).
- Android Gradle/JUnit/lint/APK/AAB: NOT RUN in this workspace (Android SDK/Gradle wrapper unavailable).
- Live RouterOS SSH: NOT RUN.
- Candidate 011 is source-only and must not be described as an APK-verified release.
