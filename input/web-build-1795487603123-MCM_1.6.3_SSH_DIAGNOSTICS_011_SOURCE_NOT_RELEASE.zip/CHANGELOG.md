> Baseline correction: the user later confirmed that source 007 built an APK successfully on AndroidForge. Candidate 009 is the current engineering source and must pass its own build/live-router gates.

## 1.6.3 — AndroidForge Kotlin compile repair (source candidate 007)
- Fixed foreground and background AUTO fallback compile errors by narrowing `McmResult` with exhaustive `when` branches before reading `Failure.code` and `Failure.message`.
- Added regression assertions for both call sites. No product feature or router behavior was added.
- Historical note at time of writing: APK/AAB had not yet been verified. The user subsequently confirmed 007 APK build success on AndroidForge.

# Changelog

## 1.6.3 — End-to-end custom WAN port and service selection reconciliation
- Completed the Advanced-only service selector and WAN port controls while retaining exactly three primary Add Router inputs and the single “Lưu & Kết nối” action.
- Connected the selected mode/port through WebView → Android bridge → connection coordinator → TLS probe → REST/API-SSL authenticated READ_CHECK → Room profile.
- AUTO with no port probes the standard REST 443 and API-SSL 8729 endpoints in parallel; AUTO with a custom WAN port tests both supported transports on that same port; explicit modes test only the chosen service.
- Persists the exact endpoint that passed READ_CHECK and reuses saved mode/port in foreground and background monitoring.
- Added service/port matrix tests and corrected UI contract checks for hidden Advanced controls.

## 1.6.2 — AndroidForge Kotlin nullability build fix

- Refactored RouterOS 7 interface-row conversion into a dedicated, typed parser with explicit null-safe defaults (`type = ""`, `running = false`); rows without an interface name are ignored.
- Added four JUnit regression tests for complete rows, missing nullable fields, missing names, and malformed values.
- Re-checked the native Android Gradle project identity and AndroidForge ZIP-root layout. No Flutter project markers are packaged.
- Version 1.6.2 / versionCode 11. Engineering source / NOT RELEASE until AndroidForge completes unit tests, lint, APK/AAB assembly and artifact verification.

## 1.6.1 — Android DNS recovery for direct Cloud DDNS

- Fixed DNS diagnostics that stopped immediately when Android `InetAddress.getAllByName()` raised `UnknownHostException`.
- Added a shared resolver chain: Android system DNS first, then DNS-over-HTTPS through Google Public DNS and Cloudflare 1.1.1.1 using numeric bootstrap IPs and normal HTTPS certificate/hostname verification.
- Routed TCP diagnostics, RouterOS 7 REST, RouterOS API-SSL and TLS fingerprint inspection through the same resolver. Raw TLS sockets connect to resolved addresses and send the original DDNS hostname using SNI.
- Added explicit resolver-source reporting and unit tests for system success, fallback success and total resolver failure.
- No router, firewall, NAT, DDNS or port configuration changes; still no VPN, relay or WinBox transport.
- Version 1.6.1 / versionCode 10. Engineering source / NOT RELEASE.

## 1.6.0 — Independent service protocol and fully editable WAN port
- Added per-router connectionMode persisted in Room: AUTO, REST_HTTPS, API_SSL.
- Added explicit API-SSL selection for RouterOS 6/7 and explicit REST HTTPS selection for RouterOS 7; invalid ROS6 + REST selection is rejected.
- Kept per-router port fully editable 1..65535 and decoupled it from OS/service; selector changes no longer overwrite a manually entered port; existing profile ports always remain user-owned, even if equal to a default.
- Added Room v3→v4 migration with AUTO default while preserving existing router profiles and history.
- Foreground and WorkManager background reads use the same saved service mode and custom port.
- Added WinBox protocol warning and clarification that TCP 8291 is not an MCM API; TCP reachability is not proof of service compatibility.
- Updated docs, CI/AndroidForge version gates, source verification and tests.
- Engineering source only; full Android Gradle/APK and physical RouterOS acceptance remain required.


## 1.5.1 — Functional connection diagnostics and TLS pin compatibility
- Fixed RouterOS 7 REST connection failures caused by OkHttp hostname verification rejecting self-signed MikroTik certificates even when the exact leaf SHA-256 pin is correct. The pinned certificate remains mandatory on every handshake; mismatched pins are rejected.
- Added an in-app DNS + TCP endpoint diagnostic that displays resolved WAN IPs, port reachability, elapsed time and actionable failure stage before TLS/authentication.
- Improved background monitoring so one unreachable router does not stop checks for the remaining stores; each router's ONLINE/OFFLINE status and concrete error code are persisted.
- Updated Android version to 1.5.1 / versionCode 8.
- Still NOT RELEASE: Gradle/KAPT/APK and real RouterOS 6/7 acceptance remain required.

## 1.5.0 — Direct MikroTik Cloud DDNS design
- Chốt kết nối trực tiếp MCM Android → MikroTik Cloud DDNS → WAN IP public động.
- Không VPN, không VPS/backend, không relay, không router agent.
- Làm rõ yêu cầu WAN public, NAT/port-forward, firewall và giới hạn CGNAT.
- Đồng bộ tài liệu ROS7 REST HTTPS 443 và ROS6 API-SSL 8729; UI tự đổi port mặc định theo RouterOS.
- Giữ nguyên Room, Keystore, monitoring read-only, MNDP LAN discovery và hồ sơ router hiện có.

# Changelog

## 1.6.3 — End-to-end custom WAN port and service selection reconciliation
- Completed the Advanced-only service selector and WAN port controls while retaining exactly three primary Add Router inputs and the single “Lưu & Kết nối” action.
- Connected the selected mode/port through WebView → Android bridge → connection coordinator → TLS probe → REST/API-SSL authenticated READ_CHECK → Room profile.
- AUTO with no port probes the standard REST 443 and API-SSL 8729 endpoints in parallel; AUTO with a custom WAN port tests both supported transports on that same port; explicit modes test only the chosen service.
- Persists the exact endpoint that passed READ_CHECK and reuses saved mode/port in foreground and background monitoring.
- Added service/port matrix tests and corrected UI contract checks for hidden Advanced controls.

## 1.4.0 — Network awareness and discovery correctness

- Corrected MNDP uptime TLV decoding: 32-bit little-endian seconds, rather than UTF-8 text.
- Added IPv6 advertised address parsing and surfaced interface/uptime/IPv6 in LAN discovery results.
- Unknown MNDP TLVs remain safely skippable; added tests for uptime, board/interface, unknown TLVs and truncated payloads.
- Added Android active-network transport and VPN-active indicator with explicit route-validation caveat.
- Added Vietnamese functional architecture covering inventory, monitoring, QR metadata, VPN workflow, read-before-write configuration, audit and release gates.
- Bumped Android version to 1.4.0 / versionCode 6.
- No router configuration writes, VPN provisioning, QR import/export or APK release are claimed.

## 1.3.0 — Multi-Router Manager foundation

- Fixed nullable parsing of RouterOS 7 interface `running` state reported by AndroidForge.
- Added MikroTik MNDP LAN discovery (UDP/5678), bounded scan, TLV parsing and duplicate suppression.
- Added LAN discovery UI; selecting a neighbor prefills the add-router form but requires credentials and independent TLS verification.
- Added MNDP parser tests and updated AndroidForge/CI version gates.
- This remains monitor-only; QR scanner, VPN provisioning and advanced configuration writes are not included.

# Changelog

## 1.6.3 — End-to-end custom WAN port and service selection reconciliation
- Completed the Advanced-only service selector and WAN port controls while retaining exactly three primary Add Router inputs and the single “Lưu & Kết nối” action.
- Connected the selected mode/port through WebView → Android bridge → connection coordinator → TLS probe → REST/API-SSL authenticated READ_CHECK → Room profile.
- AUTO with no port probes the standard REST 443 and API-SSL 8729 endpoints in parallel; AUTO with a custom WAN port tests both supported transports on that same port; explicit modes test only the chosen service.
- Persists the exact endpoint that passed READ_CHECK and reuses saved mode/port in foreground and background monitoring.
- Added service/port matrix tests and corrected UI contract checks for hidden Advanced controls.

## 1.3.0 — Multi-Cloud DDNS rebuild (engineering source)

- Added grouped site/Cloud labels and multiple independent MikroTik endpoint profiles.
- Added router edit workflow; blank password preserves the current encrypted credential, changed password rotates to a new Keystore alias.
- Added Room v1→v2→v3 migrations for site grouping and per-router health/error state.
- Added persisted per-router UNKNOWN/ONLINE/PARTIAL/OFFLINE state and sequential refresh-all.
- Added RouterOS 7 REST and RouterOS 6 API-SSL reads for IP Cloud DDNS, PPPoE active sessions, ARP, DHCP leases and Netwatch.
- Added per-interface RX/TX Mbps history and selector-driven charts without aggregating overlapping bridge/physical counters.
- Added DDNS public IPv4/IPv6 and status presentation; PPPoE active list filters to service=pppoe.
- Bounded concurrent requests to two per monitoring service to limit RouterOS API-SSL pressure.
- Added TLS protocol mismatch classification for Android/BoringSSL `UNSUPPORTED_PROTOCOL` errors.
- Added tests for host validation and TLS error classification; refreshed REST and API-SSL mock data.
- Updated Vietnamese architecture, RouterOS setup, test and build documentation.

This remains an engineering source NOT RELEASE. Android Gradle build, APK assembly, Android device installation and live RouterOS tests must pass before calling it a release.

## 1.0.1 — previous engineering source

- RouterOS 6 API-SSL and RouterOS 7 REST adapters.
- TLS certificate pinning and Android Keystore AES-256-GCM credential storage.
- Packet-loss parser validation and local metric history.


## 1.3.0 — Network visibility expansion

- Added read-only RouterOS 6/7 collection for Bridge Host MAC learning table.
- Added read-only VLAN interface and Bridge VLAN membership snapshots.
- Added conservative on-device snapshot analysis for duplicate IP-to-MAC observations, DHCP/ARP visibility differences, Netwatch DOWN and ICMP loss evidence.
- Added Top 5 interface throughput view based only on measured RX/TX interface counter deltas. This is not represented as per-device bandwidth.
- Kept Direct Cloud DDNS/domain connection, local profile storage and RouterOS 6 API-SSL / RouterOS 7 REST adapters.
- No router configuration mutation, queue creation, traffic-flow activation or firewall changes.

## 1.6.3 — First-connect diagnostics reconciliation
- Added structured DNS failure diagnostics even before a router profile exists.
- Added per-endpoint REST/API-SSL evidence for first-time TLS trust and connection failures: resolver, resolved IPs, selected ports, TCP/TLS timing, fingerprint and failure stage/cause.
- Added authenticated READ_CHECK failure details for both adapters, with password redaction, and surfaced the diagnostic trace in the connection failure dialog.
- Fixed the first-connection observability gap: the app no longer relies on a previously saved router profile to show useful diagnostics. No credentials or Authorization headers are included in diagnostic output.


## 1.6.3 — DDNS TLS pin / diagnostics correction

- Corrected the TLS identity policy: exact SHA-256 leaf pinning is required together with certificate validity and strict SAN/CN hostname matching for the DDNS hostname. A pin never bypasses hostname verification.
- Split persisted trust into separate REST HTTPS and API-SSL pins, each scoped to its exact WAN-facing port, with a Room v7→v8 data-preserving migration.
- Fixed AUTO fallback for RouterOS endpoints whose TLS listener is reachable but whose REST/API service path is unsupported; fallback is limited to protocol/endpoint failures and never bypasses auth or read-permission errors.
- Fixed AUTO authenticated transport fallback across RouterOS 6/7.
- Added richer per-endpoint DNS/TCP/TLS and READ_CHECK diagnostics, plus copy-log UI.


## 1.6.3 — Per-service TLS pinning and AUTO fallback hardening (engineering patch)
- Added independent `www-ssl` and `api-ssl` leaf SHA-256 pin fields and associated WAN-port fields. A pin is reusable only for the same service and exact port.
- Added Room migration v7→v8, mapping a legacy pin only when the previous active transport or fixed protocol mode identifies its service/port. Ambiguous AUTO profiles keep the legacy value but must reconfirm a service-specific pin; profiles and history are preserved.
- Foreground and WorkManager monitoring now select the matching per-service pin and fail closed when no pin exists for that exact endpoint.
- AUTO can retry the alternate service after endpoint/protocol errors (including REST 404/format mismatch); it reuses only an already-confirmed alternate pin for the same service/port, otherwise the operator must confirm a separate fingerprint. It does not fallback after AUTH or READ_DENIED.
- Legacy API login now requires a terminal `!done` response before it is accepted.
- The Android CI workflow source-identity gate now matches the reconciled 005 source identity.
- Full Gradle/JUnit/lint/APK and live Android/RouterOS acceptance remain NOT RUN until the pinned build toolchain and actual hardware are available.

- Đồng bộ AUTO fallback cho foreground refresh/Refresh All và WorkManager; chỉ dùng dịch vụ dự phòng đã được xác nhận pin riêng đúng WAN port, hiển thị PARTIAL/AUTO_FALLBACK và lưu endpoint thực tế.
- Sửa cập nhật trạng thái DNS lỗi ở thao tác refresh một router và worker nền để không giữ trạng thái ONLINE cũ.

- Enforce allowlist read-only ngay trong REST/API-SSL clients; chặn mọi command/method ghi cấu hình, chỉ cho phép đọc dữ liệu và ping có giới hạn (1–100 lần, 200 ms).


## 1.6.3 — Candidate 006: read-only, TLS and response-boundary hardening
- Added a transport-level command allowlist for both REST and API-SSL so non-monitoring configuration commands are rejected before network I/O.
- Restricted ping to 1–100 echo attempts at a fixed 200 ms interval; documented optional RouterOS `test` policy separately from read/API permissions.
- Added API sentence/word/total-response/row limits to constrain untrusted router replies.
- Classified expired/not-yet-valid TLS certificates as `TLS_CERT_VALIDITY` and prevented AUTO from treating certificate validity as a port/protocol error eligible for fallback.
- Rejected manually entered native IPv6 literals while retaining hostname DNS AAAA resolution.
- Engineering source only; full Android Gradle/JUnit/lint/APK and live RouterOS acceptance remain NOT RUN.


## 1.6.3 — Candidate 006 TLS / WebView / response boundaries
- Replaced default hostname-verifier behavior on raw TLS sockets with one strict SAN/IP/CN verifier shared by REST HTTPS, API-SSL and first-use fingerprint inspection. CN fallback is allowed only without DNS SAN; wildcard matching is limited to one left-most label.
- Prevented AUTO profiles with no recorded active transport from reusing an ambiguous legacy TLS pin.
- Added 16 MiB / 10,000-row response limits for REST, as well as streamed body-size checking when Content-Length is absent.
- Blocked non-packaged WebView resources and cleared the password from the WebView input/transient variable after the native request returns.
- Full Android build/APK and live RouterOS acceptance remain not run.

## MCM 1.6.3 candidate 009 — SSH v2 transport

- Rebased on the user-confirmed AndroidForge APK-build-success baseline 007.
- Added an explicit SSH v2 RouterOS CLI transport over DDNS/hostname; existing REST HTTPS and API-SSL paths remain unchanged.
- Added no-password first-use SSH host-key inspection, SHA-256 trust confirmation, strict pin checking before password authentication, and independent Room v9 pin persistence.
- Added a non-PTY SSH exec read-only CLI repository with a fixed command allowlist and sequential reads.
- Added SSH foreground/background core monitoring; SSH does not silently fall back from AUTO.
- Documented software/protocol research, including tik4net, JSch, RouterOS SSH, SNMPv3 and the transports deliberately excluded.
- Candidate 009 still requires AndroidForge build and live RouterOS validation; no APK success is claimed for 008.


## 1.6.3 — Android resource merge repair (candidate 010)
- Diagnosed candidate 009 AndroidForge failure: JSch 2.28.8 and Bouncy Castle 1.86 collide on `META-INF/versions/15/OSGI-INF/MANIFEST.MF`.
- Replaced the too-narrow `versions/9` exclusion with `META-INF/versions/**/OSGI-INF/MANIFEST.MF` so all versioned copies of that OSGi manifest metadata are excluded from Android packaging.
- Updated source preflight to require the wildcard rule. No app logic or dependency versions changed.
- Candidate 010 remains source-not-release until AndroidForge confirms APK/AAB builds.


## 1.6.3 — Candidate 011: integrated deep SSH diagnostics
- Added protocol-aware SSH diagnostics with DNS, per-IP TCP timing, local socket address, server banner, SSH key exchange and host-key fingerprint stages.
- Failures now identify the exact last completed stage; TCP timeout explicitly states that SSH handshake and authentication were not reached.
- Prevented AUTO/REST/API-SSL from probing custom WAN port 22; explicit SSH v2 selection is required.
- Added Advanced UI deep-diagnostic action, structured/copyable JSON, and app-private rolling diagnostic history.
- Diagnostic traces exclude passwords and private credentials. Candidate 011 remains source-not-release pending AndroidForge build and live router verification.
