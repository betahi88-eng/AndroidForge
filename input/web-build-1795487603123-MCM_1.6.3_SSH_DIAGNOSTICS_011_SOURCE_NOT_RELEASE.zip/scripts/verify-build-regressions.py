#!/usr/bin/env python3
"""Guard against the exact AndroidForge regressions found in historical logs."""
from pathlib import Path
import re
ROOT = Path(__file__).resolve().parents[1]
def read(rel):
    p = ROOT / rel
    if not p.is_file():
        raise SystemExit(f"FAIL: missing {rel}")
    return p.read_text(encoding="utf-8")
checks = []
def require(condition, message):
    if not condition:
        raise SystemExit("FAIL: " + message)
    checks.append(message)

dns = read("app/src/main/java/com/multicloud/mcm/DohDnsResolver.kt")
ros7 = read("app/src/main/java/com/multicloud/mcm/RouterOs7Client.kt")
coordinator = read("app/src/main/java/com/multicloud/mcm/RouterConnectionCoordinator.kt")
mode = read("app/src/main/java/com/multicloud/mcm/RouterServiceMode.kt")
bridge = read("app/src/main/java/com/multicloud/mcm/McmJavascriptBridge.kt")
ui = read("app/src/main/assets/www/router-ui.js")
html = read("app/src/main/assets/www/index.html")
db = read("app/src/main/java/com/multicloud/mcm/data/McmDatabase.kt")
monitor = read("app/src/main/java/com/multicloud/mcm/McmMonitoringService.kt")
worker = read("app/src/main/java/com/multicloud/mcm/McmBackgroundWorker.kt")
ssh = read("app/src/main/java/com/multicloud/mcm/SshRouterOsClient.kt")
ssh_repo = read("app/src/main/java/com/multicloud/mcm/SshRouterOsRepository.kt")
ssh_coord = read("app/src/main/java/com/multicloud/mcm/SshConnectionCoordinator.kt")
ssh_diag = read("app/src/main/java/com/multicloud/mcm/McmSshEndpointDiagnostics.kt")

require(".dns(object : Dns {" in dns, "DoH resolver uses valid OkHttp Dns object expression")
require(".dns(object : Dns {" in ros7, "RouterOS 7 client uses valid OkHttp Dns object expression")
require("selected.port" not in coordinator, "historical unresolved selected.port expression is absent")
require("val selectedPort = successful.port" in coordinator, "persisted port comes from the authenticated successful probe")
require("fun probePorts(requestedPort: Int)" in mode, "AUTO/custom/explicit service port mapping exists")
require("requestedPort: Int" in coordinator and "serviceMode.probePorts(requestedPort)" in coordinator, "coordinator consumes requested WAN port end-to-end")
require("port: Int, connectionMode: String" in bridge and "start(host, username, password, port, connectionMode)" in bridge, "native bridge forwards WAN port and service mode")
require('nativeCall("connectRouter", host, username, password, port, mode)' in ui, "Web UI sends WAN port and service mode to native bridge")
require('id="routerPort"' in html and 'id="routerConnectionMode"' in html and 'id="routerAdvancedOptions"' in html, "Advanced UI exposes port/service selector")
require("MIGRATION_7_8" in db and "tlsRestPinPort" in db and "tlsApiSslPinPort" in db, "Room v8 migration separates service pins by exact port")
require("MIGRATION_8_9" in db and "sshHostKeySha256Pin" in db and "sshPinPort" in db, "Room v9 stores SSH host-key pin independently from TLS pins")
require('implementation("com.github.mwiede:jsch:2.28.8")' in read("app/build.gradle.kts"), "Android SSH transport uses maintained JSch fork")
require('setConfig("StrictHostKeyChecking", "yes")' in ssh and 'setConfig("PreferredAuthentications", "none")' in ssh, "SSH host key is checked before password authentication")
require("READ_ONLY_COMMANDS" in ssh and "SSH_COMMAND_BLOCKED" in ssh, "SSH CLI commands are fixed allowlisted and mutation paths rejected")
require("ChannelExec" in ssh and 'openChannel("exec")' in ssh and "ChannelShell" not in ssh, "RouterOS SSH uses non-PTY exec channels")
require("ssh-rsa" not in ssh and "group14-sha1" not in ssh and "hmac-sha1" not in ssh and "3des" not in ssh, "SSH transport does not silently downgrade to weak algorithms")
require("setPassword(password)" in ssh and 'setConfig("PreferredAuthentications", "none")' in ssh, "SSH host-key inspection path does not set/send password")
require("sshConnectionCoordinator.start" in bridge and "sshConnectionCoordinator.confirm" in bridge, "Native bridge routes SSH trust/auth flow independently")
require("hasPortProtocolMismatch" in mode and "PROTOCOL_PORT_MISMATCH" in bridge, "port 22 cannot be mislabeled as AUTO/REST/API-SSL")
require('"SSH"' in ssh_diag and '"TCP_CONNECT_TIMEOUT"' in ssh_diag and '"SSH_BANNER"' in ssh_diag, "SSH diagnostics separate TCP, banner and key-exchange stages")
require('"NOT_APPLICABLE_FOR_SSH"' in ssh_diag and '"passwordSent", false' in ssh_diag, "SSH preflight does not invent TLS or send credentials")
require("inspectResolved" in ssh_coord and "diagnostics" in ssh_coord, "SSH connect flow returns staged diagnostic trace")
require("diagnoseConnection" in bridge and "diagnosticHistory" in bridge, "native bridge exposes deep diagnostic and retained trace history")
require('id="runDeepDiagnosticBtn"' in html and "runDeepDiagnostic" in ui, "Advanced UI provides integrated deep diagnostic action")
require("networkContext" in bridge and "mcm_diagnostic_traces" in bridge, "diagnostic traces retain network type and bounded app-private history")
require("SshRouterOsRepository(ssh)" in monitor and "SshRouterOsClient" in worker, "Foreground and background monitoring support pinned SSH transport")
require("var endpointPort = router.port" in monitor and "var endpointPort = router.port" in worker, "foreground and background reuse saved endpoint port")
def alternate_code_is_failure_narrowed(source):
    start = source.find("when (alternateResult)")
    if start < 0:
        return False
    success_branch = source.find("is McmResult.Success ->", start)
    failure_branch = source.find("is McmResult.Failure ->", start)
    code_read = source.find("alternateResult.code", start)
    return success_branch >= 0 and failure_branch > success_branch and code_read > failure_branch

require(alternate_code_is_failure_narrowed(worker), "background fallback reads alternateResult.code only inside the sealed Failure branch")
require(alternate_code_is_failure_narrowed(monitor), "foreground fallback reads alternateResult.code only inside the sealed Failure branch")
print(f"Historical build regression guards: PASS ({len(checks)} assertions)")
for item in checks:
    print(" - " + item)
