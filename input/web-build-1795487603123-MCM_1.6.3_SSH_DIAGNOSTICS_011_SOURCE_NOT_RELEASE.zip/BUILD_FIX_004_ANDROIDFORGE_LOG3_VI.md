# Build fix 004 — AndroidForge log (3)

## Exact failure
Both `assembleDebug` and `assembleRelease`, and also `bundleDebug`, fail at `merge*JavaResource` because JSch 2.28.8 and Bouncy Castle 1.86 both contain:

`META-INF/versions/15/OSGI-INF/MANIFEST.MF`

## Why candidate 009 did not fix it
Candidate 009 excluded only:

`META-INF/versions/9/OSGI-INF/MANIFEST.MF`

That exact path does not match the `versions/15` entry reported by AndroidForge.

## Candidate 010 change
`app/build.gradle.kts` now excludes:

`META-INF/versions/**/OSGI-INF/MANIFEST.MF`

The glob covers the observed version 15 entry and the previously observed version 9 entry. The source preflight asserts the wildcard exclusion is present.

## Scope
Only Android packaging metadata filtering and source verification/documentation changed. JSch/Bouncy Castle versions and app runtime code were not changed.

## Verification boundary
This source archive can be checked for syntax, project layout and ZIP integrity locally. A successful Android APK/AAB build must be confirmed by AndroidForge; this workspace does not claim to have run that build.
