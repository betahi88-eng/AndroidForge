package com.multicloud.mcm

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RouterOsSshCliParserTest {
    @Test fun parsesSystemResourceWithoutInventingMissingValues() {
        val parsed = RouterOsSshCliParser.parseSystemResource(
            "version: 7.16.2 (stable)\nuptime: 1d2h\ncpu-load: 7%\nfree-memory: 512.0MiB\ntotal-memory: 1.0GiB"
        ) as McmResult.Success
        assertEquals("7.16.2 (stable)", parsed.value.version)
        assertEquals(7, parsed.value.cpuLoadPercent)
        assertEquals(536_870_912L, parsed.value.freeMemoryBytes)
        assertEquals(1_073_741_824L, parsed.value.totalMemoryBytes)
        val partial = RouterOsSshCliParser.parseSystemResource("version: 7.16.2\nuptime: 1d") as McmResult.Success
        assertNull(partial.value.cpuLoadPercent)
        assertNull(partial.value.freeMemoryBytes)
    }

    @Test fun parsesRouterOsDetailRowsAndRunningFlags() {
        val rows = RouterOsSshCliParser.parseRows(
            "Flags: X - disabled, R - running\n 0 R name=\"ether1 WAN\" type=ether mtu=1500\n 1 X name=ether2 type=ether"
        )
        assertEquals(2, rows.size)
        assertEquals("ether1 WAN", rows[0]["name"])
        assertEquals("R", rows[0]["flags"])
        assertEquals("X", rows[1]["flags"])
    }

    @Test fun parserCapsLargeTablesAtSafetyLimitPlusOneForExplicitRejection() {
        val raw = (0..10_000).joinToString("\n") { index -> " $index name=ether$index type=ether" }
        assertEquals(10_001, RouterOsSshCliParser.parseRows(raw).size)
    }

    @Test fun recognizesEmptyTablesButRejectsUnparseableNonEmptyOutput() {
        assertTrue(RouterOsSshCliParser.isEmptyTable(""))
        assertTrue(RouterOsSshCliParser.isEmptyTable("no items"))
        assertTrue(RouterOsSshCliParser.parseRows("unrecognized output").isEmpty())
    }
}
