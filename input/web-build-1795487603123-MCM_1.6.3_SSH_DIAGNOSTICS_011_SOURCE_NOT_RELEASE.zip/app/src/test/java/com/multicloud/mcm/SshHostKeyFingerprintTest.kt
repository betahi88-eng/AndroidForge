package com.multicloud.mcm

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test
import java.security.MessageDigest
import java.util.Base64

class SshHostKeyFingerprintTest {
    @Test fun fingerprintUsesOpenSshSha256Base64WithoutPadding() {
        val key = "router-host-key".toByteArray()
        val expected = "SHA256:" + Base64.getEncoder().withoutPadding()
            .encodeToString(MessageDigest.getInstance("SHA-256").digest(key))
        assertEquals(expected, SshRouterOsClient.fingerprintFromKey(key))
    }

    @Test fun normalizesSha256PrefixAndRejectsMalformedPins() {
        val key = "router-host-key".toByteArray()
        val pin = SshRouterOsClient.fingerprintFromKey(key)
        assertEquals(pin, SshRouterOsClient.normalizeHostKeyFingerprint(pin))
        assertEquals(pin, SshRouterOsClient.normalizeHostKeyFingerprint(pin.removePrefix("SHA256:")))
        assertThrows(IllegalArgumentException::class.java) {
            SshRouterOsClient.normalizeHostKeyFingerprint("MD5:00:11")
        }
    }
}
