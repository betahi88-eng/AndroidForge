package com.multicloud.mcm

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Test
import java.net.InetAddress

class SshReadOnlyPolicyTest {
    private fun client() = SshRouterOsClient(
        host = "router.example.net",
        port = 22,
        username = "monitor",
        password = "unused-before-connect",
        expectedHostKeySha256 = "SHA256:" + "A".repeat(43),
        resolvedAddresses = listOf(InetAddress.getByName("127.0.0.1"))
    )

    @Test fun rejectsMutationAndCommandInjectionBeforeOpeningAnSshChannel() = runBlocking {
        val ssh = client()
        listOf(
            "/system/identity/set name=owned",
            "/system/resource/print; /system/reboot",
            "/ip/firewall/filter/remove [find]",
            "/export",
            "/system/reboot"
        ).forEach { command ->
            val result = ssh.executeReadOnly(command) as McmResult.Failure
            assertEquals("SSH_COMMAND_BLOCKED", result.code)
        }
    }

    @Test fun allowedReadCommandStillRequiresAnAuthenticatedSession() = runBlocking {
        val result = client().executeReadOnly("/system/resource/print detail without-paging") as McmResult.Failure
        assertEquals("SSH_NOT_CONNECTED", result.code)
    }
}
