package com.multicloud.mcm

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.net.InetAddress
import java.net.ServerSocket
import kotlin.concurrent.thread

class SshEndpointDiagnosticsContractTest {
    @Test fun sshModeNeverCreatesRestOrApiSslEndpoints() {
        val ports = RouterServiceMode.SSH.probePorts(22)
        assertNull(ports.restPort)
        assertNull(ports.apiSslPort)
    }

    @Test fun autoModeCustomPortIsNotAnSshSelection() {
        val ports = RouterServiceMode.AUTO.probePorts(22)
        assertEquals(22, ports.restPort)
        assertEquals(22, ports.apiSslPort)
        assertTrue(RouterServiceMode.AUTO.hasPortProtocolMismatch(22))
        assertFalse(RouterServiceMode.SSH.hasPortProtocolMismatch(22))
    }

    @Test fun identifiesNonSshServiceFromBannerWithoutSendingCredentials() = runBlocking {
        val server = ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"))
        val serverThread = thread(isDaemon = true) {
            runCatching { server.accept().use { socket ->
                socket.getOutputStream().write("HTTP/1.1 200 OK\r\n\r\n".toByteArray())
                socket.getOutputStream().flush()
            } }
        }
        try {
            val result = McmSshEndpointDiagnostics().inspect("127.0.0.1", server.localPort, "mcm-test")
            assertEquals("NON_SSH_SERVICE_ON_PORT", result.optString("code"))
            assertEquals("SSH", result.optString("protocol"))
            assertEquals("NOT_RUN", result.optString("sshKeyExchange"))
            assertFalse(result.optBoolean("passwordSent"))
            assertFalse(result.optBoolean("authenticationAttempted"))
        } finally {
            server.close()
            serverThread.join(1_000)
        }
    }
}
