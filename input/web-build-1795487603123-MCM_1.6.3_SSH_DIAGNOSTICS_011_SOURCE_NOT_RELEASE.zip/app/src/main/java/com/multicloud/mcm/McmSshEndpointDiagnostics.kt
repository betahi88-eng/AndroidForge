package com.multicloud.mcm

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.ConnectException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException

/** Protocol-aware, read-only SSH endpoint test. It never sends a password or changes RouterOS. */
class McmSshEndpointDiagnostics {
    suspend fun inspect(rawHost: String, port: Int, username: String): JSONObject = withContext(Dispatchers.IO) {
        val host = RouterHostValidator.normalize(rawHost)
        require(port in 1..65535) { "Port SSH phải từ 1 đến 65535." }
        val started = System.currentTimeMillis()
        val resolution = try {
            RouterDnsResolver.resolveDetailed(host)
        } catch (error: Exception) {
            return@withContext report(host, port, "DNS", "DNS_FAILED",
                "Không phân giải được hostname. Chưa thử TCP, SSH handshake hoặc đăng nhập.", started)
                .put("dns", JSONObject().put("source", "FAILED").put("addresses", JSONArray()))
                .put("dnsError", safe(error))
        }
        inspectResolvedInternal(host, port, username, resolution, started)
    }

    suspend fun inspectResolved(
        host: String, port: Int, username: String, resolution: RouterDnsResolver.Resolution
    ): JSONObject = withContext(Dispatchers.IO) {
        inspectResolvedInternal(RouterHostValidator.normalize(host), port, username, resolution, System.currentTimeMillis())
    }

    private fun inspectResolvedInternal(
        host: String, port: Int, username: String, resolution: RouterDnsResolver.Resolution, started: Long
    ): JSONObject {
        require(port in 1..65535) { "Port SSH phải từ 1 đến 65535." }
        val addressesJson = JSONArray().apply { resolution.addresses.forEach { put(it.hostAddress ?: "") } }
        var lastFailure: Throwable? = null
        var selectedAddress: InetAddress? = null
        var localAddress: String? = null
        var tcpMs = 0L
        var bannerMs = 0L
        var banner: String? = null
        var tcpConnected = false
        var tcpFailureCode = "TCP_UNREACHABLE"
        val addressAttempts = JSONArray()
        for (address in resolution.addresses) {
            val attemptStart = System.currentTimeMillis()
            try {
                Socket().use { socket ->
                    socket.connect(InetSocketAddress(address, port), TCP_TIMEOUT_MS)
                    tcpMs = System.currentTimeMillis() - attemptStart
                    tcpConnected = true
                    selectedAddress = address
                    localAddress = socket.localAddress?.hostAddress
                    socket.soTimeout = BANNER_TIMEOUT_MS
                    val bannerStart = System.currentTimeMillis()
                    val line = readBanner(socket)
                    bannerMs = System.currentTimeMillis() - bannerStart
                    banner = line
                    addressAttempts.put(JSONObject().put("ip", address.hostAddress ?: "")
                        .put("tcp", "CONNECTED").put("tcpMs", tcpMs)
                        .put("localSocketAddress", localAddress ?: JSONObject.NULL)
                        .put("banner", line.take(160)).put("bannerMs", bannerMs))
                }
                break
            } catch (error: Throwable) {
                lastFailure = error
                tcpMs = System.currentTimeMillis() - attemptStart
                tcpFailureCode = when {
                    tcpConnected && error is SocketTimeoutException -> "SSH_BANNER_TIMEOUT"
                    tcpConnected -> "SSH_BANNER_READ_FAILED"
                    error is SocketTimeoutException -> "TCP_CONNECT_TIMEOUT"
                    error is ConnectException -> "TCP_CONNECTION_REFUSED"
                    else -> "TCP_CONNECT_FAILED"
                }
                addressAttempts.put(JSONObject().put("ip", address.hostAddress ?: "")
                    .put("tcp", tcpFailureCode).put("elapsedMs", tcpMs)
                    .put("error", safe(error)))
            }
        }
        val dns = JSONObject().put("source", resolution.source).put("addresses", addressesJson)
        if (!tcpConnected) {
            val timeout = tcpFailureCode == "TCP_CONNECT_TIMEOUT"
            return report(host, port, "TCP_CONNECT", tcpFailureCode,
                if (timeout) "DNS thành công nhưng không hoàn tất bắt tay TCP tới endpoint SSH. SSH banner, SSH key exchange và xác thực đều CHƯA chạy. Đây là lỗi trước giao thức; log phía điện thoại không thể tự xác định chính xác firewall/NAT/ISP hay tuyến mạng nào đang loại gói." 
                else "DNS thành công nhưng TCP không mở được. SSH banner, key exchange và xác thực đều CHƯA chạy.", started)
                .put("dns", dns).put("addressAttempts", addressAttempts)
                .put("targetIp", JSONObject.NULL).put("localSocketAddress", JSONObject.NULL)
                .put("tcpMs", tcpMs).put("bannerMs", 0).put("sshBanner", JSONObject.NULL)
                .put("tcpError", lastFailure?.let(::safe) ?: tcpFailureCode)
                .put("tcpAttemptCode", tcpFailureCode)
                .put("sshKeyExchange", "NOT_RUN").put("hostKeyFingerprint", JSONObject.NULL)
                .put("passwordSent", false).put("authenticationAttempted", false)
                .put("tls", "NOT_APPLICABLE_FOR_SSH")
                .put("confirmed", JSONArray().put("DNS_RESOLVED").put("TCP_NOT_ESTABLISHED"))
                .put("possibleCauses", JSONArray().put("WAN/input firewall silently drops TCP 22")
                    .put("port-forward or destination NAT does not map TCP 22 to this router")
                    .put("ISP/upstream network filters inbound TCP 22")
                    .put("DDNS resolves to an address that is not the current reachable WAN endpoint")
                    .put("return route or upstream routing drops the TCP handshake"))
                .put("notProvableFromClient", JSONArray().put("Which firewall/NAT/ISP hop drops the SYN")
                    .put("Whether the RouterOS SSH service receives the connection attempt"))
        }
        val bannerText = banner.orEmpty()
        if (!bannerText.startsWith("SSH-2.0-") && !bannerText.startsWith("SSH-1.99-")) {
            val looksTls = bannerText.startsWith("TLS_RECORD")
            val code = if (bannerText == "BANNER_TIMEOUT") "SSH_BANNER_TIMEOUT" else "NON_SSH_SERVICE_ON_PORT"
            return report(host, port, "SSH_BANNER", code,
                if (looksTls) "TCP mở nhưng endpoint trả dữ liệu giống TLS, không phải SSH banner. Có thể đang trỏ nhầm cổng/dịch vụ." 
                else "TCP mở nhưng phản hồi không phải SSH-2.0/SSH-1.99 banner. Cổng có thể chuyển tiếp tới dịch vụ khác hoặc SSH banner bị chặn/trì hoãn.", started)
                .put("dns", dns).put("addressAttempts", addressAttempts)
                .put("targetIp", selectedAddress?.hostAddress ?: JSONObject.NULL)
                .put("localSocketAddress", localAddress ?: JSONObject.NULL).put("tcpMs", tcpMs)
                .put("bannerMs", bannerMs).put("sshBanner", bannerText.take(160))
                .put("sshKeyExchange", "NOT_RUN").put("hostKeyFingerprint", JSONObject.NULL)
                .put("passwordSent", false).put("authenticationAttempted", false)
                .put("tls", "NOT_APPLICABLE_FOR_SSH")
        }
        val keyExchangeStarted = System.currentTimeMillis()
        try {
            val fingerprint = SshRouterOsClient.inspectHostKey(host, port, username, resolution.addresses)
            return report(host, port, "SSH_HOST_KEY", "SSH_KEY_EXCHANGE_OK",
                "TCP và SSH key exchange thành công; đã nhận host key. Chưa gửi password và chưa chạy lệnh RouterOS.", started)
                .put("ok", true).put("dns", dns).put("addressAttempts", addressAttempts)
                .put("targetIp", selectedAddress?.hostAddress ?: JSONObject.NULL)
                .put("localSocketAddress", localAddress ?: JSONObject.NULL).put("tcpMs", tcpMs)
                .put("bannerMs", bannerMs).put("sshBanner", bannerText.take(160))
                .put("sshKeyExchange", "OK").put("sshKeyExchangeMs", System.currentTimeMillis() - keyExchangeStarted)
                .put("hostKeyFingerprint", fingerprint).put("passwordSent", false)
                .put("authenticationAttempted", false).put("tls", "NOT_APPLICABLE_FOR_SSH")
        } catch (error: Throwable) {
            val root = rootCause(error)
            val code = when {
                root is SocketTimeoutException -> "SSH_KEY_EXCHANGE_TIMEOUT"
                root.message.orEmpty().contains("algorithm negotiation", true) -> "SSH_ALGORITHM_UNSUPPORTED"
                root.message.orEmpty().contains("host key", true) -> "SSH_HOSTKEY_ERROR"
                else -> "SSH_KEY_EXCHANGE_FAILED"
            }
            return report(host, port, "SSH_KEY_EXCHANGE", code,
                "TCP và SSH banner thành công nhưng key exchange không hoàn tất. Chưa gửi password; cần xem chi tiết lỗi/thuật toán.", started)
                .put("dns", dns).put("addressAttempts", addressAttempts)
                .put("targetIp", selectedAddress?.hostAddress ?: JSONObject.NULL)
                .put("localSocketAddress", localAddress ?: JSONObject.NULL).put("tcpMs", tcpMs)
                .put("bannerMs", bannerMs).put("sshBanner", bannerText.take(160))
                .put("sshKeyExchange", "FAILED").put("sshKeyExchangeMs", System.currentTimeMillis() - keyExchangeStarted)
                .put("hostKeyFingerprint", JSONObject.NULL).put("sshError", safe(root))
                .put("passwordSent", false).put("authenticationAttempted", false)
                .put("tls", "NOT_APPLICABLE_FOR_SSH")
        }
    }

    private fun readBanner(socket: Socket): String {
        val out = StringBuilder()
        val input = socket.getInputStream()
        while (out.length < MAX_BANNER_CHARS) {
            val value = input.read()
            if (value < 0) break
            if (value == '\n'.code) break
            if (value != '\r'.code) out.append(if (value in 32..126) value.toChar() else ' ')
            if (out.length == 1 && value == 0x16) return "TLS_RECORD"
        }
        return out.toString().ifBlank { "BANNER_TIMEOUT" }
    }

    private fun report(host: String, port: Int, stage: String, code: String, message: String, started: Long) =
        JSONObject().put("ok", false).put("protocol", "SSH").put("transport", "TCP")
            .put("host", host).put("port", port).put("stage", stage).put("code", code)
            .put("message", message).put("elapsedMs", System.currentTimeMillis() - started)
            .put("timestampEpochMs", System.currentTimeMillis())

    private fun rootCause(error: Throwable): Throwable {
        var current = error
        while (current.cause != null && current.cause !== current) current = current.cause!!
        return current
    }

    private fun safe(error: Throwable): String = (error.message ?: error.javaClass.simpleName)
        .replace(Regex("[\\r\\n\\t]+"), " ").take(300)


    companion object {
        private const val TCP_TIMEOUT_MS = 5_000
        private const val BANNER_TIMEOUT_MS = 2_000
        private const val MAX_BANNER_CHARS = 255
    }
}
