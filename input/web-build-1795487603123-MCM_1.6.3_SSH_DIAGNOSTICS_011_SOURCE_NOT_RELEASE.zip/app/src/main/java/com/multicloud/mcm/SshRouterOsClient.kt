package com.multicloud.mcm

import com.jcraft.jsch.ChannelExec
import com.jcraft.jsch.HostKey
import com.jcraft.jsch.HostKeyRepository
import com.jcraft.jsch.JSch
import com.jcraft.jsch.JSchException
import com.jcraft.jsch.Session
import com.jcraft.jsch.SocketFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.Closeable
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.security.MessageDigest
import java.util.Base64
import java.util.concurrent.TimeUnit

/**
 * RouterOS SSH v2 transport. RouterOS SSH server does not provide a PTY, so each
 * allowlisted one-line CLI read is sent through an SSH exec channel. Host identity
 * is pinned independently from TLS pins.
 */
internal class SshRouterOsClient(
    private val host: String,
    private val port: Int,
    private val username: String,
    private val password: String,
    private val expectedHostKeySha256: String,
    private val resolvedAddresses: List<InetAddress>,
    private val connectTimeoutMs: Int = 10_000,
    private val commandTimeoutMs: Long = 12_000
) : Closeable {
    private var session: Session? = null
    private var activeChannel: ChannelExec? = null

    suspend fun connect(): McmResult<Unit> = withContext(Dispatchers.IO) {
        try {
            require(host.isNotBlank() && username.isNotBlank() && password.isNotEmpty())
            require(port in 1..65535 && resolvedAddresses.isNotEmpty())
            val jsch = newJSch()
            val repo = PinnedHostKeyRepository(host, expectedHostKeySha256)
            val opened = jsch.getSession(username, host, port)
            opened.setHostKeyRepository(repo)
            opened.setSocketFactory(addressSocketFactory(resolvedAddresses, connectTimeoutMs))
            opened.setPassword(password)
            opened.setConfig("StrictHostKeyChecking", "yes")
            opened.setConfig("PreferredAuthentications", "password,keyboard-interactive")
            configureStrongAlgorithms(opened)
            opened.connect(connectTimeoutMs)
            session = opened
            McmResult.Success(Unit)
        } catch (error: Exception) {
            close()
            McmResult.Failure(classify(error), safeMessage(error))
        }
    }

    suspend fun readSystemResource(): McmResult<SystemResource> = withContext(Dispatchers.IO) {
        when (val raw = executeReadOnly("/system/resource/print detail without-paging")) {
            is McmResult.Failure -> raw
            is McmResult.Success -> RouterOsSshCliParser.parseSystemResource(raw.value)
        }
    }

    suspend fun executeReadOnly(command: String): McmResult<String> = withContext(Dispatchers.IO) {
        if (command !in READ_ONLY_COMMANDS) {
            return@withContext McmResult.Failure("SSH_COMMAND_BLOCKED", "Lệnh SSH không nằm trong danh sách đọc an toàn của MCM.")
        }
        val current = session ?: return@withContext McmResult.Failure("SSH_NOT_CONNECTED", "Phiên SSH chưa được xác thực.")
        var channel: ChannelExec? = null
        try {
            channel = current.openChannel("exec") as ChannelExec
            activeChannel = channel
            channel.setCommand(command) // Exact allowlist match above; one-line command, no PTY.
            val errorOutput = BoundedByteArrayOutputStream(MAX_OUTPUT_BYTES)
            channel.setErrStream(errorOutput)
            val stream = channel.inputStream
            channel.connect(connectTimeoutMs)
            val standardOutput = readExecOutput(stream, channel, commandTimeoutMs)
            val errorText = errorOutput.toString(Charsets.UTF_8.name())
            if (standardOutput.toByteArray().size + errorOutput.size() > MAX_OUTPUT_BYTES) {
                throw IllegalStateException("SSH response exceeded the MCM combined output limit")
            }
            val result = listOf(standardOutput.trim(), errorText.trim()).filter(String::isNotBlank).joinToString("\n").trim()
            val exitStatus = channel.exitStatus
            when {
                result.contains("not enough permissions", true) || result.contains("permission denied", true) ->
                    McmResult.Failure("PERMISSION", result.take(240))
                result.contains("input does not match", true) || result.contains("syntax error", true) ||
                    result.contains("bad command name", true) || result.contains("expected end of command", true) ->
                    McmResult.Failure("SSH_COMMAND_ERROR", result.take(240))
                exitStatus > 0 -> McmResult.Failure("SSH_COMMAND_EXIT_$exitStatus", result.take(240).ifBlank { "RouterOS SSH command failed." })
                else -> McmResult.Success(result)
            }
        } catch (error: Exception) {
            if (error is java.net.SocketTimeoutException || error is IllegalStateException) close()
            McmResult.Failure(classify(error), safeMessage(error))
        } finally {
            runCatching { channel?.disconnect() }
            if (activeChannel === channel) activeChannel = null
        }
    }

    private fun readExecOutput(stream: InputStream, channel: ChannelExec, timeoutMs: Long): String {
        val buffer = ByteArrayOutputStream()
        val bytes = ByteArray(4096)
        val deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(timeoutMs)
        while (System.nanoTime() < deadline) {
            val available = runCatching { stream.available() }.getOrDefault(0)
            if (available > 0) {
                val count = stream.read(bytes, 0, minOf(bytes.size, available))
                if (count < 0) break
                buffer.write(bytes, 0, count)
                if (buffer.size() > MAX_OUTPUT_BYTES) throw IllegalStateException("SSH response exceeded the MCM output limit")
            } else if (channel.isClosed) {
                // Drain any bytes that arrived with SSH_MSG_CHANNEL_CLOSE before returning.
                val remaining = stream.available()
                if (remaining <= 0) return stripTerminal(buffer.toString(Charsets.UTF_8.name()))
            } else {
                Thread.sleep(20)
            }
        }
        if (channel.isClosed) return stripTerminal(buffer.toString(Charsets.UTF_8.name()))
        throw java.net.SocketTimeoutException("RouterOS SSH exec command timed out after ${timeoutMs}ms")
    }

    override fun close() {
        runCatching { activeChannel?.disconnect() }
        runCatching { session?.disconnect() }
        activeChannel = null
        session = null
    }

    companion object {
        private const val MAX_OUTPUT_BYTES = 1_500_000
        private val READ_ONLY_COMMANDS = setOf(
            "/system/resource/print detail without-paging",
            "/interface/print detail without-paging",
            "/interface/print stats detail without-paging",
            "/ip/cloud/print detail without-paging",
            "/ppp/active/print detail without-paging",
            "/ip/arp/print detail without-paging",
            "/ip/dhcp-server/lease/print detail without-paging",
            "/tool/netwatch/print detail without-paging",
            "/interface/bridge/host/print detail without-paging",
            "/interface/vlan/print detail without-paging",
            "/interface/bridge/vlan/print detail without-paging"
        )

        fun inspectHostKey(
            host: String,
            port: Int,
            username: String,
            addresses: List<InetAddress>,
            timeoutMs: Int = 10_000
        ): String {
            val jsch = newJSch()
            val repo = PinnedHostKeyRepository(host, null)
            val probe = jsch.getSession(username, host, port)
            probe.setHostKeyRepository(repo)
            probe.setSocketFactory(addressSocketFactory(addresses, timeoutMs))
            configureStrongAlgorithms(probe)
            probe.setConfig("StrictHostKeyChecking", "no")
            probe.setConfig("PreferredAuthentications", "none")
            var handshakeFailure: Exception? = null
            try {
                probe.connect(timeoutMs)
            } catch (error: Exception) {
                // RouterOS normally rejects the deliberately empty userauth request. The host key
                // was already received and captured during key exchange, before any password is sent.
                handshakeFailure = error
            } finally {
                runCatching { probe.disconnect() }
            }
            return try { repo.fingerprint() } catch (error: Exception) {
                val cause = handshakeFailure ?: error
                throw IllegalStateException("SSH host-key inspection failed: ${cause.message ?: cause.javaClass.simpleName}", cause)
            }
        }

        fun fingerprintFromKey(key: ByteArray): String = "SHA256:" + Base64.getEncoder().withoutPadding()
            .encodeToString(MessageDigest.getInstance("SHA-256").digest(key))

        fun normalizeHostKeyFingerprint(value: String): String {
            val normalized = value.trim().removePrefix("SHA256:").removeSuffix("=")
            require(normalized.matches(Regex("[A-Za-z0-9+/]{43}"))) { "SSH SHA-256 fingerprint không hợp lệ." }
            return "SHA256:$normalized"
        }


        private fun configureStrongAlgorithms(session: Session) {
            session.setConfig("server_host_key", "ssh-ed25519,rsa-sha2-512,rsa-sha2-256")
            session.setConfig("kex", "curve25519-sha256,curve25519-sha256@libssh.org,ecdh-sha2-nistp256,ecdh-sha2-nistp384,diffie-hellman-group14-sha256")
            session.setConfig("cipher.c2s", "aes256-gcm@openssh.com,aes128-gcm@openssh.com,aes256-ctr,aes128-ctr")
            session.setConfig("cipher.s2c", "aes256-gcm@openssh.com,aes128-gcm@openssh.com,aes256-ctr,aes128-ctr")
            session.setConfig("mac.c2s", "hmac-sha2-512,hmac-sha2-256")
            session.setConfig("mac.s2c", "hmac-sha2-512,hmac-sha2-256")
        }

        private fun newJSch(): JSch {
            // Android's provider set varies by API level. Force the bundled BC implementation for Ed25519/XDH.
            JSch.setConfig("ssh-ed25519", "com.jcraft.jsch.bc.SignatureEd25519")
            JSch.setConfig("xdh", "com.jcraft.jsch.bc.XDH")
            return JSch()
        }

        private fun addressSocketFactory(addresses: List<InetAddress>, timeoutMs: Int): SocketFactory = object : SocketFactory {
            override fun createSocket(host: String, port: Int): Socket {
                var last: Exception? = null
                addresses.forEach { address ->
                    val socket = Socket()
                    try {
                        socket.connect(InetSocketAddress(address, port), timeoutMs)
                        socket.soTimeout = timeoutMs
                        return socket
                    } catch (error: Exception) {
                        last = error
                        runCatching { socket.close() }
                    }
                }
                throw last ?: java.net.UnknownHostException("No resolved SSH address for $host")
            }
            override fun getInputStream(socket: Socket): InputStream = socket.getInputStream()
            override fun getOutputStream(socket: Socket): OutputStream = socket.getOutputStream()
        }

        private fun stripTerminal(raw: String): String = raw
            .replace(Regex("\\u001B\\[[0-?]*[ -/]*[@-~]"), "")
            .replace("\r\n", "\n")
            .replace('\r', '\n')

        private fun classify(error: Throwable): String = when {
            error is java.net.SocketTimeoutException -> "NETWORK_TIMEOUT"
            error is java.net.ConnectException -> "CONNECT_REFUSED"
            error is JSchException && error.message.orEmpty().contains("auth fail", true) -> "AUTH"
            error is JSchException && error.message.orEmpty().contains("algorithm negotiation", true) -> "SSH_ALGORITHM_UNSUPPORTED"
            error is JSchException && error.message.orEmpty().contains("hostkey", true) -> "SSH_HOSTKEY_MISMATCH"
            error.message.orEmpty().contains("host key", true) -> "SSH_HOSTKEY_MISMATCH"
            else -> "SSH_FAILED"
        }

        private fun safeMessage(error: Throwable): String = (error.message ?: error.javaClass.simpleName)
            .replace(Regex("[\\r\\n\\t]+"), " ").take(240)
    }
}

private class BoundedByteArrayOutputStream(private val limit: Int) : ByteArrayOutputStream() {
    override fun write(value: Int) {
        if (count >= limit) throw IllegalStateException("SSH stderr exceeded the MCM output limit")
        super.write(value)
    }

    override fun write(buffer: ByteArray, offset: Int, length: Int) {
        if (count + length > limit) throw IllegalStateException("SSH stderr exceeded the MCM output limit")
        super.write(buffer, offset, length)
    }
}

private class PinnedHostKeyRepository(
    private val expectedHost: String,
    private val expectedFingerprint: String?
) : HostKeyRepository {
    @Volatile private var captured: HostKey? = null

    override fun check(host: String, key: ByteArray): Int {
        val normalizedHost = host.removePrefix("[").substringBeforeLast("]:", host).removeSuffix("]")
        if (!normalizedHost.equals(expectedHost, true)) return HostKeyRepository.CHANGED
        val actual = SshRouterOsClient.fingerprintFromKey(key)
        return when {
            expectedFingerprint.isNullOrBlank() -> HostKeyRepository.NOT_INCLUDED
            actual.equals(expectedFingerprint, true) -> HostKeyRepository.OK
            else -> HostKeyRepository.CHANGED
        }
    }

    override fun add(hostkey: HostKey, ui: com.jcraft.jsch.UserInfo?) { captured = hostkey }
    override fun remove(host: String?, type: String?) { if (host == null || host.equals(expectedHost, true)) captured = null }
    override fun remove(host: String?, type: String?, key: ByteArray?) { remove(host, type) }
    override fun getKnownHostsRepositoryID(): String = "MCM-SHA256-PIN"
    override fun getHostKey(): Array<HostKey> = captured?.let { arrayOf(it) } ?: emptyArray()
    override fun getHostKey(host: String?, type: String?): Array<HostKey> =
        captured?.takeIf { host == null || it.host.equals(host, true) }?.let { arrayOf(it) } ?: emptyArray()

    fun fingerprint(): String = captured?.let { SshRouterOsClient.fingerprintFromKey(it.keyBytes()) }
        ?: throw IllegalStateException("SSH server did not present a host key")
}

private fun HostKey.keyBytes(): ByteArray = Base64.getDecoder().decode(getKey())
