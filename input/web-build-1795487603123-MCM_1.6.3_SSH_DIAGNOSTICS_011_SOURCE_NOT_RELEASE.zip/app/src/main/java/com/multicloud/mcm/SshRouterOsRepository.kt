package com.multicloud.mcm

/** Read-only RouterOS CLI adapter over the pinned SSH exec session. */
internal class SshRouterOsRepository(private val client: SshRouterOsClient) {
    suspend fun readSystemResource(): McmResult<SystemResource> = client.readSystemResource()

    suspend fun readInterfaces(): McmResult<List<InterfaceSnapshot>> {
        val base = client.executeReadOnly("/interface/print detail without-paging")
        if (base is McmResult.Failure) return base
        val stats = client.executeReadOnly("/interface/print stats detail without-paging")
        val baseRaw = (base as McmResult.Success).value
        val baseRows = RouterOsSshCliParser.parseRows(baseRaw)
        if (baseRows.size > 10_000) return McmResult.Failure("SSH_ROW_LIMIT", "Interface response exceeded the 10,000-row safety limit.")
        if (baseRows.isEmpty() && !RouterOsSshCliParser.isEmptyTable(baseRaw)) {
            return McmResult.Failure("SSH_READ_FORMAT", "Không phân tích được bảng interface từ RouterOS CLI.")
        }
        val parsedStats = (stats as? McmResult.Success)?.value?.let(RouterOsSshCliParser::parseRows).orEmpty()
        if (parsedStats.size > 10_000) return McmResult.Failure("SSH_ROW_LIMIT", "Interface statistics exceeded the 10,000-row safety limit.")
        val statRows = parsedStats.associateBy { it["name"] }
        return McmResult.Success(baseRows.mapNotNull { row ->
            val name = row["name"] ?: return@mapNotNull null
            val counters = statRows[name].orEmpty()
            InterfaceSnapshot(
                name = name,
                type = row["type"].orEmpty(),
                running = row["running"].equals("true", true) || row["running"].equals("yes", true) || row["flags"].orEmpty().contains("R"),
                rxBytes = (counters["rx-byte"] ?: row["rx-byte"])?.toLongOrNull(),
                txBytes = (counters["tx-byte"] ?: row["tx-byte"])?.toLongOrNull(),
                lastLinkUpTime = row["last-link-up-time"]
            )
        })
    }

    suspend fun readCloudStatus(): McmResult<Map<String, String>> = when (val result = client.executeReadOnly("/ip/cloud/print detail without-paging")) {
        is McmResult.Failure -> result
        is McmResult.Success -> {
            val row = RouterOsSshCliParser.parseRows(result.value).firstOrNull()
                ?: RouterOsSshCliParser.parseSingleProperties(result.value)
            if (row.isEmpty()) McmResult.Failure("DATA_EMPTY", "Router không trả dữ liệu IP Cloud.") else McmResult.Success(row)
        }
    }
    suspend fun readPppoeSessions(): McmResult<List<Map<String, String>>> = readRows("/ppp/active/print detail without-paging").mapRows { it.filter { row -> row["service"].equals("pppoe", true) } }
    suspend fun readArpEntries(): McmResult<List<Map<String, String>>> = readRows("/ip/arp/print detail without-paging")
    suspend fun readDhcpLeases(): McmResult<List<Map<String, String>>> = readRows("/ip/dhcp-server/lease/print detail without-paging")
    suspend fun readNetwatch(): McmResult<List<Map<String, String>>> = readRows("/tool/netwatch/print detail without-paging")
    suspend fun readBridgeHosts(): McmResult<List<Map<String, String>>> = readRows("/interface/bridge/host/print detail without-paging")
    suspend fun readVlans(): McmResult<List<Map<String, String>>> = readRows("/interface/vlan/print detail without-paging")
    suspend fun readBridgeVlans(): McmResult<List<Map<String, String>>> = readRows("/interface/bridge/vlan/print detail without-paging")

    private suspend fun readRows(command: String): McmResult<List<Map<String, String>>> = when (val result = client.executeReadOnly(command)) {
        is McmResult.Failure -> result
        is McmResult.Success -> {
            val rows = RouterOsSshCliParser.parseRows(result.value)
            when {
                rows.size > 10_000 -> McmResult.Failure("SSH_ROW_LIMIT", "RouterOS response exceeded the 10,000-row safety limit.")
                rows.isNotEmpty() || RouterOsSshCliParser.isEmptyTable(result.value) -> McmResult.Success(rows)
                else -> McmResult.Failure("SSH_READ_FORMAT", "Không phân tích được dữ liệu bảng RouterOS CLI: $command.")
            }
        }
    }

    private inline fun <T> McmResult<List<T>>.mapRows(transform: (List<T>) -> List<T>): McmResult<List<T>> = when (this) {
        is McmResult.Failure -> this
        is McmResult.Success -> McmResult.Success(transform(value))
    }
}
