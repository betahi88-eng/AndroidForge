package com.multicloud.mcm.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase

@Entity(tableName = "router_profiles")
data class RouterEntity(
    @PrimaryKey val id: String,
    val name: String,
    @androidx.room.ColumnInfo(defaultValue = "''") val siteName: String,
    val host: String,
    val port: Int,
    val routerOsMajor: Int,
    val username: String,
    val credentialAlias: String,
    val tlsSha256Pin: String,
    val createdAtEpochMs: Long,
    val lastSeenAtEpochMs: Long?,
    @androidx.room.ColumnInfo(defaultValue = "'UNKNOWN'") val lastStatus: String = "UNKNOWN",
    val lastErrorCode: String? = null,
    val lastErrorMessage: String? = null,
    val lastCheckedAtEpochMs: Long? = null,
    @androidx.room.ColumnInfo(defaultValue = "'AUTO'") val connectionMode: String = "AUTO",
    val activeTransport: String? = null,
    val lastResolvedIp: String? = null,
    val dnsResolver: String? = null,
    @androidx.room.ColumnInfo(defaultValue = "0") val fallbackAvailable: Boolean = false,
    val routerOsVersion: String? = null,
    @androidx.room.ColumnInfo(defaultValue = "'UNKNOWN'") val accessLevel: String = "UNKNOWN",
    val lastConnectionLatencyMs: Long? = null,
    val tlsPinConfirmedAtEpochMs: Long? = null,
    val tlsRestSha256Pin: String? = null,
    val tlsRestPinPort: Int? = null,
    val tlsApiSslSha256Pin: String? = null,
    val tlsApiSslPinPort: Int? = null,
    val sshHostKeySha256Pin: String? = null,
    val sshPinPort: Int? = null,
    val sshPinConfirmedAtEpochMs: Long? = null
)

@Entity(tableName = "metric_history", indices = [androidx.room.Index(value = ["routerId", "recordedAtEpochMs"])])
data class MetricHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val routerId: String,
    val metricKey: String,
    val value: Double,
    val unit: String,
    val recordedAtEpochMs: Long
)

@Dao
interface RouterDao {
    @Query("SELECT * FROM router_profiles ORDER BY name COLLATE NOCASE")
    suspend fun getAll(): List<RouterEntity>

    @Query("SELECT * FROM router_profiles WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): RouterEntity?

    @Query("SELECT * FROM router_profiles WHERE rtrim(replace(replace(lower(trim(host)), 'https://', ''), 'http://', ''), '/') = lower(:normalizedHost) ORDER BY createdAtEpochMs ASC LIMIT 1")
    suspend fun getByHost(normalizedHost: String): RouterEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(router: RouterEntity)

    @Query("DELETE FROM router_profiles WHERE id = :id")
    suspend fun delete(id: String)
}

@Dao
interface MetricDao {
    @Insert
    suspend fun insert(sample: MetricHistoryEntity)

    @Query("SELECT * FROM metric_history WHERE routerId = :routerId AND metricKey = :metricKey ORDER BY recordedAtEpochMs DESC LIMIT :limit")
    suspend fun recent(routerId: String, metricKey: String, limit: Int): List<MetricHistoryEntity>

    @Query("DELETE FROM metric_history WHERE recordedAtEpochMs < :beforeEpochMs")
    suspend fun deleteBefore(beforeEpochMs: Long)

    @Query("DELETE FROM metric_history WHERE routerId = :routerId")
    suspend fun deleteForRouter(routerId: String)
}

@Entity(tableName = "interface_counters", primaryKeys = ["routerId", "interfaceName"])
data class InterfaceCounterEntity(
    val routerId: String,
    val interfaceName: String,
    val rxBytes: Long,
    val txBytes: Long,
    val recordedAtEpochMs: Long
)

@Dao
interface InterfaceCounterDao {
    @Query("SELECT * FROM interface_counters WHERE routerId = :routerId AND interfaceName = :interfaceName LIMIT 1")
    suspend fun get(routerId: String, interfaceName: String): InterfaceCounterEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(counter: InterfaceCounterEntity)

    @Query("DELETE FROM interface_counters WHERE routerId = :routerId")
    suspend fun deleteForRouter(routerId: String)
}

@Entity(
    tableName = "connection_attempt_logs",
    indices = [androidx.room.Index(value = ["routerId", "attemptedAtEpochMs"])]
)
data class ConnectionAttemptLogEntity(
    @PrimaryKey val id: String,
    val routerId: String,
    val attemptedAtEpochMs: Long,
    val durationMs: Long,
    val dnsResolver: String?,
    val resolvedIps: String,
    val restResult: String,
    val apiSslResult: String,
    val restProbeDetails: String,
    val apiSslProbeDetails: String,
    val restAuthDurationMs: Long,
    val apiSslAuthDurationMs: Long,
    val selectedProtocol: String?,
    val finalState: String,
    val detail: String?
)

@Dao
interface ConnectionAttemptLogDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(log: ConnectionAttemptLogEntity)

    @Query("SELECT * FROM connection_attempt_logs WHERE routerId = :routerId ORDER BY attemptedAtEpochMs DESC LIMIT :limit")
    suspend fun recent(routerId: String, limit: Int): List<ConnectionAttemptLogEntity>

    @Query("DELETE FROM connection_attempt_logs WHERE routerId = :routerId")
    suspend fun deleteForRouter(routerId: String)
}

@Database(entities = [RouterEntity::class, MetricHistoryEntity::class, InterfaceCounterEntity::class, ConnectionAttemptLogEntity::class], version = 9, exportSchema = false)
abstract class McmDatabase : RoomDatabase() {
    abstract fun routerDao(): RouterDao
    abstract fun metricDao(): MetricDao
    abstract fun interfaceCounterDao(): InterfaceCounterDao
    abstract fun connectionAttemptLogDao(): ConnectionAttemptLogDao

    companion object {
        val MIGRATION_1_2: Migration = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN siteName TEXT NOT NULL DEFAULT ''")
            }
        }

        val MIGRATION_2_3: Migration = object : Migration(2, 3) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN lastStatus TEXT NOT NULL DEFAULT 'UNKNOWN'")
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN lastErrorCode TEXT")
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN lastErrorMessage TEXT")
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN lastCheckedAtEpochMs INTEGER")
            }
        }

        val MIGRATION_3_4: Migration = object : Migration(3, 4) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN connectionMode TEXT NOT NULL DEFAULT 'AUTO'")
            }
        }

        val MIGRATION_4_5: Migration = object : Migration(4, 5) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN lastResolvedIp TEXT")
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN dnsResolver TEXT")
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN fallbackAvailable INTEGER NOT NULL DEFAULT 0")
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN routerOsVersion TEXT")
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN accessLevel TEXT NOT NULL DEFAULT 'UNKNOWN'")
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN lastConnectionLatencyMs INTEGER")
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN tlsPinConfirmedAtEpochMs INTEGER")
            }
        }

        val MIGRATION_5_6: Migration = object : Migration(5, 6) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("""CREATE TABLE IF NOT EXISTS connection_attempt_logs (
                    id TEXT NOT NULL PRIMARY KEY,
                    routerId TEXT NOT NULL,
                    attemptedAtEpochMs INTEGER NOT NULL,
                    durationMs INTEGER NOT NULL,
                    dnsResolver TEXT,
                    resolvedIps TEXT NOT NULL,
                    restResult TEXT NOT NULL,
                    apiSslResult TEXT NOT NULL,
                    restProbeDetails TEXT NOT NULL,
                    apiSslProbeDetails TEXT NOT NULL,
                    restAuthDurationMs INTEGER NOT NULL,
                    apiSslAuthDurationMs INTEGER NOT NULL,
                    selectedProtocol TEXT,
                    finalState TEXT NOT NULL,
                    detail TEXT
                )""")
                database.execSQL("CREATE INDEX IF NOT EXISTS index_connection_attempt_logs_routerId_attemptedAtEpochMs ON connection_attempt_logs(routerId, attemptedAtEpochMs)")
            }
        }

        val MIGRATION_6_7: Migration = object : Migration(6, 7) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN activeTransport TEXT")
            }
        }

        /** Split the legacy active-service pin into independently scoped service + WAN-port pins. */
        val MIGRATION_7_8: Migration = object : Migration(7, 8) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN tlsRestSha256Pin TEXT")
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN tlsRestPinPort INTEGER")
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN tlsApiSslSha256Pin TEXT")
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN tlsApiSslPinPort INTEGER")
                database.execSQL("""UPDATE router_profiles
                    SET tlsRestSha256Pin = tlsSha256Pin, tlsRestPinPort = port
                    WHERE tlsSha256Pin != '' AND (
                        activeTransport = 'REST_HTTPS' OR
                        (activeTransport IS NULL AND connectionMode = 'REST_HTTPS')
                    )""")
                database.execSQL("""UPDATE router_profiles
                    SET tlsApiSslSha256Pin = tlsSha256Pin, tlsApiSslPinPort = port
                    WHERE tlsSha256Pin != '' AND (
                        activeTransport = 'API_SSL' OR
                        (activeTransport IS NULL AND connectionMode = 'API_SSL')
                    )""")
            }
        }

        val MIGRATION_8_9: Migration = object : Migration(8, 9) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN sshHostKeySha256Pin TEXT")
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN sshPinPort INTEGER")
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN sshPinConfirmedAtEpochMs INTEGER")
            }
        }

        val ALL_MIGRATIONS: Array<Migration> = arrayOf(
            MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9
        )
    }
}
