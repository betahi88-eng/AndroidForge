package com.multicloud.mcm

/** Strict parser for RouterOS SSH exec output. Missing fields remain null; no synthetic zeroes. */
internal object RouterOsSshCliParser {
    fun parseSystemResource(raw: String): McmResult<SystemResource> {
        val values = parseSingleProperties(raw)
        val version = values["version"]
        val uptime = values["uptime"]
        if (version.isNullOrBlank() || uptime.isNullOrBlank()) {
            return McmResult.Failure("SSH_READ_FORMAT", "RouterOS CLI system/resource output is incomplete.")
        }
        return McmResult.Success(SystemResource(
            version = version,
            uptime = uptime,
            cpuLoadPercent = values["cpu-load"]?.trimEnd('%')?.toIntOrNull()?.coerceIn(0, 100),
            freeMemoryBytes = parseBytes(values["free-memory"]),
            totalMemoryBytes = parseBytes(values["total-memory"])
        ))
    }

    private const val MAX_ROWS = 10_000

    fun parseRows(raw: String): List<Map<String, String>> {
        val rows = mutableListOf<MutableMap<String, String>>()
        val rowStart = Regex("^\\s*\\d+\\s+(?:[A-Z*]+\\s+)?[A-Za-z0-9_.-]+=.*$")
        val property = Regex("([A-Za-z0-9_.-]+)=(\\\"(?:\\\\.|[^\\\"])*\\\"|[^\\s]+)")
        raw.lineSequence().forEach { line ->
            if (rows.size > MAX_ROWS) return rows
            if (!rowStart.matches(line)) return@forEach
            val values = linkedMapOf<String, String>()
            val prefix = Regex("^\\s*\\d+\\s+([A-Z*]+)?\\s*").find(line)
            prefix?.groupValues?.getOrNull(1)?.takeIf(String::isNotBlank)?.let { values["flags"] = it }
            property.findAll(line).forEach { match ->
                val rawValue = match.groupValues[2].trim()
                val value = if (rawValue.startsWith('"') && rawValue.endsWith('"') && rawValue.length >= 2)
                    rawValue.substring(1, rawValue.length - 1).replace("\\\"", "\"").replace("\\\\", "\\")
                else rawValue
                values[match.groupValues[1]] = value
            }
            if (values.isNotEmpty()) rows += values
        }
        return rows
    }

    fun parseSingleProperties(raw: String): Map<String, String> {
        val result = linkedMapOf<String, String>()
        val property = Regex("(?m)^\\s*([A-Za-z0-9_.-]+)\\s*[:=]\\s*(.*?)\\s*$")
        property.findAll(raw).forEach { match -> result[match.groupValues[1]] = match.groupValues[2].trim().trim('"') }
        return result
    }

    fun isEmptyTable(raw: String): Boolean = raw.isBlank() ||
        raw.contains("no items", true) || raw.contains("no entries", true)

    internal fun parseBytes(raw: String?): Long? {
        if (raw.isNullOrBlank()) return null
        val value = raw.trim().replace(",", "")
        value.toLongOrNull()?.let { return it }
        val match = Regex("(?i)^([0-9]+(?:\\.[0-9]+)?)\\s*(B|KiB|MiB|GiB|TiB|KB|MB|GB)?$").matchEntire(value) ?: return null
        val amount = match.groupValues[1].toDoubleOrNull() ?: return null
        val unit = match.groupValues[2].uppercase()
        val multiplier = when (unit) {
            "KIB" -> 1024.0
            "MIB" -> 1024.0.pow(2)
            "GIB" -> 1024.0.pow(3)
            "TIB" -> 1024.0.pow(4)
            "KB" -> 1000.0
            "MB" -> 1000.0.pow(2)
            "GB" -> 1000.0.pow(3)
            else -> 1.0
        }
        return (amount * multiplier).toLong()
    }

    private fun Double.pow(exponent: Int): Double = Math.pow(this, exponent.toDouble())
}
