# Kết quả smoke test Kotlin/JVM độc lập — MCM 1.6.3 Source 007 (inherited smoke suite)

Ngày chạy: 24/11/2026 (UTC)

- Kết quả: **PASS — 44 assertions**.
- Compiler: Kotlin/JVM 1.9.0; runtime OpenJDK 21.0.12.1.
- Biên dịch trực tiếp các file Kotlin thật trong source: read-only policy, host validator, service mode/failover, REST response bounds, RouterOS API codec, TLS hostname verifier và TLS error classifier.
- Test double chỉ thay `RouterEntity` Room và hàm nhận diện IP trong DNS resolver để tách các lớp thuần Kotlin khỏi Android/Room.
- Ca kiểm tra: allowlist chặn lệnh ghi, ping giới hạn, chuẩn hóa DDNS/IPv4, từ chối HTTP/IPv6 literal/port nhúng hostname, AUTO và custom port, failover không vượt qua lỗi AUTH/TLS identity hoặc pin thiếu, pin legacy không bị dùng chéo transport, API sentence/challenge/credential rejection/giới hạn word, DNS SAN/IP SAN/CN fallback/wildcard, phân loại lỗi TLS, REST body/row limits; thêm 4 assertion compile/runtime cho sealed `McmResult` fallback ở foreground/background.

Lệnh tái chạy: `bash scripts/verify-kotlin-smoke.sh` (cần `kotlinc` trên PATH).

**Giới hạn:** smoke test này không thay thế Gradle/KAPT compile, Android JUnit, lint, APK/AAB build, kiểm thử WebView trên Android, hay kết nối RouterOS thực tế. Những cổng đó vẫn NOT RUN trong môi trường hiện tại.


Candidate 007 also has a separate compile-regression guard for the two sealed `McmResult` branches fixed after AndroidForge log (1); passing this guard is not an Android Gradle build.
