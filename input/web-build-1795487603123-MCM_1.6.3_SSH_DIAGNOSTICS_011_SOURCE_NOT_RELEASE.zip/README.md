# MikroTik Multi-Cloud Monitor (MCM)

**Version:** 1.6.3 engineering source  
**License:** Apache-2.0  
**Platform:** Android 8.0+ (API 26+)  
**Stack:** Kotlin, local WebView assets, Room, Android Keystore, OkHttp, WorkManager

## MCM connects directly to multiple stores

MCM is an Android application that connects directly to each MikroTik through its own MikroTik IP Cloud DDNS hostname (`*.sn.mynetname.net`), another DDNS/domain name, or an IP address. Each profile stores its own endpoint, public/WAN-facing port, RouterOS version, service protocol, username, separate TLS SHA-256 pins per service/port, independent SSH host-key SHA-256 pin, encrypted password, health state and local history.

There is no MCM cloud backend, VPS, relay, VPN/WireGuard, router-side agent or account synchronization. Router profiles and monitoring history stay on the Android phone.

## Connection configuration — independent fields

| Field | User control | Meaning |
|---|---|---|
| Hostname | Editable | MikroTik Cloud DDNS, another DDNS/domain, or IP |
| WAN port | **Editable 1–65535 per router in Advanced** | The port the Android phone reaches from outside; for port forwarding this is the external/WAN port |
| RouterOS version | Detected from authenticated `/system/resource` | The app verifies RouterOS 6/7 from the real response; it is not a guessed UI field |
| Service protocol | **Independent selector** | Automatic, REST HTTPS, RouterOS API-SSL, or SSH v2 |
| TLS / SSH SHA-256 | Read + verify + save | Separate TLS leaf-certificate pin or SSH host-key pin for the selected transport and endpoint |
| Credentials | Per router | Username and password stored with Android Keystore-backed encryption |

`AUTO` preserves the historic defaults: RouterOS 7 → REST HTTPS / `www-ssl` / port 443; RouterOS 6 → RouterOS API-SSL / `api-ssl` / port 8729. These are suggestions only. The user may select API-SSL on RouterOS 6 or 7 and may enter a different WAN port. A manually edited port is not overwritten when the RouterOS or service selector changes; when editing an existing profile its saved port is always treated as user-owned, even if it equals a common default. Existing profiles are migrated as `AUTO`, preserving their current host, port, credentials and history.

**Important — WinBox is not an MCM transport.** TCP 8291 is normally the WinBox service. MCM does not implement the WinBox protocol. A successful WinBox login proves only that the WinBox service is reachable; it does not prove REST or API-SSL is reachable. Port 8291 can be used in MCM only if that endpoint actually serves, or is NAT-forwarded to, the selected REST HTTPS or API-SSL service.

## Supported service adapters

- **REST HTTPS:** RouterOS 7; uses HTTPS `/rest/...` read endpoints over `www-ssl`. Default suggestion: TCP 443.
- **RouterOS API-SSL:** RouterOS 6 or 7; uses the native RouterOS API protocol over TLS `api-ssl`. Default suggestion: TCP 8729. Includes current login and legacy challenge-response support.
- **SSH v2:** direct SSH login to the same DDNS/hostname, using a separately confirmed SHA-256 SSH host-key fingerprint and a fixed read-only RouterOS CLI command allowlist. SSH monitoring uses one non-PTY exec channel per one-line command, sequentially; it does not reuse TLS pins. It offers only modern Ed25519/RSA-SHA2, Curve25519/ECDH/group14-SHA256, AES-GCM/CTR and HMAC-SHA2 algorithms; it never silently downgrades to SHA-1/3DES/CBC.
- **Automatic:** REST HTTPS for RouterOS 7 and API-SSL for RouterOS 6. SSH is an explicit independent mode, not an unsafe silent fallback.
- No WinBox protocol, plaintext API or HTTP fallback is implemented. AUTO performs initial parallel endpoint discovery and may fail over during setup or monitoring only for endpoint/protocol failures, after the alternate service has its own independently confirmed pin for the exact WAN port. AUTH, permission, certificate-validity, hostname and fingerprint failures never trigger fallback. An explicitly selected service is never silently switched.

The main Add Router form intentionally shows only DDNS/Hostname, Username and Password with one **Save & Connect** action. Service mode and WAN port are inside the closed-by-default Advanced section. In `AUTO`, a blank port probes REST/443 and API-SSL/8729 in parallel; a custom WAN port probes both supported protocols on that same external port. MCM then authenticates only the endpoint whose fingerprint was explicitly confirmed. If the preferred branch cannot pass TLS/READ_CHECK, the alternate branch requires its own fingerprint confirmation; certificates may differ between `www-ssl` and `api-ssl`. Explicit REST or API-SSL mode probes only the selected protocol. The exact port and actual protocol that passed TLS plus authenticated READ_CHECK are persisted separately from the requested `AUTO` preference. Foreground and background monitoring reuse the authenticated protocol; they do not re-guess REST/API-SSL from the RouterOS version. SSH mode uses its pinned SSH exec-channel CLI adapter and sequential read-only commands.

## DNS resolution and fallback

- Router hostname lookup first uses Android system DNS. If it returns no address or throws `UnknownHostException`, MCM retries using DNS-over-HTTPS (DoH) with Google Public DNS and then Cloudflare 1.1.1.1. DoH bootstrap uses numeric IPv4/IPv6 resolver addresses, while HTTPS certificate/hostname verification for the DNS providers remains enabled.
- Diagnostics, REST HTTPS, API-SSL, SSH and TLS/SSH identity inspection share the same DNS resolution chain. REST preserves the original DDNS hostname for HTTP Host/SNI; raw TLS sockets connect to the resolved IP while sending the original hostname as SNI.
- The resolver reports which path succeeded. If both Android DNS and both HTTPS resolvers fail, MCM reports a DNS-stage failure with details rather than misreporting a TCP/port failure.
- DoH fallback sends the queried hostname to the selected public DNS provider. No router configuration is changed.

## Monitoring features

- Manage multiple stores/sites and multiple independent MikroTik profiles.
- Add, edit and remove routers; leaving the password blank during edit preserves the encrypted credential.
- Discover MikroTik neighbors on the same Layer-2 network using MNDP UDP/5678. Discovery does not automatically save a router or bypass TLS verification.
- Per-router UNKNOWN / ONLINE / PARTIAL / OFFLINE status, last checked time and concrete error information.
- DNS + TCP endpoint diagnostics, TLS fingerprint inspection, protocol selection and authenticated RouterOS read diagnostics.
- CPU, RAM, RouterOS version, uptime, interface state and per-interface RX/TX rates from counter deltas.
- MikroTik IP Cloud DDNS state, DNS name and WAN address details where supported by the RouterOS version and permissions.
- PPPoE active sessions, ARP, DHCP lease, Netwatch, Bridge Host, VLAN interface and Bridge VLAN snapshots.
- Bounded ICMP packet-loss probe over REST/API-SSL. SSH mode does not claim ping data it cannot collect. Interface throughput is not misrepresented as per-device bandwidth or packet loss.
- Local metric history and charts; refresh-all checks routers sequentially so one failed store does not stop the others.
- Android Keystore + AES-256-GCM credential storage. Passwords and authorization headers are not exposed to JavaScript or logs.
- REST requires RouterOS `read,api,rest-api`; API-SSL requires `read,api`; SSH CLI reads require RouterOS `ssh,read` policies. Candidate 009 uses SSH password authentication; RouterOS may refuse password login when a public key is assigned to that user under `yes-if-no-key`. SSH private-key login is not included yet. Add `test` only when using MCM's bounded ping tool over REST/API-SSL. Never grant `write`, `policy` or `reboot` to the monitoring account.

## Direct DDNS network requirements

MikroTik Cloud DDNS resolves the hostname to the public address reported by the router. DDNS does not open a port, create NAT, bypass CGNAT/double NAT, or provide a relay. The chosen public/WAN port must reach the selected RouterOS service. If an upstream modem performs NAT, its port-forward must lead to the right internal `www-ssl` or `api-ssl` listener. Use firewall source restrictions and a dedicated least-privilege read-only account; do not expose management ports to the entire Internet.

If the store is behind CGNAT or inbound traffic is blocked by the ISP, direct DDNS access cannot work merely by changing the port field. MCM deliberately does not create a VPN or relay to bypass that constraint.

## TLS and fingerprint safety

- The pin is the SHA-256 hash of the leaf TLS certificate presented at the chosen hostname and port.
- TLS pinning captures the exact leaf certificate; the operator must compare it through a trusted independent channel before saving.
- SSH pinning captures the server host key during key exchange with no password authentication; the operator must verify its SHA-256 fingerprint independently before the first password is sent.
- Every session checks its saved identity pin; a mismatch fails closed.
- A self-signed TLS certificate is accepted only when its exact leaf pin is independently confirmed, its validity window is current, and its SAN/CN matches the DDNS hostname/IP. SSH host-key pins are separate and never bypass TLS checks.

## Read-only boundary

MCM does not create, edit or delete RouterOS configuration; does not change IP, DDNS, firewall, NAT, services or users; and does not reboot a router. REST, API-SSL and SSH enforce separate read-only allowlists: REST accepts only monitoring GET paths, API-SSL accepts only required `/print` commands plus bounded ping, and SSH accepts only fixed CLI `print` commands over a pinned SSH exec session. No raw command from WebView is accepted.

## Build and status

- Project: native Android Gradle/Kotlin; application ID `com.multicloud.mcm`.
- Version: `1.6.3` / versionCode `12`.
- Toolchain: JDK 17, Gradle 8.7, Android Gradle Plugin 8.6.1, Kotlin 2.0.21, SDK 35.
- Run `./scripts/androidforge-preflight.sh` and `./scripts/verify-source.sh` before uploading the ZIP.
- Then run `:app:testDebugUnitTest`, `:app:lintDebug`, `:app:assembleDebug` and `:app:bundleDebug` in AndroidForge or a correctly provisioned Android build environment.

Baseline 007 is the user-confirmed AndroidForge APK-build-success version. Candidate 009 adds an SSH v2 transport and Room v9 SSH host-key persistence. Candidate 009 is **engineering source — NOT RELEASE** until AndroidForge completes Gradle/KAPT/JUnit/lint/APK assembly and live RouterOS 6/7 verification. No build success is claimed for 008.


### TLS identity model

REST/API-SSL require two independent TLS identity checks: the exact RouterOS leaf-certificate SHA-256 pin confirmed by the operator, and a certificate SAN/CN hostname match for the DDNS hostname. SSH uses a separate SHA-256 host-key pin confirmed by the operator before password authentication. TLS and SSH pins are never interchangeable; a changed or mismatched identity fails closed.
