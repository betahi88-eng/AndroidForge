# MCM 1.6.3 — Direct DDNS, selectable service and custom port

## Product boundary

MCM Android connects directly to each router through that router's MikroTik Cloud DDNS hostname or another configured DDNS/domain/IPv4 address. Native IPv6 literal entry is outside the 1.6.3 scope; DNS names may still resolve to IPv4 and/or IPv6 records. There is no MCM backend, VPS, VPN, WireGuard, relay, router-side agent or tunnel provisioning. Profiles, secrets and history remain local on Android.

```text
Android MCM
  ├─ local multi-store/router profiles
  ├─ Room database + Android Keystore credentials
  └─ direct per-profile endpoint
       ├─ DNS: <router>.sn.mynetname.net
       ├─ user-entered WAN port (1..65535)
       ├─ selected service adapter
       │    ├─ REST HTTPS / www-ssl (RouterOS 7)
       │    ├─ RouterOS API-SSL / api-ssl (RouterOS 6 or 7)
       │    └─ SSH v2 / RouterOS CLI (explicit mode)
       └─ leaf certificate SHA-256 pin + RouterOS authentication
```

## Endpoint data model

Each profile independently stores `host`, `port`, `routerOsMajor`, `connectionMode`, `username`, `credentialAlias`, independent REST/API-SSL leaf-certificate SHA-256 pins and a separate SSH host-key SHA-256 pin scoped to the selected endpoint port. `tlsSha256Pin` remains as a legacy active-transport compatibility field. The port is the external/WAN-facing port entered on the phone. When upstream NAT changes the public port to an internal port, the profile still stores the public port; the router/modem must map it to the correct service listener.

The legacy `tlsSha256Pin` column remains for upgrade compatibility. TLS uses `tlsRestSha256Pin` + `tlsRestPinPort` and `tlsApiSslSha256Pin` + `tlsApiSslPinPort`; SSH uses `sshHostKeySha256Pin` + `sshPinPort` + `sshPinConfirmedAtEpochMs`. The Room v7→v8 migration maps the former single pin only to the service known to have been active; v8→v9 adds SSH identity fields without rewriting old profiles.

The `connectionMode` values are:
- `AUTO`: RouterOS 7 → REST HTTPS; RouterOS 6 → API-SSL.
- `SSH`: separate RouterOS CLI adapter; it is explicitly selected and never silently chosen as an AUTO fallback.
- `REST_HTTPS`: REST over `www-ssl`; requires RouterOS 7.
- `API_SSL`: native RouterOS API over TLS; supports RouterOS 6 and 7.

The read-only boundary is enforced in all three transport clients, not merely by current repository usage. REST GET is restricted to the required monitoring menus; REST POST is restricted to bounded `/ping` with an allowlisted parameter set. API-SSL accepts only the monitoring `/print` commands and bounded `/ping`; SSH accepts only fixed RouterOS CLI `print` commands through a pinned SSH exec session. Unknown commands and mutation paths are rejected before sending. Ping is diagnostic-only and uses a maximum count of 100 at a fixed 200 ms interval. RouterOS permissions should grant `read,api,rest-api`, plus `test` only if ping is required; no `write`, `reboot` or `sensitive` policy is needed for the dashboard.

The service choice is independent of the numeric WAN port. Suggested values 443 and 8729 are defaults, not hard-coded runtime ports. A manual port remains unchanged when the RouterOS/service selector changes. When editing an existing profile, the already saved port is always treated as user-owned, even if it happens to equal a standard default. The migration from Room v3 to v4 adds `connectionMode='AUTO'` to existing profiles and preserves all saved endpoint and history data.

## WinBox protocol boundary

WinBox TCP 8291 is not REST HTTPS or RouterOS API-SSL. MCM does not implement the WinBox protocol. Reaching a router using WinBox proves only that the WinBox service is reachable. An MCM profile may use port 8291 only when the endpoint on that port actually presents the selected REST/API-SSL TLS service (for example, due to an explicit service/NAT mapping). Otherwise TLS/protocol validation must fail rather than pretending it can read RouterOS data.

## WAN dynamic address behavior

- Keep the hostname as the profile identity; do not save a resolved WAN IP as the permanent host.
- Resolve DNS again on each new connection so changed WAN addresses can be followed after DDNS updates.
- A DNS result or open TCP socket alone never marks the router ONLINE.
- Preserve distinct DNS, TCP, TLS, fingerprint, AUTH, PERMISSION and RouterOS data errors.

## Required network reachability

MikroTik IP Cloud DDNS maps a hostname to the public address reported by the router; it does not open a service port, create NAT, bypass CGNAT/double NAT or provide a relay. The configured WAN port must be reachable from the phone and terminate at the selected `www-ssl` or `api-ssl` listener. If CGNAT or ISP inbound filtering prevents that, a port edit alone cannot fix it. This product boundary intentionally excludes VPN/relay workarounds.

## TLS and credentials

- Each profile stores separate leaf certificate SHA-256 pins for REST HTTPS and API-SSL, each bound to its WAN-facing port.
- Fingerprint reading is an untrusted capture; users must verify independently before saving.
- Every session verifies the configured service-specific pin for the exact WAN port. Pin mismatch fails closed.
- Passwords are encrypted using AES-256-GCM with a key in Android Keystore. Credential rotation writes a new alias before committing the profile and removes the old alias only after the database update succeeds.
- Never log passwords, authorization headers, or API sentence secrets.

## Monitoring contract

`/system/resource` success establishes core reachability. Optional snapshots fail independently and may produce PARTIAL. Refresh All is sequential. Background checks use the same stored service mode, service-scoped pin and WAN port as foreground checks. In AUTO, a failed endpoint/protocol can move to the alternate service only when that exact service + port already has an independently confirmed pin; the active transport and port are persisted after a successful core read. A missing alternate pin never triggers an untrusted connection. Authentication, permission, certificate validity, hostname and fingerprint/pin failures never trigger failover. Certificate-expiry/not-yet-valid errors have their own `TLS_CERT_VALIDITY` classification rather than being mislabeled as a closed port. Foreground refresh, Refresh All and WorkManager use the same rule. DNS failures set the profile OFFLINE with a DNS-specific code rather than leaving a stale ONLINE state.

## Explicit exclusions

No MCM server/VPS, VPN/WireGuard/Back To Home, relay, router-side agent, WinBox protocol client, plaintext API, automatic port opening, automatic firewall change, router configuration writes or cloud synchronization. LAN MNDP discovery is a local convenience only.


## TLS and SSH pin persistence (Room v9)

Room v8 stores independent REST/API-SSL TLS pins. Room v9 adds `sshHostKeySha256Pin`, `sshPinPort` and `sshPinConfirmedAtEpochMs`. TLS pins and SSH host-key pins are separate trust domains. A pin is reusable only for its own protocol and exact endpoint port.


## RouterOS command boundary

All native transport clients enforce the monitoring allowlist before network I/O. REST GET is limited to the system resource, interfaces, IP Cloud, PPP active, ARP, DHCP lease, Netwatch, Bridge Host, VLAN and Bridge VLAN paths; REST POST is reserved for bounded ping. API-SSL permits only the matching `/print` commands plus bounded `/ping`; SSH permits only fixed CLI `print` commands and never accepts raw WebView input. API responses are bounded by word, sentence, total-byte and row limits. No add/set/remove/enable/disable/reboot/firewall/NAT/service/user command is reachable through the MCM transport adapter.

The RouterOS account should use a custom least-privilege group: `read,api,rest-api` for REST, `read,api` for API-SSL, and `ssh,read` for SSH CLI reads. Optional `test` is used only when in-app ping is required over REST/API-SSL. `test` grants RouterOS permissions beyond ping when the account is used elsewhere; MCM itself still restricts the command to its bounded ping allowlist.


## TLS endpoint identity and pin migration (candidate 006)

The transport-specific SHA-256 leaf pins are independent for REST HTTPS and API-SSL and are scoped to the exact WAN-facing port. A matching pin does not waive certificate time validity or endpoint identity. DNS names are checked against dNSName SANs; IP literals require iPAddress SANs; a legacy subject CN is considered only when no dNSName SAN exists. A wildcard is accepted only as the complete left-most label and matches exactly one hostname label. REST, API-SSL and first-use fingerprint inspection share the same verifier.

On schema v8 migration, a legacy single pin is copied only when its protocol can be established from the recorded active transport or an explicitly fixed protocol mode. AUTO profiles without a recorded active transport keep the legacy value but require a new explicit service-specific pin confirmation.


## SSH v2 transport

SSH is implemented with a maintained Java SSH2 client and a pinned host-key repository. First-use inspection sends no password; the app captures the SSH host key during key exchange and asks for explicit SHA-256 trust. Only after the pin matches does MCM send the stored password. RouterOS SSH server does not provide a pseudo-TTY. MCM uses one non-PTY exec channel per allowlisted single-line read command and executes reads sequentially. See `docs/SSH_TRANSPORT_RESEARCH_VI.md` for the software comparison, sources and remaining live-router validation.
