# MCM 1.6.3 implementation map

## Implemented in this engineering source

1. Native Android shell: Kotlin + WebView local assets.
2. Local Room storage and migrations v1→v2→v3→v4→v5→v6→v7→v8→v9 (current schema v9; SSH host-key pin is independent from TLS pins).
3. Multi-profile CRUD, site/Cloud grouping and independent connection settings.
4. Host validation for canonical IPv4, ASCII DNS/DDNS domains and MikroTik Cloud DDNS recognition.
5. Credential encryption with Android Keystore-backed AES-GCM and safe alias rotation.
6. TLS SHA-256 fingerprint inspection and fail-closed verification in normal clients.
7. RouterOS 7 REST client, RouterOS 6 API-SSL client and explicit SSH v2 exec-channel CLI adapter with independent host-key pinning.
8. Core metrics and independent packet-loss parsers.
9. Cloud DDNS status, PPPoE active sessions, ARP, DHCP leases and Netwatch snapshots.
10. Per-router status and errors, selected refresh and sequential refresh-all.
11. Local history and responsive WebView UI, including per-interface RX/TX time series and charts.
12. REST/API-SSL mock servers and unit tests for parsers/host validation.
13. Per-router `AUTO` / `REST_HTTPS` / `API_SSL` selection and custom WAN port 1–65535 in the hidden Advanced section; main form remains three inputs.
14. `AUTO` probes REST/443 and API-SSL/8729 in parallel when port is blank; a custom WAN port is tested against both protocols on that same external port; explicit mode probes only the selected protocol.
15. The exact endpoint port and service mode are persisted and reused by foreground monitoring and WorkManager; no hard-coded default port is substituted after a successful custom-port READ_CHECK.
16. SSH host-key fingerprints are persisted separately from TLS pins; first-use capture sends no password, and SSH monitoring uses fixed read-only commands sequentially.

## Not implemented / not release verified

- No MCM cloud backend or cloud sync; this is not required for multi-domain device management.
- No VPN, relay or agent; remote path must be direct public WAN DDNS.
- No push notifications, custom alert rules or Netwatch event history.
- No long-term ARP/DHCP device identity tracking.
- No chart export to CSV/PDF.
- No native IPv6 literal in host field (not part of the locked 1.6.3 functional design).
- Android Gradle build, KAPT, unit tests through Gradle, lint, APK assembly and live hardware tests remain pending in an environment with full toolchain and devices.


## Candidate 009 — SSH v2 direct-DDNS transport

- Add explicit SSH v2 mode alongside REST HTTPS and API-SSL; preserve the existing AUTO selection and 007 TLS behavior.
- Resolve DDNS with the existing DNS fallback chain and use the resolved addresses through a custom SSH socket factory.
- Inspect SSH host key with `PreferredAuthentications=none`; do not send password before the first-use fingerprint is confirmed.
- Persist SSH SHA-256 host-key pin and exact endpoint port separately in Room v9. Reject changed host keys before password authentication.
- Use a non-PTY exec channel, sequential requests, fixed read-only command allowlist and bounded output.
- Use SSH for foreground and background core monitoring; optional data failures remain explicit.
- Keep WinBox, MAC-Telnet, Telnet, VPN and relay excluded.
- Candidate 009 requires AndroidForge Gradle/JUnit/lint/APK and live RouterOS 6/7 validation before release status.
