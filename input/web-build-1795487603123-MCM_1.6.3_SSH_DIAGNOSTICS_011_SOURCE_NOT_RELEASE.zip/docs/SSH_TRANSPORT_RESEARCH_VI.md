# Nghiên cứu phương thức truy cập MikroTik qua DDNS — MCM 1.6.3

## Kết luận kỹ thuật

MCM 007 chỉ có hai transport đăng nhập ở tầng ứng dụng: REST HTTPS và RouterOS API-SSL. Khi cả hai probe dừng ở `TCP_CONNECT_TIMEOUT`, ứng dụng chưa nhận được TCP connection và chưa thể kiểm tra TLS, fingerprint hay mật khẩu. Không thể sửa lỗi xác thực ở tầng trên để biến một socket chưa kết nối thành phiên đăng nhập.

Phương thức thay thế phù hợp nhất để bổ sung cho MCM là **SSH v2 qua hostname/DDNS**. RouterOS có SSH server và CLI; SSH dùng xác minh host key riêng, không dùng TLS certificate pin. MCM 008 triển khai SSH như transport độc lập, không thay thế hoặc giả mạo REST/API-SSL.

## Đối chiếu tài liệu và phần mềm

| Nguồn/phần mềm | Phương thức | Ý nghĩa đối với MCM |
|---|---|---|
| RouterOS Manual — SSH | SSH v2, CLI | Nguồn chính thức xác nhận SSH server, host-key fingerprint, password/key auth và lệnh CLI |
| RouterOS Manual — Services | API-SSL, REST HTTPS, SSH, WinBox, SNMP | Xác định các giao thức là dịch vụ riêng biệt; thành công ở dịch vụ này không chứng minh dịch vụ khác hoạt động |
| tik4net | API, REST, SSH, Telnet, MAC-Telnet, WinBox CLI/native | Tham khảo kiến trúc transport adapter và cách dùng SSH command/exec và xử lý output; không dùng PTY vì RouterOS SSH server không cấp pseudo-TTY; thư viện .NET, không thể nhúng trực tiếp vào Android Kotlin |
| mwiede/JSch | SSH2 thuần Java | Thư viện SSH được chọn cho Android; hỗ trợ host-key repository và `exec` channel |
| Androtik (Kotlin/Jetpack Compose) | RouterOS API 8728/8729 | README mô tả API/API-SSL là đường kết nối; SSH Terminal nằm trong roadmap Advanced, không phải tính năng đã chứng minh hoạt động |
| Mikrotik-Android (Java Android client) | RouterOS API | Là API client, không cung cấp transport thay thế cho API/API-SSL |
| MikroTik Manager `mikr` | SSH, REST, SNMP | Phần mềm self-hosted, không phải Android app; tài liệu của nó dùng SSH để đọc và SNMP cho monitoring-only, là mẫu kiến trúc tham khảo hữu ích |
| Android SSH clients dùng JSch | SSH2 trên Android | Tham khảo việc đóng gói SSH transport riêng khỏi UI/profile management |
| SNMPv3 / LibreNMS / Zabbix | Giám sát qua SNMP | Hữu ích cho polling/monitoring; không phải cơ chế đăng nhập tài khoản CLI RouterOS, vì vậy không thay thế SSH login |
| RouterOS API Java/Go/Python clients | RouterOS API/API-SSL | Vẫn phụ thuộc dịch vụ API tương ứng; không giải quyết trường hợp cần transport khác API/REST |

**Lưu ý về RouterOS REST:** tài liệu MikroTik mô tả REST là HTTP wrapper của RouterOS CLI/API được phục vụ bởi `www-ssl`; đây là dịch vụ khác với `api-ssl`. Vì vậy REST HTTPS và API-SSL phải giữ adapter, TLS pin và trạng thái chẩn đoán riêng.

**Lưu ý về tik4net:** tài liệu trong cùng repository có chỗ mô tả SSH là alpha và chỗ khác xếp transport vào ma trận production. Vì vậy MCM chỉ dùng repository này làm tài liệu tham khảo về transport adapter và CLI command execution, không lấy trạng thái phát hành của nó làm bằng chứng tương thích Android.

**Lưu ý về MikroTik Manager `mikr`:** tài liệu sản phẩm nêu thiết kế dùng SSH để đọc dữ liệu ngay cả với profile REST, và SNMP là monitoring-only. Đây là bằng chứng thực tiễn rằng SSH có thể là một transport đọc độc lập, nhưng không phải tài liệu chính thức của MikroTik và repository đó chỉ nhắm RouterOS 7; MCM vẫn phải kiểm thử riêng RouterOS 6/7.

## Các phương thức không đưa vào MCM

- **WinBox protocol:** là giao thức riêng, không phải REST/API; không đưa vào vì yêu cầu kiến trúc trước đó của dự án loại trừ WinBox transport.
- **MAC-Telnet / MAC-WinBox:** hoạt động ở Layer 2, không phải đường truy cập hostname/DDNS từ Internet.
- **Telnet:** truyền thông tin đăng nhập và dữ liệu dạng plaintext; không phù hợp kết nối từ xa qua Internet.
- **SNMPv3:** chỉ cung cấp dữ liệu quản trị/giám sát theo MIB; không tạo phiên đăng nhập CLI RouterOS.
- **VPN, relay hoặc cloud proxy:** không triển khai; giữ mô hình điện thoại kết nối trực tiếp router qua hostname.

## Thiết kế SSH được thêm vào MCM 008

1. Chọn `SSH v2` trong Advanced; khi bỏ trống port, transport dùng mặc định SSH.
2. MCM phân giải hostname qua cùng chuỗi Android DNS → Google DoH → Cloudflare DoH, rồi ghim socket vào các địa chỉ đã phân giải. Hostname gốc vẫn được giữ làm danh tính profile.
3. Lần đầu, MCM thực hiện SSH key exchange với `PreferredAuthentications=none`; không gửi mật khẩu. Chỉ thu fingerprint SHA-256 của host key.
4. Người dùng phải xác minh fingerprint qua kênh tin cậy rồi mới xác nhận. Khi host key đổi, MCM dừng trước bước gửi mật khẩu và yêu cầu xác minh lại.
5. Sau xác nhận, MCM mở SSH v2, xác minh đúng host key đã ghim rồi mới gửi thông tin đăng nhập.
6. MCM chỉ thương lượng Ed25519/RSA-SHA2, Curve25519/ECDH/group14-SHA256, AES-GCM/CTR và HMAC-SHA2; không tự hạ xuống ssh-rsa/SHA1, group14-sha1, CBC hay 3DES. RouterOS cũ chỉ có thuật toán yếu sẽ bị từ chối thay vì downgrade.
7. RouterOS SSH server không cấp pseudo-TTY. MCM dùng SSH `exec` channel, mỗi lệnh là một dòng độc lập và bị giới hạn bằng allowlist cố định chỉ gồm lệnh `print` phục vụ giám sát; tài khoản cần policy `ssh,read`. Không nhận raw command từ WebView, không có `add`, `set`, `remove`, `disable`, `enable`, `reboot`, `export` hay lệnh thay đổi cấu hình.
8. SSH dùng một exec channel cho mỗi lệnh một dòng, chạy tuần tự trên cùng phiên; không gửi lệnh nhiều dòng. Kết quả được phân loại rõ, không tự điền số 0 khi thiếu dữ liệu.
9. SSH host-key fingerprint, port và thời điểm xác nhận được lưu riêng trong Room v9; không tái sử dụng TLS pin.

## Giới hạn cần kiểm thử trên router thật

- MCM 008 hiện dùng password authentication. RouterOS mặc định có thể từ chối password nếu tài khoản đã gán SSH public key (`password-authentication=yes-if-no-key`); private-key authentication chưa nằm trong candidate này.
- Cần xác minh handshake và host-key algorithms trên RouterOS 6.49.x và RouterOS 7.x thực tế. Candidate không tự downgrade sang thuật toán SHA-1/3DES/CBC nếu router cũ không hỗ trợ bộ thuật toán an toàn.
- Output CLI có thể khác nhau theo RouterOS minor version, quyền tài khoản và bảng rỗng; parser phải từ chối dữ liệu không đầy đủ thay vì tạo số liệu giả.
- SSH là transport tuần tự qua exec channels, chậm hơn API/REST khi đọc nhiều bảng. API/REST vẫn là phương thức ưu tiên khi chúng hoạt động.
- MCM 008 là mã nguồn ứng viên. Chưa có Android Gradle/JUnit/lint/APK build hoặc kiểm thử live router trong runtime hiện tại; không được coi việc thêm mã SSH là bằng chứng đã đăng nhập thành công trên router của người dùng.

## Nguồn tham khảo

- MikroTik RouterOS SSH: https://manual.mikrotik.com/docs/management-tools/ssh/ (SSH exec, no-PTY behavior, host-key fingerprint and password/key authentication)
- MikroTik RouterOS Services: https://help.mikrotik.com/docs/spaces/ROS/pages/103841820/Services
- MikroTik RouterOS CLI: https://manual.mikrotik.com/docs/management-tools/console/
- MikroTik REST API: https://manual.mikrotik.com/docs/developer-guides/rest-api/
- MikroTik RouterOS API: https://help.mikrotik.com/docs/spaces/ROS/pages/47579160/API
- tik4net: https://github.com/danikf/tik4net
- tik4net SSH connection notes: https://github-wiki-see.page/m/danikf/tik4net/wiki/SSH-connection
- mwiede/JSch: https://github.com/mwiede/jsch
- JSch releases: https://github.com/mwiede/jsch/releases
- Androtik Android app: https://github.com/dulumina/androtik
- Mikrotik-Android API client: https://github.com/NabilNoN/Mikrotik-Android
- MikroTik Manager (`mikr`) SSH/REST/SNMP: https://github.com/hreskiv/mikr
- MikroTik Manager getting-started / transport comparison: https://mikr.app/docs/getting-started.html
- Android SSH/JSch reference project: https://github.com/Ojjiruon/KSTerminal
