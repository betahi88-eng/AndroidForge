# MCM 1.0.1 build status

**Status: Engineering source only — NOT a compiled APK and NOT a signed release.**

## Source and packaging verification

- ZIP archive integrity and CRC: verified before repackaging.
- Native Android Gradle/Kotlin project structure: verified.
- Application ID: `com.multicloud.mcm`.
- Android Gradle Plugin: 8.6.1; Kotlin: 2.0.21; Gradle baseline: 8.7; JDK: 17.
- Android SDK baseline: compileSdk/targetSdk 35; Build Tools 35.0.0; minSdk 26.
- AndroidForge upload instructions added, including explicit `zip_path` and project-detection acceptance checks.
- CI workflow now rejects obvious wrong-source indicators (`pubspec.yaml`, `harmony_patched`) before Gradle build.

## Static checks

- JavaScript syntax (`node --check`): run during packaging verification.
- Python mock server syntax (`py_compile`): run during packaging verification.
- Shell syntax (`bash -n`): run during packaging verification.
- Android Manifest XML: parsed during packaging verification.

## Not verified

- Full Android Gradle compilation, JUnit, lint, APK assembly: not run in this environment because Android SDK Platform 35 and Gradle are unavailable.
- Android runtime/device acceptance and RouterOS 6/7 hardware tests: not run.
- Release signing: no production signing key or signed APK included.

Do not describe this archive as a successful APK build. Follow `ANDROIDFORGE_UPLOAD_VI.md` and `docs/TEST_PLAN.md`.
