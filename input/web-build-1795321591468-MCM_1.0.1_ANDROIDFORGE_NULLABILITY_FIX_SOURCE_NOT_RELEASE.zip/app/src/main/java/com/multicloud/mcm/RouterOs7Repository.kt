package com.multicloud.mcm

import com.multicloud.mcm.routeros.PingResponseParser
import org.json.JSONObject

class RouterOs7Repository(private val client: RouterOs7Client) {
    suspend fun readSystemResource(): McmResult<SystemResource> {
        return when (val result = client.get("system/resource")) {
        is McmResult.Failure -> result
        is McmResult.Success -> {
            val row = result.value.optJSONObject(0)
                ?: return McmResult.Failure("RESOURCE_EMPTY", "Router không trả dữ liệu system/resource.")
            McmResult.Success(
                SystemResource(
                    version = row.stringValue("version"),
                    uptime = row.stringValue("uptime"),
                    cpuLoadPercent = row.stringValue("cpu-load")?.toIntOrNull()?.coerceIn(0, 100),
                    freeMemoryBytes = row.stringValue("free-memory")?.toLongOrNull(),
                    totalMemoryBytes = row.stringValue("total-memory")?.toLongOrNull()
                )
            )
        }
        }
    }

    suspend fun readInterfaces(): McmResult<List<InterfaceSnapshot>> = when (val result = client.get("interface")) {
        is McmResult.Failure -> result
        is McmResult.Success -> {
            val rows = buildList {
                for (i in 0 until result.value.length()) {
                    val row = result.value.optJSONObject(i) ?: continue
                    val name = row.stringValue("name") ?: continue
                    add(
                        InterfaceSnapshot(
                            name = name,
                            type = row.stringValue("type").orEmpty(),
                            running = row.stringValue("running")?.toBooleanStrictOrNull() ?: false,
                            rxBytes = row.stringValue("rx-byte")?.toLongOrNull(),
                            txBytes = row.stringValue("tx-byte")?.toLongOrNull(),
                            lastLinkUpTime = row.stringValue("last-link-up-time")
                        )
                    )
                }
            }
            McmResult.Success(rows)
        }
    }

    suspend fun readPppoeInterfaces(): McmResult<List<PppoeStatus>> = when (val result = readInterfaces()) {
        is McmResult.Failure -> result
        is McmResult.Success -> McmResult.Success(
            result.value.filter { it.type.contains("pppoe", true) || it.name.contains("pppoe", true) }
                .map { PppoeStatus(it.name, it.running, it.lastLinkUpTime, null) }
        )
    }

    suspend fun ping(target: String, count: Int = 20): McmResult<PingMeasurement> {
        require(target.isNotBlank() && count in 1..100)
        val payload = JSONObject()
            .put("address", target)
            .put("count", count.toString())
            .put("interval", "200ms")
        return when (val result = client.post("ping", payload)) {
            is McmResult.Failure -> result
            is McmResult.Success -> PingResponseParser.parse(target, result.value, expectedSent = count)
        }
    }
}

private fun JSONObject.stringValue(key: String): String? =
    if (!has(key) || isNull(key)) null else optString(key).takeIf(String::isNotBlank)
