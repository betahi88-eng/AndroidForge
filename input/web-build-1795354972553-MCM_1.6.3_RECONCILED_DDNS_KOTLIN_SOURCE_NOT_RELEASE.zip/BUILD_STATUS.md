# MCM 1.6.3 — Build status

**Status: Reconciled engineering source / NOT RELEASE. No APK is included or claimed.**

## Project identity

- Native Android Gradle/Kotlin project; application ID `com.multicloud.mcm`.
- Version `1.6.3` / versionCode `11`; minSdk 26, compileSdk 35.
- Flat project root: `settings.gradle.kts`, root `build.gradle.kts`, `app/build.gradle.kts`.
- Toolchain target: JDK 17, Gradle 8.7, AGP 8.6.1, Kotlin 2.0.21, Android SDK Platform 35.

## Inherited 1.6.0 change set

- Per-profile endpoint keeps hostname, WAN port (1–65535), RouterOS major version, connection/service mode, username, certificate pin and Keystore credential separate.
- Service modes: AUTO (historic defaults), REST_HTTPS (RouterOS 7 only), API_SSL (RouterOS 6/7).
- Custom port persists independently. Changing RouterOS or service mode only updates the suggestion on a fresh profile before manual input; an existing saved port is always preserved while editing, even if it equals a conventional default.
- Room database version 4 adds `connectionMode` with default AUTO. Migration v3→v4 does not rewrite existing host, port, credentials, TLS pin, or history.
- Foreground and background clients resolve the same protocol mode and use the saved custom port.
- UI explains WinBox protocol boundary: MCM does not implement WinBox; a WinBox TCP 8291 connection is not proof of REST/API-SSL availability.
- TCP diagnostic is correctly described as a socket reachability check, not an authenticated service/protocol test.

## 1.6.1 DNS repair

- Added `RouterDnsResolver`: Android system DNS first; Google Public DNS DoH (`dns.google/resolve`) fallback; Cloudflare DoH (`cloudflare-dns.com/dns-query`) second fallback.
- DoH providers are reached using numeric IPv4/IPv6 bootstrap IPs, but HTTPS certificates and provider hostnames are still verified by OkHttp.
- Applied the resolver consistently to TCP diagnostics, RouterOS 7 REST, RouterOS API-SSL and TLS fingerprint inspection.
- Native TLS sockets connect to the resolved IP and send SNI for the original DDNS hostname. REST retains the hostname for URL/Host/SNI.
- Added unit tests for Android resolver precedence, DoH fallback and dual-failure reporting.
- DNS fallback uses public DNS providers; queried hostnames are disclosed to the provider that answers.

## Preserved source capabilities

Multi-router/store profiles, AES-256-GCM credential encryption backed by Android Keystore, leaf SHA-256 TLS pinning, RouterOS 7 REST, RouterOS API-SSL with legacy login, DNS/TCP diagnostics, MNDP discovery, CPU/RAM, interfaces/rates, IP Cloud, PPPoE, ARP, DHCP, Netwatch, Bridge Host, VLAN, bounded ping, local history, sequential Refresh All and per-router health/error state.

## 1.6.3 AndroidForge Kotlin nullability repair

- AndroidForge logs from the prior source showed all three tasks (`bundleDebug`, `assembleDebug`, `assembleRelease`) stopping at `RouterOs7Repository.kt:37:65` due to calling a nullable string unsafely.
- Replaced the inline interface-row conversion with `toInterfaceSnapshotOrNull()`, using explicit Elvis defaults and nullable numeric parsing.
- Added four parser regression tests.
- The parser extraction removes the nullable-call expression from the repository compile path and makes defaults explicit. The original ZIP 1.6.0 contains `row.stringValue("type").orEmpty()`, which is normally a valid Kotlin nullable-string extension call; the uploaded AndroidForge log does not include source contents, so the exact compiled file cannot be proven from the log alone. The dedicated parser and new version identity make the intended source unambiguous on the next clean job. This does not prove that a new AndroidForge run has passed.

## Source checks completed in this workspace

- `scripts/androidforge-preflight.sh` — PASS; flat-root Android Gradle/Kotlin project.
- `scripts/verify-source.sh` — PASS for all source-level checks; it correctly reported the Android Gradle build gate as SKIPPED.
- `python3 scripts/verify-room-migrations.py` — PASS; v1→v2→v3→v4, v2→v3→v4 and v3→v4 preserve existing router ports, credentials aliases and history tables.
- `python3 scripts/verify-ui-contract.py` — PASS; 73 unique HTML IDs, 57 JS DOM lookups, editable port/service contract and WinBox protocol boundary.
- Node syntax checks for all WebView scripts — PASS.
- Python compile for mock servers and source-verification scripts — PASS.
- Bash syntax for all shell scripts — PASS.
- Android Manifest, styles and network-security XML parsing — PASS.
- Standalone `RouterServiceMode` Kotlin smoke checks with local kotlinc 1.9.0 — PASS (not a complete Android/Kotlin app compile).
- `RouterOs7InterfaceParser.kt` compiled with local kotlinc and an API-compatible `JSONObject` test stub; complete/sparse/missing-name/invalid-value cases — 4/4 PASS (not a real Android Gradle/JUnit run).
- `RouterDnsResolver` and its three resolver-chain logic tests were compiled/executed with local kotlinc plus API-compatible OkHttp/JSON/JUnit stubs — 3/3 PASS. This checks Kotlin syntax and failover logic only, not the real Android/OkHttp binary integration.
- ZIP CRC and flat-root Android project layout — PASS; SHA-256 sidecar generated next to the final source ZIP.

## Not verified here

The current packaging workspace does not have Gradle 8.7 or Android SDK Platform 35 installed; JDK 17 is also not available (the workspace Java is 21). Therefore full Android Gradle compile, Room KAPT, Gradle/JUnit, Lint and APK assembly are NOT RUN here. Physical Android and RouterOS 6/7 hardware acceptance is also NOT RUN. No production signing key is included.

## AndroidForge gate

Upload `MCM_1.6.3_ANDROIDFORGE_BUILD_FIX_SOURCE_NOT_RELEASE.zip` as a native Android Gradle project. Run `:app:testDebugUnitTest`, `:app:lintDebug`, `:app:assembleDebug` and `:app:bundleDebug`. Accept only if APK exists, package and version are correct, the APK checksum is recorded, and device/router tests pass.
