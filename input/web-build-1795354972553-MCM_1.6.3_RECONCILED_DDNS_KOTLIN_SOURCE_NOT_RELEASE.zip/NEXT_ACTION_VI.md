# MCM — Next Action

**Current checkpoint:** `MCM-162-ANDROIDFORGE-KOTLIN-NULLABILITY-FIX`  
**Source:** `MCM_1.6.3_ANDROIDFORGE_BUILD_FIX_SOURCE_NOT_RELEASE.zip`  
**Status:** Engineering source / NOT RELEASE

1. Upload this exact flat-root ZIP to AndroidForge.
2. Confirm RouterOS 7 interface parsing uses the null-safe parser and its four regression tests are included; the existing direct-DDNS DNS fallback remains intact.
3. Confirm detector selects native Android Gradle/Kotlin (not Flutter): root contains `settings.gradle.kts` and `app/build.gradle.kts`.
4. Run `:app:testDebugUnitTest`, `:app:lintDebug`, `:app:assembleDebug`, and `:app:bundleDebug`.
5. Verify APK package `com.multicloud.mcm`, version `1.6.3`, versionCode `12`, and checksum.
6. Install on Android. Test a RouterOS 7 REST HTTPS endpoint and RouterOS 6/7 API-SSL endpoint over cellular data with an actual custom WAN port.
7. Verify the WinBox-only 8291 endpoint is not misreported as MCM-compatible; then test 8291 only if deliberately mapped to the selected HTTPS/API-SSL service.

Do not call this a release until Android installation, room migration, TLS pin, user authentication, foreground/background reads and live RouterOS acceptance pass. Do not change router configuration, firewall, NAT or DDNS from MCM.
