# MikroTik Multi-Cloud Monitor (MCM)

**Version:** 1.5.1 engineering rebuild  
**License:** Apache-2.0  
**Platform:** Android 8.0+ (API 26+)  
**Stack:** Kotlin, WebView local assets, Room, Android Keystore, OkHttp, WorkManager

## MCM quản lý nhiều Cloud/domain như thế nào?

MCM là ứng dụng Android kết nối **trực tiếp** tới nhiều router MikroTik thông qua từng địa chỉ endpoint độc lập. Một hồ sơ có một router, một host (MikroTik IP Cloud DDNS `*.sn.mynetname.net`, DDNS/domain riêng hoặc IP), một port, phiên bản RouterOS, tài khoản và TLS fingerprint riêng. Hồ sơ được nhóm theo tên Cloud/địa điểm do người dùng đặt.

**Multi-Cloud ở đây là quản lý nhiều tên miền/kết nối MikroTik trong cùng một APK.** MCM không yêu cầu VPS, Cloud Backend, tài khoản cloud trung gian hoặc dịch vụ đồng bộ bên ngoài. Hồ sơ, thông tin đăng nhập đã mã hóa và lịch sử được lưu cục bộ trên điện thoại.

Ví dụ:

| Nhóm Cloud/địa điểm | Router | Host | Giao thức |
|---|---|---|---|
| Nhà thờ | MikroTik chính | `xxxx.sn.mynetname.net` | ROS 7 REST HTTPS |
| Văn phòng | MikroTik phụ | `router.example.net` | ROS 7 REST HTTPS |
| Chi nhánh | MikroTik cũ | `branch.example.net` | ROS 6 API-SSL |

Có thể thêm nhiều hồ sơ theo nhu cầu bộ nhớ và thời gian kiểm tra của thiết bị. MCM có thao tác **Kiểm tra tất cả router** theo thứ tự, không bắn đồng thời kết nối tới mọi router.

## Chức năng trong source 1.5.1

- Thêm, xem, sửa, gỡ nhiều router; giữ mật khẩu cũ khi sửa nếu để trống trường mật khẩu.
- Nhóm hồ sơ theo Cloud/địa điểm; phân loại MikroTik Cloud DDNS, custom DDNS/domain và IP trực tiếp.
- Dò MikroTik cùng broadcast domain bằng MNDP UDP/5678; đọc identity, MAC, RouterOS version, board, interface, uptime và IPv4/IPv6 quảng bá. Uptime TLV được giải mã theo số giây little-endian; TLV lạ được bỏ qua an toàn. Discovery không tự lưu router và không bỏ qua bước xác thực TLS.
- RouterOS 7 qua REST HTTPS (`www-ssl`, mặc định 443).
- RouterOS 6 qua API-SSL native (`api-ssl`, mặc định 8729), hỗ trợ đăng nhập trực tiếp và legacy challenge-response.
- Mỗi router có username/password và SHA-256 TLS certificate fingerprint riêng.
- Trạng thái từng router: chưa kiểm tra, ONLINE, PARTIAL hoặc OFFLINE; lỗi gần nhất được lưu cục bộ.
- Kiểm tra DNS/TCP ngay trong form thêm router: hiển thị IP WAN đã phân giải, trạng thái mở cổng, timeout và thời gian kiểm tra.
- Tách lỗi AUTH (sai thông tin đăng nhập) và PERMISSION (thiếu quyền) khỏi lỗi mạng/TLS khi RouterOS cung cấp mã phản hồi.
- TLS RouterOS 7 xác thực bằng SHA-256 leaf pin bắt buộc, tương thích certificate tự ký không có SAN khớp DDNS; pin sai vẫn bị từ chối.
- Đọc CPU, RAM, RouterOS version, uptime, trạng thái interface và tốc độ RX/TX Mbps từ chênh lệch byte counter; lưu lịch sử RX/TX riêng từng interface và hiển thị biểu đồ theo interface đã chọn.
- Đọc MikroTik IP Cloud: DDNS enabled, trạng thái cập nhật, DNS name, public IPv4/IPv6 và thời điểm cập nhật.
- Đọc phiên PPPoE đang hoạt động, ARP table, DHCP lease và trạng thái Netwatch hiện tại.
- Đo ICMP packet loss độc lập bằng ping giới hạn; không suy ra packet loss từ RX/TX.
- Lịch sử cục bộ cho CPU, RAM, ICMP loss, số phiên PPPoE, ARP entries, DHCP leases và Netwatch DOWN.
- Kiểm tra tất cả hồ sơ theo tuần tự; lưu trạng thái kiểm tra cho từng router.
- Hiển thị trạng thái mạng Android (Wi-Fi/di động/Ethernet) và trạng thái Internet; kết nối router luôn đi trực tiếp qua hostname DDNS.
- Refresh hồ sơ đang chọn khi app hiển thị (30 giây); WorkManager chỉ ghi CPU/RAM nền theo chu kỳ tối thiểu 15 phút.
- Android Keystore + AES-256-GCM; UI WebView chỉ dùng asset nội bộ, không tải script từ Internet.

## Giới hạn chức năng cần biết

- Bản 1.5.1 vẫn là bản giám sát chỉ đọc. Chưa triển khai các màn hình ghi cấu hình nâng cao tương đương MikroTik Pro; không được hiểu phần giám sát là đã có quản trị cấu hình.
- Chưa có QR scanner/import-export QR và chưa có module cấu hình nâng cao. MCM không sử dụng VPN, VPS, relay hoặc agent trong kiến trúc Direct-DDNS đã chốt.
- MNDP discovery chỉ hoạt động trong Layer-2/broadcast domain mà điện thoại tham gia; không xuyên VLAN/subnet và phụ thuộc Neighbor Discovery được bật trên router.

- Netwatch hiện chỉ đọc trạng thái cấu hình/host hiện tại; chưa thu thập event history từ RouterOS.
- PPPoE active hiển thị phiên có `service=pppoe`; không phải thống kê mọi giao thức PPP.
- ARP và DHCP là ảnh chụp bảng tại thời điểm làm mới, không phải lịch sử nhận dạng thiết bị dài hạn.
- Lịch sử được tạo từ các lần refresh foreground; background worker chỉ ghi CPU/RAM.
- Chưa có push notification, rule cảnh báo tùy biến, CSV/PDF export, tài khoản người dùng hoặc đồng bộ cloud.
- Chưa hỗ trợ nhập IPv6 literal trong trường host; DDNS hostname có bản ghi A/AAAA có thể được hệ điều hành phân giải nếu mạng hỗ trợ.
- Các trường dữ liệu tùy phiên bản RouterOS và quyền user. Nếu một mục phụ không đọc được, dashboard báo PARTIAL và ghi cảnh báo, không giả lập dữ liệu.

## Quan trọng về MikroTik Cloud DDNS và truy cập từ xa

MikroTik IP Cloud DDNS cập nhật DNS name về địa chỉ IP công cộng được router báo lên Cloud. **DDNS chỉ giúp tìm địa chỉ; nó không tự mở cổng quản trị hay tạo VPN.** Muốn kết nối từ ngoài LAN, endpoint dịch vụ phải được định tuyến đến router và firewall phải cho phép nguồn truy cập được ủy quyền. Nếu router nằm sau CGNAT/double NAT, inbound access có thể không hoạt động.

Không mở `www-ssl`/`api-ssl` cho toàn Internet nếu không có kiểm soát truy cập. Giới hạn `available-from` và firewall theo địa chỉ nguồn đáng tin cậy; dùng tài khoản chỉ đọc riêng cho MCM. Tham khảo tài liệu MikroTik: [IP Cloud](https://help.mikrotik.com/docs/spaces/ROS/pages/97779929/Cloud), [Securing your router](https://help.mikrotik.com/docs/spaces/ROS/pages/328353/Securing+your+router).

## Nguyên tắc chỉ đọc

MCM không tạo/sửa/xóa cấu hình RouterOS, không reboot, không thay firewall, không tạo user, không thay DHCP, không bật Cloud DDNS và không thay đổi dịch vụ. Lệnh POST duy nhất trong ROS7 là phép ping chẩn đoán giới hạn; ROS6 gửi lệnh `/ping` giới hạn `count`.

## Kết nối RouterOS

### RouterOS 7

- Bật `www-ssl`, gán certificate hợp lệ và dùng HTTPS.
- User cần quyền đọc REST; ping cần thêm `test`. Kiểm tra policy theo đúng RouterOS build và chỉ cấp quyền tối thiểu.
- Port mặc định của MCM: TCP 443.

### RouterOS 6

- Bật `api-ssl`, gán certificate; không dùng API plaintext.
- Port mặc định của MCM: TCP 8729.
- MCM yêu cầu certificate pin; không chấp nhận chế độ API-SSL không có certificate.

Hướng dẫn cấu hình, firewall và xử lý lỗi TLS: `docs/ROUTER_SETUP_VI.md`.

## Bảo mật TLS và thông tin đăng nhập

- Fingerprint SHA-256 phải được đối chiếu độc lập trước khi lưu.
- Client từ chối certificate pin không khớp.
- Mật khẩu mã hóa AES-256-GCM; key đặt trong Android Keystore, không lưu plaintext trong Room.
- Khi đổi mật khẩu router, app tạo alias mã hóa mới trước khi cập nhật profile; nếu DB ghi lỗi, alias mới được gỡ, credential cũ giữ nguyên.
- Không đưa password hoặc API token ra JavaScript.

## Thiết kế và lộ trình chức năng

Xem `docs/FUNCTIONAL_DESIGN_VI.md` để biết kiến trúc module, luồng kết nối DDNS, ma trận cấu hình ROS6/ROS7 và cổng an toàn trước khi triển khai ghi cấu hình.

## Build

- JDK 17
- Gradle 8.7
- Android SDK Platform 35 / Build Tools 35.0.0
- Application ID: `com.multicloud.mcm`
- Version: `1.5.1` (versionCode 8)

ZIP nguồn này không kèm Gradle Wrapper JAR. Dùng AndroidForge hoặc cài Gradle 8.7 để build. Chạy static checks:

```bash
./scripts/androidforge-preflight.sh
./scripts/verify-source.sh
```

Build APK nếu đã có toolchain đầy đủ:

```bash
gradle --no-daemon :app:testDebugUnitTest :app:lintDebug :app:assembleDebug
```

APK dự kiến: `app/build/outputs/apk/debug/app-debug.apk`.

## Trạng thái nghiệm thu

Đây là **engineering source NOT RELEASE**. Trong môi trường đóng gói hiện tại chưa có Android SDK Platform 35 và Gradle cài đặt, nên chưa thực hiện được Room KAPT, Gradle/JUnit, lint, assemble APK hoặc cài lên điện thoại. Chưa có router thật để xác minh ROS6/ROS7 và remote DDNS. Không được diễn giải static checks là APK build PASS hay kết nối phần cứng PASS. Xem `BUILD_STATUS.md`, `AUDIT_REPORT_VI.md` và `docs/TEST_PLAN.md`.

## Cấu trúc

```text
app/src/main/java/com/multicloud/mcm/  Kotlin Android app, bridge, profile, monitor
app/src/main/java/.../routeros/         RouterOS 6 API-SSL + ping parser
app/src/main/java/.../data/             Room DB + migrations
app/src/main/java/.../security/         Keystore, TLS pin and TLS diagnostics
app/src/main/assets/www/                Local WebView UI
app/src/test/                            Unit tests
scripts/                                 Preflight, static checks and packaging
tools/                                   RouterOS mock servers
```
