# MCM — Thiết kế chức năng Direct-DDNS đa cửa hàng

## 1. Mục tiêu

Một ứng dụng Android quản lý nhiều cửa hàng và nhiều MikroTik. Mỗi router có WAN IP public động riêng và một hostname MikroTik IP Cloud DDNS. MCM kết nối trực tiếp hostname:port để đọc dữ liệu. Không VPN, không VPS/backend MCM, không relay, không agent trên router.

## 2. Luồng thêm router

1. Tạo cửa hàng/site và nhập tên router.
2. Nhập hostname `xxxx.sn.mynetname.net`; giữ hostname làm endpoint lâu dài, không khóa profile vào IP đã phân giải.
3. Chọn RouterOS 7 (REST HTTPS, mặc định 443) hoặc RouterOS 6 (API-SSL, mặc định 8729). Khi đổi hệ điều hành, UI tự đổi port mặc định; port tùy chỉnh vẫn được phép.
4. Nhập username/password riêng. Password lưu qua Android Keystore, không đưa vào WebView/localStorage/log.
5. Đọc fingerprint TLS, đối chiếu với chứng chỉ trên router qua kênh tin cậy độc lập, rồi mới lưu.
6. Chạy kiểm tra kết nối theo từng giai đoạn và hiển thị mã lỗi chính xác.

## 3. Chẩn đoán kết nối bắt buộc

- `DNS`: hostname không phân giải hoặc chưa cập nhật IP mới.
- `TCP_TIMEOUT` / `CONNECT_REFUSED`: WAN/firewall/NAT/port/service không truy cập được.
- `TLS_PROTOCOL`: port không phải dịch vụ TLS mong đợi hoặc cấu hình TLS không tương thích.
- `TLS_HANDSHAKE`: lỗi bắt tay/chứng chỉ.
- `TLS_FINGERPRINT_MISMATCH`: certificate không khớp pin đã lưu.
- `AUTH`: sai username/password hoặc phương thức đăng nhập.
- `PERMISSION`: tài khoản thiếu quyền đọc bảng cần thiết.
- `PARTIAL`: core resource thành công nhưng một số bảng tùy chọn lỗi.
- `ONLINE`: core resource đọc thành công và không có lỗi mục tùy chọn.

Không gộp các lỗi trên thành thông báo TLS chung. Không tự bỏ pin, không fallback HTTP và không tự đổi port tùy tiện.

## 4. Hành vi khi WAN IP thay đổi

- MCM lưu hostname; khi mở kết nối mới, phân giải hostname để nhận địa chỉ hiện tại.
- Nếu ISP vừa đổi IP và DNS chưa cập nhật, thông báo `DNS/DDNS chưa cập nhật`; retry có giới hạn và backoff.
- Nếu DNS đã đổi nhưng TCP không tới được, kiểm tra WAN/firewall/NAT.
- Không đánh dấu ONLINE chỉ vì DNS phân giải thành công. Chỉ đánh dấu sau khi đọc được `/system/resource`.
- Không tự thay hostname bằng IP mới; hostname là danh tính endpoint do người dùng quản lý.

## 5. Điều kiện mạng của từng cửa hàng

- WAN phải là public/reachable; WAN động được hỗ trợ qua DDNS.
- Nếu có modem/router NAT phía trước, cần chuyển tiếp đúng port WAN tới port dịch vụ trên MikroTik.
- Firewall chỉ cho phép IP nguồn quản trị tin cậy nếu có thể.
- CGNAT, inbound bị ISP chặn hoặc double NAT chưa cấu hình port-forward sẽ không truy cập trực tiếp được. Vì đã loại trừ VPN/relay/agent nên MCM không thể tự vượt qua các giới hạn này.

## 6. Dữ liệu quản lý

- Nhiều cửa hàng, nhiều router mỗi cửa hàng, không đặt giới hạn cứng tùy tiện.
- Mỗi router độc lập hostname, port, RouterOS, username, secret alias, TLS pin, trạng thái, lịch sử và thời điểm kiểm tra.
- Dashboard tổng hợp online/partial/offline và drill-down từng cửa hàng/router.
- Giám sát CPU/RAM/version/uptime, interface/traffic, PPPoE, ARP, DHCP, Netwatch, Bridge Host, VLAN, Cloud DDNS và ping theo khả năng RouterOS.
- Dữ liệu cũ phải hiển thị thời điểm snapshot; không giả lập trạng thái realtime.

## 7. An toàn

- Tài khoản chỉ đọc, quyền tối thiểu; không dùng tài khoản full admin hằng ngày.
- TLS SHA-256 pin bắt buộc; fingerprint capture không tự động được tin cậy.
- Không lưu credential trong QR/export/log.
- Phiên bản Direct-DDNS này chỉ đọc; không có lệnh cấu hình router.

## 8. Ngoài phạm vi đã chốt

Không có VPN/WireGuard/Back To Home, VPS, MCM Cloud backend, relay, agent, remote command queue, tự mở port, tự cấu hình firewall hoặc đồng bộ cloud. MNDP chỉ phục vụ thêm router trong LAN cục bộ.


## 9. Hoạt động bên trong phiên bản 1.5.1

- Nút **Kiểm tra DNS / TCP** phân giải hostname thành danh sách IP và thử mở TCP tới port đã chọn; kết quả chỉ xác nhận reachability, không tự kết luận TLS hoặc đăng nhập thành công.
- Nút **Đọc fingerprint TLS** thực hiện TLS handshake để đọc leaf certificate SHA-256; người vận hành phải đối chiếu fingerprint qua nguồn tin cậy độc lập trước khi lưu.
- RouterOS 7 REST dùng leaf SHA-256 pin làm trust anchor. Do MikroTik thường dùng certificate tự ký không có SAN trùng DDNS, kiểm tra hostname mặc định của OkHttp được bỏ qua sau khi pin đã được xác thực; pin sai vẫn bị từ chối.
- Refresh router chỉ xác nhận ONLINE khi đọc thành công `system/resource`; bảng phụ lỗi riêng sẽ tạo trạng thái PARTIAL và cảnh báo.
- Refresh All chạy tuần tự; lỗi một router không chặn các router sau.
- Background worker chạy theo chu kỳ Android WorkManager tối thiểu 15 phút, ghi trạng thái từng router và lưu CPU/RAM history; không bảo đảm realtime khi Android hạn chế chạy nền.

- Lỗi đăng nhập RouterOS 6/7 được tách thành AUTH; lỗi thiếu quyền đọc được tách thành PERMISSION khi giao thức trả đủ thông tin.
