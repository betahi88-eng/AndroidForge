# Cấu hình MikroTik để MCM kết nối nhiều Cloud/DDNS/domain

MCM chỉ đọc dữ liệu. Người quản trị tự chuẩn bị dịch vụ và firewall trên router; ứng dụng không tự chạy lệnh cấu hình.

## 1. Khai báo một hồ sơ trong MCM

Mỗi router/domain là một hồ sơ riêng, gồm:

- Tên hiển thị router.
- Nhóm Cloud/địa điểm (ví dụ Nhà thờ, Văn phòng, Chi nhánh).
- Host: `xxxx.sn.mynetname.net`, custom DDNS/domain hoặc IPv4. Chỉ nhập hostname/IP, không nhập `https://`, không thêm port và không thêm `/rest`.
- RouterOS 7 hoặc RouterOS 6.
- Port HTTPS/API-SSL.
- Username/password dành riêng cho MCM.
- SHA-256 TLS certificate fingerprint riêng của endpoint.

Nếu một domain trỏ qua NAT khác port, nhập port WAN mà điện thoại thực sự truy cập được. Không được giả định port ngoài giống port bên trong.

## 2. MikroTik IP Cloud DDNS

Trên router, `/ip cloud print` có thể cho biết `ddns-enabled`, `dns-name`, `public-address`, `public-address-ipv6`, `status` và `update-time`. MCM đọc các trường này để hiển thị; không tự bật hoặc force-update DDNS.

Tên DDNS chỉ ánh xạ đến địa chỉ IP công cộng được cập nhật. Nó không tự mở dịch vụ quản trị hoặc xuyên qua CGNAT/double NAT. Để truy cập thực tế, cần có đường mạng đến router, NAT/port mapping phù hợp nếu cần, và firewall cho phép nguồn được ủy quyền. Theo thiết kế MCM Direct-DDNS, không sử dụng VPN/WireGuard hoặc relay. Vì vậy từng cửa hàng bắt buộc phải có WAN public truy cập được từ Internet; nếu có modem/NAT phía trước thì phải chuyển tiếp đúng cổng WAN vào dịch vụ quản trị MikroTik. Không mở API/HTTPS quản trị cho toàn Internet; giới hạn nguồn truy cập bằng firewall/available-from khi có thể.

Tham khảo: [MikroTik IP Cloud](https://help.mikrotik.com/docs/spaces/ROS/pages/97779929/Cloud), [MikroTik router security](https://help.mikrotik.com/docs/spaces/ROS/pages/328353/Securing+your+router).

## 3. RouterOS 7 — REST HTTPS

1. Bật `www-ssl` và gán certificate phù hợp cho tên domain mà điện thoại kết nối.
2. Không dùng `www` HTTP cho REST production. Dùng HTTPS.
3. Tạo user riêng với quyền tối thiểu cần thiết; đọc resource/table cần `read`, phép ping cần `test`, dịch vụ REST yêu cầu policy phù hợp với phiên bản RouterOS.
4. Giới hạn `available-from` và firewall theo IP nguồn quản trị công cộng đáng tin cậy; không dùng LAN/VPN trong thiết kế Direct-DDNS.
5. Port mặc định trong MCM là TCP 443; khi chọn RouterOS 6, MCM tự đổi mặc định sang TCP 8729. Có thể nhập port WAN tùy chỉnh nếu cấu hình thật khác.

MCM chỉ gửi GET cho các bảng đọc. POST `/rest/ping` chỉ chạy phép ping có giới hạn count.

## 4. RouterOS 6 — API-SSL

1. Bật `api-ssl`, gán certificate TLS; mặc định TCP 8729.
2. Tạo user riêng có `read`, `api` và `test` cho ping; không cấp `write`, `policy`, `reboot` hoặc `sensitive`.
3. Giới hạn `available-from` và firewall theo IP nguồn quản trị công cộng đáng tin cậy; không dùng LAN/VPN trong thiết kế Direct-DDNS.
4. MCM dùng API-SSL native; không chọn RouterOS 7 REST cho RouterOS 6.
5. MCM từ chối API-SSL không có certificate để pin.

## 5. Fingerprint TLS — thao tác an toàn

1. Nhập host và port.
2. Chọn đúng họ RouterOS.
3. Nhấn **Đọc fingerprint TLS**.
4. Lấy fingerprint của certificate từ kênh độc lập đáng tin cậy (WinBox/console/export chứng chỉ hoặc quản trị viên khác).
5. Chỉ lưu khi 64 ký tự SHA-256 khớp chính xác.

Nút đọc fingerprint chỉ trình bày certificate đang nghe tại endpoint. Nó không xác minh danh tính router thay cho bước đối chiếu độc lập.

## 6. Xử lý lỗi `UNSUPPORTED_PROTOCOL`

Lỗi này có nghĩa kết nối TLS không thương lượng được giao thức tại host/port; thường cần kiểm tra:

- Đang trỏ đến port HTTP `www` thay vì HTTPS `www-ssl`.
- Port WAN/NAT chuyển nhầm đến dịch vụ khác hoặc port API-SSL.
- `www-ssl`/`api-ssl` chưa bật hoặc không được gán certificate phù hợp.
- Router/proxy đầu cuối không nói TLS tương thích với Android.
- Profile chọn sai RouterOS: ROS7 dùng REST HTTPS qua `www-ssl`; ROS6 dùng API-SSL.

Không tắt certificate pin và không chuyển sang HTTP để né lỗi. Nếu ROS7 chọn 443, hãy xác minh chính port 443 trên domain có thực sự chuyển đến `www-ssl` hay không.

## 7. Kiểm tra sau kết nối

- CPU/RAM/version/uptime phải có giá trị hợp lệ từ `/system/resource`.
- Lần đo RX/TX đầu chỉ lập baseline; lần sau mới có Mbps. Lịch sử được lưu riêng theo từng interface và có biểu đồ RX/TX cho interface được chọn; MCM không cộng counter các cổng/bridge để tránh đếm trùng.
- PPPoE active chỉ đếm `service=pppoe`.
- ARP, DHCP lease và Netwatch là ảnh chụp tại lần refresh, không phải lịch sử event.
- Ping phải xác nhận số gói gửi/nhận theo parser; không dùng RX/TX làm packet loss.
- Nếu status PARTIAL, đọc danh sách cảnh báo để xem bảng nào bị từ chối hoặc không khả dụng.


## 8. Kiểm tra WAN động và DDNS

- Bật MikroTik IP Cloud DDNS trên từng router và xác nhận `dns-name` đúng với hostname đã nhập trong MCM.
- Xác nhận `public-address` là IP WAN public thực tế; nếu router nằm sau modem, đối chiếu địa chỉ WAN của modem và trạng thái NAT.
- Từ mạng di động bên ngoài cửa hàng, kiểm tra hostname phân giải về IP public hiện tại và cổng WAN được phép truy cập. Không dùng kiểm tra từ chính Wi-Fi cửa hàng làm bằng chứng truy cập từ Internet.
- Sau khi ISP đổi IP, chờ DDNS cập nhật rồi refresh lại MCM. Nếu thất bại, phân biệt DNS chưa cập nhật, TCP timeout, TLS/pin, đăng nhập và thiếu quyền.
- Nếu nhà mạng dùng CGNAT, IP WAN trên router thường thuộc dải private/shared và không thể nhận kết nối inbound trực tiếp; thiết kế không VPN này sẽ không truy cập được cho đến khi có WAN public thực sự.
