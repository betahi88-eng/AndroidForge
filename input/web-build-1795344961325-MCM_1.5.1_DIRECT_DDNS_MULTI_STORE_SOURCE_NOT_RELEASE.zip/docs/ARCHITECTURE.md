# MCM 1.5.1 — Direct MikroTik Cloud DDNS Architecture

## Product boundary

MCM Android connects directly to each MikroTik router through that router's MikroTik IP Cloud DDNS hostname and its current public WAN address. There is no MCM cloud backend, VPS, VPN, relay, router-side agent, tunnel provisioning, or account synchronization. Profiles and history remain local to the Android device.

```text
MCM Android
  ├─ local multi-store / multi-router inventory
  ├─ Room profile + monitoring history
  ├─ Android Keystore encrypted credentials
  └─ direct connection per profile
       ├─ DNS resolve: <router>.sn.mynetname.net
       ├─ TCP to explicitly configured public management port
       ├─ RouterOS 7: HTTPS www-ssl → REST read API (default 443)
       └─ RouterOS 6: TLS api-ssl → native RouterOS API (default 8729)
```

## WAN dynamic address behavior

- The profile stores the hostname, not a resolved WAN IP as a permanent endpoint. Every new network connection uses the hostname so DNS can return the current address.
- The displayed endpoint remains the hostname and configured port; the app must not silently replace it with a previously resolved IP.
- A DNS result changing is normal for dynamic WAN. It is not itself proof that the router is reachable or that the certificate belongs to the intended router. TLS pinning remains mandatory.
- If DNS is stale or the WAN address has just changed, retry after a bounded backoff; do not loop rapidly and do not report ONLINE until the core resource request succeeds.
- DNS resolution, TCP connect, TLS handshake/pin, HTTP/API authentication, permission and RouterOS read failures must remain distinct diagnostic stages.

## Required public reachability

Each store must have a directly reachable public WAN address (dynamic is supported) and an inbound path from the phone to the configured management port. Router firewall and any upstream modem/NAT must permit that path. MikroTik IP Cloud DDNS only maps the hostname to an address; it does not open ports, create NAT rules, bypass CGNAT, or provide a relay. If the ISP places the site behind CGNAT or blocks inbound traffic, this no-VPN direct design cannot reach that router until the ISP supplies a public/reachable address or equivalent direct inbound service.

## Protocol and ports

- RouterOS 7: REST over HTTPS through `www-ssl`, default TCP 443.
- RouterOS 6: native API over TLS through `api-ssl`, default TCP 8729.
- The UI selects the corresponding default when RouterOS family changes. Custom ports remain supported and must match the real WAN-facing port, including any NAT port translation.
- No HTTP fallback and no automatic fallback from one RouterOS protocol to another.

## Security

- Use a dedicated least-privilege read-only account per router.
- Restrict management firewall source addresses where feasible. Do not expose management services to the whole Internet without restrictions.
- Each profile has independent username, Keystore credential alias and SHA-256 leaf certificate pin.
- Fingerprint inspection is an untrusted capture for comparison only. The user must verify it through a trusted independent channel before saving. A changed certificate or changed router endpoint requires re-verification.
- Do not log passwords, authorization headers, API sentences or secret material.

## Monitoring contract

Core `system/resource` read determines reachability. Optional snapshots (interfaces, `/ip/cloud`, PPPoE active, ARP, DHCP leases, Netwatch, bridge hosts, VLANs and bounded ping) fail independently and yield PARTIAL. OFFLINE is only reported when core connectivity/read fails. Every snapshot carries a timestamp; stale data must not be presented as current.

## Explicit exclusions

No MCM server/VPS, VPN/WireGuard/Back To Home, relay, router-side agent, remote command queue, automatic router configuration, public port opening, QR credential export, or remote cloud synchronization. LAN MNDP discovery remains an optional local convenience and does not participate in remote DDNS access.
