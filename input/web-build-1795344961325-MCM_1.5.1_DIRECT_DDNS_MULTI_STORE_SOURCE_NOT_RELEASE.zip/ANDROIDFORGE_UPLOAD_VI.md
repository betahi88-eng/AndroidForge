# Build MCM 1.4.0 bằng AndroidForge

## ZIP cần upload
Dùng duy nhất `MCM_1.4.0_MULTI_ROUTER_MANAGER_SOURCE_NOT_RELEASE.zip`. Đây là dự án Android Native Gradle/Kotlin, không phải Flutter. ZIP đặt các file Gradle ngay tại root, không lồng thư mục dự án.

Root phải có `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `app/build.gradle.kts` và `app/src/main/AndroidManifest.xml`. Không có `pubspec.yaml`, `harmony_patched` hoặc project Flutter.

## Cấu hình build
- Project: `MikroTikMultiCloudMonitor`
- Application ID: `com.multicloud.mcm`
- Version: `1.4.0` / versionCode `6`
- JDK: 17
- Gradle: 8.7
- Android Gradle Plugin: 8.6.1
- Kotlin: 2.0.21
- compileSdk/targetSdk: 35; minSdk: 26
- Variant đầu tiên: `debug`
- Gradle tasks: `:app:testDebugUnitTest :app:lintDebug :app:assembleDebug`

## Tránh lỗi AndroidForge chọn nhầm Flutter
Log AndroidForge cũ trong hồ sơ cho thấy nó đã chạy `flutter build apk` trên workspace `harmony_patched` và thất bại vì Gradle 8.9 thấp hơn Flutter yêu cầu 8.14. Đó không phải lỗi Kotlin source MCM; đó là dấu hiệu AndroidForge đã nhận nhầm project Flutter/workspace. Với ZIP này:
1. Upload file ZIP 1.4.0, không upload ZIP cũ hoặc thư mục chứa nhiều project.
2. Chọn project type Android / Gradle nếu giao diện có lựa chọn.
3. Kiểm tra log Detect Project: root phải chứa trực tiếp `settings.gradle.kts` và `app/build.gradle.kts`.
4. Nếu log xuất hiện `flutter build apk`, `pubspec.yaml` hoặc `harmony_patched`, dừng build vì đã chọn sai root/project.
5. Xác nhận toolchain Gradle 8.7 + JDK 17 phù hợp AGP 8.6.1.

APK mong đợi: `app/build/outputs/apk/debug/app-debug.apk`. Chỉ xác nhận build thành công khi APK tồn tại, task assemble thành công, package `com.multicloud.mcm` và version `1.4.0` được xác minh.

## Trạng thái
ZIP là engineering source NOT RELEASE. Không chứa APK hoặc release keystore. Full Android build, lint, RouterOS thật và thiết bị Android thật vẫn cần nghiệm thu bằng AndroidForge và phần cứng.
