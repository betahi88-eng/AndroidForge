# MCM 1.4.0 — Multi-Router Manager source audit

## Kết luận

Đây là source engineering NOT RELEASE dựa trên MCM 1.2.0. Bản này sửa lỗi nullable, hoàn thiện phân tích MNDP và bổ sung nhận biết trạng thái VPN Android. Không tuyên bố đã có QR, VPN provisioning hoặc quản trị cấu hình ghi nâng cao.

## Baseline và phạm vi thay đổi

- Baseline ZIP: `MCM_1.2.0_ANDROIDFORGE_SOURCE_NOT_RELEASE.zip`
- Baseline SHA-256: `c432da3e03fab25e348c96454881d805c9c553ed55c3b80def3962d0ec1b1214`
- Project: Android native Kotlin/Gradle, WebView local assets, Room, Android Keystore.
- Version đầu ra source: 1.4.0 / versionCode 6.
- Application ID: `com.multicloud.mcm`.

## Thay đổi thực chất trong 1.4.0

1. Sửa nullable flow trong `RouterOs7Repository.readInterfaces()` bằng cách chuẩn hóa giá trị `running` trước khi parse.
2. Thêm MNDP UDP/5678 discovery, multicast lock, parser TLV, giới hạn thời gian scan và chống trùng theo MAC/source IP.
3. Thêm nút dò LAN và danh sách thiết bị tìm thấy; chọn thiết bị chỉ điền host/name/version vào form, không tự lưu và không tự tin cậy TLS.
4. Sửa MNDP uptime TLV sang uint32 little-endian, thêm IPv6 và kiểm tra trailing TLV lỗi.
5. Thêm test cho uptime, board/interface, IPv6, TLV không biết và packet lỗi.
6. Thêm chỉ báo transport mạng/VPN Android; không suy diễn route tới router.
7. Thêm tài liệu thiết kế chức năng, QR metadata không bí mật, VPN và cấu hình read-before-write.
8. Tăng versionName lên 1.4.0/versionCode 6 và cập nhật AndroidForge/CI gates.

## Các chức năng đã có từ baseline 1.2.0

1. **Nhiều Cloud/domain/device:** thêm trường nhóm Cloud/địa điểm; mỗi hồ sơ có host, port, RouterOS, username, mật khẩu và TLS pin độc lập; phân loại MikroTik `.sn.mynetname.net`, custom DDNS/domain và IP trực tiếp.
2. **CRUD profile:** hỗ trợ sửa hồ sơ, giữ password khi bỏ trống, xoay credential alias khi đổi password; xóa profile + history + interface counters trong Room transaction.
3. **Database:** migration v1→v2 thêm `siteName`; v2→v3 thêm status/error/last-check cho từng router. Đã đăng ký migration trong MainActivity và WorkManager.
4. **Multi-router status:** lưu `UNKNOWN/ONLINE/PARTIAL/OFFLINE`; ghi thời điểm check, lỗi gần nhất; UI phân nhóm và hiển thị trạng thái từng router.
5. **Refresh all:** quét tuần tự toàn bộ profile, trả summary và snapshot router đang chọn; tránh mở một loạt session tới mọi router cùng lúc.
6. **RouterOS 7 REST:** bổ sung đọc `/ip/cloud`, `/ppp/active`, `/ip/arp`, `/ip/dhcp-server/lease`, `/tool/netwatch`.
7. **RouterOS 6 API-SSL:** bổ sung các lệnh print tương ứng; giữ direct login và legacy challenge-response.
8. **Độ chính xác dữ liệu:** chỉ tính session có `service=pppoe`; lịch sử riêng theo router; ARP/DHCP/Netwatch được ghi như snapshot thời điểm refresh.
9. **TLS diagnostics:** phân biệt DNS, timeout, refused, hostname, fingerprint và protocol mismatch; nhận diện `UNSUPPORTED_PROTOCOL` và `Unsupported or unrecognized SSL message` ở cả RouterOS 6 API-SSL/RouterOS 7 REST.
10. **Interface traffic history:** lưu RX/TX Mbps riêng theo router và interface; không cộng gộp bridge/ether gây đếm trùng; chọn interface để xem biểu đồ lịch sử.
11. **Giao diện Android 15:** xử lý system bar, display cutout và IME insets cho WebView để status/navigation bar không che nội dung.
12. **Mock + tests:** cập nhật dữ liệu mock Cloud IPv4/IPv6/status; thêm test host classification, TLS error classifier và interface history key; kiểm tra DOM ID.
13. **Tài liệu:** thay tài liệu 1.0.1 cũ bằng hướng dẫn multi-DDNS, điều kiện remote reachability, RouterOS 6/7 và nghiệm thu.

## Nhóm chức năng ở source 1.4.0

| Hạng mục | Trạng thái source | Lưu ý nghiệm thu |
|---|---|---|
| Thêm/sửa/gỡ nhiều router | Có triển khai | Cần chạy Room migration và kiểm thử Keystore trên Android |
| Nhóm Cloud/địa điểm | Có triển khai | Tên nhóm do người dùng đặt, lưu cục bộ |
| MikroTik Cloud DDNS | Có đọc status/name/public IPv4/IPv6 | Cần router có IP Cloud và quyền read |
| Custom DDNS/domain/IP | Có kiểm tra định dạng và lưu độc lập | DNS resolution/reachability vẫn phụ thuộc mạng |
| RouterOS 7 REST HTTPS | Có adapter | Chưa test RouterOS thật |
| RouterOS 6 API-SSL | Có adapter | Chưa test các minor version thật |
| CPU/RAM/version/uptime | Có đọc và lưu history | Background chỉ CPU/RAM |
| Interface RX/TX | Có đọc counter, tính delta và lưu lịch sử theo từng interface | Lần đầu chỉ tạo baseline; biểu đồ tách RX/TX, không cộng bridge/ether |
| PPPoE active | Có lọc `service=pppoe` | Cần quyền đọc `/ppp/active` |
| ARP | Có snapshot table | Không phải lịch sử nhận dạng thiết bị |
| DHCP lease | Có snapshot table | Không theo dõi lease event liên tục |
| Netwatch | Có snapshot trạng thái hiện tại | Chưa ingest event history |
| ICMP loss | Có parser độc lập | Total-loss ROS7 thiếu final counter thì không đoán |
| Refresh all | Có quét tuần tự | Cần đo thời gian với số profile lớn |
| Push alert/custom alert | Chưa có | Không tuyên bố đã triển khai |
| CSV/PDF export | Chưa có | Không tuyên bố đã triển khai |
| Cloud sync/backend | Không có | Không cần cho mô hình quản lý nhiều DDNS local-first |

## Kiểm tra đã chạy trong workspace

- AndroidForge flat-root preflight: PASS.
- Node `--check` WebView JavaScript: PASS.
- Python `py_compile` mock servers: PASS.
- Bash `bash -n` scripts: PASS.
- Parse Manifest/styles/network config XML: PASS.
- `RouterHostValidator.kt` compile riêng bằng `kotlinc 1.9.0` và smoke test hostname/IP/MikroTik Cloud: PASS.
- MNDP parser Kotlin smoke harness chạy bằng `kotlinc`: PASS (identity, uptime little-endian, board/interface, unknown TLV và malformed trailing bytes).
- RouterOS 6 API-SSL mock integration với source Kotlin thật: direct login, legacy challenge, đọc system resource, Cloud DDNS và ping có loss: PASS.
- Wrong TLS fingerprint bị từ chối: PASS; HTTP giả trên cổng API-SSL được phân loại `TLS_PROTOCOL`: PASS.
- Targeted Kotlin smoke harness dùng chính `McmInterfaceRateService.kt` và `McmHistoryStore.kt` với Room/JSON test doubles: baseline không tạo Mbps giả, delta 1/2 Mbps đúng, counter reset không tạo rate âm, recovery và metric key/read tách theo interface: PASS. Đây không phải Android Gradle/JUnit build.
- Repository/monitoring Kotlin source đã compile riêng với adapter stub tương thích API để rà cú pháp/kiểu; đây không phải full Android/Room compile.
- `RouterHostValidatorTest` và `TlsErrorClassifierTest` được bổ sung nhưng chưa chạy JUnit qua Gradle.

## Chưa kiểm tra được

- Full Kotlin/Android Gradle compile và Room KAPT; các smoke compile có stub không thay thế bước này.
- JUnit Gradle task, Android Lint và assembleDebug.
- Cài APK trên Android thật.
- RouterOS 6/7 phần cứng, certificate, policy, API response và ping.
- Remote DDNS qua WAN/VPN/NAT/CGNAT, IP public đổi và firewall nguồn.
- Hiệu năng refresh-all với số lượng router lớn.

Môi trường hiện tại có Java 21 và Kotlin compiler 1.9.0, nhưng không có Gradle 8.7 hoặc Android SDK Platform 35. `scripts/verify-source.sh` đã skip build Android và ghi rõ điều kiện. MNDP parser test source đã được mở rộng; smoke harness độc lập PASS nhưng JUnit Gradle chưa chạy. Không tuyên bố APK đã tạo hay app đã hoạt động trên router thật.

## Điểm an toàn quan trọng

MikroTik IP Cloud DDNS chỉ cung cấp DNS name ánh xạ tới IP được router cập nhật. DDNS không tự tạo VPN, không mở port quản trị và không vượt qua CGNAT/double NAT. Cần có đường mạng và firewall phù hợp; ưu tiên VPN/WireGuard, không mở API/HTTPS cho toàn Internet. Tham khảo tài liệu MikroTik IP Cloud và Securing your router.

## Lệnh nghiệm thu sau khi có toolchain

```bash
gradle --no-daemon :app:testDebugUnitTest :app:lintDebug :app:assembleDebug
```

APK chỉ được xác nhận khi file `app/build/outputs/apk/debug/app-debug.apk` tồn tại, package là `com.multicloud.mcm`, version là `1.4.0`, cài được và vượt qua smoke test thiết bị.
