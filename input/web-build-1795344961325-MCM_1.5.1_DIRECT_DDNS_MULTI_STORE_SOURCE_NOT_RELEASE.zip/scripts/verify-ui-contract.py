#!/usr/bin/env python3
"""Check that literal WebView DOM id lookups exist in the main HTML document."""
from __future__ import annotations

import re
from pathlib import Path

root = Path(__file__).resolve().parents[1]
html = (root / "app/src/main/assets/www/index.html").read_text(encoding="utf-8")
ids = re.findall(r'\bid=["\']([^"\']+)["\']', html)
if len(ids) != len(set(ids)):
    duplicates = sorted({item for item in ids if ids.count(item) > 1})
    raise SystemExit(f"Duplicate HTML id(s): {', '.join(duplicates)}")

lookups: dict[str, set[str]] = {}
for path in (root / "app/src/main/assets/www").glob("*.js"):
    content = path.read_text(encoding="utf-8")
    for dom_id in re.findall(r'\$\(["\']([^"\']+)["\']\)', content):
        lookups.setdefault(dom_id, set()).add(path.name)

missing = sorted(set(lookups) - set(ids))
if missing:
    details = [f"{dom_id} ({', '.join(sorted(lookups[dom_id]))})" for dom_id in missing]
    raise SystemExit("Missing HTML element id(s): " + "; ".join(details))

print(f"WebView DOM contract: PASS ({len(ids)} unique IDs, {len(lookups)} JS literal lookups)")
