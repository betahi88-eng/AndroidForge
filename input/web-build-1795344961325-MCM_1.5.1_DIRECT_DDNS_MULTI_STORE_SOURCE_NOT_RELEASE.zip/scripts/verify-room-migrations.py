#!/usr/bin/env python3
"""Exercise the SQL used by the Room 1->2->3 migrations without Android runtime."""
from __future__ import annotations

import sqlite3


def columns(connection: sqlite3.Connection, table: str) -> set[str]:
    return {row[1] for row in connection.execute(f'PRAGMA table_info("{table}")')}


def check_v1_to_v3() -> None:
    connection = sqlite3.connect(":memory:")
    connection.execute(
        """CREATE TABLE router_profiles (
            id TEXT NOT NULL PRIMARY KEY, name TEXT NOT NULL, host TEXT NOT NULL,
            port INTEGER NOT NULL, routerOsMajor INTEGER NOT NULL, username TEXT NOT NULL,
            credentialAlias TEXT NOT NULL, tlsSha256Pin TEXT NOT NULL,
            createdAtEpochMs INTEGER NOT NULL, lastSeenAtEpochMs INTEGER
        )"""
    )
    connection.execute(
        "INSERT INTO router_profiles VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        ("router-1", "Office", "office.sn.mynetname.net", 443, 7, "monitor", "alias-1", "A" * 64, 1, 2),
    )
    connection.execute("CREATE TABLE metric_history (id INTEGER PRIMARY KEY, routerId TEXT, metricKey TEXT, value REAL)")
    connection.execute("INSERT INTO metric_history VALUES (1, 'router-1', 'cpu_load', 12.0)")
    connection.execute("CREATE TABLE interface_counters (routerId TEXT, interfaceName TEXT, rxBytes INTEGER)")
    connection.execute("INSERT INTO interface_counters VALUES ('router-1', 'ether1', 1000)")

    connection.execute("ALTER TABLE router_profiles ADD COLUMN siteName TEXT NOT NULL DEFAULT ''")
    connection.execute("ALTER TABLE router_profiles ADD COLUMN lastStatus TEXT NOT NULL DEFAULT 'UNKNOWN'")
    connection.execute("ALTER TABLE router_profiles ADD COLUMN lastErrorCode TEXT")
    connection.execute("ALTER TABLE router_profiles ADD COLUMN lastErrorMessage TEXT")
    connection.execute("ALTER TABLE router_profiles ADD COLUMN lastCheckedAtEpochMs INTEGER")

    expected = {
        "siteName", "lastStatus", "lastErrorCode", "lastErrorMessage", "lastCheckedAtEpochMs"
    }
    assert expected.issubset(columns(connection, "router_profiles"))
    row = connection.execute(
        "SELECT id, name, host, credentialAlias, siteName, lastStatus, lastErrorCode "
        "FROM router_profiles WHERE id = 'router-1'"
    ).fetchone()
    assert row == ("router-1", "Office", "office.sn.mynetname.net", "alias-1", "", "UNKNOWN", None)
    assert connection.execute("SELECT value FROM metric_history WHERE routerId = 'router-1'").fetchone() == (12.0,)
    assert connection.execute("SELECT rxBytes FROM interface_counters WHERE routerId = 'router-1'").fetchone() == (1000,)
    connection.close()


def check_v2_to_v3() -> None:
    connection = sqlite3.connect(":memory:")
    connection.execute(
        """CREATE TABLE router_profiles (
            id TEXT NOT NULL PRIMARY KEY, name TEXT NOT NULL, host TEXT NOT NULL,
            port INTEGER NOT NULL, routerOsMajor INTEGER NOT NULL, username TEXT NOT NULL,
            credentialAlias TEXT NOT NULL, tlsSha256Pin TEXT NOT NULL,
            createdAtEpochMs INTEGER NOT NULL, lastSeenAtEpochMs INTEGER,
            siteName TEXT NOT NULL DEFAULT ''
        )"""
    )
    connection.execute(
        "INSERT INTO router_profiles (id, name, host, port, routerOsMajor, username, credentialAlias, tlsSha256Pin, createdAtEpochMs, siteName) "
        "VALUES ('router-2', 'Branch', 'branch.example.net', 8729, 6, 'monitor', 'alias-2', ?, 1, 'Branch A')",
        ("B" * 64,),
    )
    connection.execute("ALTER TABLE router_profiles ADD COLUMN lastStatus TEXT NOT NULL DEFAULT 'UNKNOWN'")
    connection.execute("ALTER TABLE router_profiles ADD COLUMN lastErrorCode TEXT")
    connection.execute("ALTER TABLE router_profiles ADD COLUMN lastErrorMessage TEXT")
    connection.execute("ALTER TABLE router_profiles ADD COLUMN lastCheckedAtEpochMs INTEGER")
    row = connection.execute(
        "SELECT siteName, lastStatus, lastErrorCode FROM router_profiles WHERE id = 'router-2'"
    ).fetchone()
    assert row == ("Branch A", "UNKNOWN", None)
    connection.close()


if __name__ == "__main__":
    check_v1_to_v3()
    check_v2_to_v3()
    print("Room SQL migration preservation checks: PASS (v1→v2→v3 and v2→v3)")
