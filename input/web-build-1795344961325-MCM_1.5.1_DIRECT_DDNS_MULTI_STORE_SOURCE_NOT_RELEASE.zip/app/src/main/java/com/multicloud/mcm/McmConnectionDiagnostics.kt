package com.multicloud.mcm

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

/** Read-only endpoint diagnostics: DNS and TCP reachability only; never authenticates or changes a router. */
class McmConnectionDiagnostics {
    suspend fun inspect(rawHost: String, port: Int): JSONObject = withContext(Dispatchers.IO) {
        val host = RouterHostValidator.normalize(rawHost)
        require(port in 1..65535) { "Port phải từ 1 đến 65535." }
        val startedAt = System.currentTimeMillis()
        val addresses = try {
            InetAddress.getAllByName(host).toList()
        } catch (_: java.net.UnknownHostException) {
            return@withContext JSONObject()
                .put("ok", false).put("stage", "DNS")
                .put("code", "DNS_FAILED")
                .put("message", "Không phân giải được $host. Kiểm tra Cloud DDNS, Internet và cập nhật IP WAN.")
                .put("elapsedMs", System.currentTimeMillis() - startedAt)
        }
        val addressJson = JSONArray().apply { addresses.forEach { put(it.hostAddress ?: "") } }
        var lastError: Exception? = null
        for (address in addresses) {
            try {
                Socket().use { socket ->
                    socket.connect(InetSocketAddress(address, port), TCP_TIMEOUT_MS)
                }
                return@withContext JSONObject()
                    .put("ok", true).put("stage", "TCP")
                    .put("code", "TCP_REACHABLE")
                    .put("message", "DNS phân giải thành công và TCP mở được cổng $port. Tiếp theo cần kiểm tra TLS fingerprint và đăng nhập RouterOS.")
                    .put("addresses", addressJson)
                    .put("elapsedMs", System.currentTimeMillis() - startedAt)
            } catch (error: Exception) {
                lastError = error
            }
        }
        val timeout = lastError is java.net.SocketTimeoutException
        JSONObject()
            .put("ok", false)
            .put("stage", "TCP")
            .put("code", if (timeout) "TCP_TIMEOUT" else "TCP_UNREACHABLE")
            .put("message", if (timeout)
                "DNS đã phân giải nhưng kết nối TCP tới $host:$port bị timeout. Kiểm tra WAN firewall, NAT/port-forward hoặc ISP chặn inbound."
            else
                "DNS đã phân giải nhưng không mở được TCP $host:$port. Kiểm tra dịch vụ RouterOS, port và firewall."
            )
            .put("addresses", addressJson)
            .put("detail", lastError?.javaClass?.simpleName ?: "Unknown")
            .put("elapsedMs", System.currentTimeMillis() - startedAt)
    }

    companion object { private const val TCP_TIMEOUT_MS = 5_000 }
}
