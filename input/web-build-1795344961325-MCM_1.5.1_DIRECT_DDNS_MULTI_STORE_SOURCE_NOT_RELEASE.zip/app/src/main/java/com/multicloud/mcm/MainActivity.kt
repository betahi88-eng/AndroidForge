package com.multicloud.mcm

import android.os.Bundle
import android.graphics.Color
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.room.Room
import com.multicloud.mcm.data.McmDatabase
import androidx.webkit.WebViewAssetLoader
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var database: McmDatabase
    private lateinit var bridge: McmJavascriptBridge

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Android 15 enforces edge-to-edge for targetSdk 35. Pad the single WebView
        // with system/IME insets so status and navigation bars never cover controls.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = true
            isAppearanceLightNavigationBars = true
        }

        scheduleBackgroundMonitoring()
        database = Room.databaseBuilder(applicationContext, McmDatabase::class.java, "mcm.db")
            .addMigrations(McmDatabase.MIGRATION_1_2, McmDatabase.MIGRATION_2_3)
            .build()
        val credentials = com.multicloud.mcm.security.SecureCredentialStore(applicationContext)

        webView = WebView(this)
        ViewCompat.setOnApplyWindowInsetsListener(webView) { view, insets ->
            val safeBars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            view.setPadding(
                safeBars.left,
                safeBars.top,
                safeBars.right,
                maxOf(safeBars.bottom, ime.bottom)
            )
            insets
        }
        setContentView(webView)
        ViewCompat.requestApplyInsets(webView)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = false
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
        }
        webView.webViewClient = McmAssetWebViewClient(loader)
        webView.webChromeClient = WebChromeClient()
        bridge = McmJavascriptBridge(webView, database, credentials)
        webView.addJavascriptInterface(bridge, "McmBridge")
        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
    }

    private fun scheduleBackgroundMonitoring() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
        val request = PeriodicWorkRequestBuilder<McmBackgroundWorker>(15, TimeUnit.MINUTES)
            .setConstraints(constraints)
            .addTag("mcm-background-monitor")
            .build()
        WorkManager.getInstance(applicationContext).enqueueUniquePeriodicWork(
            "mcm-background-monitor",
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            if (::bridge.isInitialized) bridge.close()
            webView.removeJavascriptInterface("McmBridge")
            webView.destroy()
        }
        if (::database.isInitialized) database.close()
        super.onDestroy()
    }
}
