# MCM 1.6.3 — build and acceptance status

Source identity: `MCM-1.6.3-DDNS-RECONCILED-006`  
Parent source: `MCM_1.6.3_DDNS_RECONCILED_005_SOURCE_NOT_RELEASE.zip`  
Parent SHA-256: `be09a41a4ca9ab7325553c400b8e5ecc5b309817a549e2239c4f94199c2380cf`  
Application ID: `com.multicloud.mcm`  
Version: `1.6.3` (`versionCode=12`)  
Room schema: `8`

## Candidate 006 changes

- Preserves direct native Android Kotlin/Gradle app, multi-router profiles, encrypted credentials, DNS fallback, TLS identity checks, diagnostics, metrics, histories, UI and existing RouterOS 6/7 adapters.
- Separates REST HTTPS and API-SSL SHA-256 pins by service and exact WAN port; Room v7→v8 migration carries legacy pins only to the service that can be inferred safely.
- AUTO failover is consistent for first connection, individual refresh, Refresh All and WorkManager: only endpoint/protocol failures qualify; the alternate service must have its own matching, previously confirmed pin or request a separate confirmation. AUTH, permission, TLS hostname, certificate validity and fingerprint mismatch do not trigger failover.
- DNS failures are stored as OFFLINE diagnostics rather than appearing as an unexplained refresh error. A successful failover updates the active transport/port only after the alternate endpoint passes the core authenticated resource read.
- Adds a central read-only policy at both RouterOS transports. REST is limited to the monitoring GET allowlist and bounded ping POST; API-SSL is limited to the monitoring `/print` allowlist and bounded ping. Configuration mutations, reboot, firewall, NAT, service and user commands are denied before network I/O.
- Bounds API-SSL untrusted response processing: 1 MiB per word, 128 words and 4 MiB per sentence, 16 MiB per command response and maximum 10,000 response rows.
- Uses explicit X.509 endpoint identity matching (DNS SAN, IP SAN, and legacy CN only when no DNS SAN exists), with one-label wildcard handling. The same verifier is used by REST HTTPS, API-SSL and first-use certificate inspection; default JVM hostname-verifier behavior on raw TLS sockets is not relied upon.
- Limits REST responses to 16 MiB and 10,000 rows using a bounded stream reader; bounds are checked even when the server omits Content-Length. The WebView is restricted to packaged same-origin assets, and the submitted password is cleared from its field and transient JS variable after the native call returns.
- Treats old AUTO profiles with no recorded active transport as ambiguous during v7→v8 migration. Their former single pin is retained as data but is not reused for either protocol until a service-specific pin is explicitly confirmed.
- Documents RouterOS least-privilege policy: `read,api` for API-SSL; `read,api,rest-api` for REST; optional `test` only for integrated ping. No `write`, `policy` or `reboot` permissions are required.
- Rejects manually entered IPv6 literals as scoped out; a DDNS hostname may still resolve to IPv6 addresses.
- Keeps three primary Add Router inputs and the closed Advanced section for service mode/WAN port. No new product features outside the established scope were added.

## Checks actually run in this workspace

- `scripts/androidforge-preflight.sh`: **PASS** (native Android project identity and pinned package/toolchain settings).
- `scripts/verify-room-migrations.py`: **PASS** (v1→v8; profile, metrics, counters and connection logs preserved; service pins separated by transport and port; ambiguous AUTO legacy pin is not reused).
- `scripts/verify-ui-contract.py`: **PASS** (75 unique DOM IDs, exactly three primary inputs, advanced section closed by default).
- Standalone Kotlin/JVM smoke for read-only policy: **PASS**, 19 assertions.
- Standalone Kotlin/JVM smoke for API codec: **PASS**, 4 assertions, including rejection of oversized words and sentences.
- Standalone Kotlin/JVM smoke for host validation: **PASS**, 5 assertions, including rejection of raw/bracketed IPv6 literals.
- Standalone Kotlin/JVM smoke for service mode and TLS pin scoping: **PASS**, 13 assertions.
- Direct hostname-verifier smoke against X.509 test certificates: **PASS**, 10 assertions across DNS SAN, IP SAN, one-label wildcard, malformed input, legacy CN-only compatibility/mismatch and multi-label wildcard rejection. The verifier uses `X500Principal` and no Android-unsupported JNDI dependency.
- REST bounded body/row handling standalone JVM smoke: **PASS**, 5 assertions for normal bodies, streamed overflow, declared overflow and row count ceiling.
- `RouterOs6ApiClient.kt` + codec + read-only policy + pin/trust + hostname verifier + TLS error classifier compiled with Kotlin/JVM 1.9 using test doubles for Android/DNS dependencies. Local API-SSL mock: **PASS** for modern login, legacy challenge login, resource read, mutation blocked before network, wrong pin rejected and wrong hostname rejected. Retested after the final hostname parser hardening.
- First-use TLS inspector compiled from source with test doubles and local TLS mock: **PASS** for valid certificate/SAN fingerprint capture and hostname mismatch fail-closed; rerun after hostname parser hardening.
- JavaScript `node --check`, Python `py_compile`, shell `bash -n`, and Android XML parsing: **PASS** (rerun by `verify-source.sh`).
- Source provenance SHA-256 manifest: **PASS** (54 file hashes; this manifest does not self-hash).

## Not run / release blockers

- This runtime has OpenJDK 21.0.12, but no JDK 17, Gradle 8.7, Android SDK Platform 35, or Android Build Tools 35.0.0. Network access to fetch the toolchain is unavailable here.
- Therefore Android Gradle/KAPT project compilation, full JUnit task, Android lint, `assembleDebug`, APK manifest check, install on a phone/emulator and live RouterOS 6/7 WAN/DDNS tests are **NOT RUN**. There is no APK in this workspace or historical source archive.
- AndroidForge/GitHub CI was not run: no connected AndroidForge fork/repository or authorized CI session is available in this workspace. No access token should be pasted into chat.

**Decision: SOURCE CANDIDATE ONLY — NOT RELEASE / NOT FULLY ACCEPTED.** Static and focused JVM smoke checks do not establish a successful Android build or live RouterOS operation. Do not distribute this as a verified APK until the pinned Android toolchain, Gradle/JUnit/lint/APK and device/router acceptance gates pass.
