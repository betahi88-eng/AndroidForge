#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

for required in settings.gradle.kts build.gradle.kts app/build.gradle.kts app/src/main/AndroidManifest.xml; do
  test -s "$required" || { echo "Missing required Android project file: $required" >&2; exit 1; }
done
test -d app/src/main/java/com/multicloud/mcm
test ! -e pubspec.yaml
test ! -e harmony_patched
test -s app/src/test/java/com/multicloud/mcm/RouterOs7RepositoryTest.kt
test -s scripts/verify-kotlin-smoke.sh
test -s tools/kotlin-smoke/Smoke.kt
test -s SOURCE_IDENTITY.txt
grep -q 'MCM_SOURCE_ID=MCM-1.6.3-FULL-INTEGRATED-WINBOX-014' SOURCE_IDENTITY.txt
test -s app/src/main/java/com/multicloud/mcm/routeros/WinboxCliConnector.kt
test -s app/src/main/java/com/multicloud/mcm/routeros/WinboxCliRepository.kt
test -s app/src/test/java/com/multicloud/mcm/routeros/WinboxCliCryptoTest.kt
test -s app/src/test/java/com/multicloud/mcm/routeros/WinboxCliRepositoryTest.kt
test -s tools/kotlin-smoke/WinboxCryptoSmoke.kt
test -s tools/kotlin-smoke/WinboxRepositorySmoke.kt
test -s scripts/verify-winbox-smoke.sh
test -s lab/containerlab/mcm-routeros7.clab.yml
test -s lab/scripts/forward-ports.sh
test -s lab/scripts/stop-forward-ports.sh
test -s lab/README_VI.md
grep -q 'WINBOX_CLI' app/src/main/java/com/multicloud/mcm/RouterServiceMode.kt
grep -q 'connectWinboxAndPersist' app/src/main/java/com/multicloud/mcm/RouterConnectionCoordinator.kt
grep -q 'readMonitoringSnapshot' app/src/main/java/com/multicloud/mcm/McmMonitoringService.kt
grep -q 'parseAsValueRows' app/src/main/java/com/multicloud/mcm/routeros/WinboxCliRepository.kt
grep -q 'Server proof' app/src/main/java/com/multicloud/mcm/routeros/WinboxCliConnector.kt || grep -q 'expectedServerConfirmation' app/src/main/java/com/multicloud/mcm/routeros/WinboxCliConnector.kt
grep -q 'versionCode = 12' app/build.gradle.kts
grep -q 'readNonBlankString("type") ?: ""' app/src/main/java/com/multicloud/mcm/RouterOs7InterfaceParser.kt
grep -q 'applicationId = "com.multicloud.mcm"' app/build.gradle.kts
grep -q 'versionName = "1.6.3"' app/build.gradle.kts
grep -q 'rootProject.name = "MikroTikMultiCloudMonitor"' settings.gradle.kts
grep -q 'connectionCoordinator.start(host, username, password, port, connectionMode)' app/src/main/java/com/multicloud/mcm/McmJavascriptBridge.kt
grep -q 'serviceMode.probePorts(requestedPort)' app/src/main/java/com/multicloud/mcm/RouterConnectionCoordinator.kt
grep -q 'val selectedPort = successful.port' app/src/main/java/com/multicloud/mcm/RouterConnectionCoordinator.kt
if grep -q 'selected\.port' app/src/main/java/com/multicloud/mcm/RouterConnectionCoordinator.kt; then
  echo 'Coordinator contains unresolved enum port access; use the authenticated branch port.' >&2
  exit 1
fi
grep -q 'attempt.host, probe.port' app/src/main/java/com/multicloud/mcm/RouterConnectionCoordinator.kt
grep -q 'router.host, endpointPort' app/src/main/java/com/multicloud/mcm/McmMonitoringService.kt
grep -q 'host, port, username, password, pin' app/src/main/java/com/multicloud/mcm/McmBackgroundWorker.kt
grep -q 'hostnameVerifier(PinnedTlsHostnameVerifier)' app/src/main/java/com/multicloud/mcm/RouterOs7Client.kt
grep -q 'followRedirects(false)' app/src/main/java/com/multicloud/mcm/RouterOs7Client.kt
grep -q 'followSslRedirects(false)' app/src/main/java/com/multicloud/mcm/RouterOs7Client.kt
 grep -q 'RestResponseBounds.readUtf8' app/src/main/java/com/multicloud/mcm/RouterOs7Client.kt
grep -q 'RestResponseBounds.allowsRows' app/src/main/java/com/multicloud/mcm/RouterOs7Client.kt
test -s app/src/main/java/com/multicloud/mcm/RestResponseBounds.kt
grep -q 'MAX_RESPONSE_BYTES = 16 \* 1024 \* 1024' app/src/main/java/com/multicloud/mcm/RestResponseBounds.kt
grep -q 'MAX_RESPONSE_ROWS = 10_000' app/src/main/java/com/multicloud/mcm/RestResponseBounds.kt
test -s app/src/test/java/com/multicloud/mcm/RouterOs7ClientTest.kt
grep -q 'restResponseReaderBoundsDeclaredAndStreamedBodies' app/src/test/java/com/multicloud/mcm/RouterOs7ClientTest.kt
grep -q 'Blocked' app/src/main/java/com/multicloud/mcm/McmAssetWebViewClient.kt
grep -q 'allowFileAccess = false' app/src/main/java/com/multicloud/mcm/MainActivity.kt
grep -q 'password = ""' app/src/main/assets/www/router-ui.js
grep -q 'RouterTlsHostnameVerifier.verify(hostname, session)' app/src/main/java/com/multicloud/mcm/security/PinnedTlsPolicy.kt
test -s app/src/main/java/com/multicloud/mcm/security/RouterTlsHostnameVerifier.kt
! grep -q 'javax.naming\|java.naming' app/src/main/java/com/multicloud/mcm/security/RouterTlsHostnameVerifier.kt
grep -q 'subjectAlternativeNames' app/src/main/java/com/multicloud/mcm/security/RouterTlsHostnameVerifier.kt
grep -q 'entry\[0\].*!= 7' app/src/main/java/com/multicloud/mcm/security/RouterTlsHostnameVerifier.kt || grep -q 'toInt() != 7' app/src/main/java/com/multicloud/mcm/security/RouterTlsHostnameVerifier.kt
grep -q 'dnsSans.isNotEmpty()' app/src/main/java/com/multicloud/mcm/security/RouterTlsHostnameVerifier.kt
grep -q 'prefix.contains' app/src/main/java/com/multicloud/mcm/security/RouterTlsHostnameVerifier.kt
grep -q 'RouterTlsHostnameVerifier.verify(host, socket.session)' app/src/main/java/com/multicloud/mcm/routeros/RouterOs6ApiClient.kt
grep -q 'RouterTlsHostnameVerifier.verify(host, tlsSocket.session)' app/src/main/java/com/multicloud/mcm/security/TlsFingerprintInspector.kt
grep -q 'pinTransport' app/src/main/java/com/multicloud/mcm/RouterConnectionCoordinator.kt
grep -q 'NOT_RUN_PIN_REQUIRED' app/src/main/java/com/multicloud/mcm/RouterConnectionCoordinator.kt
! grep -q 'Boolean = true' app/src/main/java/com/multicloud/mcm/security/PinnedTlsPolicy.kt
grep -q 'Sha256PinnedTrustManager' app/src/main/java/com/multicloud/mcm/RouterOs7Client.kt
grep -q 'Sha256PinnedTrustManager' app/src/main/java/com/multicloud/mcm/routeros/RouterOs6ApiClient.kt
! grep -q 'verifyPeerIdentity' app/src/main/java/com/multicloud/mcm/security/TlsFingerprintInspector.kt
! grep -q 'verifyPeerIdentity' app/src/main/java/com/multicloud/mcm/routeros/RouterOs6ApiClient.kt
grep -q 'selectAuthenticatedTransport' app/src/main/java/com/multicloud/mcm/RouterConnectionCoordinator.kt
grep -q 'put("activeTransport", selected.name)' app/src/main/java/com/multicloud/mcm/RouterConnectionCoordinator.kt
grep -q 'resolveForProfile(router.routerOsMajor, router.activeTransport)' app/src/main/java/com/multicloud/mcm/McmMonitoringService.kt
grep -q 'resolveForProfile(router.routerOsMajor, router.activeTransport)' app/src/main/java/com/multicloud/mcm/McmBackgroundWorker.kt
grep -q 'MIGRATION_6_7' app/src/main/java/com/multicloud/mcm/data/McmDatabase.kt
grep -q 'MIGRATION_7_8' app/src/main/java/com/multicloud/mcm/data/McmDatabase.kt
grep -q 'tlsPinFor(selectedTransport, endpointPort)' app/src/main/java/com/multicloud/mcm/McmMonitoringService.kt
grep -q 'tlsPinFor(selectedTransport, endpointPort)' app/src/main/java/com/multicloud/mcm/McmBackgroundWorker.kt
grep -q 'fallbackAttempted' app/src/main/java/com/multicloud/mcm/RouterConnectionCoordinator.kt
grep -q 'tlsPinPortFor(alternate)' app/src/main/java/com/multicloud/mcm/McmMonitoringService.kt
grep -q 'tlsPinPortFor(alternate)' app/src/main/java/com/multicloud/mcm/McmBackgroundWorker.kt
grep -q 'canTryAlternateTransport(serviceMode, coreResource.code' app/src/main/java/com/multicloud/mcm/McmMonitoringService.kt
grep -q 'canTryAlternateTransport(RouterServiceMode.fromStorage(router.connectionMode), resource.code' app/src/main/java/com/multicloud/mcm/McmBackgroundWorker.kt
grep -q 'normalizeTransportFailureCode(code)' app/src/main/java/com/multicloud/mcm/RouterConnectionCoordinator.kt
grep -q 'catch (cancelled: CancellationException)' app/src/main/java/com/multicloud/mcm/McmBackgroundWorker.kt
grep -q 'RouterOsApiCodec.legacyChallenge(reply)' app/src/main/java/com/multicloud/mcm/routeros/RouterOs6ApiClient.kt
grep -q 'RouterOsReadOnlyPolicy.validateRestGet(path)' app/src/main/java/com/multicloud/mcm/RouterOs7Client.kt
grep -q 'RouterOsReadOnlyPolicy.validateRestPing' app/src/main/java/com/multicloud/mcm/RouterOs7Client.kt
grep -q 'RouterOsReadOnlyPolicy.validateApiCommand(command, attributes)' app/src/main/java/com/multicloud/mcm/routeros/RouterOs6ApiClient.kt
test -s app/src/test/java/com/multicloud/mcm/RouterOsReadOnlyPolicyTest.kt
! grep -q 'SupportsIpv6Literals\|SupportsIPv6Literals' app/src/test/java/com/multicloud/mcm/RouterHostValidatorTest.kt
test -s app/src/test/java/com/multicloud/mcm/PinnedTlsPolicyTest.kt
grep -q 'wildcardSanMatchesExactlyOneLeftmostLabel' app/src/test/java/com/multicloud/mcm/PinnedTlsPolicyTest.kt
test -s app/src/test/resources/tls/routeros-hostname-san.fixture
test -s app/src/test/java/com/multicloud/mcm/RouterServiceModeTest.kt
test -s app/src/test/java/com/multicloud/mcm/RouterHostValidatorTest.kt
grep -q '2001:db8::1' app/src/test/java/com/multicloud/mcm/RouterHostValidatorTest.kt
grep -q 'MAX_WORD_LENGTH = 1024 \* 1024' app/src/main/java/com/multicloud/mcm/routeros/RouterOsApiCodec.kt
grep -q 'MAX_RESPONSE_ROWS = 10_000' app/src/main/java/com/multicloud/mcm/routeros/RouterOs6ApiClient.kt
grep -q 'MAX_RESPONSE_BYTES = 16 \* 1024 \* 1024' app/src/main/java/com/multicloud/mcm/routeros/RouterOsApiCodec.kt
grep -q 'TLS_CERT_VALIDITY' app/src/main/java/com/multicloud/mcm/security/TlsFingerprintInspector.kt
grep -q 'isCertificateValidityFailure' app/src/main/java/com/multicloud/mcm/security/TlsErrorClassifier.kt
grep -q 'TLS_CERT_VALIDITY' app/src/main/java/com/multicloud/mcm/RouterConnectionCoordinator.kt
test -s app/src/test/java/com/multicloud/mcm/TlsPinSelectionTest.kt

command -v node >/dev/null || { echo "Node.js is required for UI syntax checks." >&2; exit 1; }
command -v python3 >/dev/null || { echo "Python 3 is required for mock syntax checks." >&2; exit 1; }
command -v bash >/dev/null

while IFS= read -r -d '' file; do node --check "$file"; done < <(find app/src/main/assets/www -type f -name '*.js' -print0)
python3 -m py_compile tools/*.py scripts/*.py
python3 scripts/verify-room-migrations.py
python3 scripts/verify-ui-contract.py
python3 scripts/verify-build-regressions.py
python3 scripts/verify-provenance.py
python3 - <<'PYXML'
import xml.etree.ElementTree as ET
ET.parse('app/src/main/AndroidManifest.xml')
ET.parse('app/src/main/res/values/styles.xml')
ET.parse('app/src/main/res/xml/network_security_config.xml')
print('Android XML: PASS')
PYXML
while IFS= read -r -d '' file; do bash -n "$file"; done < <(find scripts lab/scripts -type f -name '*.sh' -print0)
bash scripts/verify-winbox-smoke.sh
echo "Static source checks passed (project identity, JavaScript, Python, shell and Android XML)."

SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [[ "${MCM_SKIP_GRADLE:-0}" != "1" ]] && command -v gradle >/dev/null && [[ -n "$SDK_ROOT" && -f "$SDK_ROOT/platforms/android-35/android.jar" ]]; then
  gradle --no-daemon :app:testDebugUnitTest :app:lintDebug :app:assembleDebug
else
  echo "Android Gradle tests/lint/APK build SKIPPED: Gradle 8.7 and Android SDK Platform 35 are both required."
fi
