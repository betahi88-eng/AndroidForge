# AndroidForge — hướng dẫn nạp đúng source MCM 1.6.3

## Gói cần nạp

Dùng đúng tệp `MCM_1.6.3_FULL_INTEGRATED_WINBOX_LAB_SOURCE_NOT_RELEASE.zip` và đối chiếu SHA-256 đi kèm bên ngoài ZIP. Source ID bên trong phải là `MCM-1.6.3-FULL-INTEGRATED-WINBOX-014`.

Đây là project Android native Gradle/Kotlin lấy bản 007 đã được người dùng xác nhận build APK thành công làm nền, sau đó tích hợp WinBox CLI vào luồng chính và thêm phòng lab. Bản 014 **chưa được Android Gradle build/APK hoặc kết nối CHR thật xác minh trong runtime hiện tại**. Không xem 014 là bản release; 007 là mốc build-success được người dùng xác nhận, không phải bằng chứng build cho 014.

Không thay ZIP này bằng bản 007 (thiếu WinBox integration), bản 013 (chỉ có WinBox probe độc lập), Repair Kit hay ZIP lịch sử khác.

## Kiểm tra trước khi chạy

1. Giải nén trực tiếp ZIP vào thư mục project root.
2. Xác nhận `settings.gradle.kts`, `build.gradle.kts`, `app/build.gradle.kts` và `app/src/main/AndroidManifest.xml` nằm ngay tại root.
3. Xác nhận AndroidForge nhận đúng project native Gradle, module `:app`, source ID `MCM-1.6.3-FULL-INTEGRATED-WINBOX-014`.
4. Không chạy Gradle từ thư mục cha hoặc thư mục Repair Kit.

## Toolchain và tác vụ bắt buộc

Toolchain khóa: JDK 17, Gradle 8.7, AGP 8.6.1, Kotlin 2.0.21, Android SDK Platform 35 và Build Tools 35.0.0. ZIP không kèm Gradle Wrapper; runner cần cung cấp Gradle 8.7 và dùng lệnh `gradle`, không dùng `./gradlew`.

```bash
gradle --no-daemon clean
gradle --no-daemon :app:testDebugUnitTest
gradle --no-daemon :app:lintDebug
gradle --no-daemon :app:assembleDebug :app:bundleDebug
gradle --no-daemon :app:assembleRelease :app:bundleRelease
```

Tất cả tác vụ phải hoàn tất với exit code 0. Không bỏ qua lỗi, không đổi phiên bản toolchain để ép build, không lấy APK tồn tại từ lần chạy trước. Kiểm tra cả Debug APK và Release APK bằng `aapt dump badging`; Release APK là unsigned cho tới khi chủ sở hữu cung cấp khóa ký an toàn.

## Phần kiểm thử kết nối

- Kiểm thử CHR RouterOS 7 thật bằng Containerlab `mikrotik_chr` và image chính thức `mikrotik/chr`; cần chạy `lab/README_VI.md`.
- Kiểm thử RouterOS 6 bằng CHR trong GNS3/QEMU.
- Android Emulator cần chạy MCM APK và Maestro flow; flow hiện là bản nháp và selectors phải xác nhận trên emulator.
- Kiểm thử DDNS/WAN/NAT cần thêm máy kiểm tra bên ngoài mạng lab. Containerlab management VRF không chứng minh đường WAN/NAT.
- `probe-ports.sh` chỉ kiểm tra TCP connect, không chứng minh EC-SRP5/TLS/xác thực/đọc dữ liệu.

## Ranh giới trạng thái

Đã chạy trong workspace: preflight AndroidForge; source/static checks (trừ Android Gradle); migration Room; UI contract; regression checks; Kotlin/JVM smoke; WinBox EC-SRP5/M2 crypto + parser smoke. Chưa chạy: Android Gradle/KAPT, Android JUnit, lint, APK/AAB, Android Emulator/Maestro, CHR RouterOS 6/7 live, external DDNS/WAN. Vì vậy gói được đánh dấu `SOURCE_NOT_RELEASE`; không tuyên bố APK hoặc kết nối router thật đã thành công.

## Baseline lineage

Parent: `MCM_1.6.3_DDNS_RECONCILED_007_SOURCE_NOT_RELEASE.zip`
SHA-256 parent: `493cdf9ec77e15958073a63452e30fd3ea259a91e8a9bdd44ca35315584e6f96`
Source 014 SHA-256: xem tệp `.sha256` đi kèm ZIP do script packaging tạo.
