#!/usr/bin/env python3
"""Small RouterOS API-SSL protocol simulator for MCM integration tests only."""
from __future__ import annotations

import argparse
import hashlib
import os
import secrets
import socket
import ssl
import threading

MAX_WORD = 16 * 1024 * 1024


def read_exact(stream, size: int) -> bytes:
    chunks = bytearray()
    while len(chunks) < size:
        part = stream.recv(size - len(chunks))
        if not part:
            raise EOFError("client disconnected")
        chunks.extend(part)
    return bytes(chunks)


def read_length(stream) -> int:
    first = read_exact(stream, 1)[0]
    if first & 0x80 == 0:
        return first
    if first & 0xC0 == 0x80:
        return ((first & 0x3F) << 8) | read_exact(stream, 1)[0]
    if first & 0xE0 == 0xC0:
        data = read_exact(stream, 2)
        return ((first & 0x1F) << 16) | int.from_bytes(data, "big")
    if first & 0xF0 == 0xE0:
        data = read_exact(stream, 3)
        return ((first & 0x0F) << 24) | int.from_bytes(data, "big")
    if first == 0xF0:
        return int.from_bytes(read_exact(stream, 4), "big")
    raise ValueError(f"unsupported control byte {first:#x}")


def write_length(stream, length: int) -> None:
    if length < 0x80:
        stream.sendall(bytes([length]))
    elif length < 0x4000:
        stream.sendall(bytes([(length >> 8) | 0x80, length & 0xFF]))
    elif length < 0x200000:
        stream.sendall(bytes([(length >> 16) | 0xC0, (length >> 8) & 0xFF, length & 0xFF]))
    elif length < 0x10000000:
        stream.sendall(bytes([(length >> 24) | 0xE0, (length >> 16) & 0xFF, (length >> 8) & 0xFF, length & 0xFF]))
    else:
        stream.sendall(b"\xF0" + length.to_bytes(4, "big"))


def read_sentence(stream) -> list[str]:
    words: list[str] = []
    while True:
        length = read_length(stream)
        if length == 0:
            return words
        if length > MAX_WORD:
            raise ValueError("word exceeds safety limit")
        words.append(read_exact(stream, length).decode("utf-8"))


def send_sentence(stream, words: list[str]) -> None:
    for word in words:
        data = word.encode("utf-8")
        write_length(stream, len(data))
        stream.sendall(data)
    stream.sendall(b"\x00")


def attributes(words: list[str]) -> dict[str, str]:
    result = {}
    for word in words:
        if not word.startswith("="):
            continue
        split = word.find("=", 1)
        if split > 1:
            result[word[1:split]] = word[split + 1:]
    return result


def response_rows(stream, rows: list[dict[str, str]]) -> None:
    for row in rows:
        send_sentence(stream, ["!re"] + [f"={key}={value}" for key, value in row.items()])
    send_sentence(stream, ["!done"])


def handle_client(raw_socket, tls_context, config) -> None:
    try:
        with tls_context.wrap_socket(raw_socket, server_side=True) as stream:
            stream.settimeout(15)
            logged_in = False
            challenge = None
            while True:
                words = read_sentence(stream)
                if not words:
                    continue
                command = words[0]
                attrs = attributes(words[1:])
                if command == "/login":
                    if config.legacy_login and not attrs:
                        challenge = secrets.token_hex(16)
                        send_sentence(stream, ["!done", f"=ret={challenge}"])
                        continue
                    if config.legacy_login and attrs.get("password") is not None:
                        send_sentence(stream, ["!trap", "=message=legacy challenge mode enabled"])
                        continue
                    if attrs.get("name") == config.user and attrs.get("password") == config.password:
                        logged_in = True
                        send_sentence(stream, ["!done"])
                        continue
                    if attrs.get("name") == config.user and attrs.get("response") and challenge:
                        expected = hashlib.md5(b"\x00" + config.password.encode() + bytes.fromhex(challenge)).hexdigest()
                        if attrs["response"].lower() == "00" + expected:
                            logged_in = True
                            send_sentence(stream, ["!done"])
                            continue
                    send_sentence(stream, ["!trap", "=message=invalid username or password"])
                    continue

                if not logged_in:
                    send_sentence(stream, ["!trap", "=message=not logged in"])
                    continue

                if command == "/system/resource/print":
                    response_rows(stream, [{
                        "version": "6.49.17 (mock)", "uptime": "1d3h", "cpu-load": "9",
                        "free-memory": "300000000", "total-memory": "600000000"
                    }])
                elif command == "/interface/print":
                    response_rows(stream, [
                        {"name": "ether1", "type": "ether", "running": "true", "rx-byte": "9000000", "tx-byte": "14000000"},
                        {"name": "pppoe-out1", "type": "pppoe-out", "running": "true", "rx-byte": "7000000", "tx-byte": "8000000"}
                    ])
                elif command == "/ip/cloud/print":
                    cloud = {
                        "ddns-enabled": "true", "dns-name": "mock000000.sn.mynetname.net",
                        "public-address": "198.51.100.10", "status": "updated",
                        "update-time": "2026-11-22 04:00:00", "ddns-update-interval": "none"
                    }
                    if config.cloud_ipv6:
                        cloud["public-address-ipv6"] = "2001:db8::10"
                    response_rows(stream, [cloud])
                elif command == "/ppp/active/print":
                    response_rows(stream, [{"name": "pppoe-client-01", "service": "pppoe", "caller-id": "AA:BB:CC:DD:EE:01", "address": "100.64.0.2", "uptime": "1h22m"}])
                elif command == "/ip/arp/print":
                    response_rows(stream, [{"address": "192.0.2.10", "mac-address": "AA:BB:CC:DD:EE:10", "interface": "bridge", "complete": "true", "dynamic": "true"}])
                elif command == "/ip/dhcp-server/lease/print":
                    response_rows(stream, [{"address": "192.0.2.20", "mac-address": "AA:BB:CC:DD:EE:20", "host-name": "mock-phone", "server": "dhcp1", "status": "bound", "expires-after": "00:15:00", "dynamic": "true"}])
                elif command == "/tool/netwatch/print":
                    response_rows(stream, [{"host": "1.1.1.1", "status": "up", "since": "1d2h", "comment": "WAN test", "disabled": "false"}])
                elif command == "/ping":
                    count = max(1, min(100, int(attrs.get("count", "4"))))
                    rows = []
                    received = 0
                    for sequence in range(count):
                        success = (sequence + 1) % 5 != 0 or sequence == count - 1
                        if not success:
                            continue
                        received += 1
                        rows.append({
                            "host": attrs.get("address", "198.51.100.1"),
                            "seq": str(sequence), "size": "56", "ttl": "64", "time": "9ms250us"
                        })
                    response_rows(stream, rows)
                else:
                    send_sentence(stream, ["!trap", "=message=no such command in mock"])
    except (EOFError, OSError, ssl.SSLError, ValueError) as error:
        if not isinstance(error, EOFError):
            print(f"[mock-api] {error}")
    finally:
        try:
            raw_socket.close()
        except OSError:
            pass


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bind", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8729)
    parser.add_argument("--cert", required=True)
    parser.add_argument("--key", required=True)
    parser.add_argument("--user", default=os.getenv("MCM_TEST_USER", "mcm-test"))
    parser.add_argument("--password", default=os.getenv("MCM_TEST_PASSWORD", "test-only-change-me"))
    parser.add_argument("--legacy-login", action="store_true", help="Force the pre-v6.43 challenge-response login path")
    parser.add_argument("--no-cloud-ipv6", action="store_true", help="Simulate older RouterOS Cloud output without IPv6 fields")
    args = parser.parse_args()
    tls = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    tls.minimum_version = ssl.TLSVersion.TLSv1_2
    tls.load_cert_chain(args.cert, args.key)

    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    listener.bind((args.bind, args.port))
    listener.listen(20)
    print(f"MCM API-SSL mock listening on {args.bind}:{args.port}; legacy_login={args.legacy_login}")
    config = argparse.Namespace(
        user=args.user,
        password=args.password,
        legacy_login=args.legacy_login,
        cloud_ipv6=not args.no_cloud_ipv6,
    )
    try:
        while True:
            client, _ = listener.accept()
            threading.Thread(target=handle_client, args=(client, tls, config), daemon=True).start()
    except KeyboardInterrupt:
        print("\nStopping API-SSL mock")
    finally:
        listener.close()


if __name__ == "__main__":
    main()
