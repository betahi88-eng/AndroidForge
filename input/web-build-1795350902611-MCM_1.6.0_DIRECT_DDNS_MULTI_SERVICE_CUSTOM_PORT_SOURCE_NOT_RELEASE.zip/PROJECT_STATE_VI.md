# MCM — Project State

**Source candidate:** 1.6.0 — Direct DDNS / selectable service / user-controlled WAN port  
**State:** Engineering source / NOT RELEASE  
**Baseline:** `MCM_1.5.1_DIRECT_DDNS_MULTI_STORE_SOURCE_NOT_RELEASE.zip`  
**Checkpoint:** `MCM-160-DIRECT-DDNS-SERVICE-PORT-001` — 2026-11-22

## Scope held

- Android-only native Kotlin + local WebView assets + Room + Android Keystore.
- Multiple independent MikroTik profiles grouped by store/site.
- Direct hostname/DDNS/IP connection only; no MCM backend, VPS, VPN/WireGuard, relay or router agent.
- Read-only RouterOS monitoring plus bounded ping diagnostics.
- No router configuration writes or automatic changes.

## 1.6.0 source changes

- Added a persisted per-router `connectionMode`: AUTO, REST_HTTPS or API_SSL.
- Service protocol is independent from RouterOS family and numeric port. REST_HTTPS requires RouterOS 7; API_SSL is supported on RouterOS 6/7.
- Kept port as user-editable 1–65535 WAN-facing endpoint; a manually entered port is preserved while switching OS/service, and an already saved profile port is always treated as user-owned even when it equals a conventional default.
- Added Room v3→v4 migration with `connectionMode='AUTO'` for existing profiles; existing port, credentials, fingerprint and metric history are preserved.
- Foreground monitor and WorkManager background checks use the same saved protocol mode and custom port.
- UI explicitly explains that WinBox TCP 8291 is not a supported MCM protocol; port 8291 works only when it actually serves or maps to REST HTTPS/API-SSL.
- TCP diagnostic message no longer implies TCP reachability proves service compatibility.

## Preserved functionality

- Multi-store profile management, encrypted credentials, SHA-256 leaf pinning.
- RouterOS 7 REST adapter and RouterOS 6 native API-SSL adapter, including legacy challenge login.
- CPU/RAM, interface counters/rates, Cloud DDNS, PPPoE, ARP, DHCP, Netwatch, Bridge Host, VLAN and bounded ping reads.
- MNDP LAN discovery, per-router health/error persistence, local history/charts and sequential Refresh All.

## Validation status in this workspace

- Source ZIP parent archive SHA-256: `d4494f331c4d0e642c0a6799dfc871ecb2d60deec391c08e5206e152fa63a77b` (1.5.1 baseline).
- `scripts/androidforge-preflight.sh`: PASS (native Android Gradle/Kotlin flat-root project).
- `scripts/verify-source.sh`: PASS for JavaScript, Python compile, Room migration SQL preservation, WebView DOM contract, shell syntax and Android XML.
- Standalone Kotlin `RouterServiceMode` smoke checks: PASS with local kotlinc 1.9.0; this is not a substitute for Gradle compilation.
- Source ZIP CRC/root layout/SHA-256: verified on the final archive and recorded in its sidecar.
- Android Gradle compile/KAPT/JUnit/Lint/APK and live RouterOS/Android acceptance: NOT RUN. The workspace lacks Gradle 8.7 and Android SDK Platform 35; its Java is 21, not required JDK 17.

## Safety

No MikroTik config, firewall, NAT, DDNS, service, IP or port has been changed. No credentials from any router are included in the source archive. Do not publish management ports without source restrictions and a least-privilege account.
