#!/usr/bin/env python3
"""Check WebView DOM references and the direct-DDNS editable endpoint controls."""
from __future__ import annotations

import re
from pathlib import Path

root = Path(__file__).resolve().parents[1]
html = (root / "app/src/main/assets/www/index.html").read_text(encoding="utf-8")
ids = re.findall(r'\bid=["\']([^"\']+)["\']', html)
if len(ids) != len(set(ids)):
    duplicates = sorted({item for item in ids if ids.count(item) > 1})
    raise SystemExit(f"Duplicate HTML id(s): {', '.join(duplicates)}")

lookups: dict[str, set[str]] = {}
for path in (root / "app/src/main/assets/www").glob("*.js"):
    content = path.read_text(encoding="utf-8")
    for dom_id in re.findall(r'\$\(["\']([^"\']+)["\']\)', content):
        lookups.setdefault(dom_id, set()).add(path.name)

missing = sorted(set(lookups) - set(ids))
if missing:
    details = [f"{dom_id} ({', '.join(sorted(lookups[dom_id]))})" for dom_id in missing]
    raise SystemExit("Missing HTML element id(s): " + "; ".join(details))

required_ids = {"routerPort", "routerConnectionMode", "portConfigurationHelp"}
if not required_ids.issubset(set(ids)):
    raise SystemExit("Missing editable endpoint controls: " + ", ".join(sorted(required_ids - set(ids))))
router_ui = (root / "app/src/main/assets/www/router-ui.js").read_text(encoding="utf-8")
if 'connectionMode: $("routerConnectionMode").value' not in router_ui:
    raise SystemExit("Router form does not persist the selected service protocol.")
if "portManuallyEdited" not in router_ui or 'if (!portManuallyEdited) $("routerPort").value' not in router_ui:
    raise SystemExit("Manual port preservation is missing.")
if 'portManuallyEdited = true;' not in router_ui:
    raise SystemExit("Existing profile port is not locked from automatic replacement while editing.")
if "MCM không triển khai giao thức WinBox" not in router_ui:
    raise SystemExit("WinBox protocol boundary warning is missing.")

if "REST HTTPS chỉ hỗ trợ RouterOS 7" not in router_ui or "Number.isInteger(port)" not in router_ui:
    raise SystemExit("Protocol/port client-side validation is missing.")

print(f"WebView DOM and endpoint editor contract: PASS ({len(ids)} unique IDs, {len(lookups)} JS literal lookups)")
