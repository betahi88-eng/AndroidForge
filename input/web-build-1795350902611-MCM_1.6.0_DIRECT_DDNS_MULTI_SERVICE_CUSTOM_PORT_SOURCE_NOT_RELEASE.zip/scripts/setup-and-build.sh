#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

command -v java >/dev/null || { echo "JDK 17 is required." >&2; exit 1; }
JAVA_VERSION="$(java -version 2>&1 | sed -n '1s/.*version "\([0-9]*\).*/\1/p')"
[[ "$JAVA_VERSION" == "17" ]] || {
  echo "This project is configured for JDK 17; detected ${JAVA_VERSION:-unknown}." >&2
  exit 1
}
command -v gradle >/dev/null || {
  echo "Gradle 8.7 is required. This source package does not bundle the Gradle Wrapper JAR." >&2
  echo "Install Gradle 8.7, or use the included GitHub Actions workflow." >&2
  exit 1
}
GRADLE_VERSION="$(gradle --version | awk '/^Gradle / { print $2; exit }')"
[[ "$GRADLE_VERSION" == "8.7" ]] || {
  echo "This build baseline is pinned to Gradle 8.7; detected $GRADLE_VERSION." >&2
  exit 1
}
SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [[ -z "$SDK_ROOT" && -f local.properties ]]; then
  SDK_ROOT="$(sed -n 's/^sdk.dir=//p' local.properties | head -n1 | sed 's#\\:#:#g')"
fi
[[ -n "$SDK_ROOT" && -f "$SDK_ROOT/platforms/android-35/android.jar" ]] || {
  echo "Android SDK Platform 35 is required. Set ANDROID_SDK_ROOT or ANDROID_HOME." >&2
  exit 1
}
[[ -d "$SDK_ROOT/build-tools/35.0.0" ]] || {
  echo "Android Build Tools 35.0.0 are required in $SDK_ROOT." >&2
  exit 1
}
printf 'Environment OK: JDK %s, Gradle %s, Android SDK %s\n' "$JAVA_VERSION" "$GRADLE_VERSION" "$SDK_ROOT"
gradle --no-daemon :app:testDebugUnitTest :app:lintDebug :app:assembleDebug
APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
test -s "$APK"
echo "Debug APK: $APK"
sha256sum "$APK"
