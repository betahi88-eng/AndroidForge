#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
required=(settings.gradle.kts build.gradle.kts gradle.properties app/build.gradle.kts app/src/main/AndroidManifest.xml)
for file in "${required[@]}"; do
  test -s "$file" || { echo "FAIL: missing root project file: $file" >&2; exit 1; }
done
test -d app/src/main/java/com/multicloud/mcm
test -d app/src/main/assets/www
test ! -e pubspec.yaml
test ! -e harmony_patched
grep -Fq 'rootProject.name = "MikroTikMultiCloudMonitor"' settings.gradle.kts
grep -Fq 'id("com.android.application") version "8.6.1"' build.gradle.kts
grep -Fq 'id("org.jetbrains.kotlin.android") version "2.0.21"' build.gradle.kts
grep -Fq 'applicationId = "com.multicloud.mcm"' app/build.gradle.kts
grep -Fq 'compileSdk = 35' app/build.gradle.kts
grep -Fq 'versionName = "1.6.0"' app/build.gradle.kts
grep -Fq 'versionCode = 9' app/build.gradle.kts
echo 'AndroidForge preflight PASS: flat-root native Android Gradle/Kotlin project detected.'
echo 'Expected detector result: Gradle / Android / Kotlin; not Flutter.'
