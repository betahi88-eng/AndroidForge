# MCM 1.6.0 — Build status

**Status: AndroidForge-ready engineering source / NOT RELEASE. No APK is included or claimed.**

## Project identity

- Native Android Gradle/Kotlin project; application ID `com.multicloud.mcm`.
- Version `1.6.0` / versionCode `9`; minSdk 26, compileSdk 35.
- Flat project root: `settings.gradle.kts`, root `build.gradle.kts`, `app/build.gradle.kts`.
- Toolchain target: JDK 17, Gradle 8.7, AGP 8.6.1, Kotlin 2.0.21, Android SDK Platform 35.

## Change set 1.6.0

- Per-profile endpoint keeps hostname, WAN port (1–65535), RouterOS major version, connection/service mode, username, certificate pin and Keystore credential separate.
- Service modes: AUTO (historic defaults), REST_HTTPS (RouterOS 7 only), API_SSL (RouterOS 6/7).
- Custom port persists independently. Changing RouterOS or service mode only updates the suggestion on a fresh profile before manual input; an existing saved port is always preserved while editing, even if it equals a conventional default.
- Room database version 4 adds `connectionMode` with default AUTO. Migration v3→v4 does not rewrite existing host, port, credentials, TLS pin, or history.
- Foreground and background clients resolve the same protocol mode and use the saved custom port.
- UI explains WinBox protocol boundary: MCM does not implement WinBox; a WinBox TCP 8291 connection is not proof of REST/API-SSL availability.
- TCP diagnostic is correctly described as a socket reachability check, not an authenticated service/protocol test.

## Preserved source capabilities

Multi-router/store profiles, AES-256-GCM credential encryption backed by Android Keystore, leaf SHA-256 TLS pinning, RouterOS 7 REST, RouterOS API-SSL with legacy login, DNS/TCP diagnostics, MNDP discovery, CPU/RAM, interfaces/rates, IP Cloud, PPPoE, ARP, DHCP, Netwatch, Bridge Host, VLAN, bounded ping, local history, sequential Refresh All and per-router health/error state.

## Source checks completed in this workspace

- `scripts/androidforge-preflight.sh` — PASS; flat-root Android Gradle/Kotlin project.
- `scripts/verify-source.sh` — PASS for all source-level checks; it correctly reported the Android Gradle build gate as SKIPPED.
- `python3 scripts/verify-room-migrations.py` — PASS; v1→v2→v3→v4, v2→v3→v4 and v3→v4 preserve existing router ports, credentials aliases and history tables.
- `python3 scripts/verify-ui-contract.py` — PASS; 73 unique HTML IDs, 57 JS DOM lookups, editable port/service contract and WinBox protocol boundary.
- Node syntax checks for all WebView scripts — PASS.
- Python compile for mock servers and source-verification scripts — PASS.
- Bash syntax for all shell scripts — PASS.
- Android Manifest, styles and network-security XML parsing — PASS.
- Standalone `RouterServiceMode` Kotlin smoke checks with local kotlinc 1.9.0 — PASS (not a complete Android/Kotlin app compile).
- ZIP CRC and flat-root Android project layout — PASS; SHA-256 sidecar generated next to the final source ZIP.

## Not verified here

The current packaging workspace does not have Gradle 8.7 or Android SDK Platform 35 installed; JDK 17 is also not available (the workspace Java is 21). Therefore full Android Gradle compile, Room KAPT, Gradle/JUnit, Lint and APK assembly are NOT RUN here. Physical Android and RouterOS 6/7 hardware acceptance is also NOT RUN. No production signing key is included.

## AndroidForge gate

Upload `MCM_1.6.0_DIRECT_DDNS_MULTI_SERVICE_CUSTOM_PORT_SOURCE_NOT_RELEASE.zip` as a native Android Gradle project. Run `:app:testDebugUnitTest`, `:app:lintDebug`, `:app:assembleDebug`. Accept only if APK exists, package and version are correct, the APK checksum is recorded, and device/router tests pass.
