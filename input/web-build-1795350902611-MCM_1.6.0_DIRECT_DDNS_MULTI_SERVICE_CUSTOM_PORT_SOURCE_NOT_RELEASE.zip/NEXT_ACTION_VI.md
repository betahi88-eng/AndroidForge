# MCM — Next Action

**Current checkpoint:** `MCM-160-DIRECT-DDNS-SERVICE-PORT-001`  
**Source:** `MCM_1.6.0_DIRECT_DDNS_MULTI_SERVICE_CUSTOM_PORT_SOURCE_NOT_RELEASE.zip`  
**Status:** Engineering source / NOT RELEASE

1. Upload this exact flat-root ZIP to AndroidForge.
2. Confirm detector selects native Android Gradle/Kotlin (not Flutter): root contains `settings.gradle.kts` and `app/build.gradle.kts`.
3. Run `:app:testDebugUnitTest`, `:app:lintDebug`, and `:app:assembleDebug`.
4. Verify APK package `com.multicloud.mcm`, version `1.6.0`, versionCode `9`, and checksum.
5. Install on Android. Test a RouterOS 7 REST HTTPS endpoint and RouterOS 6/7 API-SSL endpoint over cellular data with an actual custom WAN port.
6. Verify the WinBox-only 8291 endpoint is not misreported as MCM-compatible; then test 8291 only if deliberately mapped to the selected HTTPS/API-SSL service.

Do not call this a release until Android installation, room migration, TLS pin, user authentication, foreground/background reads and live RouterOS acceptance pass. Do not change router configuration, firewall, NAT or DDNS from MCM.
