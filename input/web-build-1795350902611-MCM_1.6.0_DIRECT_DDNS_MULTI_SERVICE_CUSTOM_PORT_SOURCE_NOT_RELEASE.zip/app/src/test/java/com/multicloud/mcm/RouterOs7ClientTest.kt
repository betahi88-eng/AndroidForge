package com.multicloud.mcm

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class RouterOs7ClientTest {
    @Test
    fun normalizesColonSeparatedAndWhitespaceSeparatedSha256Pins() {
        val compact = "0123456789ABCDEF".repeat(4)
        val colonSeparated = compact.chunked(2).joinToString(":")
        val whitespaceSeparated = compact.chunked(4).joinToString(" ")

        assertEquals(compact, RouterOs7Client.normalizePin(colonSeparated))
        assertEquals(compact, RouterOs7Client.normalizePin(whitespaceSeparated))
    }

    @Test
    fun rejectsMalformedSha256Pins() {
        assertThrows(IllegalArgumentException::class.java) {
            RouterOs7Client.normalizePin("not-a-certificate-fingerprint")
        }
    }
}
