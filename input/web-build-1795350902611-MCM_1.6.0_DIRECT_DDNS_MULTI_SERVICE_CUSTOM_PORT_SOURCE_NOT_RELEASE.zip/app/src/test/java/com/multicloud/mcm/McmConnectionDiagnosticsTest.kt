package com.multicloud.mcm

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.net.InetAddress
import java.net.ServerSocket
import kotlin.concurrent.thread

class McmConnectionDiagnosticsTest {
    @Test
    fun reportsDnsAndTcpReachabilityForLocalTestEndpoint() = runBlocking {
        val server = ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"))
        val acceptThread = thread(isDaemon = true) {
            runCatching { server.accept().use { } }
        }
        try {
            val result = McmConnectionDiagnostics().inspect("127.0.0.1", server.localPort)
            assertTrue(result.optBoolean("ok"))
            assertEquals("TCP_REACHABLE", result.optString("code"))
            assertTrue(result.getJSONArray("addresses").length() > 0)
        } finally {
            server.close()
            acceptThread.join(1_000)
        }
    }
}
