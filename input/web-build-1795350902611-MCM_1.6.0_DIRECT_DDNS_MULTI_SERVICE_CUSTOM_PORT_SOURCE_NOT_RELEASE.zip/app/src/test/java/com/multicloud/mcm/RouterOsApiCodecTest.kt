package com.multicloud.mcm

import com.multicloud.mcm.routeros.RouterOsApiCodec
import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream

class RouterOsApiCodecTest {
    @Test
    fun sentenceFramingRoundTripsAcrossLengthPrefixes() {
        val words = listOf("/test", "=" + "x".repeat(130), "=" + "y".repeat(16_400), "=" + "z".repeat(140_000))
        val encoded = ByteArrayOutputStream().also { output ->
            RouterOsApiCodec.writeSentence(DataOutputStream(output), words)
        }.toByteArray()
        val decoded = RouterOsApiCodec.readSentence(DataInputStream(ByteArrayInputStream(encoded)))
        assertEquals(words, decoded)
    }

    @Test
    fun legacyLoginResponseUsesRequiredZeroPrefixAndMd5() {
        val actual = RouterOsApiCodec.legacyLoginResponse("password", "00112233445566778899aabbccddeeff")
        assertEquals("00" + java.security.MessageDigest.getInstance("MD5")
            .digest(byteArrayOf(0) + "password".toByteArray() + ByteArray(16) {
                (it * 0x11).toByte()
            }.let { it })
            .joinToString("") { "%02x".format(it.toInt() and 0xff) }, actual)
    }
}
