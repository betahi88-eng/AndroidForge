package com.multicloud.mcm

import com.multicloud.mcm.security.TlsErrorClassifier
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TlsErrorClassifierTest {
    @Test fun identifiesUnsupportedProtocolNestedInProviderError() {
        val error = IllegalStateException("Read error", RuntimeException("OPENSSL_internal:UNSUPPORTED_PROTOCOL"))
        assertTrue(TlsErrorClassifier.isProtocolMismatch(error))
    }

    @Test fun identifiesPlainHttpOnTlsPort() {
        assertTrue(TlsErrorClassifier.isProtocolMismatch(IllegalStateException("Unsupported or unrecognized SSL message")))
    }

    @Test fun identifiesFingerprintMismatchWithoutDisablingPinning() {
        assertTrue(TlsErrorClassifier.isFingerprintMismatch(IllegalStateException("Router TLS certificate fingerprint mismatch")))
        assertFalse(TlsErrorClassifier.isProtocolMismatch(IllegalStateException("Router TLS certificate fingerprint mismatch")))
    }
}
