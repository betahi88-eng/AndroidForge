package com.multicloud.mcm.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase

@Entity(tableName = "router_profiles")
data class RouterEntity(
    @PrimaryKey val id: String,
    val name: String,
    @androidx.room.ColumnInfo(defaultValue = "''") val siteName: String,
    val host: String,
    val port: Int,
    val routerOsMajor: Int,
    val username: String,
    val credentialAlias: String,
    val tlsSha256Pin: String,
    val createdAtEpochMs: Long,
    val lastSeenAtEpochMs: Long?,
    @androidx.room.ColumnInfo(defaultValue = "'UNKNOWN'") val lastStatus: String = "UNKNOWN",
    val lastErrorCode: String? = null,
    val lastErrorMessage: String? = null,
    val lastCheckedAtEpochMs: Long? = null,
    @androidx.room.ColumnInfo(defaultValue = "'AUTO'") val connectionMode: String = "AUTO"
)

@Entity(tableName = "metric_history", indices = [androidx.room.Index(value = ["routerId", "recordedAtEpochMs"])])
data class MetricHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val routerId: String,
    val metricKey: String,
    val value: Double,
    val unit: String,
    val recordedAtEpochMs: Long
)

@Dao
interface RouterDao {
    @Query("SELECT * FROM router_profiles ORDER BY name COLLATE NOCASE")
    suspend fun getAll(): List<RouterEntity>

    @Query("SELECT * FROM router_profiles WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): RouterEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(router: RouterEntity)

    @Query("DELETE FROM router_profiles WHERE id = :id")
    suspend fun delete(id: String)
}

@Dao
interface MetricDao {
    @Insert
    suspend fun insert(sample: MetricHistoryEntity)

    @Query("SELECT * FROM metric_history WHERE routerId = :routerId AND metricKey = :metricKey ORDER BY recordedAtEpochMs DESC LIMIT :limit")
    suspend fun recent(routerId: String, metricKey: String, limit: Int): List<MetricHistoryEntity>

    @Query("DELETE FROM metric_history WHERE recordedAtEpochMs < :beforeEpochMs")
    suspend fun deleteBefore(beforeEpochMs: Long)

    @Query("DELETE FROM metric_history WHERE routerId = :routerId")
    suspend fun deleteForRouter(routerId: String)
}

@Entity(tableName = "interface_counters", primaryKeys = ["routerId", "interfaceName"])
data class InterfaceCounterEntity(
    val routerId: String,
    val interfaceName: String,
    val rxBytes: Long,
    val txBytes: Long,
    val recordedAtEpochMs: Long
)

@Dao
interface InterfaceCounterDao {
    @Query("SELECT * FROM interface_counters WHERE routerId = :routerId AND interfaceName = :interfaceName LIMIT 1")
    suspend fun get(routerId: String, interfaceName: String): InterfaceCounterEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(counter: InterfaceCounterEntity)

    @Query("DELETE FROM interface_counters WHERE routerId = :routerId")
    suspend fun deleteForRouter(routerId: String)
}

@Database(entities = [RouterEntity::class, MetricHistoryEntity::class, InterfaceCounterEntity::class], version = 4, exportSchema = false)
abstract class McmDatabase : RoomDatabase() {
    abstract fun routerDao(): RouterDao
    abstract fun metricDao(): MetricDao
    abstract fun interfaceCounterDao(): InterfaceCounterDao

    companion object {
        val MIGRATION_1_2: Migration = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN siteName TEXT NOT NULL DEFAULT ''")
            }
        }

        val MIGRATION_2_3: Migration = object : Migration(2, 3) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN lastStatus TEXT NOT NULL DEFAULT 'UNKNOWN'")
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN lastErrorCode TEXT")
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN lastErrorMessage TEXT")
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN lastCheckedAtEpochMs INTEGER")
            }
        }

        val MIGRATION_3_4: Migration = object : Migration(3, 4) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // Existing profiles retain their endpoint and are migrated to the old OS-based default.
                database.execSQL("ALTER TABLE router_profiles ADD COLUMN connectionMode TEXT NOT NULL DEFAULT 'AUTO'")
            }
        }
    }
}
