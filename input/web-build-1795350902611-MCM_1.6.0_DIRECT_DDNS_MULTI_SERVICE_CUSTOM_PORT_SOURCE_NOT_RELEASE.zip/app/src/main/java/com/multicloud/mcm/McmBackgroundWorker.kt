package com.multicloud.mcm

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.multicloud.mcm.data.McmDatabase
import com.multicloud.mcm.data.MetricHistoryEntity
import com.multicloud.mcm.security.SecureCredentialStore
import com.multicloud.mcm.routeros.RouterOs6ApiClient
import com.multicloud.mcm.routeros.RouterOs6Repository
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.CancellationException
import androidx.room.Room

/** Best-effort background health samples. WorkManager's periodic minimum interval is 15 minutes. */
class McmBackgroundWorker(context: Context, parameters: WorkerParameters) : CoroutineWorker(context, parameters) {
    override suspend fun doWork(): Result = withTimeout(10 * 60 * 1_000L) {
        val database = Room.databaseBuilder(applicationContext, McmDatabase::class.java, "mcm.db")
            .addMigrations(McmDatabase.MIGRATION_1_2, McmDatabase.MIGRATION_2_3, McmDatabase.MIGRATION_3_4)
            .build()
        val credentials = SecureCredentialStore(applicationContext)
        try {
            val routers = database.routerDao().getAll()
            routers.forEach { router ->
                val now = System.currentTimeMillis()
                try {
                    val password = credentials.get(router.credentialAlias)
                        ?: throw IllegalStateException("CREDENTIAL_UNAVAILABLE: Không tìm thấy mật khẩu đã mã hóa.")
                    val selectedTransport = RouterServiceMode.fromStorage(router.connectionMode).resolve(router.routerOsMajor)
                    val resource = if (selectedTransport == RouterTransport.REST_HTTPS) {
                        RouterOs7Repository(RouterOs7Client(router.host, router.port, router.username, password, router.tlsSha256Pin))
                            .readSystemResource()
                    } else {
                        RouterOs6Repository(RouterOs6ApiClient(router.host, router.port, router.username, password, router.tlsSha256Pin))
                            .readSystemResource()
                    }
                    when (resource) {
                        is McmResult.Success -> {
                            val values = resource.value
                            database.routerDao().upsert(router.copy(
                                lastSeenAtEpochMs = now, lastStatus = "ONLINE", lastErrorCode = null,
                                lastErrorMessage = null, lastCheckedAtEpochMs = now
                            ))
                            values.cpuLoadPercent?.let {
                                database.metricDao().insert(MetricHistoryEntity(routerId = router.id, metricKey = "cpu_load", value = it.toDouble(), unit = "%", recordedAtEpochMs = now))
                            }
                            if (values.freeMemoryBytes != null && values.totalMemoryBytes != null && values.totalMemoryBytes > 0) {
                                val used = 100.0 * (values.totalMemoryBytes - values.freeMemoryBytes).coerceAtLeast(0) / values.totalMemoryBytes.toDouble()
                                database.metricDao().insert(MetricHistoryEntity(routerId = router.id, metricKey = "memory_used", value = used, unit = "%", recordedAtEpochMs = now))
                            }
                        }
                        is McmResult.Failure -> database.routerDao().upsert(router.copy(
                            lastStatus = "OFFLINE", lastErrorCode = resource.code,
                            lastErrorMessage = resource.message.take(240), lastCheckedAtEpochMs = now
                        ))
                    }
                } catch (error: Exception) {
                    val message = error.message ?: "Không rõ lỗi nền"
                    val code = message.substringBefore(':').takeIf { it.matches(Regex("[A-Z0-9_]{2,48}")) } ?: "BACKGROUND_FAILED"
                    database.routerDao().upsert(router.copy(
                        lastStatus = "OFFLINE", lastErrorCode = code,
                        lastErrorMessage = message.take(240), lastCheckedAtEpochMs = now
                    ))
                }
            }
            database.metricDao().deleteBefore(System.currentTimeMillis() - 30L * 24L * 60L * 60L * 1_000L)
            Result.success()
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            Result.retry()
        } finally {
            database.close()
        }
    }
}
