package com.multicloud.mcm

/** Validates an IPv4 address or ASCII DNS/DDNS hostname without performing DNS lookup. */
object RouterHostValidator {
    fun normalize(raw: String): String {
        val value = raw.trim()
        require(value.isNotBlank()) { "Nhập Cloud DDNS/domain hoặc địa chỉ IP." }
        require(value.length <= 253 && !value.contains("://") && !value.contains('/') &&
            !value.contains('?') && !value.contains(':') && !value.any(Char::isWhitespace)) {
            "Chỉ nhập hostname/IP, không nhập scheme, port hoặc đường dẫn. IPv6 chưa được hỗ trợ trong bản này."
        }
        val host = (if (value.endsWith('.')) value.dropLast(1) else value).lowercase()
        val labels = host.split('.')
        val ipv4Candidate = labels.size == 4 && labels.all { it.toIntOrNull() != null }
        if (ipv4Candidate) {
            require(labels.all { it.toInt() in 0..255 }) { "Địa chỉ IPv4 không hợp lệ." }
            return host
        }
        require(labels.all { label ->
            label.length in 1..63 && label.matches(Regex("[a-z0-9](?:[a-z0-9-]*[a-z0-9])?"))
        }) { "Tên miền không hợp lệ. Kiểm tra lại Cloud DDNS/domain." }
        return host
    }

    fun endpointKind(host: String): String = when {
        host.endsWith(".sn.mynetname.net", ignoreCase = true) -> "MIKROTIK_CLOUD"
        host.matches(Regex("[0-9]{1,3}(\\.[0-9]{1,3}){3}")) -> "IP"
        else -> "DDNS_DOMAIN"
    }
}
