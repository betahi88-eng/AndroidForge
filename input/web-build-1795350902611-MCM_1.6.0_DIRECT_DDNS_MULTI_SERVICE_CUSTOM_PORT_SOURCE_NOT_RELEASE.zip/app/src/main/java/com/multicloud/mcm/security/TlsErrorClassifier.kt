package com.multicloud.mcm.security

/** Identifies protocol/port mismatches surfaced by different Android TLS providers. */
object TlsErrorClassifier {
    private val protocolMarkers = listOf(
        "UNSUPPORTED_PROTOCOL",
        "WRONG_VERSION_NUMBER",
        "UNRECOGNIZED SSL MESSAGE",
        "HTTP_REQUEST",
        "UNKNOWN PROTOCOL",
        "NO_PROTOCOLS_AVAILABLE"
    )

    fun isProtocolMismatch(error: Throwable): Boolean = generateSequence(error) { it.cause }
        .mapNotNull { it.message }
        .any { message -> protocolMarkers.any { marker -> message.contains(marker, ignoreCase = true) } }

    fun isFingerprintMismatch(error: Throwable): Boolean = generateSequence(error) { it.cause }
        .mapNotNull { it.message }
        .any { message -> message.contains("fingerprint", ignoreCase = true) }
}
