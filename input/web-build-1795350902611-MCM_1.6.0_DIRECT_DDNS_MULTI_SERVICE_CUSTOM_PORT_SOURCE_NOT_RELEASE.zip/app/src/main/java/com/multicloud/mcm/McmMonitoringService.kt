package com.multicloud.mcm

import com.multicloud.mcm.data.McmDatabase
import com.multicloud.mcm.data.RouterEntity
import com.multicloud.mcm.routeros.RouterOs6ApiClient
import com.multicloud.mcm.routeros.RouterOs6Repository
import com.multicloud.mcm.security.SecureCredentialStore
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.json.JSONArray
import org.json.JSONObject

/** Read-only snapshot collector. Optional tables fail independently and never hide core metrics. */
class McmMonitoringService(
    private val database: McmDatabase,
    private val credentialStore: SecureCredentialStore
) {
    private val history = McmHistoryStore(database)
    private val interfaceRates = McmInterfaceRateService(database)
    // API-SSL creates a TLS/login session per command; keep request pressure bounded on ROS 6/7.
    private val requestGate = Semaphore(2)

    suspend fun refreshRouter(routerId: String, target: String): JSONObject {
        val router = database.routerDao().getById(routerId)
            ?: throw IllegalArgumentException("Không tìm thấy router.")
        val password = try {
            credentialStore.get(router.credentialAlias)
        } catch (error: Exception) {
            markCredentialUnavailable(router, error.message)
            throw IllegalStateException(
                "Không giải mã được thông tin đăng nhập. Kiểm tra Android Keystore hoặc nhập lại mật khẩu.",
                error
            )
        } ?: run {
            markCredentialUnavailable(router, "Không tìm thấy dữ liệu mã hóa.")
            throw IllegalStateException("Không giải mã được thông tin đăng nhập. Kiểm tra Android Keystore hoặc nhập lại mật khẩu.")
        }

        val selectedTransport = RouterServiceMode.fromStorage(router.connectionMode).resolve(router.routerOsMajor)
        val snapshot = if (selectedTransport == RouterTransport.REST_HTTPS) {
            val repository = RouterOs7Repository(
                RouterOs7Client(router.host, router.port, router.username, password, router.tlsSha256Pin)
            )
            val resource = requireCoreResource(router, requestGate.withPermit { repository.readSystemResource() })
            coroutineScope {
                val interfaces = async { requestGate.withPermit { repository.readInterfaces() } }
                val cloud = async { requestGate.withPermit { repository.readCloudStatus() } }
                val ppp = async { requestGate.withPermit { repository.readPppoeSessions() } }
                val arp = async { requestGate.withPermit { repository.readArpEntries() } }
                val dhcp = async { requestGate.withPermit { repository.readDhcpLeases() } }
                val netwatch = async { requestGate.withPermit { repository.readNetwatch() } }
                val bridgeHosts = async { requestGate.withPermit { repository.readBridgeHosts() } }
                val vlans = async { requestGate.withPermit { repository.readVlans() } }
                val bridgeVlans = async { requestGate.withPermit { repository.readBridgeVlans() } }
                val ping = async { target.trim().takeIf(String::isNotBlank)?.let { value -> requestGate.withPermit { repository.ping(value) } } }
                SnapshotResults(resource, interfaces.await(), cloud.await(), ppp.await(), arp.await(), dhcp.await(), netwatch.await(), bridgeHosts.await(), vlans.await(), bridgeVlans.await(), ping.await())
            }
        } else {
            val repository = RouterOs6Repository(
                RouterOs6ApiClient(router.host, router.port, router.username, password, router.tlsSha256Pin)
            )
            val resource = requireCoreResource(router, requestGate.withPermit { repository.readSystemResource() })
            coroutineScope {
                val interfaces = async { requestGate.withPermit { repository.readInterfaces() } }
                val cloud = async { requestGate.withPermit { repository.readCloudStatus() } }
                val ppp = async { requestGate.withPermit { repository.readPppoeSessions() } }
                val arp = async { requestGate.withPermit { repository.readArpEntries() } }
                val dhcp = async { requestGate.withPermit { repository.readDhcpLeases() } }
                val netwatch = async { requestGate.withPermit { repository.readNetwatch() } }
                val bridgeHosts = async { requestGate.withPermit { repository.readBridgeHosts() } }
                val vlans = async { requestGate.withPermit { repository.readVlans() } }
                val bridgeVlans = async { requestGate.withPermit { repository.readBridgeVlans() } }
                val ping = async { target.trim().takeIf(String::isNotBlank)?.let { value -> requestGate.withPermit { repository.ping(value) } } }
                SnapshotResults(resource, interfaces.await(), cloud.await(), ppp.await(), arp.await(), dhcp.await(), netwatch.await(), bridgeHosts.await(), vlans.await(), bridgeVlans.await(), ping.await())
            }
        }

        val measuredAt = System.currentTimeMillis()
        val resource = snapshot.resource
        resource.cpuLoadPercent?.let { history.record(router.id, "cpu_load", it.toDouble(), "%", measuredAt) }
        val free = resource.freeMemoryBytes
        val total = resource.totalMemoryBytes
        if (free != null && total != null && total > 0) {
            val used = 100.0 * (total - free).coerceAtLeast(0) / total.toDouble()
            history.record(router.id, "memory_used", used, "%", measuredAt)
        }

        val interfaceValues = (snapshot.interfaces as? McmResult.Success)?.value
        val interfaceJson = interfaceValues?.let { interfaceRates.enrich(router.id, it, measuredAt) }
        val pingJson: Any = when (val ping = snapshot.ping) {
            is McmResult.Success -> {
                history.record(router.id, "icmp_loss", ping.value.lossPercent, "%", ping.value.measuredAtEpochMs)
                ping.value.toJson()
            }
            is McmResult.Failure -> JSONObject().put("error", ping.message).put("code", ping.code)
            null -> JSONObject.NULL
        }

        (snapshot.pppActive as? McmResult.Success)?.value?.size?.let {
            history.record(router.id, "pppoe_active", it.toDouble(), "sessions", measuredAt)
        }
        (snapshot.arp as? McmResult.Success)?.value?.size?.let {
            history.record(router.id, "arp_entries", it.toDouble(), "entries", measuredAt)
        }
        (snapshot.dhcp as? McmResult.Success)?.value?.size?.let {
            history.record(router.id, "dhcp_leases", it.toDouble(), "leases", measuredAt)
        }
        (snapshot.netwatch as? McmResult.Success)?.value?.count {
            it["status"].equals("down", ignoreCase = true)
        }?.let {
            history.record(router.id, "netwatch_down", it.toDouble(), "hosts", measuredAt)
        }

        val warnings = buildList {
            optionalWarning("interface", snapshot.interfaces)?.let(::add)
            optionalWarning("MikroTik Cloud DDNS", snapshot.cloud)?.let(::add)
            optionalWarning("PPPoE active", snapshot.pppActive)?.let(::add)
            optionalWarning("ARP", snapshot.arp)?.let(::add)
            optionalWarning("DHCP lease", snapshot.dhcp)?.let(::add)
            optionalWarning("Netwatch", snapshot.netwatch)?.let(::add)
            optionalWarning("Bridge Host", snapshot.bridgeHosts)?.let(::add)
            optionalWarning("VLAN", snapshot.vlans)?.let(::add)
            optionalWarning("Bridge VLAN", snapshot.bridgeVlans)?.let(::add)
            optionalWarning("ICMP", snapshot.ping)?.let(::add)
        }
        database.routerDao().upsert(
            router.copy(
                lastSeenAtEpochMs = measuredAt,
                lastStatus = if (warnings.isEmpty()) "ONLINE" else "PARTIAL",
                lastErrorCode = if (warnings.isEmpty()) null else "OPTIONAL_DATA",
                lastErrorMessage = warnings.joinToString(" · ").take(240).ifBlank { null },
                lastCheckedAtEpochMs = measuredAt
            )
        )
        return JSONObject()
            .put("ok", true)
            .put("router", (database.routerDao().getById(router.id) ?: router).toPublicJson())
            .put("resource", JSONObject()
                .put("version", resource.version ?: JSONObject.NULL)
                .put("uptime", resource.uptime ?: JSONObject.NULL)
                .put("cpuLoadPercent", resource.cpuLoadPercent ?: JSONObject.NULL)
                .put("freeMemoryBytes", free ?: JSONObject.NULL)
                .put("totalMemoryBytes", total ?: JSONObject.NULL))
            .put("cloud", snapshot.cloud?.toJsonOrNull() ?: JSONObject.NULL)
            .put("interfaces", interfaceJson ?: JSONObject.NULL)
            .put("pppoeSessions", snapshot.pppActive.toJsonIfAvailable())
            .put("arpEntries", snapshot.arp.toJsonIfAvailable())
            .put("dhcpLeases", snapshot.dhcp.toJsonIfAvailable())
            .put("netwatch", snapshot.netwatch.toJsonIfAvailable())
            .put("bridgeHosts", snapshot.bridgeHosts.toJsonIfAvailable())
            .put("vlans", snapshot.vlans.toJsonIfAvailable())
            .put("bridgeVlans", snapshot.bridgeVlans.toJsonIfAvailable())
            .put("ping", pingJson)
            .put("warnings", JSONArray().apply { warnings.forEach(::put) })
            .put("refreshedAt", measuredAt)
    }

    /** Sequential multi-router sweep so a large profile list does not open sessions on every router at once. */
    suspend fun refreshAll(target: String, selectedRouterId: String?): JSONObject {
        val results = JSONArray()
        val routers = database.routerDao().getAll()
        var online = 0
        var partial = 0
        var offline = 0
        var selectedSnapshot: JSONObject? = null
        for (router in routers) {
            val row = try {
                val snapshot = refreshRouter(router.id, target)
                if (router.id == selectedRouterId) selectedSnapshot = snapshot
                val status = snapshot.optJSONObject("router")?.optString("lastStatus")
                    ?: database.routerDao().getById(router.id)?.lastStatus
                    ?: "UNKNOWN"
                when (status) {
                    "ONLINE" -> online++
                    "PARTIAL" -> partial++
                    else -> offline++
                }
                JSONObject().put("id", router.id).put("name", router.name)
                    .put("host", router.host).put("status", status).put("ok", true)
            } catch (cancelled: kotlinx.coroutines.CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                offline++
                val current = database.routerDao().getById(router.id) ?: router
                database.routerDao().upsert(
                    current.copy(
                        lastStatus = "OFFLINE",
                        lastErrorCode = error.message?.substringBefore(':')
                            ?.takeIf { it.matches(Regex("[A-Z0-9_]{2,48}")) } ?: "REFRESH_FAILED",
                        lastErrorMessage = (error.message ?: "Không rõ lỗi").take(240),
                        lastCheckedAtEpochMs = System.currentTimeMillis()
                    )
                )
                JSONObject().put("id", router.id).put("name", router.name)
                    .put("host", router.host).put("status", "OFFLINE").put("ok", false)
                    .put("error", error.message ?: "Không rõ lỗi")
            }
            results.put(row)
        }
        return JSONObject().put("ok", true).put("total", routers.size)
            .put("online", online).put("partial", partial).put("offline", offline)
            .put("results", results)
            .put("selectedSnapshot", selectedSnapshot ?: JSONObject.NULL)
            .put("refreshedAt", System.currentTimeMillis())
    }

    private suspend fun requireCoreResource(
        router: RouterEntity,
        result: McmResult<SystemResource>
    ): SystemResource = when (result) {
        is McmResult.Success -> result.value
        is McmResult.Failure -> {
            val checkedAt = System.currentTimeMillis()
            database.routerDao().upsert(
                router.copy(
                    lastStatus = "OFFLINE",
                    lastErrorCode = result.code,
                    lastErrorMessage = result.message.take(240),
                    lastCheckedAtEpochMs = checkedAt
                )
            )
            throw IllegalStateException("${result.code}: ${result.message}")
        }
    }

    suspend fun metricHistory(routerId: String, metricKey: String): JSONObject = history.read(routerId, metricKey)

    private suspend fun markCredentialUnavailable(router: RouterEntity, detail: String?) {
        database.routerDao().upsert(
            router.copy(
                lastStatus = "OFFLINE",
                lastErrorCode = "CREDENTIAL_UNAVAILABLE",
                lastErrorMessage = (detail?.takeIf(String::isNotBlank)
                    ?: "Không giải mã được thông tin đăng nhập. Kiểm tra Android Keystore hoặc nhập lại mật khẩu.").take(240),
                lastCheckedAtEpochMs = System.currentTimeMillis()
            )
        )
    }

    private fun optionalWarning(label: String, result: McmResult<*>?): String? =
        (result as? McmResult.Failure)?.let { "$label: ${it.code} — ${it.message}" }

    private fun McmResult<Map<String, String>>?.toJsonOrNull(): Any = when (this) {
        is McmResult.Success -> value.toJson()
        is McmResult.Failure, null -> JSONObject.NULL
    }

    private fun McmResult<List<Map<String, String>>>?.toJsonIfAvailable(): Any = when (this) {
        is McmResult.Success -> value.toJson()
        is McmResult.Failure, null -> JSONObject.NULL
    }

    private fun Map<String, String>.toJson(): JSONObject = JSONObject().also { json ->
        forEach { (key, value) -> json.put(key, value) }
    }

    private fun List<Map<String, String>>.toJson(): JSONArray = JSONArray().also { array ->
        forEach { array.put(it.toJson()) }
    }

    private fun PingMeasurement.toJson(): JSONObject = JSONObject()
        .put("target", target)
        .put("sent", sent)
        .put("received", received)
        .put("lost", lost)
        .put("lossPercent", lossPercent)
        .put("minRttMs", minRttMs ?: JSONObject.NULL)
        .put("avgRttMs", avgRttMs ?: JSONObject.NULL)
        .put("maxRttMs", maxRttMs ?: JSONObject.NULL)

    private fun RouterEntity.toPublicJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("name", name)
        .put("siteName", siteName)
        .put("host", host)
        .put("port", port)
        .put("routerOsMajor", routerOsMajor)
        .put("username", username)
        .put("lastSeenAt", lastSeenAtEpochMs ?: JSONObject.NULL)
        .put("lastStatus", lastStatus)
        .put("lastErrorCode", lastErrorCode ?: JSONObject.NULL)
        .put("lastErrorMessage", lastErrorMessage ?: JSONObject.NULL)
        .put("lastCheckedAt", lastCheckedAtEpochMs ?: JSONObject.NULL)

    private data class SnapshotResults(
        val resource: SystemResource,
        val interfaces: McmResult<List<InterfaceSnapshot>>,
        val cloud: McmResult<Map<String, String>>?,
        val pppActive: McmResult<List<Map<String, String>>>?,
        val arp: McmResult<List<Map<String, String>>>?,
        val dhcp: McmResult<List<Map<String, String>>>?,
        val netwatch: McmResult<List<Map<String, String>>>?,
        val bridgeHosts: McmResult<List<Map<String, String>>>?,
        val vlans: McmResult<List<Map<String, String>>>?,
        val bridgeVlans: McmResult<List<Map<String, String>>>?,
        val ping: McmResult<PingMeasurement>?
    )
}
