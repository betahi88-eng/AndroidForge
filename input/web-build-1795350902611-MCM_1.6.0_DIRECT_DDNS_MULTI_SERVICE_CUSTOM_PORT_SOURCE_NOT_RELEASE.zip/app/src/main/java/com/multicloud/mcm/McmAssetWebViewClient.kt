package com.multicloud.mcm

import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import androidx.webkit.WebViewAssetLoader

class McmAssetWebViewClient(
    private val assetLoader: WebViewAssetLoader
) : android.webkit.WebViewClient() {
    override fun shouldInterceptRequest(
        view: WebView?,
        request: WebResourceRequest?
    ): WebResourceResponse? = request?.url?.let(assetLoader::shouldInterceptRequest)

    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
        val uri = request?.url ?: return true
        return uri.host != "appassets.androidplatform.net" || uri.scheme != "https"
    }
}
