# Build MCM 1.6.0 bằng AndroidForge

## ZIP cần upload

Dùng duy nhất `MCM_1.6.0_DIRECT_DDNS_MULTI_SERVICE_CUSTOM_PORT_SOURCE_NOT_RELEASE.zip`. Đây là dự án Android Native Gradle/Kotlin, không phải Flutter. Tất cả file Gradle đặt trực tiếp tại root ZIP.

Root phải có `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `app/build.gradle.kts` và `app/src/main/AndroidManifest.xml`. Không có `pubspec.yaml` hoặc `harmony_patched`.

## Cấu hình build

- Project: `MikroTikMultiCloudMonitor`
- Application ID: `com.multicloud.mcm`
- Version: `1.6.0` / versionCode `9`
- JDK: 17
- Gradle: 8.7
- Android Gradle Plugin: 8.6.1
- Kotlin: 2.0.21
- compileSdk/targetSdk: 35; minSdk: 26
- Gradle tasks: `:app:testDebugUnitTest :app:lintDebug :app:assembleDebug`

## Kiểm tra AndroidForge chọn đúng project

1. Upload duy nhất ZIP `1.6.0`; không upload source ZIP khác cùng lúc.
2. Chọn Android / Gradle nếu UI có project selector.
3. Detector phải nhận root có `settings.gradle.kts` và `app/build.gradle.kts`.
4. Nếu log chạy `flutter build apk`, tìm `pubspec.yaml` hoặc chọn `harmony_patched`, dừng build vì đã chọn nhầm workspace.
5. Xác nhận toolchain Gradle 8.7 + JDK 17 + Android SDK Platform 35.

APK dự kiến: `app/build/outputs/apk/debug/app-debug.apk`. Chỉ xác nhận build khi assemble thành công, APK tồn tại, package `com.multicloud.mcm`, version `1.6.0` được xác minh và SHA-256 khớp file tải về.

## Trạng thái

ZIP là **engineering source NOT RELEASE**. Không kèm APK hoặc release keystore. Cần chạy full Gradle/JUnit/KAPT/lint/assemble, cài Android thật và thử RouterOS 6/7 qua mạng di động trước khi công nhận release.
