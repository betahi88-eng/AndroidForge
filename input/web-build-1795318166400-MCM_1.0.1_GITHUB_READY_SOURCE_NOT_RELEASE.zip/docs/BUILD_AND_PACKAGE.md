# Build and package

## Local prerequisites

- JDK 17 or newer
- Gradle 8.7
- Android SDK Platform 35
- Android Build Tools 35.0.0
- Android platform-tools for `adb install`

## Debug build

```bash
./scripts/setup-and-build.sh
```

The script runs `:app:testDebugUnitTest` and `:app:assembleDebug`, then prints the APK location and SHA-256 checksum. The debug APK is automatically debug-signed by the Android Gradle Plugin. It is not a release-signed artifact.

## Install over USB

```bash
./scripts/install-debug.sh
```

## Source archive

```bash
./scripts/package-source.sh
```

The archive is named `MCM_1.0.1_ENGINEERING_SOURCE_NOT_RELEASE.zip` by default. It excludes build caches, Python bytecode, local SDK paths, certificates/private keys, keystores and APKs. Keep any production signing key outside the source archive and under owner-controlled secure storage.
