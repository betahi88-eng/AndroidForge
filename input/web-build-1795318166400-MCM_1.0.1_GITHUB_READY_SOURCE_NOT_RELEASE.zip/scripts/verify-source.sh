#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
command -v node >/dev/null || { echo "Node.js is required for UI syntax checks." >&2; exit 1; }
command -v python3 >/dev/null || { echo "Python 3 is required for mock syntax checks." >&2; exit 1; }
command -v bash >/dev/null

while IFS= read -r -d '' file; do
  node --check "$file"
done < <(find app/src/main/assets/www -type f -name '*.js' -print0)
python3 -m py_compile tools/*.py
while IFS= read -r -d '' file; do
  bash -n "$file"
done < <(find scripts -type f -name '*.sh' -print0)

echo "Static source checks passed (JavaScript, Python and shell)."
if command -v gradle >/dev/null; then
  gradle --no-daemon :app:testDebugUnitTest
else
  echo "Gradle is not installed; Android/JUnit Gradle tests were not run." >&2
fi
