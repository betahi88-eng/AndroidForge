#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${1:-$(dirname "$ROOT")/MCM_1.0.1_ENGINEERING_SOURCE_NOT_RELEASE.zip}"
case "$OUT" in
  /*) ;;
  *) OUT="$PWD/$OUT" ;;
esac
case "$OUT" in
  "$ROOT"/*) echo "Choose an archive destination outside the source tree." >&2; exit 1 ;;
esac
mkdir -p "$(dirname "$OUT")"
rm -f "$OUT"
cd "$ROOT"
zip -qr "$OUT" . \
  -x '.git/*' '.gradle/*' '*/build/*' 'build/*' 'local.properties' \
     '*/__pycache__/*' '*.pyc' '*.apk' '*.aab' '*.jks' '*.keystore' \
     '*.pem' '*.key' '*.crt' '.mcm-test-cert/*'
echo "Source archive: $OUT"
sha256sum "$OUT"
