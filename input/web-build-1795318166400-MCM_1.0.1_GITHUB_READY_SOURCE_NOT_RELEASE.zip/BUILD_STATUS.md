# MCM 1.0.1 build status

**Status:** Engineering source package only — not a signed release.

## Checks completed in this workspace

- JavaScript syntax checks (`node --check`) — passed for all local UI scripts.
- Python syntax checks (`python3 -m py_compile`) — passed for both mock servers.
- Shell syntax checks (`bash -n`) — passed for build/package/install/certificate scripts.
- Kotlin core compilation and executable checks — passed for data models, RouterOS 7 ping parser, RouterOS 6 ping parser, RouterOS API framing and legacy MD5 challenge response. This was a focused `kotlinc` check with local API-compatible stubs for Android/JSON boundaries, not a complete Android app compile.
- Mock REST HTTPS — resource response and bounded ping loss fixture passed.
- Mock API-SSL — direct login, legacy challenge login and bounded ping response fixtures passed.

## Not verified here

- Full Android Gradle build and APK assembly: not run because this workspace does not have Gradle or Android SDK Platform 35 / Build Tools 35.0.0 installed, and cannot download them from package repositories.
- Gradle/JUnit task execution: not run; test methods were executed in a focused local Kotlin harness with compatibility stubs, but the actual Gradle/JUnit task remains unrun.
- RouterOS 6/7 hardware validation and Android device validation: not run.
- Release signing: no app signing key or production APK is included.

The source archive must not be described as a compiled or production-ready APK. Follow `docs/TEST_PLAN.md` before release.
