package com.multicloud.mcm

import com.multicloud.mcm.routeros.PingResponseParser
import org.json.JSONArray
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PingResponseParserTest {
    @Test
    fun cumulativeCountersAreUsedInsteadOfCountingRows() {
        val rows = JSONArray()
            .put("""{"seq":"0","sent":"1","received":"1","time":"453us"}""")
            .put("""{"seq":"2","sent":"3","received":"2","time":"500us"}""")

        val result = PingResponseParser.parse("1.1.1.1", rows, expectedSent = 3, now = 123L)
        assertTrue(result is McmResult.Success)
        val value = (result as McmResult.Success).value
        assertEquals(3, value.sent)
        assertEquals(2, value.received)
        assertEquals(1, value.lost)
        assertEquals(33.3333, value.lossPercent, 0.001)
        assertEquals(123L, value.measuredAtEpochMs)
        assertEquals(0.453, value.minRttMs!!, 0.0001)
    }

    @Test
    fun missingSentCountIsRejectedInsteadOfAssumingRequestedCount() {
        val rows = JSONArray().put("""{"seq":"0","time":"10ms"}""")
        val result = PingResponseParser.parse("192.0.2.1", rows, expectedSent = 1)
        assertTrue(result is McmResult.Failure)
        assertEquals("PING_INVALID", (result as McmResult.Failure).code)
    }

    @Test
    fun durationUnitsAreNormalizedToMilliseconds() {
        assertEquals(0.25, PingResponseParser.parseDurationMs("250us")!!, 0.0001)
        assertEquals(4.5, PingResponseParser.parseDurationMs("4.5ms")!!, 0.0001)
        assertEquals(1_000.0, PingResponseParser.parseDurationMs("1s")!!, 0.0001)
        assertEquals(14.612, PingResponseParser.parseDurationMs("14ms612us")!!, 0.0001)
        assertEquals(null, PingResponseParser.parseDurationMs("timeout"))
    }

    @Test
    fun incompleteTrailingTimeoutDoesNotProduceAnUnderstatedLossRate() {
        val rows = JSONArray()
            .put("""{"sent":"1","received":"1","time":"10ms"}""")
            .put("""{"sent":"2","received":"1","time":"11ms"}""")
        val result = PingResponseParser.parse("198.51.100.1", rows, expectedSent = 3)
        assertTrue(result is McmResult.Failure)
        assertEquals("PING_INCOMPLETE", (result as McmResult.Failure).code)
    }

    @Test
    fun partialCounterPairAndDecreasingCountersAreRejected() {
        val partial = JSONArray().put("""{"sent":"2","time":"10ms"}""")
        val partialResult = PingResponseParser.parse("203.0.113.1", partial, expectedSent = 2)
        assertTrue(partialResult is McmResult.Failure)

        val decreasing = JSONArray()
            .put("""{"sent":"2","received":"2","time":"10ms"}""")
            .put("""{"sent":"3","received":"1","time":"11ms"}""")
        val decreasingResult = PingResponseParser.parse("203.0.113.1", decreasing, expectedSent = 3)
        assertTrue(decreasingResult is McmResult.Failure)
    }

    @Test
    fun invalidCounterRelationshipsAreRejected() {
        val rows = JSONArray().put("""{"sent":"3","received":"4","time":"2ms"}""")
        val result = PingResponseParser.parse("203.0.113.1", rows, expectedSent = 1)
        assertTrue(result is McmResult.Failure)
    }
}
