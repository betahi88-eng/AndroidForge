# BUILD FIX 002 — Remove unresolved enum property from failing Kotlin call sites

## Evidence from latest uploaded AndroidForge logs
The latest log bundle still reports the exact same diagnostics in `RouterConnectionCoordinator.kt`:
- lines 262–263: unresolved `port` and chained `put`
- lines 291–292: unresolved `port` and chained `put`
The failure is at `:app:compileDebugKotlin` / `:app:compileReleaseKotlin`.
The logs do not contain the source archive or a source hash, so they cannot prove that the Builder compiled the previously supplied BUILD FIX 001 ZIP. The same diagnostics after that patch strongly suggest the Builder may still be compiling the old source input or an existing workspace copy.

## Additional source-side hardening in this package
The coordinator now calculates a local `selectedPort` with an exhaustive `when`:
- `REST_HTTPS` → 443
- `API_SSL` → 8729
Both JSON payload writes use the local `Int` instead of `selected.port`. This removes the exact unresolved-property expression from both reported locations and avoids relying on enum property metadata at those call sites.

The `RouterTransport.port` property added in BUILD FIX 001 remains, and unit assertions remain.

## Important Builder input check
After uploading this ZIP, ensure the Builder's selected input points to this exact file and that it re-extracts into a clean workspace. If the next log still shows `.put("port", selected.port)`, the Builder is not compiling this archive; it is reusing a stale ZIP/workspace or another source path.

## Verification status
- Exact source replacement count: 2 of 2.
- No remaining `selected.port` references in RouterConnectionCoordinator.
- ZIP CRC and root project structure: verified.
- Android Gradle build: NOT RUN here; Builder execution is still required.
