# ANDROIDFORGE — MẪU DỰ ÁN MCM 1.6.3 DÙNG ĐỂ ZIP → APK

## Mục đích
Đây là **ZIP đầu vào mẫu** cho AndroidForge Builder. Nội dung là source Android native Kotlin của MCM 1.6.3, không phải Repair Kit và không phải APK dựng sẵn.

ZIP được đóng theo dạng project-root: `settings.gradle.kts`, `build.gradle.kts` và `app/build.gradle.kts` nằm ngay ở thư mục gốc sau khi giải nén. AndroidForge phải nhận diện module `:app`, không chạy Gradle tại thư mục cha hoặc thư mục Repair Kit.

## Nhận diện dự án
- Project: MikroTik Multi-Cloud Monitor (MCM)
- Source ID: `MCM-1.6.3-RECONCILED-001`
- Application ID: `com.multicloud.mcm`
- Version: `1.6.3` (versionCode `12`)
- Loại: Android native / Kotlin / Gradle
- Module: `:app`
- Min SDK: 26; Compile/Target SDK: 35
- JDK: 17; Gradle: 8.7; AGP: 8.6.1; Kotlin: 2.0.21

## Cách đưa vào AndroidForge
1. Tải nguyên ZIP này lên Builder. Không giải nén rồi nén thêm thành một thư mục Repair Kit.
2. Chọn profile `mcm-native` nếu Builder có trường project profile; nếu chỉ có `auto`, để auto-detect.
3. Chọn build variant `debug` để tạo APK thử nghiệm.
4. Với workflow nhận đường dẫn source nội bộ, dùng `zip_source=input-directory` và trỏ tới file ZIP đã upload/copy vào input folder.
5. Kết quả cần lấy là APK được tạo từ chính lần chạy Actions hiện tại (artifact của run đó), không phải APK cũ trong thư mục hay Release trước đó.

## Các lệnh build chuẩn
```bash
./gradlew clean
./gradlew :app:testDebugUnitTest
./gradlew :app:lintDebug
./gradlew :app:assembleDebug
```

Source archive hiện không kèm Gradle Wrapper. AndroidForge phải cung cấp Gradle 8.7, JDK 17 và Android SDK Platform 35 / Build Tools 35.0.0 theo tài liệu pipeline. Không tự thêm wrapper khác phiên bản nếu chưa kiểm tra tương thích.

## Những gì đã có trong source
- Mã nguồn Kotlin và AndroidManifest.
- Giao diện WebView assets (HTML/CSS/JS).
- Room database và migration checks.
- Unit tests Kotlin/JUnit.
- Script kiểm tra source, UI contract, Room migrations và đóng gói source.
- Tài liệu kiến trúc, thiết kế chức năng, kế hoạch test, cấu hình RouterOS và build.

## Trạng thái cần hiểu đúng
Đây là **mẫu source để AndroidForge build và tiếp tục chỉnh sửa**. Việc tạo ZIP và kiểm tra cấu trúc không chứng minh APK đã build thành công. Chỉ đánh dấu build thành công khi `testDebugUnitTest`, `lintDebug`, `assembleDebug` đều exit code 0 và APK được kiểm tra package/version/mtime/hash của đúng run.
