# AndroidForge — hướng dẫn dùng source MCM 1.6.3

Đầu vào gốc được khóa bằng SHA-256 và giữ nguyên trong thư mục `LOCKED_BASE` của gói sửa chữa. Source dẫn xuất `MCM_1.6.3_RECONCILED_DDNS_KOTLIN_SOURCE_DERIVED_PATCH_001.zip` là bản có các thay đổi kỹ thuật; đây là source build candidate, không phải APK.

Pipeline MCM phải chọn đúng ZIP dẫn xuất bằng đường dẫn xác định, xác minh SHA-256, kiểm tra provenance và nhận diện Gradle native `:app` trước khi gọi Gradle. Toolchain được khóa: JDK 17, Gradle 8.7, AGP 8.6.1, Kotlin 2.0.21, Android SDK 35. Không tự cài/chuyển phiên bản trong pipeline.

Build chỉ thành công sau khi `clean`, `testDebugUnitTest`, `lintDebug`, `assembleDebug` đều trả mã 0. APK collector phải xác minh APK mới từ lần chạy này, manifest/package/version, và asset build provenance; tên file hoặc APK có sẵn không phải bằng chứng. Automatic GitHub Release bị vô hiệu hóa trong patch cho đến khi chủ dự án cho phép rõ ràng.

Chưa có APK build thật trong gói này. Hãy xem `BUILD_STATUS.md` và `NEXT_ACTION_VI.md` trước nghiệm thu.
