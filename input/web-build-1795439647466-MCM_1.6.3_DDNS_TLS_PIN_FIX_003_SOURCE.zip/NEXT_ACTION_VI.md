# Các bước còn bắt buộc trước nghiệm thu MCM 1.6.3

1. Trên runner có đúng JDK 17, Gradle 8.7, Android Gradle Plugin 8.6.1, Kotlin 2.0.21 và Android SDK Platform 35/build-tools, chạy preflight trên ZIP dẫn xuất đã khóa hash.
2. Chạy `:app:testDebugUnitTest`, `:app:lintDebug` và `:app:assembleDebug`; không bỏ qua lỗi.
3. Thu APK mới sinh từ đúng workspace/lần build; kiểm tra ZIP integrity, package `com.multicloud.mcm`, versionName `1.6.3`, versionCode `12`, variant debug và manifest provenance.
4. Chạy cài đặt trên Android API 26+ thực tế; kiểm tra UI dọc/ngang, bàn phím, insets, thêm nhiều profile, cập nhật profile trùng hostname và lưu lịch sử.
5. Kiểm thử RouterOS 6 và RouterOS 7 trên thiết bị/lab được ủy quyền: DNS system/DoH fallback, REST 443, API-SSL 8729, sai mật khẩu, thiếu quyền đọc, timeout, refused port, self-signed TLS, FIRST_TIME_PIN và TLS_CHANGED. Không thay đổi cấu hình Router nếu chưa được cấp phép.
6. Kiểm tra bằng chứng kết nối: không READY giả, không ghi credential/token vào log, không xác thực hostname tùy tiện, READY_LIMITED không chạy monitoring.
7. Chỉ nghiệm thu khi build thật, cài đặt và các kịch bản tích hợp đạt; phát hành/push/merge cần ủy quyền riêng.
