#!/usr/bin/env python3
"""Validate the mobile-first DDNS form and WebView DOM bindings."""
from __future__ import annotations
import re
from pathlib import Path

root = Path(__file__).resolve().parents[1]
www = root / "app/src/main/assets/www"
html = (www / "index.html").read_text(encoding="utf-8")
ids = re.findall(r'\bid=["\']([^"\']+)["\']', html)
if len(ids) != len(set(ids)):
    duplicates = sorted({item for item in ids if ids.count(item) > 1})
    raise SystemExit("Duplicate HTML id(s): " + ", ".join(duplicates))

lookups: dict[str, set[str]] = {}
for path in www.glob("*.js"):
    content = path.read_text(encoding="utf-8")
    for dom_id in re.findall(r'\$\(["\']([^"\']+)["\']\)', content):
        lookups.setdefault(dom_id, set()).add(path.name)
missing = sorted(set(lookups) - set(ids))
if missing:
    raise SystemExit("Missing HTML element id(s): " + "; ".join(missing))

required_inputs = {"routerHost", "routerUsername", "routerPassword"}
if not required_inputs.issubset(set(ids)):
    raise SystemExit("Missing required DDNS inputs: " + ", ".join(sorted(required_inputs - set(ids))))
form = re.search(r'<form id="routerForm">(.*?)</form>', html, re.S)
if not form:
    raise SystemExit("Router form is missing")
form_html = form.group(1)
primary = re.search(r'<div class="form-grid connection-form-grid">(.*?)</div>', form_html, re.S)
if not primary:
    raise SystemExit("Primary connection form grid is missing")
input_ids = set(re.findall(r'<input\b[^>]*\bid="([^"\']+)"', primary.group(1)))
if input_ids != required_inputs:
    raise SystemExit(f"Primary form must expose exactly three inputs; found {sorted(input_ids)}")
advanced = re.search(r'<details id="routerAdvancedOptions" class="advanced-options">(.*?)</details>', form_html, re.S)
if not advanced or re.search(r'<details[^>]*\bopen(?:=|\s|>)', form_html):
    raise SystemExit("Technical settings must be inside a closed-by-default advanced section")
advanced_html = advanced.group(1)
for required in ('id="routerPort"', 'id="routerConnectionMode"', 'openConnectionLogsBtn', 'Nhật ký kỹ thuật'):
    if required not in advanced_html:
        raise SystemExit(f"Missing advanced connection setting: {required}")
if 'min="1"' not in advanced_html or 'max="65535"' not in advanced_html:
    raise SystemExit("Advanced WAN port must be constrained to 1..65535")
for mode in ('value="AUTO"', 'value="REST_HTTPS"', 'value="API_SSL"'):
    if mode not in advanced_html:
        raise SystemExit(f"Missing service mode option: {mode}")
if form_html.count('type="submit"') != 1 or "Lưu &amp; Kết nối" not in form_html:
    raise SystemExit("Router form must have one primary 'Lưu & Kết nối' action")
if "openConnectionLogsBtn" not in form_html or "Nhật ký kỹ thuật" not in form_html:
    raise SystemExit("Connection diagnostics must remain available in the advanced section")
if "<p>" in form_html:
    raise SystemExit("Unnecessary explanatory notes remain in the Add Router form")
router_ui = (www / "router-ui.js").read_text(encoding="utf-8")
bridge = (www / "native-bridge.js").read_text(encoding="utf-8")
if "window.McmBridge" not in bridge:
    raise SystemExit("Native Android bridge is not connected")
for required in ("FIRST_TIME_PIN", "TLS_CHANGED", "PORTS_UNREACHABLE", "READY_LIMITED", "connectionLogs", "Kết nối thất bại · nhật ký chẩn đoán", "result.diagnostics"):
    if required not in router_ui:
        raise SystemExit(f"Missing connection UI behavior: {required}")
if 'connectionDialog.addEventListener("cancel"' not in router_ui:
    raise SystemExit("Back/Escape cancellation is not wired for trust dialogs")
if 'nativeCall("connectRouter", host, username, password, port, mode)' not in router_ui:
    raise SystemExit("Advanced port/service selection is not passed to the native connection bridge")
if 'routerAdvancedOptions").open = false' not in router_ui:
    raise SystemExit("Advanced section must be explicitly closed when resetting the form")
print(f"Mobile DDNS UI contract: PASS ({len(ids)} unique IDs, {len(lookups)} JS literal lookups, 3 primary inputs + hidden advanced service/port)")
