package com.multicloud.mcm

import com.multicloud.mcm.routeros.RouterOsApiCodec
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RouterOsApiCodecTest {
    @Test fun recognizesModernLoginCredentialRejection() {
        assertTrue(RouterOsApiCodec.isCredentialRejected(listOf("!trap", "=message=invalid user name or password (6)")))
        assertTrue(RouterOsApiCodec.isCredentialRejected(listOf("!fatal", "=message=login failure")))
    }

    @Test fun doesNotTreatLegacyLoginSyntaxTrapAsBadPassword() {
        assertFalse(RouterOsApiCodec.isCredentialRejected(listOf("!trap", "=message=unknown parameter name")))
        assertFalse(RouterOsApiCodec.isCredentialRejected(listOf("!done", "=ret=1234")))
    }
}
