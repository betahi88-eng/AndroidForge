package com.multicloud.mcm

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class RouterHostValidatorTest {
    @Test fun acceptsMikroTikCloudDomainAndNormalizesCase() {
        assertEquals("abcd1234.sn.mynetname.net", RouterHostValidator.normalize("ABCD1234.SN.MYNETNAME.NET"))
        assertEquals("MIKROTIK_CLOUD", RouterHostValidator.endpointKind("abcd1234.sn.mynetname.net"))
    }

    @Test fun acceptsCustomDdnsAndIpv4() {
        assertEquals("router.example.net", RouterHostValidator.normalize("router.example.net"))
        assertEquals("DDNS_DOMAIN", RouterHostValidator.endpointKind("router.example.net"))
        assertEquals("192.168.1.1", RouterHostValidator.normalize("192.168.1.1"))
        assertEquals("IP", RouterHostValidator.endpointKind("192.168.1.1"))
    }

    @Test fun acceptsOneDnsRootDotAndRejectsMalformedExtraDots() {
        assertEquals("router.example.net", RouterHostValidator.normalize("router.example.net."))
        assertThrows(IllegalArgumentException::class.java) {
            RouterHostValidator.normalize("router.example.net..")
        }
    }

    @Test fun stripsHttpsAndTrailingSlashAndSupportsIpv6Literals() {
        assertEquals("router.example.net", RouterHostValidator.normalize(" HTTPS://ROUTER.EXAMPLE.NET/ "))
        assertEquals("2001:db8:0:0:0:0:0:1", RouterHostValidator.normalize("2001:db8::1"))
        assertEquals("IP", RouterHostValidator.endpointKind("2001:db8::1"))
    }

    @Test fun rejectsHttpPortPathAndInvalidIpv4() {
        listOf("http://router.example.net", "router.example.net:443", "router.example.net/rest", "192.168.1.999", "2001:db8:::1").forEach { host ->
            assertThrows(IllegalArgumentException::class.java) { RouterHostValidator.normalize(host) }
        }
    }
}
