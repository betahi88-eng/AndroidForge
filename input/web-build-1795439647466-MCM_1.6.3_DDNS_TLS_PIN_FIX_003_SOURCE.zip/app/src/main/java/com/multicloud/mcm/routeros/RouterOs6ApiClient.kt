package com.multicloud.mcm.routeros

import com.multicloud.mcm.McmResult
import com.multicloud.mcm.RouterDnsResolver
import com.multicloud.mcm.DnsResolutionException
import com.multicloud.mcm.RouterOs7Client
import com.multicloud.mcm.security.TlsErrorClassifier
import com.multicloud.mcm.security.Sha256PinnedTrustManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.security.SecureRandom
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket

internal class RouterOsAuthenticationException(message: String) : Exception(message)

/** RouterOS native API over TLS client with current and legacy login support (ROS 6/7). */
class RouterOs6ApiClient(
    private val host: String,
    private val port: Int,
    private val username: String,
    private val password: String,
    expectedPinHex: String,
    private val connectTimeoutMs: Int = 5_000,
    private val loginReadTimeoutMs: Int = 8_000,
    private val commandReadTimeoutMs: Int = 20_000,
    private val resolvedAddresses: List<java.net.InetAddress>? = null
) {
    private val pin = RouterOs7Client.normalizePin(expectedPinHex)
    private val trustManager = Sha256PinnedTrustManager(pin)
    private val sslContext = SSLContext.getInstance("TLS").apply {
        init(null, arrayOf(trustManager), SecureRandom())
    }

    suspend fun execute(
        command: String,
        attributes: Map<String, String> = emptyMap()
    ): McmResult<List<Map<String, String>>> = withContext(Dispatchers.IO) {
        require(command.startsWith('/') && command.matches(Regex("/[A-Za-z0-9_/-]+")))
        try {
            openAuthenticatedSocket().use { socket ->
                socket.soTimeout = commandReadTimeoutMs
                val input = DataInputStream(BufferedInputStream(socket.inputStream))
                val output = DataOutputStream(BufferedOutputStream(socket.outputStream))
                val words = listOf(command) + attributes.map { (key, value) -> "=$key=$value" }
                RouterOsApiCodec.writeSentence(output, words)
                val rows = mutableListOf<Map<String, String>>()
                while (true) {
                    val sentence = RouterOsApiCodec.readSentence(input)
                    when (sentence.firstOrNull()) {
                        "!re" -> rows.add(RouterOsApiCodec.parseAttributes(sentence.drop(1)))
                        "!trap", "!fatal" -> {
                            val message = RouterOsApiCodec.responseMessage(sentence).ifBlank { sentence.first() }
                            val permissionDenied = message.contains("not enough permissions", true) ||
                                message.contains("permission denied", true) || message.contains("not permitted", true)
                            val authenticationRejected = RouterOsApiCodec.isCredentialRejected(sentence)
                            return@withContext McmResult.Failure(
                                when {
                                    permissionDenied -> "PERMISSION"
                                    authenticationRejected -> "AUTH"
                                    else -> "API_COMMAND"
                                },
                                when {
                                    authenticationRejected -> "RouterOS từ chối username/password API-SSL."
                                    else -> "RouterOS API: $message"
                                }
                            )
                        }
                        "!done" -> return@withContext McmResult.Success(rows)
                        "!empty" -> return@withContext McmResult.Failure(
                            "API_EMPTY",
                            "RouterOS kết thúc lệnh bằng !empty thay vì !done; không xác nhận phép đo ping hoàn tất."
                        )
                    }
                }
                @Suppress("UNREACHABLE_CODE")
                McmResult.Failure("API_PROTOCOL", "RouterOS API response ended unexpectedly.")
            }
        } catch (error: RouterOsAuthenticationException) {
            McmResult.Failure("AUTH", "RouterOS từ chối đăng nhập API-SSL. Kiểm tra username/password và policy user.")
        } catch (error: IllegalStateException) {
            McmResult.Failure("API_PROTOCOL", error.message?.take(300)?.ifBlank { "RouterOS API-SSL protocol error." }
                ?: "RouterOS API-SSL protocol error.")
        } catch (error: DnsResolutionException) {
            McmResult.Failure(error.failureCode, "Không phân giải được domain $host: ${error.message.orEmpty()}")
        } catch (error: java.net.UnknownHostException) {
            McmResult.Failure("DNS_FAILED", "Không phân giải được domain $host bằng Android DNS, Google DoH hoặc Cloudflare DoH.")
        } catch (error: java.net.SocketTimeoutException) {
            McmResult.Failure("TIMEOUT", "Hết thời gian kết nối/đọc $host:$port. Kiểm tra port và firewall.")
        } catch (error: java.net.ConnectException) {
            McmResult.Failure("CONNECT_REFUSED", "Không mở được API-SSL tại $host:$port. Kiểm tra dịch vụ và firewall.")
        } catch (error: javax.net.ssl.SSLProtocolException) {
            McmResult.Failure("TLS_PROTOCOL", "Cổng $port không phản hồi API-SSL/TLS. Kiểm tra bật api-ssl và đúng port (mặc định 8729).")
        } catch (error: javax.net.ssl.SSLHandshakeException) {
            when {
                TlsErrorClassifier.isFingerprintMismatch(error) -> McmResult.Failure(
                    "TLS_FINGERPRINT_MISMATCH", "SHA-256 fingerprint không khớp chứng chỉ RouterOS."
                )
                TlsErrorClassifier.isProtocolMismatch(error) -> McmResult.Failure(
                    "TLS_PROTOCOL", "Cổng $port không trả lời API-SSL/TLS đúng chuẩn. Kiểm tra api-ssl và port."
                )
                else -> McmResult.Failure(
                    "TLS_HANDSHAKE", "TLS handshake thất bại. Kiểm tra chứng chỉ api-ssl và cấu hình TLS."
                )
            }
        } catch (error: javax.net.ssl.SSLException) {
            if (TlsErrorClassifier.isProtocolMismatch(error)) {
                McmResult.Failure(
                    "TLS_PROTOCOL",
                    "Cổng $port không trả lời API-SSL/TLS. Có thể đang trỏ nhầm cổng HTTP hoặc dịch vụ khác; kiểm tra lại api-ssl và port."
                )
            } else {
                McmResult.Failure("TLS", "Kết nối API-SSL bị lỗi: ${error.message ?: "không rõ nguyên nhân"}")
            }
        } catch (error: Exception) {
            McmResult.Failure("NETWORK", error.message ?: "Không thể kết nối RouterOS API-SSL.")
        }
    }

    private fun openAuthenticatedSocket(): SSLSocket {
        val modernSocket = connectSocket()
        try {
            val input = DataInputStream(BufferedInputStream(modernSocket.inputStream))
            val output = DataOutputStream(BufferedOutputStream(modernSocket.outputStream))
            RouterOsApiCodec.writeSentence(output, listOf("/login", "=name=$username", "=password=$password"))
            val reply = RouterOsApiCodec.readUntilTerminal(input)
            if (RouterOsApiCodec.isCredentialRejected(reply)) {
                throw RouterOsAuthenticationException(RouterOsApiCodec.responseMessage(reply))
            }
            val rejected = reply.any { it == "!trap" || it == "!fatal" }
            if (!rejected) return modernSocket
            // A non-authentication trap indicates an unsupported modern login form on old ROS.
        } catch (error: RouterOsAuthenticationException) {
            runCatching { modernSocket.close() }
            throw error
        } catch (error: java.net.SocketTimeoutException) {
            runCatching { modernSocket.close() }
            throw error
        } catch (error: java.io.IOException) {
            runCatching { modernSocket.close() }
            throw error
        }
        runCatching { modernSocket.close() }
        return connectAndLegacyLogin()
    }

    private fun connectAndLegacyLogin(): SSLSocket {
        val socket = connectSocket()
        try {
            val input = DataInputStream(BufferedInputStream(socket.inputStream))
            val output = DataOutputStream(BufferedOutputStream(socket.outputStream))
            RouterOsApiCodec.writeSentence(output, listOf("/login"))
            val firstReply = RouterOsApiCodec.readUntilTerminal(input)
            val challenge = firstReply.asSequence()
                .filter { it.startsWith("=") }
                .mapNotNull { RouterOsApiCodec.parseAttribute(it)?.takeIf { pair -> pair.first == "ret" }?.second }
                .firstOrNull()
                ?: throw IllegalStateException("RouterOS API did not return a legacy login challenge")
            val response = RouterOsApiCodec.legacyLoginResponse(password, challenge)
            RouterOsApiCodec.writeSentence(output, listOf("/login", "=name=$username", "=response=$response"))
            val loginReply = RouterOsApiCodec.readUntilTerminal(input)
            if (loginReply.any { it == "!trap" || it == "!fatal" }) {
                val message = RouterOsApiCodec.responseMessage(loginReply).ifBlank { "Authentication rejected" }
                throw RouterOsAuthenticationException(message)
            }
            return socket
        } catch (error: Exception) {
            runCatching { socket.close() }
            throw error
        }
    }

    private fun connectSocket(): SSLSocket {
        require(host.isNotBlank() && port in 1..65535)
        val addresses = resolvedAddresses?.takeIf { it.isNotEmpty() } ?: RouterDnsResolver.resolve(host)
        var lastConnectError: Exception? = null
        for (address in addresses) {
            val socket = sslContext.socketFactory.createSocket() as SSLSocket
            try {
                socket.useClientMode = true
                socket.soTimeout = loginReadTimeoutMs
                socket.connect(InetSocketAddress(address, port), connectTimeoutMs)
                RouterDnsResolver.configureSni(socket, host)
                socket.startHandshake()
                // The custom X509TrustManager has already enforced the exact SHA-256 pin.
                // Keep DDNS SNI; do not impose a second CN/SAN hostname check on RouterOS
                // self-signed certificates that were explicitly trusted by fingerprint.
                return socket
            } catch (error: Exception) {
                runCatching { socket.close() }
                lastConnectError = error
                if (error !is java.net.ConnectException && error !is java.net.SocketTimeoutException) {
                    throw error
                }
            }
        }
        throw lastConnectError ?: java.net.UnknownHostException("No reachable address for $host")
    }

    companion object {

    }
}
