package com.multicloud.mcm

import com.multicloud.mcm.security.TlsErrorClassifier
import com.multicloud.mcm.security.Sha256PinnedTrustManager
import com.multicloud.mcm.security.PinnedTlsHostnameVerifier
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Credentials
import okhttp3.Dns
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext

/** RouterOS 7 REST client. HTTPS only, with a manually verified SHA-256 leaf certificate pin. */
class RouterOs7Client(
    private val host: String,
    private val port: Int,
    private val username: String,
    private val password: String,
    expectedPinHex: String,
    connectTimeoutMs: Long = 5_000,
    readTimeoutMs: Long = 20_000,
    writeTimeoutMs: Long = 10_000,
    callTimeoutMs: Long = 30_000,
    private val resolvedAddresses: List<java.net.InetAddress>? = null
) {
    private val normalizedPin = normalizePin(expectedPinHex)
    private val trustManager = Sha256PinnedTrustManager(normalizedPin)

    private val http = OkHttpClient.Builder()
        .dns(object : Dns {
            override fun lookup(hostname: String): List<java.net.InetAddress> =
                if (hostname.equals(host, ignoreCase = true)) {
                    resolvedAddresses?.takeIf { it.isNotEmpty() } ?: RouterDnsResolver.resolve(hostname)
                } else Dns.SYSTEM.lookup(hostname)
        })
        .connectTimeout(connectTimeoutMs, TimeUnit.MILLISECONDS)
        .readTimeout(readTimeoutMs, TimeUnit.MILLISECONDS)
        .writeTimeout(writeTimeoutMs, TimeUnit.MILLISECONDS)
        .callTimeout(callTimeoutMs, TimeUnit.MILLISECONDS)
        .sslSocketFactory(
            SSLContext.getInstance("TLS").apply {
                init(null, arrayOf(trustManager), SecureRandom())
            }.socketFactory,
            trustManager
        )
        // This client is deliberately pin-only: the custom TrustManager above rejects every
        // leaf except the exact SHA-256 pin confirmed out-of-band by the user. RouterOS often
        // uses a self-signed certificate whose CN/SAN is not its IP Cloud DDNS name, so the
        // platform hostname verifier would reject a legitimate, explicitly pinned router.
        // The URL hostname is still the DDNS name, preserving TLS SNI and HTTP Host.
        .hostnameVerifier(PinnedTlsHostnameVerifier)
        .build()

    private fun url(path: String): String {
        require(path.matches(Regex("[A-Za-z0-9_./-]+"))) { "Invalid RouterOS REST path" }
        require(host.isNotBlank() && port in 1..65535)
        val urlHost = if (host.contains(':') && !host.startsWith('[')) "[$host]" else host
        return "https://$urlHost:$port/rest/${path.trimStart('/')}"
    }

    suspend fun get(path: String): McmResult<JSONArray> = withContext(Dispatchers.IO) {
        execute(Request.Builder().url(url(path)).get().build())
    }

    suspend fun post(path: String, payload: JSONObject): McmResult<JSONArray> = withContext(Dispatchers.IO) {
        val body = payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        execute(Request.Builder().url(url(path)).post(body).build())
    }

    private fun execute(request: Request): McmResult<JSONArray> {
        val authenticated = request.newBuilder()
            .header("Authorization", Credentials.basic(username, password))
            .header("Accept", "application/json")
            .build()
        return try {
            http.newCall(authenticated).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val detail = runCatching {
                        val error = JSONObject(body)
                        listOf(error.optString("message"), error.optString("detail"))
                            .filter(String::isNotBlank)
                            .distinct()
                            .joinToString(" — ")
                    }.getOrNull()
                    val code = when (response.code) {
                        401 -> "AUTH"
                        403 -> "PERMISSION"
                        else -> "HTTP_${response.code}"
                    }
                    val fallback = when (response.code) {
                        401 -> "RouterOS từ chối đăng nhập. Kiểm tra username/password."
                        403 -> "Tài khoản đã đăng nhập nhưng không đủ quyền đọc REST/API."
                        else -> "RouterOS REST trả HTTP ${response.code}."
                    }
                    McmResult.Failure(code, detail?.takeIf(String::isNotBlank) ?: fallback)
                } else {
                    val trimmed = body.trim()
                    val result = when {
                        trimmed.isBlank() -> JSONArray()
                        trimmed.startsWith("[") -> JSONArray(trimmed)
                        trimmed.startsWith("{") -> JSONArray().put(JSONObject(trimmed))
                        else -> return McmResult.Failure("REST_FORMAT", "Phản hồi REST không phải JSON hợp lệ.")
                    }
                    McmResult.Success(result)
                }
            }
        } catch (e: DnsResolutionException) {
            McmResult.Failure(e.failureCode, "Không phân giải được $host: ${e.message.orEmpty()}")
        } catch (e: java.net.UnknownHostException) {
            McmResult.Failure("DNS_FAILED", "Không phân giải được $host bằng Android DNS, Google DoH hoặc Cloudflare DoH.")
        } catch (e: java.net.SocketTimeoutException) {
            McmResult.Failure("NETWORK_TIMEOUT", "Hết thời gian kết nối/đọc từ $host:$port. Kiểm tra Internet, firewall, NAT và dịch vụ RouterOS.")
        } catch (e: java.net.ConnectException) {
            McmResult.Failure("CONNECT_REFUSED", "Không mở được kết nối tới $host:$port. Kiểm tra port www-ssl và firewall.")
        } catch (e: javax.net.ssl.SSLProtocolException) {
            McmResult.Failure("TLS_PROTOCOL", "Cổng $port không phản hồi đúng giao thức TLS. Với RouterOS 7, kiểm tra dịch vụ www-ssl, chứng chỉ và cổng HTTPS; không dùng cổng www/HTTP.")
        } catch (e: javax.net.ssl.SSLHandshakeException) {
            when {
                TlsErrorClassifier.isFingerprintMismatch(e) -> McmResult.Failure(
                    "TLS_FINGERPRINT_MISMATCH",
                    "SHA-256 fingerprint không khớp chứng chỉ hiện tại của router. Kiểm tra lại domain, port và chứng chỉ."
                )
                TlsErrorClassifier.isProtocolMismatch(e) -> McmResult.Failure(
                    "TLS_PROTOCOL",
                    "Cổng $port không trả lời HTTPS/TLS đúng chuẩn. Kiểm tra www-ssl, port NAT và không dùng cổng HTTP."
                )
                else -> McmResult.Failure(
                    "TLS_HANDSHAKE",
                    "TLS handshake thất bại. Kiểm tra chứng chỉ router, ngày giờ thiết bị, cấu hình TLS và dịch vụ www-ssl."
                )
            }
        } catch (e: javax.net.ssl.SSLException) {
            val text = e.message.orEmpty()
            if (text.contains("unsupported", true) || text.contains("unrecognized SSL message", true)) {
                McmResult.Failure("TLS_PROTOCOL", "Cổng $port không trả lời HTTPS/TLS. Kiểm tra dịch vụ www-ssl và port trên MikroTik; cổng www là HTTP và không thể dùng cho REST HTTPS.")
            } else {
                McmResult.Failure("TLS", "Kết nối TLS bị lỗi: ${text.ifBlank { "không rõ nguyên nhân" }}")
            }
        } catch (e: Exception) {
            McmResult.Failure("NETWORK", e.message ?: "Không thể kết nối router.")
        }
    }

    companion object {
        fun normalizePin(value: String): String {
            val candidate = value.trim().substringAfterLast('=', value.trim())
            val pin = candidate.replace(Regex("[:\\s]"), "").uppercase()
            require(pin.matches(Regex("[A-F0-9]{64}"))) {
                "SHA-256 fingerprint phải gồm đúng 64 ký tự hex (có thể ngăn cách bằng dấu hai chấm)."
            }
            return pin
        }

        fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256")
            .digest(bytes).joinToString("") { "%02X".format(it.toInt() and 0xFF) }
    }
}
