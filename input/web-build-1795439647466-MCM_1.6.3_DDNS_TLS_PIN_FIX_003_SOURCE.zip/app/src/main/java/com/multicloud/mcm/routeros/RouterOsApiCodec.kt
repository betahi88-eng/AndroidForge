package com.multicloud.mcm.routeros

import java.io.DataInputStream
import java.io.DataOutputStream
import java.security.MessageDigest
import java.util.Locale

/** Binary word framing used by the RouterOS API protocol. */
internal object RouterOsApiCodec {
    private const val MAX_WORD_LENGTH = 16 * 1024 * 1024

    fun writeSentence(output: DataOutputStream, words: List<String>) {
        words.forEach { word ->
            val bytes = word.toByteArray(Charsets.UTF_8)
            writeLength(output, bytes.size)
            output.write(bytes)
        }
        output.writeByte(0)
        output.flush()
    }

    fun readSentence(input: DataInputStream): List<String> {
        val words = mutableListOf<String>()
        while (true) {
            val length = readLength(input)
            if (length == 0) return words
            require(length <= MAX_WORD_LENGTH) { "RouterOS API word exceeds safety limit" }
            val bytes = ByteArray(length)
            input.readFully(bytes)
            words.add(bytes.toString(Charsets.UTF_8))
        }
    }

    fun readUntilTerminal(input: DataInputStream): List<String> {
        val all = mutableListOf<String>()
        repeat(16) {
            val sentence = readSentence(input)
            all.addAll(sentence)
            if (sentence.firstOrNull() in setOf("!done", "!trap", "!fatal", "!empty")) return all
        }
        throw IllegalStateException("RouterOS API response did not terminate")
    }

    fun parseAttributes(words: List<String>): Map<String, String> = buildMap {
        words.forEach { word -> parseAttribute(word)?.let { (key, value) -> put(key, value) } }
    }


    fun isCredentialRejected(reply: List<String>): Boolean {
        if (reply.none { it == "!trap" || it == "!fatal" }) return false
        val message = reply.asSequence()
            .mapNotNull { parseAttribute(it)?.takeIf { pair -> pair.first == "message" }?.second }
            .joinToString(" ")
            .lowercase(Locale.ROOT)
        return listOf(
            "invalid user name or password",
            "invalid username or password",
            "invalid user name",
            "invalid username",
            "invalid password",
            "wrong username",
            "wrong password",
            "login failure",
            "authentication failed",
            "not logged in"
        ).any(message::contains)
    }

    fun responseMessage(reply: List<String>): String = reply.asSequence()
        .mapNotNull { parseAttribute(it)?.takeIf { pair -> pair.first == "message" }?.second }
        .firstOrNull()
        .orEmpty()

    fun parseAttribute(word: String): Pair<String, String>? {
        if (!word.startsWith("=")) return null
        val separator = word.indexOf('=', startIndex = 1)
        if (separator < 2) return null
        return word.substring(1, separator) to word.substring(separator + 1)
    }

    fun legacyLoginResponse(secret: String, challengeHex: String): String {
        require(challengeHex.length % 2 == 0 && challengeHex.matches(Regex("[A-Fa-f0-9]+"))) {
            "Invalid RouterOS legacy challenge"
        }
        val challenge = challengeHex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
        val payload = byteArrayOf(0) + secret.toByteArray(Charsets.UTF_8) + challenge
        val digest = MessageDigest.getInstance("MD5").digest(payload)
        return "00" + digest.joinToString("") {
            "%02x".format(Locale.ROOT, it.toInt() and 0xFF)
        }
    }

    private fun writeLength(output: DataOutputStream, length: Int) {
        require(length in 0..MAX_WORD_LENGTH)
        when {
            length < 0x80 -> output.writeByte(length)
            length < 0x4000 -> {
                output.writeByte((length shr 8) or 0x80)
                output.writeByte(length)
            }
            length < 0x200000 -> {
                output.writeByte((length shr 16) or 0xC0)
                output.writeByte(length shr 8)
                output.writeByte(length)
            }
            length < 0x10000000 -> {
                output.writeByte((length shr 24) or 0xE0)
                output.writeByte(length shr 16)
                output.writeByte(length shr 8)
                output.writeByte(length)
            }
            else -> {
                output.writeByte(0xF0)
                output.writeInt(length)
            }
        }
    }

    private fun readLength(input: DataInputStream): Int {
        val first = input.readUnsignedByte()
        return when {
            first and 0x80 == 0 -> first
            first and 0xC0 == 0x80 -> ((first and 0x3F) shl 8) or input.readUnsignedByte()
            first and 0xE0 == 0xC0 -> ((first and 0x1F) shl 16) or
                (input.readUnsignedByte() shl 8) or input.readUnsignedByte()
            first and 0xF0 == 0xE0 -> ((first and 0x0F) shl 24) or
                (input.readUnsignedByte() shl 16) or (input.readUnsignedByte() shl 8) or input.readUnsignedByte()
            first == 0xF0 -> input.readInt().also { require(it >= 0) }
            else -> throw IllegalStateException("Unsupported RouterOS API control byte: $first")
        }
    }
}
