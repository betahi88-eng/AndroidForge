package com.multicloud.mcm

import com.multicloud.mcm.data.McmDatabase
import com.multicloud.mcm.data.RouterEntity
import androidx.room.withTransaction
import com.multicloud.mcm.security.SecureCredentialStore
import com.multicloud.mcm.security.TlsFingerprintInspector
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Owns multi-domain router profiles. Every profile has an independent endpoint and credential. */
class McmRouterProfileService(
    private val database: McmDatabase,
    private val credentialStore: SecureCredentialStore
) {
    suspend fun listRouters(): JSONArray {
        val result = JSONArray()
        database.routerDao().getAll().forEach { result.put(it.toPublicJson()) }
        return result
    }

    suspend fun inspectTls(host: String, port: Int): String =
        TlsFingerprintInspector.inspect(RouterHostValidator.normalize(host), port)

    suspend fun findByHost(rawHost: String): RouterEntity? {
        val normalized = RouterHostValidator.normalize(rawHost)
        return database.routerDao().getAll().firstOrNull { stored ->
            runCatching { RouterHostValidator.normalize(stored.host) == normalized }.getOrDefault(false)
        }
    }

    suspend fun connectionLogs(routerId: String, limit: Int = 50): JSONArray {
        val output = JSONArray()
        database.connectionAttemptLogDao().recent(routerId, limit.coerceIn(1, 200)).forEach { row ->
            output.put(JSONObject()
                .put("id", row.id)
                .put("attemptedAt", row.attemptedAtEpochMs)
                .put("durationMs", row.durationMs)
                .put("dnsResolver", row.dnsResolver ?: JSONObject.NULL)
                .put("resolvedIps", JSONArray(row.resolvedIps))
                .put("restResult", row.restResult)
                .put("apiSslResult", row.apiSslResult)
                .put("restProbeDetails", JSONObject(row.restProbeDetails))
                .put("apiSslProbeDetails", JSONObject(row.apiSslProbeDetails))
                .put("restAuthDurationMs", row.restAuthDurationMs)
                .put("apiSslAuthDurationMs", row.apiSslAuthDurationMs)
                .put("selectedProtocol", row.selectedProtocol ?: JSONObject.NULL)
                .put("finalState", row.finalState)
                .put("detail", row.detail ?: JSONObject.NULL))
        }
        return output
    }

    /** Create or update. A blank password during edit preserves the previously encrypted secret. */
    suspend fun saveRouter(payloadJson: String): String {
        val payload = JSONObject(payloadJson)
        val id = payload.optString("id").takeIf(String::isNotBlank)
        val requestedHost = payload.optString("host").takeIf(String::isNotBlank)?.let(RouterHostValidator::normalize)
        val existing = when {
            id != null -> database.routerDao().getById(id)
                ?: throw IllegalArgumentException("Không tìm thấy router cần sửa.")
            requestedHost != null -> database.routerDao().getAll().firstOrNull { stored ->
                runCatching { RouterHostValidator.normalize(stored.host) == requestedHost }.getOrDefault(false)
            }
            else -> null
        }

        val name = payload.getString("name").trim()
        val siteName = payload.optString("siteName", "Mặc định").trim().ifBlank { "Mặc định" }
        val host = RouterHostValidator.normalize(payload.getString("host"))
        val major = payload.getInt("routerOsMajor")
        val serviceMode = RouterServiceMode.fromUserInput(payload.optString("connectionMode", "AUTO"))
        serviceMode.resolve(major) // Validate the selected protocol against the selected RouterOS family.
        val port = payload.getInt("port")
        val username = payload.getString("username").trim()
        val password = payload.optString("password")
        val pin = RouterOs7Client.normalizePin(payload.getString("tlsSha256Pin"))

        require(name.isNotBlank() && name.length <= 64) { "Tên router phải có từ 1 đến 64 ký tự." }
        require(siteName.length <= 64) { "Tên Cloud/địa điểm tối đa 64 ký tự." }
        require(major == 6 || major == 7) { "Chỉ hỗ trợ RouterOS 6 hoặc 7." }
        require(port in 1..65535 && username.isNotBlank()) { "Port phải là số nguyên từ 1 đến 65535 và username không được để trống." }
        require(existing != null || password.isNotEmpty()) { "Password không được để trống khi thêm router." }
        if (existing != null && password.isEmpty()) {
            require(credentialStore.get(existing.credentialAlias) != null) {
                "Không đọc được mật khẩu đã lưu. Hãy nhập lại mật khẩu router trước khi cập nhật."
            }
        }

        val routerId = existing?.id ?: UUID.randomUUID().toString()
        val replaceCredential = password.isNotEmpty()
        val previousAlias = existing?.credentialAlias
        val alias = when {
            existing == null -> "mcm_credential_${routerId}_${UUID.randomUUID()}"
            replaceCredential -> "mcm_credential_${routerId}_${UUID.randomUUID()}"
            else -> existing.credentialAlias
        }

        // Write a rotated secret under a new alias before committing the profile. If Room fails,
        // the existing profile and its old encrypted secret remain untouched.
        if (replaceCredential) credentialStore.put(alias, password)
        try {
            database.routerDao().upsert(
                RouterEntity(
                    id = routerId,
                    name = name,
                    siteName = siteName,
                    host = host,
                    port = port,
                    routerOsMajor = major,
                    username = username,
                    credentialAlias = alias,
                    tlsSha256Pin = pin,
                    createdAtEpochMs = existing?.createdAtEpochMs ?: System.currentTimeMillis(),
                    lastSeenAtEpochMs = existing?.lastSeenAtEpochMs,
                    lastStatus = payload.optString("lastStatus").takeIf(String::isNotBlank) ?: existing?.lastStatus ?: "UNKNOWN",
                    lastErrorCode = existing?.lastErrorCode,
                    lastErrorMessage = existing?.lastErrorMessage,
                    lastCheckedAtEpochMs = existing?.lastCheckedAtEpochMs,
                    connectionMode = serviceMode.storageValue,
                    lastResolvedIp = payload.optString("lastResolvedIp").takeIf(String::isNotBlank) ?: existing?.lastResolvedIp,
                    dnsResolver = payload.optString("dnsResolver").takeIf(String::isNotBlank) ?: existing?.dnsResolver,
                    fallbackAvailable = payload.optBoolean("fallbackAvailable", existing?.fallbackAvailable ?: false),
                    routerOsVersion = payload.optString("routerOsVersion").takeIf(String::isNotBlank) ?: existing?.routerOsVersion,
                    accessLevel = payload.optString("accessLevel").takeIf(String::isNotBlank) ?: existing?.accessLevel ?: "UNKNOWN",
                    lastConnectionLatencyMs = payload.optLong("lastConnectionLatencyMs").takeIf { it > 0 } ?: existing?.lastConnectionLatencyMs,
                    tlsPinConfirmedAtEpochMs = if (payload.optBoolean("tlsPinConfirmed", false)) System.currentTimeMillis() else existing?.tlsPinConfirmedAtEpochMs
                )
            )
        } catch (error: Exception) {
            if (replaceCredential) credentialStore.remove(alias)
            throw error
        }
        if (previousAlias != null && previousAlias != alias) {
            runCatching { credentialStore.remove(previousAlias) }
        }
        return routerId
    }

    suspend fun removeRouter(routerId: String) {
        val router = database.routerDao().getById(routerId)
            ?: throw IllegalArgumentException("Không tìm thấy router.")
        database.withTransaction {
            database.routerDao().delete(routerId)
            database.metricDao().deleteForRouter(routerId)
            database.interfaceCounterDao().deleteForRouter(routerId)
            database.connectionAttemptLogDao().deleteForRouter(routerId)
        }
        runCatching { credentialStore.remove(router.credentialAlias) }
    }

    private fun RouterEntity.toPublicJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("name", name)
        .put("siteName", siteName)
        .put("host", host)
        .put("endpointKind", RouterHostValidator.endpointKind(host))
        .put("port", port)
        .put("routerOsMajor", routerOsMajor)
        .put("connectionMode", connectionMode)
        .put("lastResolvedIp", lastResolvedIp ?: JSONObject.NULL)
        .put("dnsResolver", dnsResolver ?: JSONObject.NULL)
        .put("fallbackAvailable", fallbackAvailable)
        .put("routerOsVersion", routerOsVersion ?: JSONObject.NULL)
        .put("accessLevel", accessLevel)
        .put("lastConnectionLatencyMs", lastConnectionLatencyMs ?: JSONObject.NULL)
        .put("tlsPinConfirmedAt", tlsPinConfirmedAtEpochMs ?: JSONObject.NULL)
        .put("username", username)
        .put("tlsSha256Pin", tlsSha256Pin)
        .put("lastSeenAt", lastSeenAtEpochMs ?: JSONObject.NULL)
        .put("lastStatus", lastStatus)
        .put("lastErrorCode", lastErrorCode ?: JSONObject.NULL)
        .put("lastErrorMessage", lastErrorMessage ?: JSONObject.NULL)
        .put("lastCheckedAt", lastCheckedAtEpochMs ?: JSONObject.NULL)


}