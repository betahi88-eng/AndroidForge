package com.multicloud.mcm

/** RouterOS management service used by MCM. WinBox is intentionally not an API transport. */
enum class RouterServiceMode(val storageValue: String) {
    AUTO("AUTO"),
    REST_HTTPS("REST_HTTPS"),
    API_SSL("API_SSL");

    fun resolve(routerOsMajor: Int): RouterTransport {
        require(routerOsMajor == 6 || routerOsMajor == 7) { "Chỉ hỗ trợ RouterOS 6 hoặc 7." }
        return when (this) {
            AUTO -> if (routerOsMajor == 7) RouterTransport.REST_HTTPS else RouterTransport.API_SSL
            REST_HTTPS -> {
                require(routerOsMajor == 7) { "REST HTTPS yêu cầu RouterOS 7 trở lên; hãy chọn API-SSL cho RouterOS 6." }
                RouterTransport.REST_HTTPS
            }
            API_SSL -> RouterTransport.API_SSL
        }
    }

    fun suggestedPort(routerOsMajor: Int): Int = resolve(routerOsMajor).port

    /** Select only a branch that passed authenticated READ_CHECK (or authenticated limited read). */
    fun selectAuthenticatedTransport(
        routerOsMajor: Int,
        restAuthenticated: Boolean,
        apiSslAuthenticated: Boolean
    ): RouterTransport? {
        require(routerOsMajor == 6 || routerOsMajor == 7) { "Chỉ hỗ trợ RouterOS 6 hoặc 7." }
        return when (this) {
            AUTO -> {
                val preferred = if (routerOsMajor == 7) RouterTransport.REST_HTTPS else RouterTransport.API_SSL
                val alternate = if (preferred == RouterTransport.REST_HTTPS) RouterTransport.API_SSL else RouterTransport.REST_HTTPS
                fun passed(transport: RouterTransport) = when (transport) {
                    RouterTransport.REST_HTTPS -> restAuthenticated
                    RouterTransport.API_SSL -> apiSslAuthenticated
                }
                when {
                    passed(preferred) -> preferred
                    passed(alternate) -> alternate
                    else -> null
                }
            }
            REST_HTTPS -> resolve(routerOsMajor).takeIf { restAuthenticated }
            API_SSL -> resolve(routerOsMajor).takeIf { apiSslAuthenticated }
        }
    }

    /**
     * Build WAN probe endpoints. AUTO with no custom port probes the conventional
     * REST/API-SSL ports in parallel. AUTO with a custom port probes both protocols
     * on that same externally forwarded port. Explicit modes probe only that service.
     * A zero port means the user left the WAN port blank.
     */
    fun probePorts(requestedPort: Int): RouterProbePorts {
        require(requestedPort == 0 || requestedPort in 1..65535) {
            "Port phải là số nguyên từ 1 đến 65535."
        }
        return when (this) {
            AUTO -> RouterProbePorts(
                restPort = if (requestedPort == 0) RouterTransport.REST_HTTPS.port else requestedPort,
                apiSslPort = if (requestedPort == 0) RouterTransport.API_SSL.port else requestedPort
            )
            REST_HTTPS -> RouterProbePorts(requestedPort.takeIf { it > 0 } ?: RouterTransport.REST_HTTPS.port, null)
            API_SSL -> RouterProbePorts(null, requestedPort.takeIf { it > 0 } ?: RouterTransport.API_SSL.port)
        }
    }

    companion object {
        fun fromStorage(value: String?): RouterServiceMode =
            entries.firstOrNull { it.storageValue.equals(value?.trim(), ignoreCase = true) } ?: AUTO

        fun fromUserInput(value: String?): RouterServiceMode =
            entries.firstOrNull { it.storageValue.equals(value?.trim(), ignoreCase = true) }
                ?: throw IllegalArgumentException("Chọn giao thức kết nối hợp lệ: Tự động, REST HTTPS hoặc API-SSL.")
    }
}

data class RouterProbePorts(val restPort: Int?, val apiSslPort: Int?)

enum class RouterTransport(val port: Int) { REST_HTTPS(443), API_SSL(8729) }
