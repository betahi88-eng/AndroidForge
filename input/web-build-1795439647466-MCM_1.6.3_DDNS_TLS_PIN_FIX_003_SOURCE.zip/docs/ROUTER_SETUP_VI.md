# Hướng dẫn kết nối MCM trực tiếp qua MikroTik Cloud DDNS

## 1. Cấu hình hồ sơ trên Android

Mỗi cửa hàng/router có các giá trị độc lập:

- Host: `xxxx.sn.mynetname.net`, DDNS/domain khác hoặc IP. Không nhập `https://`, port hay path vào ô Host.
- RouterOS major: 6 hoặc 7.
- Service protocol: `AUTO`, `REST HTTPS`, hoặc `RouterOS API-SSL`.
- WAN port: số 1–65535 mà điện thoại thực sự truy cập. Nếu có NAT/port-forward, đây là port phía WAN/ngoài.
- Username/password read-only riêng.
- SHA-256 fingerprint của chứng chỉ TLS máy chủ tại đúng host + WAN port.

`AUTO` gợi ý ROS7 → REST HTTPS/443 và ROS6 → API-SSL/8729. MCM cho phép người dùng đổi port theo từng hồ sơ. Khi thay RouterOS/service, app chỉ thay số gợi ý nếu port chưa được chỉnh thủ công; port tùy chỉnh đã lưu sẽ được giữ nguyên.

## 2. Quan trọng về MikroTik Cloud DDNS

MikroTik IP Cloud DDNS cập nhật hostname về địa chỉ public mà router báo lên. DDNS không mở port quản trị, không tạo NAT, không vượt CGNAT/double NAT và không cấp relay. Muốn truy cập trực tiếp, endpoint phải có đường inbound tới đúng dịch vụ và firewall/NAT phải cho phép nguồn được ủy quyền. MCM không sử dụng VPN/WireGuard/VPS/relay và không tự thay cấu hình router.

## 3. Chọn đúng service protocol

### REST HTTPS / www-ssl

- Chỉ hỗ trợ RouterOS 7 trong MCM.
- Bật `www-ssl` và gán certificate TLS. MCM xác thực bằng SHA-256 pin đã được người dùng đối chiếu; chứng chỉ tự ký không bắt buộc CN/SAN trùng DDNS, nhưng fingerprint phải đúng tuyệt đối.
- Port mặc định đề xuất 443; nhập port WAN tùy chỉnh nếu endpoint/NAT dùng port khác.
- MCM đọc REST qua HTTPS; không dùng dịch vụ `www` HTTP.

### RouterOS API-SSL / api-ssl

- Hỗ trợ RouterOS 6 và 7.
- Bật `api-ssl` và gán certificate TLS. MCM xác thực bằng SHA-256 pin đã được người dùng đối chiếu; chứng chỉ tự ký không bắt buộc CN/SAN trùng DDNS, nhưng fingerprint phải đúng tuyệt đối.
- Port mặc định đề xuất 8729; nhập port WAN tùy chỉnh nếu endpoint/NAT dùng port khác.
- MCM sử dụng giao thức RouterOS API native qua TLS, không phải WinBox.

### Automatic

- RouterOS 7 → REST HTTPS.
- RouterOS 6 → API-SSL.

Không có plaintext API hoặc HTTP fallback.

## 4. WinBox TCP 8291 không phải API

WinBox Android có thể đăng nhập bằng `hostname:8291`, nhưng WinBox dùng giao thức riêng. Điều này chỉ chứng minh dịch vụ WinBox nghe trên 8291. MCM không triển khai giao thức WinBox và không thể đọc dữ liệu router bằng cách chỉ đổi số port sang 8291.

Có thể nhập 8291 trong MCM **chỉ khi** cổng public đó đang phục vụ REST HTTPS/API-SSL đã chọn hoặc được NAT chuyển tiếp đến đúng listener. Nếu 8291 vẫn là WinBox service, TLS inspection/API login của MCM sẽ thất bại và đó là kết quả đúng.

## 5. Port WAN và NAT

- Nếu `www-ssl` nghe nội bộ 443 nhưng modem/NAT công bố 8443, nhập 8443 trong MCM; thiết bị trước router phải forward TCP 8443 → đúng IP MikroTik:443.
- Nếu `api-ssl` nghe nội bộ 8729 nhưng port ngoài là 18729, nhập 18729; NAT phải forward 18729 → router:8729.
- MCM không tự thêm firewall rule, bật service hoặc cấu hình port-forward.

Dùng firewall source restriction và user read-only. Không mở quản trị cho toàn Internet nếu chưa kiểm soát nguồn.

## 6. Lấy và xác minh fingerprint

1. Nhập host và đúng WAN port.
2. Nhấn **Kiểm tra DNS / TCP**. TCP open chỉ cho biết có socket trả lời, chưa xác nhận TLS hoặc giao thức.
3. Nhấn **Đọc fingerprint TLS** tại đúng endpoint.
4. Đối chiếu chuỗi SHA-256 64 ký tự với leaf certificate được quản trị viên xác minh độc lập qua WinBox/console/certificate export hoặc kênh tin cậy.
5. Chỉ lưu khi fingerprint khớp. Pin sai phải bị từ chối.

## 7. Chẩn đoán

| Mã | Ý nghĩa / kiểm tra |
|---|---|
| `DNS_FAILED` | Cloud DDNS/domain chưa phân giải hoặc DNS chưa cập nhật |
| `TCP_TIMEOUT` | IP đã phân giải nhưng cổng WAN không phản hồi; kiểm tra firewall, NAT, ISP, CGNAT và port mapping |
| `CONNECT_REFUSED` | Có phản hồi từ đích nhưng không có listener phù hợp hoặc cổng bị reject |
| `TLS_PROTOCOL` | Port không phải dịch vụ TLS phù hợp; có thể đã nhập cổng WinBox/HTTP hoặc NAT nhầm dịch vụ |
| `TLS_FINGERPRINT_MISMATCH` | Chứng chỉ tại endpoint khác pin đã lưu |
| `AUTH` | Sai username/password hoặc login bị RouterOS từ chối |
| `PERMISSION` | User thiếu quyền đọc |

Không tắt certificate pinning, không chuyển sang HTTP và không tự đổi giao thức để né lỗi. Nếu DNS thành công nhưng TCP timeout thì chưa đến bước fingerprint/TLS.

## 8. Kiểm tra WAN động

- Xác nhận `dns-name` trong `/ip cloud print` đúng với hostname MCM.
- Từ mạng di động bên ngoài cửa hàng, xác nhận hostname phân giải về public IP hiện tại.
- Đổi WAN IP: đợi Cloud DDNS cập nhật, sau đó refresh lại hồ sơ.
- Nếu router nằm sau modem/NAT, đối chiếu WAN modem và port-forward.
- Nếu CGNAT hoặc ISP chặn inbound, direct-DDNS không thể hoạt động cho đến khi có đường public inbound phù hợp.
