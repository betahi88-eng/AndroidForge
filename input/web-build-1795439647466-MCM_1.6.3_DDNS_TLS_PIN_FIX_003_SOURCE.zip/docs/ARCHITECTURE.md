# MCM 1.6.3 — Direct DDNS, selectable service and custom port

## Product boundary

MCM Android connects directly to each router through that router's MikroTik Cloud DDNS hostname or another configured DDNS/domain/IP. There is no MCM backend, VPS, VPN, WireGuard, relay, router-side agent or tunnel provisioning. Profiles, secrets and history remain local on Android.

```text
Android MCM
  ├─ local multi-store/router profiles
  ├─ Room database + Android Keystore credentials
  └─ direct per-profile endpoint
       ├─ DNS: <router>.sn.mynetname.net
       ├─ user-entered WAN port (1..65535)
       ├─ selected service adapter
       │    ├─ REST HTTPS / www-ssl (RouterOS 7)
       │    └─ RouterOS API-SSL / api-ssl (RouterOS 6 or 7)
       └─ leaf certificate SHA-256 pin + RouterOS authentication
```

## Endpoint data model

Each profile independently stores `host`, `port`, `routerOsMajor`, `connectionMode`, `username`, `credentialAlias` and `tlsSha256Pin`. The port is the external/WAN-facing port entered on the phone. When upstream NAT changes the public port to an internal port, the profile still stores the public port; the router/modem must map it to the correct service listener.

The `connectionMode` values are:
- `AUTO`: RouterOS 7 → REST HTTPS; RouterOS 6 → API-SSL.
- `REST_HTTPS`: REST over `www-ssl`; requires RouterOS 7.
- `API_SSL`: native RouterOS API over TLS; supports RouterOS 6 and 7.

The service choice is independent of the numeric WAN port. Suggested values 443 and 8729 are defaults, not hard-coded runtime ports. A manual port remains unchanged when the RouterOS/service selector changes. When editing an existing profile, the already saved port is always treated as user-owned, even if it happens to equal a standard default. The migration from Room v3 to v4 adds `connectionMode='AUTO'` to existing profiles and preserves all saved endpoint and history data.

## WinBox protocol boundary

WinBox TCP 8291 is not REST HTTPS or RouterOS API-SSL. MCM does not implement the WinBox protocol. Reaching a router using WinBox proves only that the WinBox service is reachable. An MCM profile may use port 8291 only when the endpoint on that port actually presents the selected REST/API-SSL TLS service (for example, due to an explicit service/NAT mapping). Otherwise TLS/protocol validation must fail rather than pretending it can read RouterOS data.

## WAN dynamic address behavior

- Keep the hostname as the profile identity; do not save a resolved WAN IP as the permanent host.
- Resolve DNS again on each new connection so changed WAN addresses can be followed after DDNS updates.
- A DNS result or open TCP socket alone never marks the router ONLINE.
- Preserve distinct DNS, TCP, TLS, fingerprint, AUTH, PERMISSION and RouterOS data errors.

## Required network reachability

MikroTik IP Cloud DDNS maps a hostname to the public address reported by the router; it does not open a service port, create NAT, bypass CGNAT/double NAT or provide a relay. The configured WAN port must be reachable from the phone and terminate at the selected `www-ssl` or `api-ssl` listener. If CGNAT or ISP inbound filtering prevents that, a port edit alone cannot fix it. This product boundary intentionally excludes VPN/relay workarounds.

## TLS and credentials

- Each profile has its own leaf certificate SHA-256 pin.
- Fingerprint reading is an untrusted capture; users must verify independently before saving.
- Every session verifies the configured pin. Pin mismatch fails closed.
- Passwords are encrypted using AES-256-GCM with a key in Android Keystore. Credential rotation writes a new alias before committing the profile and removes the old alias only after the database update succeeds.
- Never log passwords, authorization headers, or API sentence secrets.

## Monitoring contract

`/system/resource` success establishes core reachability. Optional snapshots fail independently and may produce PARTIAL. Refresh All is sequential. Background checks use the same stored service mode and port as foreground checks.

## Explicit exclusions

No MCM server/VPS, VPN/WireGuard/Back To Home, relay, router-side agent, WinBox protocol client, plaintext API, automatic port opening, automatic firewall change, router configuration writes or cloud synchronization. LAN MNDP discovery is a local convenience only.
