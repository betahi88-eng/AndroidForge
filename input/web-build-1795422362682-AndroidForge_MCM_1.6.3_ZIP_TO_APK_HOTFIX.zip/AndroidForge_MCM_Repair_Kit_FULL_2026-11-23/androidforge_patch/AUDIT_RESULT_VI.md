# Kết quả kiểm toán bổ sung – ZIP → APK

## Bằng chứng log mới
Cả ba lệnh Gradle chạy trong thư mục `AndroidForge_MCM_Repair_Kit_FULL_2026-11-23` không có Gradle settings/build root. Root cause là sai ZIP/project root, không phải lỗi Kotlin compile.

## Sửa chữa
Đã bổ sung `resolve_mcm_source.py` và thay `extract_zip.py` bằng extractor có kiểm tra root. Workflow patcher chèn bước resolve chính xác MCM source trước extraction, dùng source path/hash đã resolve xuyên suốt validate/provenance/collector, đặt mặc định profile MCM native.

## Regression tests
25/25 PASS. Bao gồm resolver direct/nested ZIP, từ chối wrapper không có source dẫn xuất, strict Gradle root detection, chặn ZIP path traversal, workflow fixture.

## Chưa được xác minh
Chưa áp dụng vào repository AndroidForge thật, chưa chạy GitHub Actions thật, chưa có Gradle/JDK17/SDK35 để build, chưa có APK. Không được ghi nhận build PASS.
