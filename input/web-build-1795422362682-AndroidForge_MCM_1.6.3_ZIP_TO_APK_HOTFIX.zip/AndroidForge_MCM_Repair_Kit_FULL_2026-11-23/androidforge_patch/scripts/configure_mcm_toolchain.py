#!/usr/bin/env python3
"""Configure the known MCM native Gradle toolchain without mutating source files."""
from __future__ import annotations

import json
import argparse
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path


def run(command: list[str]) -> str:
    completed = subprocess.run(command, text=True, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, check=True, timeout=30)
    return completed.stdout


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    project_root = Path(args.root).resolve()
    if not project_root.is_dir():
        raise RuntimeError(f"MCM project root does not exist: {project_root}")

    if not shutil.which("java"):
        raise RuntimeError("JDK 17 is required but java is not on PATH")
    if not shutil.which("gradle"):
        raise RuntimeError("Standalone Gradle is required but gradle is not on PATH")

    java_output = run(["java", "-version"])
    java_match = re.search(r'version\s+"?(\d+)', java_output)
    if not java_match or java_match.group(1) != "17":
        raise RuntimeError("MCM requires JDK 17; detected Java output: " + java_output.strip())

    gradle_output = run(["gradle", "--version"])
    gradle_match = re.search(r"(?m)^Gradle\s+(\d+)\.(\d+)(?:\.(\d+))?\s*$", gradle_output)
    if not gradle_match:
        raise RuntimeError("Cannot determine the installed Gradle version")
    gradle_version = ".".join(part for part in gradle_match.groups() if part is not None)
    gradle_tuple = tuple(int(part) for part in gradle_match.groups() if part is not None)
    if gradle_tuple != (8, 7):
        raise RuntimeError(
            f"MCM toolchain is pinned to exactly Gradle 8.7; found {gradle_version}"
        )

    sdk_root = os.environ.get("ANDROID_SDK_ROOT") or os.environ.get("ANDROID_HOME")
    if not sdk_root:
        raise RuntimeError("Android SDK is required; set ANDROID_SDK_ROOT or ANDROID_HOME")
    sdk_path = Path(sdk_root).resolve()
    android_jar = sdk_path / "platforms" / "android-35" / "android.jar"
    if not android_jar.is_file():
        raise RuntimeError(f"Pinned Android SDK Platform 35 is missing: {android_jar}")
    build_tools = sdk_path / "build-tools"
    if not build_tools.is_dir() or not any(
        (candidate / "aapt").is_file() for candidate in build_tools.iterdir() if candidate.is_dir()
    ):
        raise RuntimeError(f"Android SDK Build-Tools with aapt are missing under {build_tools}")

    payload = {
        "project_type": "gradle",
        "project_root": str(project_root),
        "jdk_version": "17",
        "gradle_version": gradle_version,
        "android_sdk_platform": "35",
        "android_sdk_root": str(sdk_path),
        "agp_version": "8.6.1",
        "kotlin_version": "2.0.21",
        "use_gradle_wrapper": False,
        "use_wrapper": False,
        "needs_flutter": False,
        "needs_ndk": False,
        "needs_gradle": True,
        "prep_commands": [],
        "build_commands": [
            ["gradle", "--no-daemon", "--no-build-cache", "--stacktrace", ":app:clean"],
            [
                "gradle", "--no-daemon", "--no-build-cache", "--rerun-tasks", "--stacktrace",
                ":app:testDebugUnitTest", ":app:lintDebug", ":app:assembleDebug",
            ],
        ],
        "source_mutation": False,
    }

    output_path = Path(args.output)
    output_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    github_output = os.environ.get("GITHUB_OUTPUT")
    if github_output:
        with open(github_output, "a", encoding="utf-8") as stream:
            for key, value in {
                "jdk_version": "17",
                "gradle_version": gradle_version,
                "android_sdk_platform": "35",
                "agp_version": "8.6.1",
                "kotlin_version": "2.0.21",
                "needs_flutter": "false",
                "needs_ndk": "false",
                "needs_gradle": "true",
                "use_wrapper": "false",
            }.items():
                stream.write(f"{key}={value}\n")
    print(json.dumps(payload, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"MCM TOOLCHAIN CONFIGURATION FAILED: {error}", file=sys.stderr)
        raise SystemExit(2)
