#!/usr/bin/env python3
"""Validate extracted source identity and bind it to the selected ZIP digest.

Generic projects remain supported. MCM can be explicitly required with
--profile mcm-native; that mode refuses Flutter, mixed workspaces, stale
identity markers, and old nullable parser source.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
from pathlib import Path


# This repair package intentionally pins one known source archive so an old or
# silently altered MCM ZIP cannot pass as the intended 1.6.3 build input.
EXPECTED_MCM_163_SHA256 = "6b2f810a430f69d172a81dedafb0f3729e1c5c6f3170db3367426e3c77a59f45"
EXPECTED_MCM_BASE_SHA256 = "6313e1b28d2e7fa18fd56f20f8a4d91d6abf81a0027d1fe44e33e48a94ea1f0b"
EXPECTED_MCM_PATCH_ID = "MCM-1.6.3-ANDROIDFORGE-HARDENED-001"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_key_values(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip()
    return values


def gradle_value(text: str, key: str) -> str | None:
    pattern = rf"^\s*{re.escape(key)}\s*=\s*['\"]([^'\"]+)['\"]"
    match = re.search(pattern, text, re.MULTILINE)
    return match.group(1) if match else None


def gradle_integer(text: str, key: str) -> str | None:
    pattern = rf"^\s*{re.escape(key)}\s*=\s*(\d+)\b"
    match = re.search(pattern, text, re.MULTILINE)
    return match.group(1) if match else None


def is_mcm_project(root: Path) -> bool:
    identity = root / "SOURCE_IDENTITY.txt"
    app_gradle = root / "app" / "build.gradle.kts"
    if identity.is_file():
        values = parse_key_values(identity)
        return values.get("APPLICATION_ID") == "com.multicloud.mcm"
    if app_gradle.is_file():
        return 'applicationId = "com.multicloud.mcm"' in app_gradle.read_text(
            encoding="utf-8", errors="replace"
        )
    return False


def validate_mcm(root: Path) -> dict[str, str]:
    required = [
        "settings.gradle.kts",
        "build.gradle.kts",
        "gradle.properties",
        "app/build.gradle.kts",
        "app/src/main/AndroidManifest.xml",
        "SOURCE_IDENTITY.txt",
        "app/src/main/java/com/multicloud/mcm/RouterOs7Repository.kt",
        "app/src/main/java/com/multicloud/mcm/RouterOs7InterfaceParser.kt",
        "app/src/main/java/com/multicloud/mcm/RouterConnectionCoordinator.kt",
        "app/src/main/java/com/multicloud/mcm/RouterDnsResolver.kt",
        "app/src/main/java/com/multicloud/mcm/DohDnsResolver.kt",
        "app/src/main/java/com/multicloud/mcm/McmJavascriptBridge.kt",
        "app/src/main/java/com/multicloud/mcm/McmMonitoringService.kt",
        "app/src/main/java/com/multicloud/mcm/McmBackgroundWorker.kt",
        "app/src/main/java/com/multicloud/mcm/security/SecureCredentialStore.kt",
        "app/src/main/java/com/multicloud/mcm/data/McmDatabase.kt",
        "app/src/main/java/com/multicloud/mcm/security/TlsFingerprintInspector.kt",
        "app/src/main/java/com/multicloud/mcm/routeros/RouterOs6ApiClient.kt",
        "app/src/main/java/com/multicloud/mcm/routeros/RouterOsApiCodec.kt",
        "app/src/test/java/com/multicloud/mcm/RouterOs7RepositoryTest.kt",
        "app/src/test/java/com/multicloud/mcm/RouterOsApiCodecTest.kt",
        "SOURCE_PROVENANCE.json",
        "app/src/main/assets/mcm-source-provenance.json",
    ]
    missing = [name for name in required if not (root / name).is_file()]
    if missing:
        raise RuntimeError("MCM source is missing required files: " + ", ".join(missing))
    if (root / "pubspec.yaml").exists() or (root / "harmony_patched").exists():
        raise RuntimeError("MCM native Gradle source is mixed with Flutter/harmony_patched content")

    identity = parse_key_values(root / "SOURCE_IDENTITY.txt")
    gradle = (root / "app" / "build.gradle.kts").read_text(encoding="utf-8", errors="replace")
    app_id = gradle_value(gradle, "applicationId")
    version_name = gradle_value(gradle, "versionName")
    version_code = gradle_integer(gradle, "versionCode")

    expected = {
        "APPLICATION_ID": "com.multicloud.mcm",
        "PROJECT_KIND": "NATIVE_ANDROID_GRADLE_KOTLIN",
    }
    for key, value in expected.items():
        if identity.get(key) != value:
            raise RuntimeError(f"SOURCE_IDENTITY {key} mismatch: expected {value!r}, got {identity.get(key)!r}")
    if identity.get("MCM_SOURCE_ID") != "MCM-1.6.3-RECONCILED-001":
        raise RuntimeError("SOURCE_IDENTITY MCM_SOURCE_ID is not the reconciled MCM 1.6.3 baseline")
    if identity.get("VERSION_NAME") != "1.6.3" or identity.get("VERSION_CODE") != "12":
        raise RuntimeError("This AndroidForge repair is pinned to MCM 1.6.3 / versionCode 12")
    if app_id != identity["APPLICATION_ID"]:
        raise RuntimeError(f"Gradle applicationId {app_id!r} does not match source identity")
    if version_name != identity["VERSION_NAME"]:
        raise RuntimeError(f"Gradle versionName {version_name!r} does not match source identity")
    if version_code != identity["VERSION_CODE"]:
        raise RuntimeError(f"Gradle versionCode {version_code!r} does not match source identity")

    parser_file = root / "app/src/main/java/com/multicloud/mcm/RouterOs7InterfaceParser.kt"
    repository_file = root / "app/src/main/java/com/multicloud/mcm/RouterOs7Repository.kt"
    parser_text = parser_file.read_text(encoding="utf-8", errors="replace")
    repository_text = repository_file.read_text(encoding="utf-8", errors="replace")
    root_gradle = (root / "build.gradle.kts").read_text(encoding="utf-8", errors="replace")
    settings_gradle = (root / "settings.gradle.kts").read_text(encoding="utf-8", errors="replace")
    if 'readNonBlankString("type") ?: ""' not in parser_text:
        raise RuntimeError("MCM parser null-default implementation is missing or has changed")
    if 'row.stringValue("type").orEmpty()' in repository_text:
        raise RuntimeError("Old nullable interface-row expression remains in RouterOs7Repository.kt")
    if "toInterfaceSnapshotOrNull()" not in repository_text:
        raise RuntimeError("Repository does not call the extracted null-safe interface parser")
    if 'id("com.android.application") version "8.6.1" apply false' not in root_gradle:
        raise RuntimeError("Unexpected Android Gradle Plugin; expected 8.6.1")
    if 'id("org.jetbrains.kotlin.android") version "2.0.21" apply false' not in root_gradle:
        raise RuntimeError("Unexpected Kotlin Gradle plugin; expected 2.0.21")
    if 'rootProject.name = "MikroTikMultiCloudMonitor"' not in settings_gradle or 'include(":app")' not in settings_gradle:
        raise RuntimeError("Root Gradle settings do not identify the expected native :app module")
    if not (root / "app/src/main/assets/www").is_dir():
        raise RuntimeError("MCM WebView asset tree is missing")

    app_gradle_text = gradle
    if gradle_integer(app_gradle_text, "compileSdk") != "35" or gradle_integer(app_gradle_text, "minSdk") != "26":
        raise RuntimeError("MCM SDK configuration must remain compileSdk 35 / minSdk 26")
    if "version = 6" not in (root / "app/src/main/java/com/multicloud/mcm/data/McmDatabase.kt").read_text(encoding="utf-8"):
        raise RuntimeError("MCM Room schema must be version 6")
    worker = (root / "app/src/main/java/com/multicloud/mcm/McmBackgroundWorker.kt").read_text(encoding="utf-8")
    if "McmDatabase.ALL_MIGRATIONS" not in worker or 'router.accessLevel == "LIMITED"' not in worker:
        raise RuntimeError("MCM background worker is not aligned with Room v6 and READY_LIMITED")
    if "RouterDnsResolver.resolveDetailed(router.host)" not in worker or "resolvedAddresses = resolution.addresses" not in worker:
        raise RuntimeError("MCM background worker does not use the required DNS fallback and resolved address path")
    monitoring = (root / "app/src/main/java/com/multicloud/mcm/McmMonitoringService.kt").read_text(encoding="utf-8")
    if "RouterDnsResolver.resolveDetailed(router.host)" not in monitoring or "resolvedAddresses = resolution.addresses" not in monitoring:
        raise RuntimeError("MCM monitoring refresh does not use the required DNS fallback and resolved address path")
    credential_store = (root / "app/src/main/java/com/multicloud/mcm/security/SecureCredentialStore.kt").read_text(encoding="utf-8")
    if '"AES/GCM/NoPadding"' not in credential_store or '"AndroidKeyStore"' not in credential_store:
        raise RuntimeError("MCM credential storage is not backed by Android Keystore AES-GCM")
    coordinator = (root / "app/src/main/java/com/multicloud/mcm/RouterConnectionCoordinator.kt").read_text(encoding="utf-8")
    for required_timeout in ("TOTAL_CONNECTION_TIMEOUT_MS = 30_000L", "PROBE_BRANCH_TIMEOUT_MS = 10_500L", "REST_AUTH_BRANCH_TIMEOUT_MS = 8_000L", "API_AUTH_BRANCH_TIMEOUT_MS = 13_000L"):
        if required_timeout not in coordinator:
            raise RuntimeError(f"MCM connection timeout contract missing: {required_timeout}")
    if '"TLS_CHANGED"' not in coordinator or '"FIRST_TIME_PIN"' not in coordinator or '"READY_LIMITED"' not in coordinator:
        raise RuntimeError("MCM TLS confirmation or limited-read state is missing")
    client = (root / "app/src/main/java/com/multicloud/mcm/RouterOs7Client.kt").read_text(encoding="utf-8")
    if "hostnameVerifier { _, _ -> true }" in client or "object : Dns" not in client:
        raise RuntimeError("MCM REST client contains permissive TLS verification or lacks the resolved-address DNS path")
    api_client = (root / "app/src/main/java/com/multicloud/mcm/routeros/RouterOs6ApiClient.kt").read_text(encoding="utf-8")
    api_codec = (root / "app/src/main/java/com/multicloud/mcm/routeros/RouterOsApiCodec.kt").read_text(encoding="utf-8")
    if "RouterOsAuthenticationException" not in api_client or "isCredentialRejected" not in api_codec:
        raise RuntimeError("MCM API-SSL login does not distinguish credential rejection from legacy login fallback")
    profile_service = (root / "app/src/main/java/com/multicloud/mcm/McmRouterProfileService.kt").read_text(encoding="utf-8")
    if "RouterHostValidator.normalize(stored.host) == normalized" not in profile_service:
        raise RuntimeError("MCM profile lookup does not compare normalized hostnames across legacy profiles")

    provenance_path = root / "SOURCE_PROVENANCE.json"
    provenance = json.loads(provenance_path.read_text(encoding="utf-8"))
    source_asset = json.loads((root / "app/src/main/assets/mcm-source-provenance.json").read_text(encoding="utf-8"))
    for item in (provenance, source_asset):
        if item.get("source_id") != "MCM-1.6.3-RECONCILED-001":
            raise RuntimeError("MCM source provenance ID does not match")
        if item.get("patch_id") != EXPECTED_MCM_PATCH_ID:
            raise RuntimeError("MCM source provenance patch ID does not match")
        if item.get("base_source_archive_sha256", "").lower() != EXPECTED_MCM_BASE_SHA256:
            raise RuntimeError("MCM base source archive SHA-256 does not match the locked source")
    if provenance.get("application_id") != "com.multicloud.mcm" or provenance.get("version_name") != "1.6.3" or provenance.get("version_code") != 12:
        raise RuntimeError("Derived MCM provenance application/version identity mismatch")
    if provenance.get("toolchain") != {"jdk": "17", "gradle": "8.7", "agp": "8.6.1", "kotlin": "2.0.21", "android_sdk": "35"}:
        raise RuntimeError("Derived MCM provenance toolchain was changed")

    # Do not execute scripts supplied by the ZIP during preflight. Static checks
    # are performed here; Gradle executes only after source identity is accepted.
    return {
        "is_mcm": "true",
        "source_id": identity["MCM_SOURCE_ID"],
        "expected_package": identity["APPLICATION_ID"],
        "expected_version_name": identity["VERSION_NAME"],
        "expected_version_code": identity["VERSION_CODE"],
        "project_kind": identity["PROJECT_KIND"],
        "patch_id": EXPECTED_MCM_PATCH_ID,
        "base_source_sha256": EXPECTED_MCM_BASE_SHA256,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--zip", required=True)
    parser.add_argument("--zip-sha256", required=True)
    parser.add_argument("--profile", choices=["auto", "mcm-native"], default="auto")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    root = Path(args.root).resolve()
    zip_path = Path(args.zip).resolve()
    if not root.is_dir() or not zip_path.is_file():
        raise RuntimeError("Project root or acquired ZIP path does not exist")
    actual_hash = sha256_file(zip_path)
    if actual_hash.lower() != args.zip_sha256.lower():
        raise RuntimeError(
            f"Selected ZIP digest changed after acquisition: expected {args.zip_sha256}, got {actual_hash}"
        )

    detected_mcm = is_mcm_project(root)
    if args.profile == "mcm-native" and not detected_mcm:
        raise RuntimeError("MCM profile was selected, but extracted source is not com.multicloud.mcm native Gradle")
    if "mcm" in zip_path.name.casefold() and not detected_mcm:
        raise RuntimeError("ZIP filename indicates MCM, but extracted source identity is not MCM")

    if detected_mcm:
        if actual_hash.lower() != EXPECTED_MCM_163_SHA256:
            raise RuntimeError(
                "MCM source ZIP SHA-256 does not match the pinned derived MCM 1.6.3 archive: "
                f"expected {EXPECTED_MCM_163_SHA256}, got {actual_hash}"
            )
        identity = validate_mcm(root)
    else:
        identity = {
            "is_mcm": "false",
            "source_id": "",
            "expected_package": "",
            "expected_version_name": "",
            "expected_version_code": "",
            "project_kind": "GENERIC",
            "patch_id": "",
            "base_source_sha256": "",
        }

    result = {
        **identity,
        "zip_path": str(zip_path),
        "zip_name": zip_path.name,
        "zip_sha256": actual_hash,
        "project_root": str(root),
        "validation": "PASS",
    }
    Path(args.output).write_text(json.dumps(result, indent=2), encoding="utf-8")
    output_file = os.environ.get("GITHUB_OUTPUT")
    if output_file:
        with open(output_file, "a", encoding="utf-8") as stream:
            for key, value in identity.items():
                stream.write(f"{key}={value}\n")
            stream.write(f"zip_sha256={actual_hash}\n")
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"SOURCE VALIDATION FAILED: {error}", file=sys.stderr)
        raise SystemExit(2)
