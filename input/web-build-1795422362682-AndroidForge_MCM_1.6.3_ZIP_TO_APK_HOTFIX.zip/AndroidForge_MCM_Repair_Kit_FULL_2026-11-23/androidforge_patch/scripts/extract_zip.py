#!/usr/bin/env python3
"""Safe AndroidForge ZIP extraction with validated project-root detection.

Never returns the extraction directory merely because it exists. In MCM mode
it requires the exact native Gradle project identity and :app module.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
import zipfile
from pathlib import Path, PurePosixPath


def safe_extract(archive: zipfile.ZipFile, destination: Path) -> None:
    base = destination.resolve()
    for info in archive.infolist():
        raw = info.filename.replace("\\", "/")
        member = PurePosixPath(raw)
        if member.is_absolute() or any(part in ("..", "") for part in member.parts):
            raise RuntimeError(f"Unsafe ZIP member path: {info.filename}")
        mode = (info.external_attr >> 16) & 0xFFFF
        if mode and (mode & 0o170000) == 0o120000:
            raise RuntimeError(f"ZIP symlink entries are not accepted: {info.filename}")
        target = (destination / Path(*member.parts)).resolve()
        try:
            target.relative_to(base)
        except ValueError as error:
            raise RuntimeError(f"ZIP member escapes extraction root: {info.filename}") from error
        if info.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info, "r") as source, target.open("wb") as output:
                shutil.copyfileobj(source, output)


def candidate_roots(destination: Path) -> list[Path]:
    found: list[Path] = []
    for directory, dirs, files in os.walk(destination):
        dirs[:] = [d for d in dirs if d not in {".git", ".gradle", "build", ".androidforge"}]
        current = Path(directory)
        file_set = set(files)
        has_settings = bool({"settings.gradle", "settings.gradle.kts", "settings.gradle.dcl"} & file_set)
        has_build = bool({"build.gradle", "build.gradle.kts", "build.gradle.dcl"} & file_set)
        has_app = (current / "app" / "build.gradle").is_file() or (current / "app" / "build.gradle.kts").is_file()
        has_flutter = (current / "pubspec.yaml").is_file() and (
            (current / "android" / "settings.gradle").is_file()
            or (current / "android" / "settings.gradle.kts").is_file()
        )
        if (has_settings and has_build and has_app) or has_flutter:
            found.append(current.resolve())
    return sorted(set(found), key=lambda p: (len(p.parts), str(p)))


def validate_mcm_root(root: Path) -> None:
    required = [
        "settings.gradle.kts", "build.gradle.kts", "gradle.properties",
        "app/build.gradle.kts", "app/src/main/AndroidManifest.xml",
        "SOURCE_IDENTITY.txt",
    ]
    missing = [name for name in required if not (root / name).is_file()]
    if missing:
        raise RuntimeError("BUILD_STOPPED_INVALID_PROJECT: MCM project root missing " + ", ".join(missing))
    values = {}
    for line in (root / "SOURCE_IDENTITY.txt").read_text(encoding="utf-8", errors="replace").splitlines():
        if "=" in line and not line.lstrip().startswith("#"):
            key, value = line.split("=", 1)
            values[key.strip()] = value.strip()
    expected = {
        "APPLICATION_ID": "com.multicloud.mcm",
        "VERSION_NAME": "1.6.3",
        "VERSION_CODE": "12",
        "MCM_SOURCE_ID": "MCM-1.6.3-RECONCILED-001",
        "PROJECT_KIND": "NATIVE_ANDROID_GRADLE_KOTLIN",
    }
    mismatch = [f"{key}={values.get(key)!r} (expected {value!r})"
                for key, value in expected.items() if values.get(key) != value]
    if mismatch:
        raise RuntimeError("BUILD_STOPPED_INVALID_PROJECT: source identity mismatch: " + "; ".join(mismatch))
    gradle = (root / "app/build.gradle.kts").read_text(encoding="utf-8", errors="replace")
    if 'applicationId = "com.multicloud.mcm"' not in gradle or 'versionName = "1.6.3"' not in gradle or "versionCode = 12" not in gradle:
        raise RuntimeError("BUILD_STOPPED_INVALID_PROJECT: app Gradle identity does not match MCM 1.6.3")
    settings = (root / "settings.gradle.kts").read_text(encoding="utf-8", errors="replace")
    if 'include(":app")' not in settings:
        raise RuntimeError("BUILD_STOPPED_INVALID_PROJECT: Gradle :app module is not included")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--zip", required=True)
    parser.add_argument("--dest-dir")
    parser.add_argument("--profile", choices=["auto", "mcm-native"], default="auto")
    args = parser.parse_args()

    source_zip = Path(args.zip).resolve()
    if not source_zip.is_file() or not zipfile.is_zipfile(source_zip):
        raise RuntimeError(f"Source archive is not a valid ZIP: {source_zip}")
    destination = Path(args.dest_dir).resolve() if args.dest_dir else (
        Path(".androidforge/workspace") / source_zip.stem
    ).resolve()
    if destination.exists():
        shutil.rmtree(destination)
    destination.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(source_zip, "r") as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f"ZIP CRC validation failed at {bad}")
        safe_extract(archive, destination)

    roots = candidate_roots(destination)
    if len(roots) != 1:
        raise RuntimeError(
            "BUILD_STOPPED_INVALID_PROJECT: expected exactly one valid project root, "
            f"found {len(roots)} under {destination}: {[str(p) for p in roots]}"
        )
    project_root = roots[0]
    if args.profile == "mcm-native":
        validate_mcm_root(project_root)

    result = {
        "status": "PASS",
        "archive": str(source_zip),
        "extraction_directory": str(destination),
        "project_root": str(project_root),
        "project_kind": "NATIVE_ANDROID_GRADLE_KOTLIN" if (project_root / "SOURCE_IDENTITY.txt").exists() else "DETECTED",
    }
    report = Path("extract.json")
    report.write_text(json.dumps(result, indent=2), encoding="utf-8")
    output_file = os.environ.get("GITHUB_OUTPUT")
    if output_file:
        with open(output_file, "a", encoding="utf-8") as stream:
            stream.write(f"project_root={project_root}\n")
            stream.write(f"extraction_directory={destination}\n")
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"PROJECT EXTRACTION FAILED: {error}", file=sys.stderr)
        raise SystemExit(2)
