#!/usr/bin/env python3
"""AndroidForge APK collection with strict manifest identity verification.

Generic projects retain the existing best-effort APK/AAB collection behavior.
When --exact-apk and expected identity values are provided, exactly that fresh
APK is accepted only if its package/version manifest matches.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path
from typing import Any


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def tool_candidates(tool_name: str) -> list[list[str]]:
    candidates: list[list[str]] = []
    located = shutil.which(tool_name)
    if located:
        candidates.append([located])
    sdk_root = os.environ.get("ANDROID_SDK_ROOT") or os.environ.get("ANDROID_HOME")
    if sdk_root:
        sdk = Path(sdk_root)
        if tool_name == "apkanalyzer":
            for path in [
                sdk / "cmdline-tools" / "latest" / "bin" / "apkanalyzer",
                sdk / "tools" / "bin" / "apkanalyzer",
            ]:
                if path.is_file():
                    candidates.append([str(path)])
        elif tool_name == "aapt":
            build_tools = sdk / "build-tools"
            if build_tools.is_dir():
                dirs = sorted((p for p in build_tools.iterdir() if p.is_dir()),
                              key=lambda p: tuple(int(x) if x.isdigit() else -1 for x in re.split(r"[._-]", p.name)),
                              reverse=True)
                for directory in dirs:
                    binary = directory / "aapt"
                    if binary.is_file():
                        candidates.append([str(binary)])
    return candidates


def run_identity_tool(command: list[str], apk: Path) -> tuple[str, str, str]:
    application_id = subprocess.check_output(
        command + ["manifest", "application-id", str(apk)],
        text=True, stderr=subprocess.STDOUT, timeout=30,
    ).strip()
    version_name = subprocess.check_output(
        command + ["manifest", "version-name", str(apk)],
        text=True, stderr=subprocess.STDOUT, timeout=30,
    ).strip()
    version_code = subprocess.check_output(
        command + ["manifest", "version-code", str(apk)],
        text=True, stderr=subprocess.STDOUT, timeout=30,
    ).strip()
    return application_id, version_name, version_code


def parse_aapt_badging(output: str) -> tuple[str, str, str]:
    line = next((row for row in output.splitlines() if row.startswith("package:")), None)
    if line is None:
        raise RuntimeError("aapt output has no package manifest line")
    package = re.search(r"\bname='([^']+)'", line)
    version_code = re.search(r"\bversionCode='([^']+)'", line)
    version_name = re.search(r"\bversionName='([^']*)'", line)
    if not package or not version_code or not version_name:
        raise RuntimeError("aapt output is missing package/versionCode/versionName")
    return package.group(1), version_name.group(1), version_code.group(1)


def read_apk_identity(apk: Path) -> tuple[str, str, str]:
    errors: list[str] = []
    for command in tool_candidates("apkanalyzer"):
        try:
            return run_identity_tool(command, apk)
        except (OSError, subprocess.SubprocessError, RuntimeError) as error:
            errors.append(f"apkanalyzer: {error}")
    for command in tool_candidates("aapt"):
        try:
            output = subprocess.check_output(
                command + ["dump", "badging", str(apk)],
                text=True, stderr=subprocess.STDOUT, timeout=30,
            )
            return parse_aapt_badging(output)
        except (OSError, subprocess.SubprocessError, RuntimeError, StopIteration) as error:
            errors.append(f"aapt: {error}")
    detail = "; ".join(errors) if errors else "neither apkanalyzer nor aapt is installed"
    raise RuntimeError(f"Unable to verify APK manifest identity: {detail}")


def validate_expected_identity(
    package: str,
    version_name: str,
    version_code: str,
    expected_package: str,
    expected_version_name: str,
    expected_version_code: str,
) -> None:
    expected = {
        "package": (expected_package, package),
        "versionName": (expected_version_name, version_name),
        "versionCode": (expected_version_code, version_code),
    }
    mismatches = [
        f"{name}: expected {wanted!r}, got {actual!r}"
        for name, (wanted, actual) in expected.items()
        if wanted != actual
    ]
    if mismatches:
        raise RuntimeError("APK manifest mismatch: " + "; ".join(mismatches))


def find_generic_artifacts(root: Path) -> list[Path]:
    found: list[Path] = []
    for pattern in ("*.apk", "*.aab"):
        for path in root.rglob(pattern):
            if "intermediates" not in path.parts:
                found.append(path)
    return sorted(set(found), key=lambda item: str(item))


def write_outputs(result: dict[str, Any], output_json: Path) -> None:
    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(json.dumps(result, indent=2), encoding="utf-8")
    github_output = os.environ.get("GITHUB_OUTPUT")
    if not github_output:
        return
    with open(github_output, "a", encoding="utf-8") as stream:
        stream.write(f"apk_count={result['apk_count']}\n")
        stream.write(f"aab_count={result.get('aab_count', 0)}\n")
        stream.write(f"apk_directory={result['output_directory']}\n")
        stream.write(f"verified={'true' if result.get('verified') else 'false'}\n")
        if result.get("primary_apk"):
            stream.write(f"primary_apk={result['primary_apk']}\n")
            stream.write(f"primary_apk_name={Path(result['primary_apk']).name}\n")
        if result.get("package"):
            stream.write(f"verified_package={result['package']}\n")
            if result.get("source_id"):
                stream.write(f"source_id={result['source_id']}\n")
                stream.write(f"source_zip_sha256={result['source_zip_sha256']}\n")
                stream.write(f"provenance_verified={'true' if result.get('provenance_verified') else 'false'}\n")
            stream.write(f"verified_version_name={result['version_name']}\n")
            stream.write(f"verified_version_code={result['version_code']}\n")
            stream.write(f"apk_sha256={result['sha256']}\n")



def read_apk_provenance(apk: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    if not zipfile.is_zipfile(apk):
        raise RuntimeError("Collected file is not a valid APK/ZIP archive")
    try:
        with zipfile.ZipFile(apk, "r") as archive:
            bad_member = archive.testzip()
            if bad_member is not None:
                raise RuntimeError(f"APK ZIP integrity check failed at {bad_member}")
            build_data = json.loads(archive.read("assets/mcm-build-provenance.json").decode("utf-8"))
            source_data = json.loads(archive.read("assets/mcm-source-provenance.json").decode("utf-8"))
    except KeyError as error:
        raise RuntimeError(f"APK is missing required MCM provenance asset: {error}") from error
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise RuntimeError("APK provenance asset is not valid UTF-8 JSON") from error
    return build_data, source_data


def validate_apk_provenance(
    build_data: dict[str, Any], source_data: dict[str, Any],
    expected_source_id: str, expected_patch_id: str,
    expected_base_source_sha256: str, expected_source_zip_sha256: str,
    build_started_epoch: int,
) -> None:
    expected = {
        "source_id": expected_source_id,
        "patch_id": expected_patch_id,
        "base_source_archive_sha256": expected_base_source_sha256.lower(),
    }
    for field, value in expected.items():
        if build_data.get(field) != value:
            raise RuntimeError(f"APK build provenance mismatch for {field}: expected {value!r}, got {build_data.get(field)!r}")
        if source_data.get(field) != value:
            raise RuntimeError(f"APK source provenance mismatch for {field}: expected {value!r}, got {source_data.get(field)!r}")
    if build_data.get("selected_source_zip_sha256") != expected_source_zip_sha256.lower():
        raise RuntimeError("APK was not built from the exact validated source ZIP")
    if build_data.get("build_started_epoch") != build_started_epoch:
        raise RuntimeError("APK build provenance timestamp does not match the current build invocation")
    if build_data.get("build_variant") != "debug":
        raise RuntimeError("MCM pipeline is permitted to collect only the debug variant")
    if build_data.get("application_id") != "com.multicloud.mcm" or build_data.get("version_name") != "1.6.3" or build_data.get("version_code") != 12:
        raise RuntimeError("APK build provenance application/version identity mismatch")


def main() -> int:
    parser = argparse.ArgumentParser(description="Collect and optionally verify Android APKs")
    parser.add_argument("--root", required=True)
    parser.add_argument("--variant", default="auto", choices=["auto", "debug", "release", "bundle"])
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--output-json", required=True)
    parser.add_argument("--exact-apk", help="Exact APK path relative to project root")
    parser.add_argument("--expected-package")
    parser.add_argument("--expected-version-name")
    parser.add_argument("--expected-version-code")
    parser.add_argument("--expected-source-id")
    parser.add_argument("--expected-patch-id")
    parser.add_argument("--expected-base-source-sha256")
    parser.add_argument("--expected-source-zip-sha256")
    parser.add_argument("--build-started-epoch", type=int)
    args = parser.parse_args()

    root = Path(args.root).resolve()
    output_dir = Path(args.output_dir).resolve()
    output_json = Path(args.output_json).resolve()
    if not root.is_dir():
        raise RuntimeError(f"Project root does not exist: {root}")
    output_dir.mkdir(parents=True, exist_ok=True)
    for stale in output_dir.glob("*"):
        if stale.is_file():
            stale.unlink()

    strict = bool(args.exact_apk or args.expected_package or args.expected_version_name or args.expected_version_code)
    if strict:
        required_strict = [args.exact_apk, args.expected_package, args.expected_version_name, args.expected_version_code,
                           args.expected_source_id, args.expected_patch_id, args.expected_base_source_sha256,
                           args.expected_source_zip_sha256, args.build_started_epoch]
        if any(value is None or value == "" for value in required_strict):
            raise RuntimeError("Strict MCM mode requires exact APK identity, full provenance and build timestamp")
        apk = (root / args.exact_apk).resolve()
        try:
            apk.relative_to(root)
        except ValueError as error:
            raise RuntimeError("--exact-apk must resolve inside the project root") from error
        if not apk.is_file() or apk.stat().st_size <= 0:
            raise RuntimeError(f"Expected freshly assembled APK is missing or empty: {apk}")
        if apk.stat().st_mtime + 1 < args.build_started_epoch:
            raise RuntimeError("APK timestamp predates the current build invocation; refusing a stale artifact")
        build_provenance, source_provenance = read_apk_provenance(apk)
        validate_apk_provenance(
            build_provenance, source_provenance, args.expected_source_id, args.expected_patch_id,
            args.expected_base_source_sha256, args.expected_source_zip_sha256, args.build_started_epoch,
        )
        package, version_name, version_code = read_apk_identity(apk)
        validate_expected_identity(
            package,
            version_name,
            version_code,
            args.expected_package,
            args.expected_version_name,
            args.expected_version_code,
        )
        destination = output_dir / apk.name
        shutil.copy2(apk, destination)
        size_kb = round(destination.stat().st_size / 1024, 1)
        primary_info = {
            "source_path": str(apk),
            "output_path": str(destination),
            "output_name": destination.name,
            "size_kb": size_kb,
            "is_primary": True,
        }
        result: dict[str, Any] = {
            "project_root": str(root),
            "apk_count": 1,
            "aab_count": 0,
            "verified": True,
            "primary": primary_info,
            "primary_apk": str(destination),
            "all_apks": [primary_info],
            "all_aabs": [],
            "package": package,
            "version_name": version_name,
            "version_code": version_code,
            "size_bytes": destination.stat().st_size,
            "sha256": sha256_file(destination),
            "source_id": args.expected_source_id,
            "patch_id": args.expected_patch_id,
            "base_source_archive_sha256": args.expected_base_source_sha256,
            "source_zip_sha256": args.expected_source_zip_sha256,
            "build_started_epoch": args.build_started_epoch,
            "provenance_verified": True,
            "output_directory": str(output_dir),
        }
    else:
        artifacts = find_generic_artifacts(root)
        copied: list[dict[str, Any]] = []
        for item in artifacts:
            suffix = item.suffix.lower()
            stem = item.stem
            for variant in ("release", "debug"):
                stem = stem.replace(f"-{variant}", "").replace(f"_{variant}", "")
            destination = output_dir / f"AndroidForge-{stem}-{item.parent.name}{suffix}"
            shutil.copy2(item, destination)
            copied.append({
                "source_path": str(item),
                "output_path": str(destination),
                "output_name": destination.name,
                "size_kb": round(destination.stat().st_size / 1024, 1),
                "is_primary": False,
                "artifact_type": "aab" if suffix == ".aab" else "apk",
            })
        copied_apks = [item for item in copied if item.get("artifact_type") == "apk"]
        copied_aabs = [item for item in copied if item.get("artifact_type") == "aab"]
        preferred_variant = args.variant if args.variant != "auto" else None
        primary_info = None
        if copied_apks:
            preferred = [item for item in copied_apks
                         if preferred_variant is None or preferred_variant in item["output_name"].lower()]
            primary_info = (preferred or copied_apks)[0]
            primary_info["is_primary"] = True
        result = {
            "project_root": str(root),
            "apk_count": len(copied_apks),
            "aab_count": len(copied_aabs),
            "verified": False,
            "primary": primary_info,
            "primary_apk": primary_info["output_path"] if primary_info else None,
            "all_apks": copied_apks,
            "all_aabs": copied_aabs,
            "output_directory": str(output_dir),
        }

    write_outputs(result, output_json)
    print(json.dumps(result, indent=2))
    return 0 if result["apk_count"] > 0 else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"APK COLLECTION/VERIFICATION FAILED: {error}", file=sys.stderr)
        raise SystemExit(2)
