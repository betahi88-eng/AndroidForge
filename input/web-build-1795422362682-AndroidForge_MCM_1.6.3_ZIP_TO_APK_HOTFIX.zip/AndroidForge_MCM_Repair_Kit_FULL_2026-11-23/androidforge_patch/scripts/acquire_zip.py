#!/usr/bin/env python3
"""AndroidForge — acquire one exact source ZIP and record its SHA-256.

Fail-closed policy:
- input-directory with no --path is allowed only when exactly one ZIP exists.
- an explicit path must resolve inside input/ and point to a ZIP.
- release-asset refuses ambiguous releases containing more than one ZIP.
- all acquired ZIPs are integrity-checked before extraction.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
import urllib.error
import urllib.request
import zipfile
from pathlib import Path
from urllib.parse import unquote, urlparse

REPO_ROOT = Path(__file__).resolve().parent.parent
INPUT_DIR = REPO_ROOT / "input"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def list_input_zips() -> list[Path]:
    if not INPUT_DIR.is_dir():
        return []
    return sorted(
        (item for item in INPUT_DIR.iterdir() if item.is_file() and item.suffix.lower() == ".zip"),
        key=lambda item: item.name.casefold(),
    )


def validate_zip(path: Path) -> None:
    if not path.is_file() or path.suffix.lower() != ".zip":
        raise RuntimeError(f"Source is not an existing .zip file: {path}")
    if not zipfile.is_zipfile(path):
        raise RuntimeError(f"File is not a valid ZIP archive: {path}")
    with zipfile.ZipFile(path, "r") as archive:
        bad_member = archive.testzip()
        if bad_member is not None:
            raise RuntimeError(f"ZIP CRC check failed for member: {bad_member}")


def download(url: str, destination: Path) -> None:
    request = urllib.request.Request(url, headers={"User-Agent": "AndroidForge-Action"})
    with urllib.request.urlopen(request, timeout=600) as response, destination.open("wb") as output:
        shutil.copyfileobj(response, output)


def get_release_asset_url(repo: str, tag: str, token: str | None) -> tuple[str, str]:
    api_url = f"https://api.github.com/repos/{repo}/releases/tags/{tag}"
    headers = {
        "Accept": "application/vnd.github+json",
        "User-Agent": "AndroidForge-Action",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"
    request = urllib.request.Request(api_url, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            data = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as error:
        raise RuntimeError(
            f"GitHub API error {error.code} fetching release {tag}: {error.reason}"
        ) from error

    assets = [asset for asset in (data.get("assets") or [])
              if str(asset.get("name", "")).lower().endswith(".zip")]
    if not assets:
        raise RuntimeError(f"No .zip asset found in release {tag}")
    if len(assets) != 1:
        names = ", ".join(str(asset.get("name", "<unnamed>")) for asset in assets)
        raise RuntimeError(
            f"Release {tag} contains {len(assets)} ZIP assets: {names}. "
            "Use download-url with the exact asset URL to avoid choosing the wrong source."
        )
    asset = assets[0]
    url = asset.get("browser_download_url") or asset.get("url")
    if not url:
        raise RuntimeError(f"ZIP asset in release {tag} has no download URL")
    return str(asset.get("name")), str(url)


def select_input_zip(explicit_path: str | None) -> Path:
    input_root = INPUT_DIR.resolve()
    if explicit_path:
        candidate = Path(explicit_path)
        if not candidate.is_absolute():
            candidate = REPO_ROOT / candidate
        candidate = candidate.resolve()
        try:
            candidate.relative_to(input_root)
        except ValueError as error:
            raise RuntimeError(
                f"Explicit ZIP must be inside input/: {candidate}"
            ) from error
        validate_zip(candidate)
        return candidate

    candidates = list_input_zips()
    if len(candidates) != 1:
        print(
            f"ERROR: expected exactly one ZIP in input/, found {len(candidates)}.",
            file=sys.stderr,
        )
        for candidate in candidates:
            print(f"  - input/{candidate.name}", file=sys.stderr)
        print(
            "Set zip_path to the exact input/<filename>.zip. Automatic first-ZIP selection is disabled.",
            file=sys.stderr,
        )
        raise RuntimeError("Ambiguous source ZIP selection")
    validate_zip(candidates[0])
    return candidates[0]


def main() -> int:
    parser = argparse.ArgumentParser(description="Acquire one unambiguous Android source ZIP")
    parser.add_argument("--source", default="input-directory",
                        choices=["input-directory", "download-url", "release-asset"])
    parser.add_argument("--url")
    parser.add_argument("--tag")
    parser.add_argument("--path", help="Exact ZIP path, relative to repository root or absolute")
    parser.add_argument("--dest-dir")
    args = parser.parse_args()

    destination_dir = Path(args.dest_dir) if args.dest_dir else REPO_ROOT / ".androidforge" / "downloads"
    destination_dir.mkdir(parents=True, exist_ok=True)

    try:
        if args.source == "input-directory":
            selected = select_input_zip(args.path)
            target = destination_dir / selected.name
            if selected.resolve() != target.resolve():
                shutil.copy2(selected, target)
            selected = target
        elif args.source == "download-url":
            if not args.url:
                raise RuntimeError("--url is required when source=download-url")
            name = unquote(Path(urlparse(args.url).path).name) or "source.zip"
            if not name.lower().endswith(".zip"):
                raise RuntimeError("Download URL must resolve to a .zip filename")
            selected = destination_dir / name
            download(args.url, selected)
            validate_zip(selected)
        else:
            if not args.tag:
                raise RuntimeError("--tag is required when source=release-asset")
            repo = os.environ.get("GITHUB_REPOSITORY", "")
            if not repo:
                raise RuntimeError("GITHUB_REPOSITORY is not set")
            name, asset_url = get_release_asset_url(repo, args.tag, os.environ.get("GITHUB_TOKEN"))
            selected = destination_dir / name
            download(asset_url, selected)
            validate_zip(selected)

        validate_zip(selected)
        digest = sha256_file(selected)
        result = {
            "source": args.source,
            "zip_path": str(selected),
            "zip_name": selected.name,
            "size_bytes": selected.stat().st_size,
            "sha256": digest,
            "zip_integrity": "PASS",
        }
        print(json.dumps(result, indent=2))
        output_file = os.environ.get("GITHUB_OUTPUT")
        if output_file:
            with open(output_file, "a", encoding="utf-8") as stream:
                stream.write(f"zip_path={selected}\n")
                stream.write(f"zip_name={selected.name}\n")
                stream.write(f"zip_sha256={digest}\n")
        return 0
    except Exception as error:
        print(f"ZIP ACQUISITION FAILED: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
