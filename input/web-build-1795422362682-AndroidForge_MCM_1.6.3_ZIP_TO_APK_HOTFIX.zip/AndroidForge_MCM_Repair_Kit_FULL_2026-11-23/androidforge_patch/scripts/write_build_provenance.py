#!/usr/bin/env python3
"""Write build-specific MCM provenance before Gradle compiles the APK."""
from __future__ import annotations
import argparse, json, os, re, sys, time
from pathlib import Path

HEX64 = re.compile(r"^[0-9a-f]{64}$", re.I)

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--source-id", required=True)
    parser.add_argument("--patch-id", required=True)
    parser.add_argument("--base-source-sha256", required=True)
    parser.add_argument("--source-zip-sha256", required=True)
    parser.add_argument("--output", default="app/src/main/assets/mcm-build-provenance.json")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    if not root.is_dir(): raise RuntimeError("Project root does not exist")
    if args.source_id != "MCM-1.6.3-RECONCILED-001": raise RuntimeError("Unexpected MCM source ID")
    if not args.patch_id.strip(): raise RuntimeError("Patch ID must not be blank")
    for label, value in (("base source SHA-256", args.base_source_sha256), ("source ZIP SHA-256", args.source_zip_sha256)):
        if not HEX64.fullmatch(value): raise RuntimeError(f"Invalid {label}")
    destination = (root / args.output).resolve()
    try: destination.relative_to(root)
    except ValueError as error: raise RuntimeError("Provenance asset must be inside the project root") from error
    started = int(time.time())
    payload = {
        "schema_version": 1,
        "source_id": args.source_id,
        "patch_id": args.patch_id,
        "base_source_archive_sha256": args.base_source_sha256.lower(),
        "selected_source_zip_sha256": args.source_zip_sha256.lower(),
        "build_started_epoch": started,
        "build_variant": "debug",
        "application_id": "com.multicloud.mcm",
        "version_name": "1.6.3",
        "version_code": 12,
    }
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    github_output = os.environ.get("GITHUB_OUTPUT")
    if github_output:
        with open(github_output, "a", encoding="utf-8") as stream:
            stream.write(f"build_started_epoch={started}\n")
    print(json.dumps(payload, indent=2))
    return 0

if __name__ == "__main__":
    try: raise SystemExit(main())
    except Exception as error:
        print(f"BUILD PROVENANCE FAILED: {error}", file=sys.stderr)
        raise SystemExit(2)
