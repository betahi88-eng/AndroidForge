# MCM 1.1.0 — Build status

**Status: engineering source / NOT RELEASE. No APK is claimed.**

- Native Android Gradle/Kotlin project; application ID `com.multicloud.mcm`; version 1.1.0 / versionCode 3.
- Multi Cloud DDNS/domain profiles, local grouping, edit/delete, persisted per-router status and sequential refresh-all were added.
- RouterOS 6/7 read adapters include Cloud DDNS, PPPoE active, ARP, DHCP lease and Netwatch snapshots.
- Per-interface RX/TX Mbps samples are persisted separately and shown in selector-driven history charts; no aggregate traffic sums are used.
- TLS error classification distinguishes unsupported protocol, DNS, timeout, refused connection, hostname and fingerprint mismatch.
- AndroidForge preflight, JavaScript/Python/shell/XML static validation passed.
- `RouterHostValidator.kt` compiled and had a basic smoke run using Kotlin 1.9.0.
- JUnit tests were added but not executed through Gradle.
- Targeted Kotlin interface-rate/history smoke with Room/JSON test doubles passed for baseline, 1/2 Mbps deltas, counter reset/recovery and per-interface history keys/read; this is not a full Android compile.
- Full Kotlin/Android Gradle compilation, Room KAPT, lint and APK assembly were not run: Gradle 8.7 and Android SDK Platform 35 are absent in this workspace.
- Live MikroTik RouterOS 6/7 and physical Android acceptance remain NOT RUN.
- This ZIP does not contain APK/AAB or release signing keys.

**Next gate:** AndroidForge build of this exact ZIP. Confirm Kotlin compile, `:app:assembleDebug`, APK existence, package/version and checksum; then install on Android and test at least one ROS7 and one ROS6 router.

## Additional protocol smoke checks

- Actual RouterOS 6 API-SSL client/repository against local TLS mock: direct login, legacy challenge-response, resource read, IP Cloud read and bounded ping with packet loss passed.
- Wrong certificate pin failed closed; plaintext HTTP on the API-SSL port was classified as `TLS_PROTOCOL`.
- This is a local mock protocol test, not validation against a physical MikroTik router.
