# Changelog

## 1.1.0 — Multi-Cloud DDNS rebuild (engineering source)

- Added grouped site/Cloud labels and multiple independent MikroTik endpoint profiles.
- Added router edit workflow; blank password preserves the current encrypted credential, changed password rotates to a new Keystore alias.
- Added Room v1→v2→v3 migrations for site grouping and per-router health/error state.
- Added persisted per-router UNKNOWN/ONLINE/PARTIAL/OFFLINE state and sequential refresh-all.
- Added RouterOS 7 REST and RouterOS 6 API-SSL reads for IP Cloud DDNS, PPPoE active sessions, ARP, DHCP leases and Netwatch.
- Added per-interface RX/TX Mbps history and selector-driven charts without aggregating overlapping bridge/physical counters.
- Added DDNS public IPv4/IPv6 and status presentation; PPPoE active list filters to service=pppoe.
- Bounded concurrent requests to two per monitoring service to limit RouterOS API-SSL pressure.
- Added TLS protocol mismatch classification for Android/BoringSSL `UNSUPPORTED_PROTOCOL` errors.
- Added tests for host validation and TLS error classification; refreshed REST and API-SSL mock data.
- Updated Vietnamese architecture, RouterOS setup, test and build documentation.

This remains an engineering source NOT RELEASE. Android Gradle build, APK assembly, Android device installation and live RouterOS tests must pass before calling it a release.

## 1.0.1 — previous engineering source

- RouterOS 6 API-SSL and RouterOS 7 REST adapters.
- TLS certificate pinning and Android Keystore AES-256-GCM credential storage.
- Packet-loss parser validation and local metric history.
