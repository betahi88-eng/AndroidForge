# MCM — Project State

**Source candidate:** 1.1.0 — Multi-Cloud DDNS rebuild  
**State:** Engineering source / NOT RELEASE  
**Last checkpoint:** 2026-11-22

## Scope held

- Android-only MCM application; native Kotlin + WebView assets + Room + Android Keystore.
- Multiple independent MikroTik endpoint profiles grouped by Cloud/site name.
- Direct connection to each configured DDNS/domain/IP; no MCM cloud backend, no VPS, no shared server.
- RouterOS 7 REST over HTTPS and RouterOS 6 API-SSL; read-only monitoring plus bounded ICMP probes.
- No router configuration changes are sent by MCM.

## Implemented in the current source candidate

- Multi-router profile create/edit/delete, independent host/port/OS/user/TLS pin and encrypted credentials.
- Local grouping by Cloud/site, sequential Refresh All, persisted per-router health and error state.
- Cloud DDNS details, resource metrics, interface counters/rates, PPPoE active, ARP, DHCP lease and Netwatch snapshots.
- ICMP packet-loss validation, local metric history/charts and bounded background CPU/RAM sampling.
- TLS protocol/DNS/timeout/refused/hostname/fingerprint diagnostic classification.
- Room migrations from v1 to v2 to v3.

## Verification evidence

- AndroidForge flat-root native Gradle/Kotlin preflight: PASS.
- Source static checks, JS syntax, Python compilation, shell syntax, XML parsing: PASS.
- Room SQL migration preservation checks: PASS.
- WebView DOM contract: PASS.
- Targeted Kotlin interface-rate/history smoke with Room/JSON test doubles: PASS; not a full Android compile.
- ZIP structure and SHA-256 verification: PASS.
- Full Android Gradle compile, Room KAPT, Gradle/JUnit, lint and APK assembly: NOT RUN (Gradle 8.7 and Android SDK Platform 35 unavailable in the current workspace).
- Physical Android and RouterOS 6/7 acceptance: NOT RUN.

## Important operating limitation

MikroTik Cloud DDNS resolves a hostname to the router's reported public address. It does not create a VPN, open management ports, or bypass CGNAT/double NAT. The remote route must already be reachable and restricted; prefer VPN/WireGuard and do not expose management services to the entire Internet.
