"use strict";

let editingRouterId = null;

function statusLabel(status) {
  switch (status) {
    case "ONLINE": return "Đang đọc đủ dữ liệu";
    case "PARTIAL": return "Kết nối · thiếu một số mục";
    case "OFFLINE": return "Lỗi kết nối/đọc dữ liệu";
    default: return "Chưa kiểm tra";
  }
}

function endpointLabel(router) {
  if (router.endpointKind === "MIKROTIK_CLOUD") return "MIKROTIK CLOUD";
  if (router.endpointKind === "DDNS_DOMAIN") return "DDNS / DOMAIN";
  return "IP DIRECT";
}

function renderRouters() {
  const list = $("routerList");
  $("routerCount").textContent = String(state.routers.length);
  list.replaceChildren();
  if (state.routers.length === 0) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = "Chưa có Cloud/domain. Thêm kết nối MikroTik đầu tiên.";
    list.append(empty);
    state.selectedId = null;
    clearDashboard();
    $("refreshBtn").disabled = true;
    $("removeBtn").disabled = true;
    $("editBtn").disabled = true;
    $("refreshAllBtn").disabled = true;
    $("selectedName").textContent = "Chưa chọn thiết bị";
    $("selectedMeta").textContent = "Mỗi domain được quản lý độc lập";
    return;
  }
  if (!state.routers.some((router) => router.id === state.selectedId)) {
    state.selectedId = state.routers[0].id;
    clearDashboard();
  }
  const grouped = new Map();
  for (const router of state.routers) {
    const groupName = router.siteName || "Mặc định";
    if (!grouped.has(groupName)) grouped.set(groupName, []);
    grouped.get(groupName).push(router);
  }
  for (const [groupName, routers] of grouped) {
    const group = document.createElement("section");
    group.className = "router-group";
    const heading = document.createElement("h3");
    heading.textContent = groupName;
    group.append(heading);
    for (const router of routers) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = `router-item${router.id === state.selectedId ? " active" : ""}`;
      const title = document.createElement("b");
      title.textContent = router.name;
      const meta = document.createElement("span");
      meta.textContent = `${router.host}:${router.port} · RouterOS ${router.routerOsMajor}`;
      const badge = document.createElement("em");
      badge.textContent = endpointLabel(router);
      const health = document.createElement("small");
      health.className = `router-health ${String(router.lastStatus || "UNKNOWN").toLowerCase()}`;
      const checkedValue = Number(router.lastCheckedAt);
      const checked = Number.isFinite(checkedValue) && checkedValue > 0
        ? new Date(checkedValue).toLocaleString()
        : "Chưa kiểm tra";
      health.textContent = `${statusLabel(router.lastStatus)} · ${checked}`;
      if (router.lastErrorCode || router.lastErrorMessage) {
        health.title = `${router.lastErrorCode || ""} ${router.lastErrorMessage || ""}`.trim();
      }
      button.append(title, meta, badge, health);
      button.addEventListener("click", () => {
        if (state.selectedId !== router.id) clearDashboard();
        state.selectedId = router.id;
        renderRouters();
        renderSelectedMeta();
        refreshSelected();
      });
      group.append(button);
    }
    list.append(group);
  }
  const locked = state.refreshAllBusy;
  $("refreshBtn").disabled = locked;
  $("removeBtn").disabled = locked;
  $("editBtn").disabled = locked;
  $("refreshAllBtn").disabled = locked;
  $("showAddBtn").disabled = locked;
  renderSelectedMeta();
}

function renderSelectedMeta() {
  const router = state.routers.find((item) => item.id === state.selectedId);
  if (!router) return;
  $("selectedName").textContent = router.name;
  $("selectedMeta").textContent = `${router.siteName || "Mặc định"} · ${router.host}:${router.port} · RouterOS ${router.routerOsMajor} · ${router.username}`;
}

async function loadRouters() {
  const result = await nativeCall("listRouters");
  if (!result.ok) throw new Error(result.error || "Không đọc được danh sách Cloud/router.");
  state.routers = Array.isArray(result.routers) ? result.routers : [];
  renderRouters();
}

function resetRouterForm() {
  editingRouterId = null;
  $("routerForm").reset();
  $("formTitle").textContent = "Thêm Cloud / router MikroTik";
  $("routerPort").value = "443";
  $("routerPassword").required = true;
  $("routerPassword").placeholder = "Mật khẩu RouterOS";
}

function showPanel(show) {
  $("addPanel").hidden = !show;
  if (show) $("routerName").focus();
  if (!show) resetRouterForm();
}

function editSelectedRouter() {
  const router = state.routers.find((item) => item.id === state.selectedId);
  if (!router) return;
  editingRouterId = router.id;
  $("formTitle").textContent = `Sửa ${router.name}`;
  $("routerName").value = router.name;
  $("routerSite").value = router.siteName || "Mặc định";
  $("routerHost").value = router.host;
  $("routerOs").value = String(router.routerOsMajor);
  $("routerPort").value = String(router.port);
  $("routerUsername").value = router.username;
  $("routerPassword").value = "";
  $("routerPassword").required = false;
  $("routerPassword").placeholder = "Để trống để giữ mật khẩu hiện tại";
  $("routerPin").value = router.tlsSha256Pin || "";
  showPanel(true);
}

async function inspectTls() {
  const host = $("routerHost").value.trim();
  const major = Number($("routerOs").value);
  const port = Number($("routerPort").value) || (major === 6 ? 8729 : 443);
  if (!host) return toast("Nhập Cloud DDNS/domain hoặc IP trước.");
  $("inspectTlsBtn").disabled = true;
  $("inspectTlsBtn").textContent = "Đang đọc…";
  try {
    const result = await nativeCall("inspectTls", host, port);
    if (!result.ok) throw new Error(result.error || "Không đọc được fingerprint.");
    $("routerPin").value = result.fingerprint;
    toast("Đã đọc fingerprint. Phải đối chiếu độc lập trước khi lưu.");
  } catch (error) {
    toast(error.message);
  } finally {
    $("inspectTlsBtn").disabled = false;
    $("inspectTlsBtn").textContent = "Đọc fingerprint TLS";
  }
}

async function saveRouter(event) {
  event.preventDefault();
  const wasEditing = Boolean(editingRouterId);
  const payload = {
    id: editingRouterId || undefined,
    name: $("routerName").value.trim(),
    siteName: $("routerSite").value.trim(),
    host: $("routerHost").value.trim(),
    routerOsMajor: Number($("routerOs").value),
    port: Number($("routerPort").value),
    username: $("routerUsername").value.trim(),
    password: $("routerPassword").value,
    tlsSha256Pin: $("routerPin").value.trim()
  };
  const message = editingRouterId
    ? "Xác nhận fingerprint đang lưu đúng với domain/cổng/chứng chỉ hiện tại của router? Nếu đổi host hoặc chứng chỉ, hãy đọc và đối chiếu fingerprint mới trước khi lưu."
    : "Bạn đã đối chiếu SHA-256 fingerprint với nguồn đáng tin cậy độc lập và xác nhận đúng chứng chỉ của router?";
  if (!window.confirm(message)) return;
  const submit = $("routerForm").querySelector("button[type=submit]");
  submit.disabled = true;
  try {
    const result = await nativeCall("saveRouter", JSON.stringify(payload));
    if (!result.ok) throw new Error(result.error || "Không lưu được Cloud/router.");
    const savedId = result.id;
    resetRouterForm();
    $("addPanel").hidden = true;
    await loadRouters();
    if (savedId) state.selectedId = savedId;
    renderRouters();
    if (state.selectedId) refreshSelected();
    toast(wasEditing ? "Đã cập nhật router." : "Đã thêm Cloud/router.");
  } catch (error) {
    toast(error.message);
  } finally {
    submit.disabled = false;
    $("routerPassword").value = "";
  }
}

async function removeSelected() {
  const router = state.routers.find((item) => item.id === state.selectedId);
  if (!router || !window.confirm(`Gỡ “${router.name}” (${router.host}) khỏi MCM?`)) return;
  try {
    const result = await nativeCall("removeRouter", router.id);
    if (!result.ok) throw new Error(result.error || "Không gỡ được router.");
    await loadRouters();
    if (state.selectedId) refreshSelected();
    toast("Đã gỡ router và lịch sử cục bộ.");
  } catch (error) {
    toast(error.message);
  }
}


async function refreshAllRouters() {
  if (state.refreshAllBusy || state.routers.length === 0) return;
  if (state.refreshing) return toast("Đang làm mới router đang chọn. Thử kiểm tra tất cả sau khi hoàn tất.");
  state.refreshAllBusy = true;
  const button = $("refreshAllBtn");
  const summary = $("refreshAllSummary");
  button.disabled = true;
  $("refreshBtn").disabled = true;
  $("editBtn").disabled = true;
  $("removeBtn").disabled = true;
  $("showAddBtn").disabled = true;
  button.textContent = "Đang kiểm tra từng Cloud…";
  summary.textContent = "Đang kết nối tuần tự; không gửi đồng thời lệnh tới mọi router.";
  try {
    const result = await nativeCall("refreshAllRouters", $("pingTarget").value.trim(), state.selectedId || "");
    if (!result.ok) throw new Error(result.error || "Không kiểm tra được danh sách router.");
    await loadRouters();
    summary.textContent = `Tổng ${result.total}: ${result.online} đầy đủ · ${result.partial} thiếu dữ liệu phụ · ${result.offline} lỗi.`;
    if (result.selectedSnapshot && state.selectedId) {
      renderSnapshot(result.selectedSnapshot);
      const warnings = result.selectedSnapshot.warnings || [];
      setStatus(warnings.length ? "Đã kết nối · thiếu dữ liệu phụ" : "Đã kết nối", warnings.length ? "warn" : "good");
      await loadHistory();
    } else if (state.selectedId) {
      const selectedResult = (result.results || []).find((item) => item.id === state.selectedId);
      if (selectedResult && !selectedResult.ok) {
        clearDashboard();
        setStatus("Router đang chọn OFFLINE · Dữ liệu cũ đã được ẩn", "bad");
        summary.textContent += ` Router đang chọn: ${selectedResult.error || "không kết nối được"}.`;
      }
    }
    toast("Đã kiểm tra xong các Cloud/router.");
  } catch (error) {
    summary.textContent = error.message;
    toast(error.message);
  } finally {
    state.refreshAllBusy = false;
    button.disabled = state.routers.length === 0;
    $("refreshBtn").disabled = !state.selectedId;
    $("editBtn").disabled = !state.selectedId;
    $("removeBtn").disabled = !state.selectedId;
    $("showAddBtn").disabled = false;
    button.textContent = "↻ Kiểm tra tất cả Cloud";
    renderRouters();
  }
}
