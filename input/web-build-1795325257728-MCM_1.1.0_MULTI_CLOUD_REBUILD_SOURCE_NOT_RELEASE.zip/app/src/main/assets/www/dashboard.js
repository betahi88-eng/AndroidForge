"use strict";

async function refreshSelected() {
  const routerId = state.selectedId;
  if (!routerId || state.refreshing || state.refreshAllBusy) return;
  state.refreshing = true;
  $("refreshBtn").disabled = true;
  $("refreshBtn").textContent = "Đang đọc…";
  setStatus("Đang kết nối Cloud/router", "idle");
  try {
    const result = await nativeCall("refreshRouter", routerId, $("pingTarget").value.trim());
    if (state.selectedId !== routerId) return;
    if (!result.ok) throw new Error(result.error || "Đọc dữ liệu router thất bại.");
    renderSnapshot(result);
    setStatus(result.warnings?.length ? "Đã kết nối · Có mục không hỗ trợ" : "Đã kết nối", result.warnings?.length ? "warn" : "good");
    await loadRouters().catch((error) => toast(`Không cập nhật được danh sách router: ${error.message}`));
    await loadHistory();
  } catch (error) {
    if (state.selectedId === routerId) {
      clearDashboard();
      setStatus("Không kết nối được · Dữ liệu cũ đã được ẩn", "bad");
      await loadRouters().catch(() => {});
      toast(error.message);
    }
  } finally {
    state.refreshing = false;
    $("refreshBtn").disabled = !state.selectedId;
    $("refreshBtn").textContent = "↻ Làm mới";
    if (state.selectedId && state.selectedId !== routerId) refreshSelected();
  }
}

function clearDashboard() {
  $("cpuValue").textContent = "—";
  $("ramValue").textContent = "—";
  $("pppoeValue").textContent = "—";
  $("pppoeHint").textContent = "Chưa có dữ liệu";
  $("lossValue").textContent = "—";
  $("lossHint").textContent = "Đo độc lập bằng ping";
  $("versionValue").textContent = "—";
  $("uptimeValue").textContent = "—";
  $("pppoeCountValue").textContent = "—";
  $("arpCountValue").textContent = "—";
  $("dhcpCountValue").textContent = "—";
  $("netwatchDownValue").textContent = "—";
  for (const id of ["interfaceList", "cloudInfo", "pppoeSessionList", "arpList", "dhcpList", "netwatchList"]) {
    $(id).replaceChildren();
  }
  state.selectedInterfaceName = null;
  $("interfaceHistorySelect").replaceChildren();
  $("interfaceHistorySelect").disabled = true;
  $("warnings").hidden = true;
  $("warnings").textContent = "";
  $("lastUpdated").textContent = "Chưa cập nhật";
  for (const id of ["cpuChart", "ramChart", "lossChart", "pppoeChart", "arpChart", "dhcpChart", "netwatchChart", "interfaceRxChart", "interfaceTxChart"]) drawChart(id, []);
}

function renderSnapshot(data) {
  const resource = data.resource || {};
  $("cpuValue").textContent = resource.cpuLoadPercent == null ? "—" : `${resource.cpuLoadPercent}%`;
  $("versionValue").textContent = resource.version || "—";
  $("uptimeValue").textContent = resource.uptime || "—";
  let ram = null;
  if (Number.isFinite(resource.freeMemoryBytes) && Number.isFinite(resource.totalMemoryBytes) && resource.totalMemoryBytes > 0) {
    ram = Math.max(0, 100 * (resource.totalMemoryBytes - resource.freeMemoryBytes) / resource.totalMemoryBytes);
  }
  $("ramValue").textContent = ram == null ? "—" : `${ram.toFixed(1)}%`;

  const interfaces = Array.isArray(data.interfaces) ? data.interfaces : null;
  const pppInterfaces = interfaces?.filter((item) => (item.type || "").toLowerCase().includes("pppoe") || String(item.name || "").toLowerCase().includes("pppoe")) || [];
  const activeSessions = Array.isArray(data.pppoeSessions) ? data.pppoeSessions : null;
  $("pppoeValue").textContent = activeSessions == null ? "—" : String(activeSessions.length);
  $("pppoeHint").textContent = activeSessions == null
    ? "Không đọc được PPPoE active"
    : `${interfaces == null ? "—" : pppInterfaces.length} interface PPPoE · ${activeSessions.length} phiên active`;
  $("pppoeCountValue").textContent = activeSessions == null ? "—" : String(activeSessions.length);
  $("arpCountValue").textContent = Array.isArray(data.arpEntries) ? String(data.arpEntries.length) : "—";
  $("dhcpCountValue").textContent = Array.isArray(data.dhcpLeases) ? String(data.dhcpLeases.length) : "—";
  $("netwatchDownValue").textContent = Array.isArray(data.netwatch)
    ? String(data.netwatch.filter((item) => String(item.status).toLowerCase() === "down").length)
    : "—";

  const ping = data.ping || null;
  if (ping && Number.isFinite(ping.lossPercent)) {
    $("lossValue").textContent = `${ping.lossPercent.toFixed(1)}%`;
    $("lossHint").textContent = `${ping.received}/${ping.sent} nhận · ${ping.lost} mất · ${ping.target}`;
  } else {
    $("lossValue").textContent = "—";
    $("lossHint").textContent = ping?.error || "Chưa có phép đo ICMP hợp lệ";
  }

  renderCloud(data.cloud || {});
  renderInterfaces(interfaces);
  populateInterfaceHistoryOptions(interfaces);
  renderRows("pppoeSessionList", activeSessions, ["name", "service", "address", "caller-id", "uptime"]);
  renderRows("arpList", data.arpEntries, ["address", "mac-address", "interface", "complete"]);
  renderRows("dhcpList", data.dhcpLeases, ["address", "host-name", "mac-address", "status", "server", "expires-after"]);
  renderRows("netwatchList", data.netwatch, ["host", "status", "since", "comment"]);
  const warnings = Array.isArray(data.warnings) ? data.warnings : [];
  $("warnings").hidden = warnings.length === 0;
  $("warnings").textContent = warnings.join(" · ");
  $("lastUpdated").textContent = `Cập nhật ${new Date(data.refreshedAt).toLocaleTimeString()}`;
}

function renderCloud(cloud) {
  const node = $("cloudInfo");
  node.replaceChildren();
  const values = [
    ["DDNS enabled", cloud["ddns-enabled"]],
    ["DDNS status", cloud.status],
    ["DNS name", cloud["dns-name"]],
    ["Public IPv4", cloud["public-address"]],
    ["Public IPv6", cloud["public-address-ipv6"]],
    ["Last update", cloud["update-time"]],
    ["Update interval", cloud["ddns-update-interval"]]
  ];
  if (!values.some(([, value]) => value != null && value !== "")) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = "Router không trả thông tin /ip/cloud hoặc tài khoản chưa đủ quyền đọc.";
    node.append(empty);
    return;
  }
  for (const [label, value] of values) {
    const item = document.createElement("div");
    item.className = "data-item";
    const caption = document.createElement("small");
    caption.textContent = label;
    const content = document.createElement("b");
    content.textContent = value == null || value === "" ? "—" : String(value);
    item.append(caption, content);
    node.append(item);
  }
}

function renderInterfaces(interfaces) {
  const list = $("interfaceList");
  list.replaceChildren();
  if (!Array.isArray(interfaces) || interfaces.length === 0) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = Array.isArray(interfaces)
      ? "Không có interface hoặc router trả danh sách rỗng."
      : "Không đọc được interface. Xem cảnh báo kết nối.";
    list.append(empty);
    return;
  }
  for (const item of interfaces) {
    const row = document.createElement("article");
    row.className = "interface-row";
    const header = document.createElement("header");
    const name = document.createElement("b");
    name.textContent = item.name;
    const status = document.createElement("em");
    status.className = item.running ? "" : "down";
    status.textContent = item.running ? "RUNNING" : "DOWN";
    header.append(name, status);
    const rates = document.createElement("div");
    rates.className = "rates";
    const rx = Number.isFinite(item.rxMbps) ? `${item.rxMbps.toFixed(2)} Mbps` : "—";
    const tx = Number.isFinite(item.txMbps) ? `${item.txMbps.toFixed(2)} Mbps` : "—";
    rates.innerHTML = `<span>↓ <strong>${rx}</strong></span><span>↑ <strong>${tx}</strong></span>`;
    row.append(header, rates);
    list.append(row);
  }
}

function renderRows(containerId, rows, fields) {
  const node = $(containerId);
  node.replaceChildren();
  if (!Array.isArray(rows) || rows.length === 0) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = Array.isArray(rows)
      ? "Không có bản ghi tại thời điểm kiểm tra."
      : "Không đọc được dữ liệu. Xem cảnh báo kết nối ở trên.";
    node.append(empty);
    return;
  }
  const table = document.createElement("table");
  const head = document.createElement("tr");
  for (const field of fields) {
    const cell = document.createElement("th");
    cell.textContent = field;
    head.append(cell);
  }
  const thead = document.createElement("thead");
  thead.append(head);
  const tbody = document.createElement("tbody");
  for (const row of rows.slice(0, 100)) {
    const tr = document.createElement("tr");
    for (const field of fields) {
      const td = document.createElement("td");
      td.textContent = row[field] == null ? "—" : String(row[field]);
      tr.append(td);
    }
    tbody.append(tr);
  }
  table.append(thead, tbody);
  node.append(table);
}


function populateInterfaceHistoryOptions(interfaces) {
  const select = $("interfaceHistorySelect");
  const names = Array.isArray(interfaces)
    ? [...new Set(interfaces.map((item) => String(item.name || "").trim()).filter(Boolean))]
    : [];
  const preferred = names.includes(state.selectedInterfaceName)
    ? state.selectedInterfaceName
    : names.find((name) => name.toLowerCase().includes("pppoe")) || names[0] || null;
  state.selectedInterfaceName = preferred;
  select.replaceChildren();
  for (const name of names) {
    const option = document.createElement("option");
    option.value = name;
    option.textContent = name;
    select.append(option);
  }
  select.disabled = names.length === 0;
  if (preferred) select.value = preferred;
  else {
    drawChart("interfaceRxChart", []);
    drawChart("interfaceTxChart", []);
  }
}

function interfaceHistoryMetricKey(direction, interfaceName) {
  const bytes = new TextEncoder().encode(interfaceName);
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  const encoded = btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
  return `interface_${direction}_mbps_${encoded}`;
}

async function loadInterfaceHistory() {
  const name = state.selectedInterfaceName;
  if (!state.selectedId || !name) {
    drawChart("interfaceRxChart", []);
    drawChart("interfaceTxChart", []);
    return;
  }
  const metrics = [
    ["rx", "interfaceRxChart"],
    ["tx", "interfaceTxChart"]
  ];
  for (const [direction, chartId] of metrics) {
    try {
      const key = interfaceHistoryMetricKey(direction, name);
      const result = await nativeCall("metricHistory", state.selectedId, key);
      drawChart(chartId, result.ok ? result.points : []);
    } catch {
      drawChart(chartId, []);
    }
  }
}
