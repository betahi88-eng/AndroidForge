# Build MCM bằng AndroidForge — hướng dẫn đúng luồng ZIP → APK

## 1. ZIP nguồn và cấu trúc dự án

Dùng file `MCM_1.1.0_MULTI_CLOUD_REBUILD_SOURCE_NOT_RELEASE.zip` do gói source này tạo. ZIP phải có các file dự án ngay tại thư mục gốc, không bọc thêm một thư mục MCM bên ngoài.

Các đường dẫn gốc bắt buộc:

```text
settings.gradle.kts
build.gradle.kts
gradle.properties
app/build.gradle.kts
app/src/main/AndroidManifest.xml
app/src/main/java/com/multicloud/mcm/
app/src/main/assets/www/
app/src/test/java/com/multicloud/mcm/
```

Đây là Android native Gradle/Kotlin, không phải Flutter. Không được có `pubspec.yaml` hoặc `harmony_patched`.

Thông số dự án:

- Gradle project: `MikroTikMultiCloudMonitor`
- Application ID / namespace: `com.multicloud.mcm`
- Android Gradle Plugin: `8.6.1`
- Kotlin Gradle Plugin: `2.0.21`
- JDK: `17`
- Gradle được AndroidForge chọn theo bảng tương thích của chính repository: AGP `8.6.1` → Gradle `8.7`, JDK `17`.
- ZIP hiện không kèm Gradle Wrapper JAR. Detector AndroidForge sẽ đánh dấu wrapper thiếu và workflow có bước tự khôi phục wrapper / dùng Gradle tương thích; phải xác nhận log `Configure toolchain` và `Self-heal project` trước khi build.
- `compileSdk` / `targetSdk`: `35`; `minSdk`: `26`

## 2. Dùng giao diện web AndroidForge (khuyến nghị)

1. Mở <https://professional-x.github.io/AndroidForge/>.
2. Kết nối repository fork `anhtranmng-sys/AndroidForge` bằng PAT của chính bạn. Không gửi PAT cho người khác.
3. Chọn file ZIP MCM và tải trực tiếp lên thẻ upload.
4. Chọn build variant `debug`.
5. Bấm **Build APK** và mở run link khi giao diện báo đã tạo workflow.

**Lưu ý quan trọng:** giao diện web tự tạo GitHub Release, upload ZIP thành Release asset và dispatch workflow với `zip_source=release-asset` cùng `release_tag`. Khi dùng giao diện này, không cần điền `zip_path`; trường `zip_path` chỉ dành cho cách chạy workflow thủ công với `zip_source=input-directory`.

## 3. Chạy thủ công trong GitHub Actions

Nếu đã commit ZIP vào thư mục `input/` của repository AndroidForge:

- Workflow: `Build Android APK`
- `zip_source`: `input-directory`
- `zip_path`: đường dẫn đúng, ví dụ `input/MCM_1.1.0_MULTI_CLOUD_REBUILD_SOURCE_NOT_RELEASE.zip`
- `build_variant`: `debug`
- `enable_ndk`: `false`

Nếu đã tạo Release asset thủ công:

- `zip_source`: `release-asset`
- `release_tag`: tag của Release chứa ZIP
- `build_variant`: `debug`
- `enable_ndk`: `false`

## 4. Bắt buộc kiểm tra log trước khi tải APK

Trong log `Detect project type`, xác nhận:

- Project type là Gradle / Android.
- Kotlin được nhận diện.
- `project_root` chứa trực tiếp `settings.gradle.kts` và `app/build.gradle.kts`.
- Không được chọn Flutter, `pubspec.yaml`, `harmony_patched` hoặc một dự án khác.

Trong log `Configure toolchain`, xác nhận JDK 17 và Gradle tương thích AGP 8.6.1. Nếu dùng Gradle hệ thống, phiên bản phải từ 8.7 trở lên.

Trong log build, cần thấy lệnh Gradle cho module `:app`, đặc biệt `:app:assembleDebug`. Không coi workflow thành công nếu chỉ có bước detect hoặc nếu APK không được thu thập.

APK mong đợi từ project output:

`app/build/outputs/apk/debug/app-debug.apk`

Chỉ tải artifact khi build step thành công, artifact APK tồn tại và package được xác nhận là `com.multicloud.mcm`.

## 5. Những gì ZIP không tuyên bố

- ZIP là source engineering, không phải APK đã biên dịch hoặc release đã ký.
- Không có keystore release trong ZIP.
- Không có bằng chứng build Android Gradle hoàn chỉnh trong môi trường đóng gói hiện tại; AndroidForge phải chạy `testDebugUnitTest`, lint/build và tạo APK mới là bước nghiệm thu build.
- Kiểm thử RouterOS 6/7 trên router thật và cài đặt trên điện thoại thật vẫn cần thực hiện sau khi tạo APK.
