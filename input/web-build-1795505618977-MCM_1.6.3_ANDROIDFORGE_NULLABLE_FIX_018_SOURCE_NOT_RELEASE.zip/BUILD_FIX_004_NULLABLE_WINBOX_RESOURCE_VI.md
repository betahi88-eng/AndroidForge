# Build Fix 004 — nullable WinBox resource output (source 018)

## Evidence from AndroidForge logs (24 November 2026)

The supplied archive contains three Gradle logs: `assembleDebug`, `assembleRelease`, and `bundleDebug`. All three execute `:app:verifyMcmRuntimeDependencies` successfully, reporting 134 resolved module-variant entries. The release SDK dependency metadata contains no `jsch`, `bouncycastle`, `bcprov`, or `SshRouterOsClient` strings. The earlier duplicate-resource hypothesis is therefore not the cause of these particular failures.

All three tasks stop at Kotlin compilation in `app/src/main/java/com/multicloud/mcm/RouterConnectionCoordinator.kt`:

- line 255: nullable `result.resource` is passed to `parseKeyValueOutput(String)`;
- line 262: nullable `result.resource` is dereferenced with `.take(800)`.

`WinboxCliConnector.Result.resource` is explicitly declared `String?`. The coordinator had treated it as non-null.

## Repair in 018

- Added a null-safe RouterOS version parser accepting `String?`.
- A missing/blank `/system/resource/print` response now returns `WINBOX_RESOURCE_MISSING` with a bounded diagnostic instead of crashing.
- An output with no supported RouterOS 6/7 version still returns `WINBOX_VERSION_UNSUPPORTED` and includes only the bounded resource text.
- Added JUnit tests for null, blank, missing-version, malformed, RouterOS 6 and RouterOS 7 output.
- Added JVM smoke coverage and three static build-regression assertions.
- Kept the Debug+Release JSch/BouncyCastle dependency guard and the existing single-command build gate. No dependency or packaging exclusion was added.

## Verification limits

The WinBox crypto and repository JVM smoke script passed in this runtime after the patch. Source-tree, provenance, Room/UI/build-regression checks are run as part of package validation. This runtime does not have the Android SDK Platform 35 or Gradle installation, so the full Android Gradle/KAPT/JUnit/lint/APK/AAB build is **not run here**. Source 018 must still pass `bash scripts/androidforge-build-and-verify.sh` on AndroidForge before APK build success can be claimed. Live DDNS/WAN/router acceptance is a separate gate and remains unverified.
