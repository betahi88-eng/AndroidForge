package com.multicloud.mcm.routeros

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class WinboxCliRepositoryTest {
    @Test fun nullableResourceOutputIsHandledWithoutThrowing() {
        assertNull(WinboxCliRepository.parseRouterOsVersion(null))
        assertNull(WinboxCliRepository.parseRouterOsVersion(""))
        assertNull(WinboxCliRepository.parseRouterOsVersion("uptime: 2d03:04:05"))
        assertNull(WinboxCliRepository.parseRouterOsVersion("version: unknown"))
    }

    @Test fun parsesSupportedRouterOs6And7VersionParts() {
        val ros6 = WinboxCliRepository.parseRouterOsVersion("version: 6.49.17 (stable)")
        assertEquals("6.49.17", ros6?.version)
        assertEquals(6, ros6?.major)
        assertEquals(listOf(6, 49, 17), ros6?.parts)

        val ros7 = WinboxCliRepository.parseRouterOsVersion("version: 7.18.2 (stable)")
        assertEquals("7.18.2", ros7?.version)
        assertEquals(7, ros7?.major)
        assertEquals(listOf(7, 18, 2), ros7?.parts)
    }

    @Test fun parsesRouterOsSystemResourceKeyValueOutput() {
        val parsed = WinboxCliRepository.parseKeyValueOutput(
            """
                uptime: 2d03:04:05
                version: 7.18.2 (stable)
                cpu-load: 17%
                free-memory: 128.5MiB
                total-memory: 512MiB
                [admin@edge-router] >
            """.trimIndent()
        )
        assertEquals("2d03:04:05", parsed["uptime"])
        assertEquals("7.18.2 (stable)", parsed["version"])
        assertEquals("17%", parsed["cpu-load"])
        assertEquals("128.5MiB", parsed["free-memory"])
    }

    @Test fun parsesRouterOs7JsonArrayAndKeepsSemicolonsInsideValues() {
        val command = WinboxCliRepository.monitoringCommand("ip/dhcp-server/lease", true)
        val raw = "[admin@chr] > $command\r\n" +
            "[{\"address\":\"192.0.2.10\",\"host-name\":\"work;station=1\",\"dynamic\":true}]\r\n" +
            "[admin@chr] > "
        val rows = WinboxCliRepository.parseJsonRows(raw, command, setOf("address", "host-name", "dynamic"))
        assertEquals(1, rows.size)
        assertEquals("192.0.2.10", rows[0]["address"])
        assertEquals("work;station=1", rows[0]["host-name"])
        assertEquals("true", rows[0]["dynamic"])
    }

    @Test fun parsesRouterOs7CloudSingletonObject() {
        val command = WinboxCliRepository.monitoringCommand("ip/cloud", true)
        val raw = "[admin@chr] > $command\n{\"public-address\":\"203.0.113.9\",\"ddns-enabled\":true}\n[admin@chr] > "
        val rows = WinboxCliRepository.parseJsonRows(raw, command)
        assertEquals(1, rows.size)
        assertEquals("203.0.113.9", rows[0]["public-address"])
        assertEquals("true", rows[0]["ddns-enabled"])
    }

    @Test fun parsesRouterOs6AsValueRowsAndListFields() {
        val command = WinboxCliRepository.monitoringCommand("interface/bridge/vlan", false)
        val raw = "[admin@chr6] > $command\r\n" +
            ".id=*1;bridge=br0;vlan-ids=10,20;tagged=br0;ether2;untagged=ether3;dynamic=false\r\n" +
            ".id=*2;bridge=br0;vlan-ids=30;tagged=br0;ether4;dynamic=true\r\n" +
            "[admin@chr6] > "
        val rows = WinboxCliRepository.parseAsValueRows(raw, command,
            setOf("bridge", "vlan-ids", "tagged", "untagged", "dynamic"))
        assertEquals(2, rows.size)
        assertEquals("br0", rows[0]["bridge"])
        assertEquals("10,20", rows[0]["vlan-ids"])
        assertEquals("br0,ether2", rows[0]["tagged"])
        assertEquals("ether3", rows[0]["untagged"])
        assertEquals("true", rows[1]["dynamic"])
    }

    @Test fun ignoresUnrequestedRouterOs6FieldsWithoutAppendingThemToPreviousColumn() {
        val command = WinboxCliRepository.monitoringCommand("ip/dhcp-server/lease", false)
        val raw = "[admin@chr6] > $command\r\n" +
            ".id=*3;address=192.0.2.10;host-name=work;interface=ether1;status=bound\r\n" +
            "[admin@chr6] > "
        val rows = WinboxCliRepository.parseAsValueRows(raw, command,
            setOf("address", "host-name", "status"))
        assertEquals(1, rows.size)
        assertEquals("work", rows[0]["host-name"])
        assertEquals("bound", rows[0]["status"])
        assertNull(rows[0]["interface"])
    }

    @Test fun refusesCliFailureInsteadOfReturningAnEmptySuccessfulTable() {
        val command = WinboxCliRepository.monitoringCommand("interface", false)
        val raw = "[admin@chr6] > $command\nexpected end of command (line 1 column 8)\n[admin@chr6] > "
        var failed = false
        try { WinboxCliRepository.parseAsValueRows(raw, command, setOf("name", "type")) }
        catch (_: IllegalArgumentException) { failed = true }
        assertEquals(true, failed)
    }

    @Test fun parsesBinaryAndDecimalMemoryUnitsWithoutInventingValues() {
        assertEquals(128L * 1024L * 1024L, WinboxCliRepository.parseByteSize("128MiB"))
        assertEquals(128L * 1024L, WinboxCliRepository.parseByteSize("128KiB"))
        assertEquals(1_000_000L, WinboxCliRepository.parseByteSize("1MB"))
        assertEquals(1234567L, WinboxCliRepository.parseByteSize("1234567"))
        assertNull(WinboxCliRepository.parseByteSize("unknown"))
    }
}
