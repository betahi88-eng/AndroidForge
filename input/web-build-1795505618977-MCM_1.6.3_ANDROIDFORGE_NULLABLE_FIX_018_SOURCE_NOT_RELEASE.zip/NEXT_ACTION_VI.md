# Cổng nghiệm thu MCM 1.6.3 — source 018

1. Nạp ZIP 018 vào một AndroidForge workspace mới (không overlay workspace cũ).
2. Chạy duy nhất `bash scripts/androidforge-build-and-verify.sh`. Script tự kiểm tra cây nguồn và dependency graph Debug/Release, chạy JUnit + lint, build Debug/Release APK+AAB, xác minh package/version metadata và SHA-256.
3. Chỉ coi build đạt nếu script in `ANDROIDFORGE BUILD GATE PASS` và tạo đủ 4 artefact có checksum trong `app/build/mcm-acceptance/`.
4. Sau khi build đạt mới nghiệm thu trên thiết bị Android API 26+, rồi kiểm tra DNS, TCP, TLS hostname+pin, AUTH và READ_CHECK tách biệt cho REST HTTPS, API-SSL và WinBox.
5. Không suy rộng WinBox 8291 thành kết quả cho REST 443/API-SSL 8729. Chưa phát hành trước khi build và router live acceptance đều đạt.
