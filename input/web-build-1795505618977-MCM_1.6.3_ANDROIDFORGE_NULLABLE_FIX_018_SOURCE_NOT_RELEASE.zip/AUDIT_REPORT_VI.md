# Cập nhật kiểm toán MCM 1.6.3 — 23/11/2026

Bản audit lịch sử bên dưới phản ánh các mốc MCM 1.6.0–1.6.3 trước candidate hiện tại. Source hiện tại là `MCM-1.6.3-ANDROIDFORGE-GATED-BUILD-018`, lấy `MCM_1.6.3_DDNS_RECONCILED_007_SOURCE_NOT_RELEASE.zip` làm nền (SHA-256 `493cdf9ec77e15958073a63452e30fd3ea259a91e8a9bdd44ca35315584e6f96`). Chính sách TLS fail-closed yêu cầu exact SHA-256 pin, certificate validity và hostname SAN/CN phù hợp; pin được ràng buộc riêng theo service + WAN port. Rebuild 014 bổ sung WinBox CLI thành transport riêng trong luồng chính. Android Gradle build, APK và RouterOS WAN thực tế chưa được xác nhận trong runtime này.

---

# MCM 1.6.0 — Full source audit and implementation report

## Kết luận

Đã lấy source MCM 1.5.1 Direct-DDNS/Multi-Store mới nhất trong Library làm baseline, kiểm tra cấu trúc, các adapter RouterOS, phần profile/Room, UI form, chẩn đoán endpoint, foreground monitor, WorkManager và build scripts. Đã triển khai thay đổi source 1.6.0 để tách giao thức dịch vụ khỏi port và phiên bản RouterOS; không thay đổi cấu hình router thật.

**Trạng thái:** Engineering source / NOT RELEASE. Không có APK được build trong workspace hiện tại.

## Vấn đề được xử lý

1. Ở 1.5.1, port vốn đã là trường riêng per-router và được truyền đến DNS/TCP diagnostic, TLS inspector, REST/API-SSL client và background worker.
2. Nhưng giao thức thực tế bị suy ra cứng từ RouterOS major: ROS7 REST HTTPS, ROS6 API-SSL. UI không cho chọn protocol riêng.
3. `routerOs` change listener luôn ghi đè port về 443/8729, kể cả khi người dùng đã nhập port WAN tùy chỉnh.
4. Màn hình chưa giải thích rõ rằng TCP 8291 của WinBox không phải REST/API-SSL; việc WinBox kết nối thành công không chứng minh MCM có thể đọc dữ liệu.
5. Room profile chưa lưu protocol selection độc lập.

## Source changes 1.6.0

- Thêm `RouterServiceMode`: AUTO, REST_HTTPS, API_SSL và resolver protocol có kiểm tra tương thích.
- REST_HTTPS chỉ hợp lệ cho RouterOS 7; API_SSL cho RouterOS 6 hoặc 7; AUTO giữ hành vi cũ.
- `RouterEntity` thêm `connectionMode`; Room database nâng từ version 3 lên 4 bằng migration thêm cột `connectionMode TEXT NOT NULL DEFAULT 'AUTO'`.
- MainActivity và WorkManager đều đăng ký migration v3→v4.
- Profile save/list lưu và trả `connectionMode`, validate port là integer 1..65535.
- Monitoring foreground và background đều resolve cùng service mode và tiếp tục dùng port saved per profile.
- UI bổ sung service selector, WAN port editor, gợi ý port theo protocol, giữ port thủ công khi đổi OS/service, cảnh báo khi nhập 8291.
- DNS/TCP message phân biệt socket reachability với TLS/service/authentication.
- Thêm unit tests cho service resolution và nâng migration/UI contract checks.
- Cập nhật version 1.6.0 / versionCode 9, CI and AndroidForge version gates, tài liệu, changelog and package script.

## WinBox boundary — trạng thái lịch sử trước rebuild 014

Ở mốc 1.6.0 và source 007, MCM chưa triển khai giao thức WinBox; đổi port sang 8291 không thể biến REST/API-SSL thành WinBox. Rebuild 014 bổ sung `WINBOX_CLI` như một transport riêng dùng EC-SRP5/M2/mepty, chỉ áp dụng cho RouterOS 6.43 trở lên. Các cổng ngoài vẫn phải được NAT/forward tới đúng listener; MCM không tự tạo quy tắc NAT/firewall.

## Bảo toàn và an toàn

- Existing profiles migrate as AUTO; the DB migration leaves hostname, WAN port, RouterOS major, credentials alias, TLS pin, health fields and monitoring tables intact.
- Port/service changes are local profile metadata only. MCM does not mutate RouterOS services, firewall, NAT, DDNS, addresses or user accounts.
- TLS fingerprint remains mandatory; capture is not treated as trust until independently verified.
- At historical 1.6.0 stage: no plaintext API, HTTP fallback, WinBox protocol implementation, VPN, VPS or relay was added. Rebuild 014 later adds explicit encrypted WinBox CLI; it still adds no VPN/relay and does not change router configuration.

## Validation boundary

Source checks completed:
- AndroidForge flat-root project preflight: PASS.
- `scripts/verify-source.sh`: PASS for JS, Python compile, Room SQL migration preservation, DOM/port/protocol contract, shell syntax and Android XML.
- Room migration simulation: PASS for v1→v2→v3→v4, v2→v3→v4 and v3→v4.
- WebView contract: PASS (73 unique HTML IDs and 57 JS DOM lookups).
- Standalone `RouterServiceMode` Kotlin smoke tests: PASS with local kotlinc 1.9.0; this is not a complete application compile.
- Final source archive CRC and root layout: PASS; SHA-256 sidecar is supplied with the archive.

Not run / not verified:
- Full Gradle compilation, Room KAPT, Android JUnit tests, lint, APK assembly and APK signing.
- Physical Android installation, live WAN/DDNS reachability and RouterOS 6/7 hardware acceptance.

The workspace lacks Gradle 8.7 and Android SDK Platform 35, and has Java 21 rather than the required JDK 17. Therefore this package is engineering source / NOT RELEASE. Final source package and next steps are documented in `BUILD_STATUS.md` and `NEXT_ACTION_VI.md`.


## 1.6.3 DDNS TLS identity audit — 23/11/2026

**Root cause xác định trong source:** một pin SHA-256 dùng chung cho cả REST HTTPS và API-SSL có thể xác thực nhầm certificate giữa hai dịch vụ; đồng thời hostname verifier bị bypass hoàn toàn ở API-SSL và REST.

**Sửa:** pin được ràng buộc với transport đã xác nhận; AUTO không xác thực nhánh thứ hai nếu chưa có pin riêng, mà yêu cầu xác nhận fingerprint riêng khi cần chuyển nhánh. Cả REST và API-SSL đều bắt buộc hostname SAN/CN khớp DDNS/IP và certificate còn hiệu lực. UI hiển thị endpoint/protocol cần xác nhận và giữ log DNS/TCP/TLS/AUTH/READ_CHECK.

**Kiểm chứng cục bộ:** candidate này cần chạy lại source/static/UI/Room checks sau thay đổi. Không tuyên bố local TLS handshake với certificate CN/SAN sai hostname là hợp lệ; strict hostname verification phải từ chối endpoint đó. Android Gradle/APK và WAN/DDNS thực tế chưa được chạy.


## Audit delta — pin isolation + AUTO fallback reconciliation (23/11/2026)

The earlier 005 source still had only one `tlsSha256Pin` column. Although the coordinator selected a single active transport, the profile could not retain two different RouterOS certificates for `www-ssl` and `api-ssl`. That did not satisfy the per-service trust boundary. Candidate 006 uses Room v8 with four additional nullable fields: REST pin/port and API-SSL pin/port. The v7→v8 migration maps the previous pin only when the old active transport or fixed protocol mode identifies the service. An AUTO row without a recorded active transport is ambiguous: its legacy pin remains stored but is not reused, and the selected service must be explicitly confirmed again. Each foreground/background request demands the corresponding service + exact port pin.

AUTO previously offered fallback only for a narrow subset of connection errors and did not reuse a previously confirmed alternate-service pin. It now retries only for endpoint/protocol failure classes (including REST HTTP 404/format mismatch); it does not bypass AUTH or READ_DENIED. A previously accepted alternate pin is reused only when service and WAN port both match. Otherwise the app pauses for a separate explicit fingerprint confirmation. A changed alternate pin gets the same old/new fingerprint confirmation path.

The Android CI source identity gate is now fixed to candidate 007 (with candidate 006 retained as the previous security-hardening stage). The legacy API-SSL challenge-response path must terminate with `!done` before the socket is accepted.

**Current validation boundary:** SQL migration simulation v1→v8, WebView UI contract, source provenance, JS/Python/shell syntax, Android XML and AndroidForge source preflight are run locally. Focused Kotlin/JVM source compilation and local API-SSL/TLS mock tests cover modern/legacy login, API read-only gating, pin mismatch, SAN/IP/wildcard hostname matching, first-use fingerprint inspection and response-size guards. These tests use test doubles for Android/DNS dependencies and do not replace Android Gradle/JUnit. Full Kotlin/Gradle/KAPT project compilation, Android JUnit, lint, APK assembly, installation and RouterOS 6/7 WAN/DDNS acceptance are still NOT RUN because JDK 17 + Gradle 8.7 + SDK 35 are unavailable here. No working APK or live router connection is claimed.


### Foreground/background AUTO monitoring follow-through (23/11/2026)

The first AUTO reconciliation covered connection-time authentication but still left a gap during subsequent monitoring. The foreground monitor and WorkManager now share the same conservative failover rule: try the alternate only after endpoint/protocol failure and only if its own fingerprint was previously accepted for the exact WAN port. A successful alternate core read updates the profile's active transport/port and surfaces `AUTO_FALLBACK`/PARTIAL rather than silently reporting ONLINE. AUTH, READ_DENIED, TLS hostname/handshake/pin errors remain terminal. Single-router DNS failures now persist OFFLINE with their DNS-specific code; the background worker does likewise. This is source-level behavior pending full Android Gradle/device verification.

- Đối chiếu scope đã khóa: bỏ nhập IPv6 literal; vẫn giữ DNS A/AAAA cho DDNS/domain, không thêm chức năng ngoài kế hoạch.

- Siết quyền read-only ở tầng transport: REST chỉ GET các menu monitoring và POST `/ping` giới hạn; API-SSL chỉ nhận danh sách `/print` đã khai báo và `/ping` giới hạn. Lệnh thay đổi cấu hình, reboot, script và thuộc tính lạ bị chặn trước I/O mạng; thêm JUnit matrix cho allowlist.


## Candidate 006 — security boundary and operational reconciliation (23/11/2026)

- Room v8 persists independent REST/API-SSL pins and exact WAN ports.
- AUTO fallback now follows the same guarded policy in setup, refresh, Refresh All and WorkManager; only endpoint/protocol failures can qualify and no trust downgrade is performed.
- DNS failures are persisted as OFFLINE diagnostics.
- A transport-level command allowlist rejects all RouterOS operations outside monitoring reads and bounded ping. API-SSL parsing and row collection are bounded.
- Manual IPv6 literal entry is rejected; DNS names may still resolve AAAA records.
- The endpoint hostname verifier uses DNS SAN / IP SAN and legacy CN fallback only when no DNS SAN exists; the wildcard can match one left-most label only. REST, API-SSL and first-use certificate inspection share this verifier.
- REST response bodies are capped at 16 MiB / 10,000 rows; the WebView blocks non-packaged resource requests and clears the password field after the native request.
- Focused standalone Kotlin/JVM smoke and local API-SSL/TLS mock results are recorded in `BUILD_STATUS.md`. Full Gradle/JUnit/lint/APK and live RouterOS acceptance remain NOT RUN because the required toolchain and connected AndroidForge CI are unavailable here.


## Rebuild 014 — integrated WinBox CLI transport

Current source identity: `MCM-1.6.3-ANDROIDFORGE-GATED-BUILD-018`; parent is user-confirmed build baseline 007 (`MCM_1.6.3_DDNS_RECONCILED_007_SOURCE_NOT_RELEASE.zip`, SHA-256 `493cdf9ec77e15958073a63452e30fd3ea259a91e8a9bdd44ca35315584e6f96`).

- WINBOX_CLI has been added to the main transport enum/selection, save & connect, encrypted profile save, foreground snapshot collection and background core read.
- The adapter performs EC-SRP5 modern auth, derives stream keys, verifies M2 HMAC, opens mepty, answers VT100 cursor probes, uses terminal pulls/byte acknowledgements and waits for the RouterOS prompt before finishing each command.
- The read command set is fixed. Optional table parse/command errors are independent and produce PARTIAL; a lost prompt boundary halts subsequent reads. Ping is explicitly unavailable on WinBox.
- Focused JVM smoke checks pass (crypto vectors, AES/HMAC integrity, chunk boundary, ROS6 as-value parser and refusal/error cases). The connector/repository have been type-checked with temporary dependency signatures, not as an Android Gradle project.
- Lab assets reuse existing products: Containerlab CHR, GNS3/QEMU CHR6, CoreDNS, Toxiproxy/NetEm concepts, Android Emulator, Maestro and tik4net as independent reference client. No CHR image or proprietary binary is included.

### Acceptance gaps

This workspace has no Android SDK/Gradle/JDK17, Docker/Containerlab/QEMU, ADB/Android Emulator or Maestro. Accordingly, there is no Android APK, no actual emulator run, no live CHR EC-SRP5/auth/session test, and no public-DDNS test from an external network. A local source/crypto/parser smoke pass is not a substitute. Release remains blocked until those tests are performed.
