# AndroidForge — build MCM 1.6.3 source 018

## Why this revision exists

The latest AndroidForge log bundle (`AndroidForge-logs (4).zip`, 24 November 2026) contains three Gradle invocations: `assembleDebug`, `assembleRelease`, and `bundleDebug`. Every invocation passed `:app:verifyMcmRuntimeDependencies` with 134 resolved module-variant entries. The Release SDK dependency metadata contains no JSch, BouncyCastle, bcprov or `SshRouterOsClient` references. These runs did **not** fail at duplicate Java-resource merging.

All three runs stopped at Kotlin compilation with the same two errors in `RouterConnectionCoordinator.kt`: nullable `WinboxCliConnector.Result.resource` was passed to a non-null parser and was then dereferenced. Revision 018 repairs that exact issue, distinguishes missing `/system/resource/print` output from an unsupported RouterOS version, and adds regression coverage.

The earlier duplicate-resource/JSch/BouncyCastle incident remains the reason for keeping the fail-closed dependency guard and exact source-tree inventory. The current logs show that guard working: it passed, and the compiler exposed the next source defect. Revision 018 does not introduce SSH/JSch/BouncyCastle or use packaging exclusions to hide dependency collisions.

## One-time import and build

1. Create a fresh AndroidForge project/workspace. Do not extract over the old workspace.
2. Upload `MCM_1.6.3_ANDROIDFORGE_GATED_BUILD_018_SOURCE_NOT_RELEASE.zip` as the whole project root. The ZIP root must contain `settings.gradle.kts`, `build.gradle.kts`, `app/build.gradle.kts`, and `SOURCE_IDENTITY.txt`.
3. Ensure AndroidForge provides JDK 17, Gradle 8.7+ compatible with AGP 8.6.1 (workflow pinned to 8.9), Android SDK Platform 35, and Build Tools 35.0.0.
4. Run this one command from the extracted project root:

```bash
bash scripts/androidforge-build-and-verify.sh
```

The script runs the exact source preflight, resolves both Android runtime dependency graphs, runs clean/unit tests/lint, builds Debug and Release APK+AAB, validates APK package/version metadata, and writes build logs/checksums under `app/build/mcm-acceptance/`.

## How to interpret failure

- If preflight reports `UNEXPECTED`, `MISSING` or `HASH_MISMATCH`, the workspace does not exactly match the uploaded ZIP. Start from a fresh workspace; do not overlay files.
- If the dependency guard reports JSch or BouncyCastle, stop. Do not add packaging excludes; inspect which dependency or plugin introduced it.
- If the dependency guard passes and a later Gradle task fails, the error is a new build issue and must be fixed from that exact log.
- Only `ANDROIDFORGE BUILD GATE PASS` plus four newly produced artifacts and `SHA256SUMS.txt` count as build-gate success. Never use an older APK already present in the workspace.

## Scope not covered by the Android build gate

A successful Gradle build does not prove connectivity to the user's router. The separate live acceptance must test DNS system/DoH, TCP reachability, TLS identity/pin, authentication and read-only data retrieval independently for REST HTTPS, API-SSL and WinBox from the relevant external network. WinBox 8291 success does not imply REST 443 or API-SSL 8729 works. No router port check is being requested again here.

Baseline 007 (user-confirmed APK build success): SHA-256 `493cdf9ec77e15958073a63452e30fd3ea259a91e8a9bdd44ca35315584e6f96`. Integrated feature parent 014. Revision 018 remains **SOURCE_NOT_RELEASE** until both build and separate live-router acceptance pass.


## Lỗi build mới nhất và cách xử lý

AndroidForge logs ngày 24/11/2026 cho thấy dependency gate đã PASS; cả `assembleDebug`, `assembleRelease`, `bundleDebug` cùng thất bại tại `RouterConnectionCoordinator.kt` do `WinboxCliConnector.Result.resource` có kiểu `String?`. Source 018 đã thêm nhánh `WINBOX_RESOURCE_MISSING`, parser phiên bản null-safe và JUnit/JVM regression tests. Dùng ZIP 018 trong workspace mới, không chép đè lên workspace 017.
