# MCM 1.6.3 — AndroidForge nullable-resource repair 018

Source ID: `MCM-1.6.3-ANDROIDFORGE-GATED-BUILD-018`  
Previous source: `MCM-1.6.3-ANDROIDFORGE-GATED-BUILD-017`  
Integrated feature parent: `MCM-1.6.3-FULL-INTEGRATED-WINBOX-014`  
User-confirmed build-success baseline: `MCM_1.6.3_DDNS_RECONCILED_007_SOURCE_NOT_RELEASE.zip`  
Baseline SHA-256: `493cdf9ec77e15958073a63452e30fd3ea259a91e8a9bdd44ca35315584e6f96`  
Application ID: `com.multicloud.mcm` · Version `1.6.3` · versionCode `12`.

## Diagnosis from AndroidForge logs (24 November 2026)

The supplied log archive contains three actual Gradle runs: `assembleDebug`, `assembleRelease`, and `bundleDebug`. All three passed `:app:verifyMcmRuntimeDependencies` (134 resolved module-variant entries), then failed during Kotlin compilation. Each reports the same two errors in `RouterConnectionCoordinator.kt`: a nullable `WinboxCliConnector.Result.resource` (`String?`) was passed to a non-null parser at line 255, and dereferenced with `.take(800)` at line 262. The connector's `Result.resource` property is explicitly nullable.

The included Release SDK dependency metadata contains zero matches for JSch, BouncyCastle, bcprov and `SshRouterOsClient`. Thus the current logs do not show the earlier duplicate Java-resource merge failure; the dependency gate has passed and the blocker is a Kotlin nullability defect.

## Repair in 018

- Added a null-safe RouterOS version parser accepting `String?`.
- Missing or blank `/system/resource/print` data now returns `WINBOX_RESOURCE_MISSING` and a bounded diagnostic.
- Present but malformed/unsupported version data returns `WINBOX_VERSION_UNSUPPORTED` with bounded diagnostic text.
- Added Android JUnit regression tests for null, empty, missing-version, malformed, RouterOS 6 and RouterOS 7 data.
- Added standalone JVM smoke assertions and three regression guards.
- Preserved the 017 exact source-tree inventory, Debug+Release runtime dependency gate, and one-command AndroidForge build gate.
- No `!!`, dependency suppression, router write, or configuration change was introduced.

## Checks performed on 018

- AndroidForge source preflight: PASS.
- Exact source-tree integrity: PASS (138 files).
- Source provenance: PASS (137 hashes).
- Room migration verification v1→v8: PASS.
- Mobile UI contract: PASS (77 unique IDs, 60 JS lookups, 3 primary inputs).
- Build regression guards: PASS (22 assertions).
- Kotlin/JVM source smoke: PASS (48 assertions).
- WinBox crypto smoke: PASS (EC-SRP5, PTY, AES/HMAC/frame/tamper vectors).
- WinBox repository smoke: PASS (ROS6 parsing, field boundaries, CLI refusal, allowlist, nullable resource and ROS6/ROS7 version parsing).
- JavaScript, Python, shell and Android XML checks: PASS.

## Not yet proven

- Full Android Gradle/KAPT/JUnit/lint/Debug APK/Release APK/Debug AAB/Release AAB build: **not run in this authoring runtime** (Gradle and Android SDK Platform 35 are unavailable). A fresh AndroidForge build of source 018 is still required to confirm there are no further compiler/build errors after this fix.
- Android device/emulator install and RouterOS CHR 6/7 live integration: **not run**.
- External DDNS/WAN tests for REST HTTPS 443, API-SSL 8729 and WinBox 8291: **not run**.

**Release decision: SOURCE_NOT_RELEASE / NO-GO.** Source 018 fixes the precise compile errors visible in the supplied logs, but APK build success and router connectivity are not claimed.
