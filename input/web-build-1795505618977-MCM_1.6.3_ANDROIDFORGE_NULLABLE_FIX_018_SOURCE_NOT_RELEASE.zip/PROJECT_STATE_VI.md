# Trạng thái dự án MCM 1.6.3

- **Source hiện tại:** `MCM-1.6.3-ANDROIDFORGE-GATED-BUILD-018`.
- **Nền:** `MCM_1.6.3_DDNS_RECONCILED_007_SOURCE_NOT_RELEASE.zip` — người dùng xác nhận đây là mốc APK build thành công.
- **Mục tiêu bổ sung:** tích hợp WinBox CLI thật vào Save & Connect, lưu profile, refresh dashboard và background core check; không chỉ thêm nút probe rời.
- **Transport:** AUTO (REST HTTPS ROS7 / API-SSL ROS6), REST HTTPS, API-SSL và WINBOX_CLI (EC-SRP5/M2 TCP 8291, RouterOS 6.43+).
- **WinBox read-only:** identity/resource + các bảng interface, IP Cloud, PPP active, ARP, DHCP lease, Netwatch, Bridge Host, VLAN, Bridge VLAN. Các bảng lỗi riêng sẽ tạo PARTIAL; ping không hỗ trợ trên WinBox và không giả kết quả.
- **Phòng lab:** `lab/` có topology Containerlab CHR RouterOS 7, ví dụ CHR RouterOS 6 cho GNS3/QEMU, CoreDNS, script probe, Maestro flow mẫu.
- **Focused smoke:** `scripts/verify-winbox-smoke.sh` kiểm tra EC-SRP5 known-answer vector, stream-key vector, AES/HMAC, frame 14-chunk boundary, tamper rejection, ROS6 as-value parsing, list continuation, semicolon values, CLI error refusal và read-menu allowlist.

## Trạng thái xác minh trong workspace hiện tại

- WinBox connector standalone Kotlin/JVM compile: **PASS**.
- WinBox repository/connector compile có Android/coroutine/JSON signature stubs: **PASS** (chỉ kiểm tra type/signature; không thay Android build).
- WinBox crypto và repository parser smoke: **PASS** qua `scripts/verify-winbox-smoke.sh`.
- JavaScript syntax, Python syntax, shell syntax, XML, migration/UI/static regressions: PASS ở lượt xác minh đóng gói hiện tại. Kotlin/JVM smoke suite: 48 assertions PASS; WinBox crypto/repository smoke PASS.
- Android Gradle/JUnit/lint/APK/AAB: **NOT RUN** vì runtime không có Gradle 8.7, Android SDK 35 và JDK 17.
- Android Emulator/Maestro: **NOT RUN**.
- Containerlab/GNS3/QEMU CHR live test và public-DDNS VPS test: **NOT RUN** vì runtime không có Docker/Containerlab/QEMU/ADB.

**Quyết định:** chỉ phát hành source archive `SOURCE_NOT_RELEASE`; không tuyên bố đây là APK đã kiểm thử live. Bước đóng release cần chạy đầy đủ test Android và CHR lab trên host có toolchain.

- Build gate 018: dependency graph Debug/Release được kiểm tra trước preBuild; có script một-lệnh cho JUnit, lint, APK/AAB và hash/metadata.
- Trạng thái thực tế: SOURCE_NOT_RELEASE; Gradle/APK/live router chưa chạy trong runtime hiện tại.

- Build fix 018: đã sửa nullable WinBox resource output theo log AndroidForge; JUnit/JVM regression coverage đã thêm. APK build và router WAN/DDNS live vẫn chờ nghiệm thu AndroidForge.
