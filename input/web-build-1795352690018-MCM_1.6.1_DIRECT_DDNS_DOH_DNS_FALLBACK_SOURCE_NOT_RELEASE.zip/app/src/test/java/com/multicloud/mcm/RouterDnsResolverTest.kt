package com.multicloud.mcm

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test
import java.net.InetAddress
import java.net.UnknownHostException

class RouterDnsResolverTest {
    @Test
    fun usesAndroidResolverWhenItSucceeds() {
        val expected = InetAddress.getByAddress(byteArrayOf(115, 78, (-48), 58))
        var fallbackCalled = false
        val chain = SystemFirstDnsChain(
            systemLookup = { listOf(expected) },
            fallbackLookup = {
                fallbackCalled = true
                emptyList()
            }
        )

        val result = chain.resolve("router.example")

        assertEquals("ANDROID_SYSTEM", result.source)
        assertEquals(listOf(expected), result.addresses)
        assertTrue(!fallbackCalled)
    }

    @Test
    fun usesHttpsDnsWhenAndroidResolverFails() {
        val expected = InetAddress.getByAddress(byteArrayOf(115, 78, (-48), 58))
        val chain = SystemFirstDnsChain(
            systemLookup = { throw UnknownHostException("system DNS unavailable") },
            fallbackLookup = { listOf(expected) }
        )

        val result = chain.resolve("router.example")

        assertEquals("HTTPS_DOH_FALLBACK", result.source)
        assertEquals(listOf(expected), result.addresses)
    }

    @Test
    fun reportsFailureOnlyWhenBothResolversFail() {
        val chain = SystemFirstDnsChain(
            systemLookup = { throw UnknownHostException("system DNS unavailable") },
            fallbackLookup = { throw UnknownHostException("DoH unavailable") }
        )

        val error = assertThrows(UnknownHostException::class.java) {
            chain.resolve("router.example")
        }

        assertTrue(error.message.orEmpty().contains("Android DNS or HTTPS DNS fallback"))
        assertEquals(2, error.suppressed.size)
    }
}
