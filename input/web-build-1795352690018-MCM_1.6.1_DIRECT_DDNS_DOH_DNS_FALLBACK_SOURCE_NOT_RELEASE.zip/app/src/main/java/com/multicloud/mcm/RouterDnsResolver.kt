package com.multicloud.mcm

import java.net.InetAddress
import java.net.UnknownHostException
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLSocket

internal class SystemFirstDnsChain(
    private val systemLookup: (String) -> List<InetAddress>,
    private val fallbackLookup: (String) -> List<InetAddress>
) {
    fun resolve(host: String): RouterDnsResolver.Resolution {
        val systemFailure = try {
            val addresses = systemLookup(host).distinctBy { it.hostAddress }
            if (addresses.isNotEmpty()) return RouterDnsResolver.Resolution(addresses, "ANDROID_SYSTEM")
            UnknownHostException("Android resolver returned no addresses for $host")
        } catch (error: Exception) {
            error
        }

        val fallbackFailure = try {
            val addresses = fallbackLookup(host).distinctBy { it.hostAddress }
            if (addresses.isNotEmpty()) return RouterDnsResolver.Resolution(addresses, "HTTPS_DOH_FALLBACK")
            UnknownHostException("Encrypted DNS returned no A/AAAA records for $host")
        } catch (error: Exception) {
            error
        }

        throw UnknownHostException(
            "Could not resolve $host using Android DNS or HTTPS DNS fallback. " +
                "System=${systemFailure.javaClass.simpleName}; DoH=${fallbackFailure.message ?: fallbackFailure.javaClass.simpleName}."
        ).apply {
            addSuppressed(systemFailure)
            addSuppressed(fallbackFailure)
        }
    }
}

/** Shared router hostname resolution for diagnostics, REST, API-SSL and TLS inspection. */
object RouterDnsResolver {
    data class Resolution(val addresses: List<InetAddress>, val source: String)

    private val resolutionChain by lazy {
        SystemFirstDnsChain(
            systemLookup = { host -> InetAddress.getAllByName(host).toList() },
            fallbackLookup = DohDnsResolver::resolve
        )
    }

    fun resolve(rawHost: String): List<InetAddress> = resolveDetailed(rawHost).addresses

    fun resolveDetailed(rawHost: String): Resolution =
        resolutionChain.resolve(RouterHostValidator.normalize(rawHost))

    /** Preserve the original DDNS hostname as TLS SNI when the socket connects to a resolved IP. */
    fun configureSni(socket: SSLSocket, rawHost: String) {
        val host = RouterHostValidator.normalize(rawHost)
        if (isIpv4Literal(host)) return
        val parameters = socket.sslParameters
        parameters.serverNames = listOf(SNIHostName(host))
        socket.sslParameters = parameters
    }

    private fun isIpv4Literal(host: String): Boolean {
        val parts = host.split('.')
        return parts.size == 4 && parts.all { part ->
            part.toIntOrNull()?.let { it in 0..255 } == true
        }
    }
}
