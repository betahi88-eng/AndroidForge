package com.multicloud.mcm

import okhttp3.Dns
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException
import java.net.InetAddress
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

/** HTTPS DNS fallback with numeric bootstrap IPs and normally verified TLS provider identities. */
internal object DohDnsResolver {
    private data class Provider(
        val host: String,
        val path: String,
        val bootstrap: List<ByteArray>
    )

    private val providers = listOf(
        Provider(
            host = "dns.google",
            path = "/resolve",
            bootstrap = listOf(
                byteArrayOf(8, 8, 8, 8),
                byteArrayOf(8, 8, 4, 4),
                addressBytes(0x20, 0x01, 0x48, 0x60, 0x48, 0x60, 0, 0, 0, 0, 0, 0, 0, 0, 0x88, 0x88),
                addressBytes(0x20, 0x01, 0x48, 0x60, 0x48, 0x60, 0, 0, 0, 0, 0, 0, 0, 0, 0x88, 0x44)
            )
        ),
        Provider(
            host = "cloudflare-dns.com",
            path = "/dns-query",
            bootstrap = listOf(
                byteArrayOf(1, 1, 1, 1),
                byteArrayOf(1, 0, 0, 1),
                addressBytes(0x26, 0x06, 0x47, 0, 0x47, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x11, 0x11),
                addressBytes(0x26, 0x06, 0x47, 0, 0x47, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x10, 0x01)
            )
        )
    )

    private val http by lazy {
        OkHttpClient.Builder()
            .dns(Dns { hostname ->
                val provider = providers.firstOrNull { it.host.equals(hostname, ignoreCase = true) }
                if (provider == null) Dns.SYSTEM.lookup(hostname)
                else provider.bootstrap.map { address -> InetAddress.getByAddress(address) }
            })
            .connectTimeout(2, TimeUnit.SECONDS)
            .readTimeout(2, TimeUnit.SECONDS)
            .writeTimeout(2, TimeUnit.SECONDS)
            .callTimeout(4, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }

    fun resolve(host: String): List<InetAddress> {
        val results = linkedMapOf<String, InetAddress>()
        val providerErrors = mutableListOf<Exception>()

        for (provider in providers) {
            for (recordType in listOf("A", "AAAA")) {
                try {
                    query(provider, host, recordType, results)
                } catch (error: Exception) {
                    providerErrors += error
                }
            }
            if (results.isNotEmpty()) return results.values.toList()
        }

        throw UnknownHostException(
            "HTTPS DNS providers returned no usable A/AAAA record for $host: " +
                providerErrors.map { it.message ?: it.javaClass.simpleName }.distinct().joinToString("; ").take(280)
        ).apply { providerErrors.forEach { addSuppressed(it) } }
    }

    private fun query(
        provider: Provider,
        host: String,
        recordType: String,
        results: MutableMap<String, InetAddress>
    ) {
        val url = "https://${provider.host}${provider.path}".toHttpUrl().newBuilder()
            .addQueryParameter("name", host)
            .addQueryParameter("type", recordType)
            .build()
        val request = Request.Builder()
            .url(url)
            .header("Accept", "application/dns-json")
            .get()
            .build()

        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("${provider.host} returned HTTP ${response.code}")
            val body = response.body?.string()
                ?: throw IOException("${provider.host} returned an empty DNS response")
            val json = JSONObject(body)
            if (json.optInt("Status", -1) != 0) return
            val answers = json.optJSONArray("Answer") ?: return
            for (index in 0 until answers.length()) {
                val answer = answers.optJSONObject(index) ?: continue
                val address = parseAddress(answer.optString("data").trim(), answer.optInt("type")) ?: continue
                results.putIfAbsent(address.hostAddress, address)
            }
        }
    }

    private fun parseAddress(value: String, type: Int): InetAddress? = when (type) {
        1 -> parseIpv4(value)
        28 -> parseIpv6(value)
        else -> null
    }

    private fun parseIpv4(value: String): InetAddress? {
        val parts = value.split('.')
        if (parts.size != 4) return null
        val bytes = ByteArray(4)
        for (index in parts.indices) {
            val octet = parts[index].toIntOrNull() ?: return null
            if (octet !in 0..255) return null
            bytes[index] = octet.toByte()
        }
        return InetAddress.getByAddress(bytes)
    }

    private fun parseIpv6(value: String): InetAddress? {
        if (!value.contains(':') || !value.matches(Regex("[0-9a-fA-F:]+"))) return null
        return runCatching { InetAddress.getByName(value) }
            .getOrNull()
            ?.takeIf { it.address.size == 16 }
    }

    private fun addressBytes(vararg octets: Int): ByteArray =
        ByteArray(octets.size) { index -> octets[index].toByte() }
}
