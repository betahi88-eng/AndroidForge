package com.multicloud.mcm.security

import com.multicloud.mcm.RouterOs7Client
import com.multicloud.mcm.RouterDnsResolver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.SecureRandom
import java.net.InetSocketAddress
import java.security.cert.X509Certificate
import javax.net.ssl.SSLContext
import javax.net.ssl.X509TrustManager

/**
 * Reads a server certificate fingerprint for display only. This intentionally does not
 * authenticate the certificate; the user must compare it through a trusted independent
 * channel before saving it. Normal router sessions never use this permissive trust manager.
 */
object TlsFingerprintInspector {
    suspend fun inspect(host: String, port: Int): String = withContext(Dispatchers.IO) {
        require(host.matches(Regex("[A-Za-z0-9.-]+")) && port in 1..65535)
        val captureTrustManager = object : X509TrustManager {
            var leaf: X509Certificate? = null
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
            override fun checkClientTrusted(chain: Array<out X509Certificate>, authType: String) = Unit
            override fun checkServerTrusted(chain: Array<out X509Certificate>, authType: String) {
                leaf = chain.firstOrNull() ?: throw java.security.cert.CertificateException("No server certificate")
            }
        }
        val context = SSLContext.getInstance("TLS").apply {
            init(null, arrayOf(captureTrustManager), SecureRandom())
        }
        val addresses = try {
            RouterDnsResolver.resolve(host)
        } catch (error: java.net.UnknownHostException) {
            throw IllegalStateException("Không phân giải được $host bằng Android DNS hoặc DNS dự phòng HTTPS. Kiểm tra Internet/Private DNS và Cloud DDNS.", error)
        }
        var lastError: Exception? = null
        for (address in addresses) {
            val socket = context.socketFactory.createSocket() as javax.net.ssl.SSLSocket
            try {
                socket.connect(InetSocketAddress(address, port), CONNECT_TIMEOUT_MS)
                RouterDnsResolver.configureSni(socket, host)
                socket.soTimeout = READ_TIMEOUT_MS
                try {
                    socket.startHandshake()
                } catch (error: javax.net.ssl.SSLException) {
                    if (TlsErrorClassifier.isProtocolMismatch(error) || error is javax.net.ssl.SSLProtocolException) {
                        throw IllegalStateException("Cổng $port không phục vụ TLS/HTTPS. Kiểm tra đúng dịch vụ www-ssl (REST) hoặc api-ssl (API), port và NAT/firewall.", error)
                    }
                    throw IllegalStateException("TLS handshake thất bại tại $host:$port: ${error.message ?: "kiểm tra chứng chỉ và port"}", error)
                }
                val certificate = captureTrustManager.leaf
                    ?: throw IllegalStateException("Router không cung cấp chứng chỉ TLS.")
                return@withContext RouterOs7Client.sha256(certificate.encoded)
            } catch (error: java.net.ConnectException) {
                lastError = error
            } catch (error: java.net.SocketTimeoutException) {
                lastError = error
            } finally {
                runCatching { socket.close() }
            }
        }
        throw IllegalStateException(
            "Không kết nối được tới bất kỳ IP nào của $host:$port. Kiểm tra dịch vụ, NAT và firewall.",
            lastError
        )
    }

    private const val CONNECT_TIMEOUT_MS = 8_000
    private const val READ_TIMEOUT_MS = 8_000
}
