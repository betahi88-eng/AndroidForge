# MCM 1.6.1 implementation map

## Implemented in this engineering source

1. Native Android shell: Kotlin + WebView local assets.
2. Local Room storage and migration v1→v2→v3.
3. Multi-profile CRUD, site/Cloud grouping and independent connection settings.
4. Host validation for IPv4, DNS and IDN domains; MikroTik Cloud DDNS recognition.
5. Credential encryption with Android Keystore-backed AES-GCM and safe alias rotation.
6. TLS SHA-256 fingerprint inspection and fail-closed verification in normal clients.
7. RouterOS 7 REST client and RouterOS 6 API-SSL client.
8. Core metrics and independent packet-loss parsers.
9. Cloud DDNS status, PPPoE active sessions, ARP, DHCP leases and Netwatch snapshots.
10. Per-router status and errors, selected refresh and sequential refresh-all.
11. Local history and responsive WebView UI, including per-interface RX/TX time series and charts.
12. REST/API-SSL mock servers and unit tests for parsers/host validation.

## Not implemented / not release verified

- No MCM cloud backend or cloud sync; this is not required for multi-domain device management.
- No VPN, relay or agent; remote path must be direct public WAN DDNS.
- No push notifications, custom alert rules or Netwatch event history.
- No long-term ARP/DHCP device identity tracking.
- No chart export to CSV/PDF.
- No native IPv6 literal in host field.
- Android Gradle build, KAPT, unit tests through Gradle, lint, APK assembly and live hardware tests remain pending in an environment with full toolchain and devices.
