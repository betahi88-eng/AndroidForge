# MCM 1.6.1 — Test plan and acceptance matrix

This file separates source-level checks from Android, RouterOS and remote-network acceptance. A source ZIP cannot be declared release-ready just because static scripts pass.

## A. Source and packaging

- AndroidForge preflight detects flat-root Gradle/Android/Kotlin project.
- `node --check` all WebView JavaScript.
- `python3 scripts/verify-room-migrations.py` checks v1→v2→v3→v4, v2→v3→v4 and v3→v4 migration SQL preserves existing profile/metrics rows.
- `python3 scripts/verify-ui-contract.py` checks duplicate/missing DOM IDs referenced by WebView JavaScript.
- `python3 -m py_compile tools/*.py`.
- `bash -n` every shell script.
- Parse Android Manifest, styles and Network Security Config XML.
- ZIP CRC, root layout, forbidden Flutter markers, private keys and APK presence.
- `:app:testDebugUnitTest`, `:app:lintDebug`, `:app:assembleDebug` on JDK 17 / Gradle 8.7 / SDK 35.
- Verify APK package `com.multicloud.mcm`, version and SHA-256.

## B. Multi-Cloud profiles

- Create separate `.sn.mynetname.net`, custom DDNS/domain and IP profiles.
- Create multiple groups/sites and multiple routers inside each group.
- Confirm no host, credentials or TLS pins are copied between profiles.
- Edit name, group, host, custom WAN port (1–65535), RouterOS family, service protocol, username and pin.
- Edit with blank password preserves old secret; edit with new password rotates credential alias.
- Simulate Room write failure during credential rotation; old profile/secret remain usable.
- Delete profile removes that profile's metrics/counters and secret alias only.
- App restart preserves groups, profiles and status history.
- Upgrade v1/v2/v3 Room database to v4 without losing router profiles, custom ports, credentials, TLS pins or history.

- Change RouterOS/service selector after manually entering a custom port; custom port remains unchanged.
- AUTO resolves ROS7 to REST HTTPS and ROS6 to API-SSL; explicit API-SSL works with ROS6 and ROS7; explicit REST is rejected for ROS6.
- Save/reopen each profile and confirm selected service + custom port persist independently.
- Port 8291 reports TCP reachability only; TLS inspection/API read must fail when the endpoint is actually WinBox, never report RouterOS data success.

## C. RouterOS 7

- REST `www-ssl` reachable on correct host/port.
- Direct TLS certificate pin pass; mismatched pin fail closed.
- Test `UNSUPPORTED_PROTOCOL`, wrong HTTP port, timeout, DNS failure, refused port, bad credentials, insufficient read policy.
- Read `/system/resource`, `/interface`, `/ip/cloud`, `/ppp/active`, `/ip/arp`, `/ip/dhcp-server/lease`, `/tool/netwatch`.
- Test optional table permission denied: core dashboard remains available and status becomes PARTIAL.
- Ping success, partial loss, all-loss/incomplete counters, duplicate sequence and malformed rows.

- Test a custom WAN port NAT-forwarded to internal `www-ssl` and verify certificate pin remains correct.

## D. RouterOS 6

- `api-ssl` reachable at actual configured port (default 8729).
- Certificate pin mismatch and TLS protocol/port errors fail closed.
- Direct login and pre-6.43 legacy challenge-response login.
- Read system resource/interface/cloud/ppp active/ARP/DHCP lease/Netwatch.
- `!trap`, `!fatal`, `!empty`, disconnect, command timeout and missing `!done`.
- Ping with valid echo replies, partial loss, no replies after valid `!done`, duplicate/malformed/out-of-range sequences.
- Confirm the router is not overloaded by repeated sessions; app bounds concurrent commands to two.

- Test RouterOS 7 with explicit API-SSL service mode and a non-default WAN port.
- Test custom WAN port NAT-forwarded to internal `api-ssl`; verify background worker uses the same saved port and service mode.

## E. Dashboard and history

- Selected router refresh, 30-second visible refresh, app background/foreground.
- Refresh-all sequentially scans every saved router and preserves selected router snapshot.
- Per-router status `UNKNOWN/ONLINE/PARTIAL/OFFLINE`, timestamps and error details.
- CPU/RAM/interface rates, Cloud DDNS fields, PPPoE-only session count, ARP, DHCP, Netwatch.
- No-data/permission-denied/unsupported fields never become fake zero-valued success.
- History is separated by router ID; switch profiles and verify charts do not mix data.
- RX/TX interface history is separated by router and interface name; verify selected-interface charts load only matching counters and do not sum bridge/ether counters.
- First interface sample stores a counter baseline and does not report a fabricated Mbps value; counter reset/wrap/gap must not create a negative rate.
- Background worker records CPU/RAM only and respects retention.

## F. Remote DDNS network acceptance

For each remote site:
- Verify DDNS hostname resolves to the expected public IP/IPv6.
- Verify WAN routing/NAT and firewall path from the test network.
- Verify the endpoint port reaches the correct `www-ssl` (ROS7) or `api-ssl` (ROS6) service.
- Verify source-IP restriction and direct public WAN path; no VPN or relay.
- Test ISP dynamic IP change and DDNS convergence.
- Test CGNAT/double NAT and document when inbound connections cannot work.
- Confirm TLS certificate is valid for the hostname where hostname verification is used and pin matches independent export.

## G. Security and safety

- Password never appears in Room plaintext, WebView JSON or logs.
- Certificate mismatch blocks session; no fallback to HTTP or unpinned TLS.
- UI does not issue configuration writes.
- Inspect outbound API commands and confirm only read/print and bounded ping.
- No Internet-wide management exposure in sample configs.

## Current environment gate

The packaging container does not have a full Android Gradle toolchain or live MikroTik hardware. Therefore Android Gradle tests, Room KAPT, lint, APK assembly, physical Android installation and RouterOS live tests must be reported as NOT RUN until executed on appropriate infrastructure.


## MNDP discovery tests (preserved from 1.4.0)

- `MndpPacketParserTest.parsesIdentityMacVersionAndIpv4`: valid TLVs produce the expected MAC, identity, version and advertised IPv4.
- `MndpPacketParserTest.rejectsTruncatedTlv`: truncated TLV payload is rejected.
- Device acceptance: scan while connected to the same Wi-Fi/L2 segment as a MikroTik with MNDP enabled; confirm identity/MAC/IP, select it, verify the host is prefilled, and verify no profile is saved until credentials and TLS pin are supplied.
- Negative acceptance: discovery across a routed VLAN must return no claim of success; manual IP entry remains available.


## DNS resolution fallback (1.6.1)

- Android system resolver succeeds: confirm DoH is not called and result identifies `ANDROID_SYSTEM`.
- Android system resolver returns `UnknownHostException`: confirm Google DoH resolves A/AAAA and result identifies `HTTPS_DOH_FALLBACK`.
- Google DoH unavailable: confirm Cloudflare DoH is attempted.
- All resolvers unavailable: confirm result remains `DNS_FAILED` and includes the system/DoH failure detail.
- Confirm diagnostics and the real REST/API-SSL/fingerprint paths resolve the same DDNS hostname.
- Confirm the connected socket targets the returned IP while TLS SNI and REST Host remain the original hostname.
- Confirm DNS fallback never changes router services, ports, firewall, NAT, DDNS, IP addresses or credentials.
- Run these checks on Android using both mobile data and Wi-Fi; validate the exact router hostname and expected WAN address.
