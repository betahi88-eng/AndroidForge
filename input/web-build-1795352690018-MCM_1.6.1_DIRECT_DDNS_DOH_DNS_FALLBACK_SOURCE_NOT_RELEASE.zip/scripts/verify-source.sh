#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

for required in settings.gradle.kts build.gradle.kts app/build.gradle.kts app/src/main/AndroidManifest.xml; do
  test -s "$required" || { echo "Missing required Android project file: $required" >&2; exit 1; }
done
test -d app/src/main/java/com/multicloud/mcm
test ! -e pubspec.yaml
test ! -e harmony_patched
grep -q 'applicationId = "com.multicloud.mcm"' app/build.gradle.kts
grep -q 'versionName = "1.6.1"' app/build.gradle.kts
grep -q 'rootProject.name = "MikroTikMultiCloudMonitor"' settings.gradle.kts

command -v node >/dev/null || { echo "Node.js is required for UI syntax checks." >&2; exit 1; }
command -v python3 >/dev/null || { echo "Python 3 is required for mock syntax checks." >&2; exit 1; }
command -v bash >/dev/null

while IFS= read -r -d '' file; do node --check "$file"; done < <(find app/src/main/assets/www -type f -name '*.js' -print0)
python3 -m py_compile tools/*.py scripts/verify-room-migrations.py scripts/verify-ui-contract.py
python3 scripts/verify-room-migrations.py
python3 scripts/verify-ui-contract.py
python3 - <<'PYXML'
import xml.etree.ElementTree as ET
ET.parse('app/src/main/AndroidManifest.xml')
ET.parse('app/src/main/res/values/styles.xml')
ET.parse('app/src/main/res/xml/network_security_config.xml')
print('Android XML: PASS')
PYXML
while IFS= read -r -d '' file; do bash -n "$file"; done < <(find scripts -type f -name '*.sh' -print0)
echo "Static source checks passed (project identity, JavaScript, Python, shell and Android XML)."

SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if command -v gradle >/dev/null && [[ -n "$SDK_ROOT" && -f "$SDK_ROOT/platforms/android-35/android.jar" ]]; then
  gradle --no-daemon :app:testDebugUnitTest :app:lintDebug :app:assembleDebug
else
  echo "Android Gradle tests/lint/APK build SKIPPED: Gradle 8.7 and Android SDK Platform 35 are both required."
fi
