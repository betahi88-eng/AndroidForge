# MikroTik Multi-Cloud Monitor (MCM)

**Version:** 1.6.3 engineering source  
**License:** Apache-2.0  
**Platform:** Android 8.0+ (API 26+)  
**Stack:** Kotlin, local WebView assets, Room, Android Keystore, OkHttp, WorkManager

## MCM connects directly to multiple stores

MCM is an Android application that connects directly to each MikroTik through its own MikroTik IP Cloud DDNS hostname (`*.sn.mynetname.net`), another DDNS/domain name, or an IP address. Each profile stores its own endpoint, public/WAN-facing port, RouterOS version, service protocol, username, separate TLS SHA-256 pins per service and WAN port, encrypted password, health state and local history.

There is no MCM cloud backend, VPS, relay, VPN/WireGuard, router-side agent or account synchronization. Router profiles and monitoring history stay on the Android phone.

## Connection configuration — independent fields

| Field | User control | Meaning |
|---|---|---|
| Hostname | Editable | MikroTik Cloud DDNS, another DDNS/domain, or IP |
| WAN port | **Editable 1–65535 per router in Advanced** | The port the Android phone reaches from outside; for port forwarding this is the external/WAN port |
| RouterOS version | Detected from authenticated `/system/resource` | The app verifies RouterOS 6/7 from the real response; it is not a guessed UI field |
| Service protocol | **Independent selector** | Automatic, REST HTTPS, or RouterOS API-SSL |
| TLS SHA-256 | Read + verify + save | Fingerprint of the TLS certificate actually presented at the chosen host and port |
| Credentials | Per router | Username and password stored with Android Keystore-backed encryption |

`AUTO` preserves the historic defaults: RouterOS 7 → REST HTTPS / `www-ssl` / port 443; RouterOS 6 → RouterOS API-SSL / `api-ssl` / port 8729. These are suggestions only. The user may select API-SSL on RouterOS 6 or 7 and may enter a different WAN port. A manually edited port is not overwritten when the RouterOS or service selector changes; when editing an existing profile its saved port is always treated as user-owned, even if it equals a common default. Existing profiles are migrated as `AUTO`, preserving their current host, port, credentials and history.

**Important — WinBox is not an MCM transport.** TCP 8291 is normally the WinBox service. MCM does not implement the WinBox protocol. A successful WinBox login proves only that the WinBox service is reachable; it does not prove REST or API-SSL is reachable. Port 8291 can be used in MCM only if that endpoint actually serves, or is NAT-forwarded to, the selected REST HTTPS or API-SSL service.

## Supported service adapters

- **REST HTTPS:** RouterOS 7; uses HTTPS `/rest/...` read endpoints over `www-ssl`. Default suggestion: TCP 443.
- **RouterOS API-SSL:** RouterOS 6 or 7; uses the native RouterOS API protocol over TLS `api-ssl`. Default suggestion: TCP 8729. Includes current login and legacy challenge-response support.
- **Automatic:** REST HTTPS for RouterOS 7 and API-SSL for RouterOS 6.
- No WinBox protocol, plaintext API or HTTP fallback is implemented. AUTO performs initial parallel endpoint discovery and may fail over during setup or monitoring only for endpoint/protocol failures, after the alternate service has its own independently confirmed pin for the exact WAN port. AUTH, permission, certificate-validity, hostname and fingerprint failures never trigger fallback. An explicitly selected service is never silently switched.

The main Add Router form intentionally shows only DDNS/Hostname, Username and Password with one **Save & Connect** action. Service mode and WAN port are inside the closed-by-default Advanced section. In `AUTO`, a blank port probes REST/443 and API-SSL/8729 in parallel; a custom WAN port probes both supported protocols on that same external port. MCM then authenticates only the endpoint whose fingerprint was explicitly confirmed. If the preferred branch cannot pass TLS/READ_CHECK, the alternate branch requires its own fingerprint confirmation; certificates may differ between `www-ssl` and `api-ssl`. Explicit REST or API-SSL mode probes only the selected protocol. The exact port and actual protocol that passed TLS plus authenticated READ_CHECK are persisted separately from the requested `AUTO` preference. Foreground and background monitoring reuse the authenticated protocol; they do not re-guess REST/API-SSL from the RouterOS version.

## DNS resolution and fallback

- Router hostname lookup first uses Android system DNS. If it returns no address or throws `UnknownHostException`, MCM retries using DNS-over-HTTPS (DoH) with Google Public DNS and then Cloudflare 1.1.1.1. DoH bootstrap uses numeric IPv4/IPv6 resolver addresses, while HTTPS certificate/hostname verification for the DNS providers remains enabled.
- Diagnostics, REST HTTPS, API-SSL and TLS fingerprint inspection share the same resolver. REST preserves the original DDNS hostname for HTTP Host/SNI; raw TLS sockets connect to the resolved IP while sending the original hostname as SNI.
- The resolver reports which path succeeded. If both Android DNS and both HTTPS resolvers fail, MCM reports a DNS-stage failure with details rather than misreporting a TCP/port failure.
- DoH fallback sends the queried hostname to the selected public DNS provider. No router configuration is changed.

## Monitoring features

- Manage multiple stores/sites and multiple independent MikroTik profiles.
- Add, edit and remove routers; leaving the password blank during edit preserves the encrypted credential.
- Discover MikroTik neighbors on the same Layer-2 network using MNDP UDP/5678. Discovery does not automatically save a router or bypass TLS verification.
- Per-router UNKNOWN / ONLINE / PARTIAL / OFFLINE status, last checked time and concrete error information.
- DNS + TCP endpoint diagnostics, TLS fingerprint inspection, protocol selection and authenticated RouterOS read diagnostics.
- CPU, RAM, RouterOS version, uptime, interface state and per-interface RX/TX rates from counter deltas.
- MikroTik IP Cloud DDNS state, DNS name and WAN address details where supported by the RouterOS version and permissions.
- PPPoE active sessions, ARP, DHCP lease, Netwatch, Bridge Host, VLAN interface and Bridge VLAN snapshots.
- Bounded ICMP packet-loss probe. Interface throughput is not misrepresented as per-device bandwidth or packet loss.
- Local metric history and charts; refresh-all checks routers sequentially so one failed store does not stop the others.
- Android Keystore + AES-256-GCM credential storage. Passwords and authorization headers are not exposed to JavaScript or logs.
- REST requires RouterOS `read,api,rest-api`; API-SSL requires `read,api`. Add the `test` policy only when using MCM's bounded ping tool; without it, the other read-only monitoring remains available. Never grant `write`, `policy` or `reboot` to the monitoring account.

## Direct DDNS network requirements

MikroTik Cloud DDNS resolves the hostname to the public address reported by the router. DDNS does not open a port, create NAT, bypass CGNAT/double NAT, or provide a relay. The chosen public/WAN port must reach the selected RouterOS service. If an upstream modem performs NAT, its port-forward must lead to the right internal `www-ssl` or `api-ssl` listener. Use firewall source restrictions and a dedicated least-privilege read-only account; do not expose management ports to the entire Internet.

If the store is behind CGNAT or inbound traffic is blocked by the ISP, direct DDNS access cannot work merely by changing the port field. MCM deliberately does not create a VPN or relay to bypass that constraint.

## TLS and fingerprint safety

- The pin is the SHA-256 hash of the leaf TLS certificate presented at the chosen hostname and port.
- The in-app fingerprint reader only captures/displays the certificate. The operator must compare it through a trusted independent channel before saving.
- Every session checks the saved pin; a mismatch fails closed.
- A self-signed certificate is accepted only when its exact leaf pin is independently confirmed, its validity window is current, and its SAN/CN matches the DDNS hostname/IP. A pin never bypasses hostname verification.

## Read-only boundary

MCM does not create, edit or delete RouterOS configuration; does not change IP, DDNS, firewall, NAT, services or users; and does not reboot a router. Both transport clients enforce a central command allowlist: REST accepts only the required monitoring GET paths, API-SSL accepts only the required `/print` commands, and POST is limited to bounded ping. The API decoder also limits word/sentence sizes and record count. No other RouterOS command is sent.

## Build and status

- Project: native Android Gradle/Kotlin; application ID `com.multicloud.mcm`.
- Version: `1.6.3` / versionCode `12`.
- Toolchain: JDK 17, Gradle 8.7, Android Gradle Plugin 8.6.1, Kotlin 2.0.21, SDK 35.
- Run `./scripts/androidforge-preflight.sh` and `./scripts/verify-source.sh` before uploading the ZIP.
- Then run `:app:testDebugUnitTest`, `:app:lintDebug`, `:app:assembleDebug` and `:app:bundleDebug` in AndroidForge or a correctly provisioned Android build environment.

This candidate is **engineering source — NOT RELEASE**. Its current source identity is `MCM-1.6.3-DDNS-RECONCILED-006`. It does not contain an APK or production signing key. Full Gradle/KAPT/JUnit/lint/APK assembly, physical Android use and live RouterOS 6/7 tests are not claimed until those checks run on the required toolchain and hardware.


### TLS identity model

MCM requires two independent TLS identity checks: the exact RouterOS leaf-certificate SHA-256 pin confirmed by the operator, and a certificate SAN/CN hostname match for the DDNS hostname used by SNI/HTTP Host. A pin never bypasses hostname or certificate-validity checks. Each saved pin is bound to its own transport and WAN port; REST HTTPS and API-SSL are never authenticated using one another's fingerprint. If AUTO needs the alternate transport, MCM requests a separate fingerprint confirmation for that endpoint. A changed or mismatched pin fails closed.
