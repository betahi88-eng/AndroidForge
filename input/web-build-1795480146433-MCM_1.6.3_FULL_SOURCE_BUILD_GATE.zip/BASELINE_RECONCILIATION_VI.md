# MCM 1.6.3 — Baseline and build-regression reconciliation

## Locked source lineage

- Stable baseline: `AndroidForge_MCM_1.6.3_SAMPLE_PROJECT_BUILD_FIX_002.zip`
- Baseline SHA-256: `7e5872d18df840f7367de787d7f15818191bd2402612efa1fe2162c96cd6337a`
- Integration stage: `MCM_1.6.3_DDNS_RECONCILED_005_SOURCE_NOT_RELEASE.zip`
- Integration-stage SHA-256: `be09a41a4ca9ab7325553c400b8e5ecc5b309817a549e2239c4f94199c2380cf`
- Current source candidate: `MCM-1.6.3-DDNS-RECONCILED-006`

Candidate 005 explicitly records FIX_002 as its parent and completes the previously disconnected Advanced WAN-port/service-mode path. Candidate 006 carries that path forward and adds the later TLS/read-only/response-bound hardening. This is a traceable lineage from FIX_002, not a claim that candidate 006 itself has passed Android Gradle build.

## Historical AndroidForge log correlation

- `AndroidForge-logs (2).zip`: `Dns does not have constructors` in `DohDnsResolver.kt` and an inference error in `RouterOs7Client.kt`. These diagnostics are not present in the FIX_002 baseline: both files use `.dns(object : Dns { ... })`. The log archive does not carry a source ZIP hash, so it cannot establish which exact archive was compiled.
- `AndroidForge-logs (6).zip` and `AndroidForge-logs (7).zip`: both report the same four Kotlin compiler diagnostics (`unresolved reference port` and cascading `put`) at the two call sites in `RouterConnectionCoordinator.kt`. In log (7), `assembleDebug`, `bundleDebug` and `assembleRelease` all stop at `compile*Kotlin`; the runner reports Gradle 8.9 rather than the pinned 8.7. The recorded working directory is the project workspace root, so this is not the separate nested-Repair-Kit working-directory failure found in log (4). The diagnostics match the older `DERIVED_PATCH_001` call sites. FIX_002 does not contain those expressions; candidate 006 has no `selected.port` expression and persists the exact authenticated branch port via `successful.port`. The log archives do not contain a source ZIP hash, so they cannot prove which exact archive AndroidForge compiled.
- `AndroidForge-logs (4).zip`: Gradle was launched from the nested Repair Kit directory rather than the MCM project root. That package is not the application source ZIP. The current archive keeps `settings.gradle.kts`, `build.gradle.kts`, `app/build.gradle.kts`, and `app/src/main/AndroidManifest.xml` at ZIP root.

## Functional integration retained

- Native Android Kotlin/Gradle app, `com.multicloud.mcm`, version 1.6.3 / code 12.
- RouterOS 6/7 adapters: REST HTTPS and API-SSL; AUTO selection and explicit mode.
- Per-router DDNS/hostname, credentials, service mode and user-entered WAN port (1–65535); AUTO default ports 443/8729; custom port passed UI → bridge → coordinator → TLS probe → authenticated read → Room profile.
- Foreground/background monitoring reuse the saved port and active transport.
- Android DNS → Google DoH → Cloudflare DoH fallback.
- Per-service/per-port TLS pinning, hostname validation, certificate validity checks, fail-closed behavior and explicit trust confirmation.
- Read-only monitoring and bounded ping; no router configuration writes.
- Multi-router profiles, history/charts, diagnostics, MNDP discovery and sequential Refresh All.
- Three primary Add Router fields; Advanced section closed by default.

## Verification performed for this rebased package

- AndroidForge project-root/preflight: PASS.
- Room migration simulation v1→v8: PASS.
- UI contract: PASS (75 unique DOM IDs, three primary inputs, Advanced closed).
- JavaScript, Python, shell and Android XML syntax: PASS.
- Source provenance hashes: PASS.
- Historical build regression guard: PASS (11 assertions for DoH syntax, `selected.port` removal, WAN port/service-mode wiring, Room v8 pins and foreground/background endpoint reuse).
- ZIP CRC/root layout/SHA-256: checked during packaging.

## Not verified — do not claim release success

No Android Gradle/KAPT compile, Android JUnit task, lint, `assembleDebug`, APK manifest validation, emulator/phone install, or live RouterOS WAN acceptance of candidate 006 was run in this environment. The historical log (7) is a failed build of an unverified source snapshot, not a build result for candidate 006. The required JDK 17, Gradle 8.7 and Android SDK Platform/Build Tools 35 are not installed, and toolchain download is unavailable. No APK is included. The exact successful build cannot be established from the supplied historical logs; a clean AndroidForge build of this exact ZIP is still the acceptance gate.
