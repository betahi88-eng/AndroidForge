# AndroidForge — hướng dẫn nạp đúng source MCM 1.6.3

## Gói cần nạp

Dùng nguyên tệp `MCM_1.6.3_FULL_SOURCE_BUILD_GATE.zip` và đối chiếu checksum bằng tệp `.sha256` đi kèm ở ngoài ZIP. Source ID bên trong phải là `MCM-1.6.3-DDNS-RECONCILED-006`.

Đây là ZIP mã nguồn Android native ở dạng project-root, **không phải Repair Kit, không phải APK và chưa phải bản release đã xác minh**. Không dùng các gói `AndroidForge_MCM_1.6.3_FULL_DELIVERY.zip`, `AndroidForge_MCM_1.6.3_ZIP_TO_APK_HARDENED_002.zip` hoặc source candidate lịch sử làm đầu vào thay thế.

## Kiểm tra trước khi chạy

1. Giải nén trực tiếp ZIP vào thư mục project root.
2. Xác nhận `settings.gradle.kts`, `build.gradle.kts`, `app/build.gradle.kts` và `app/src/main/AndroidManifest.xml` nằm ngay tại root.
3. Xác nhận AndroidForge nhận đúng project native Gradle, module `:app`, source ID `MCM-1.6.3-DDNS-RECONCILED-006`.
4. Không chạy Gradle từ thư mục cha hoặc thư mục Repair Kit.

## Toolchain và tác vụ bắt buộc

Toolchain khóa: JDK 17, Gradle 8.7, AGP 8.6.1, Kotlin 2.0.21, Android SDK Platform 35 và Build Tools 35.0.0. ZIP không kèm Gradle Wrapper; runner cần cung cấp Gradle 8.7 và dùng lệnh `gradle`, không dùng `./gradlew`.

Thứ tự nghiệm thu build:

```bash
gradle --no-daemon clean
gradle --no-daemon :app:testDebugUnitTest
gradle --no-daemon :app:lintDebug
gradle --no-daemon :app:assembleDebug :app:bundleDebug
gradle --no-daemon :app:assembleRelease :app:bundleRelease
```

Tất cả tác vụ phải hoàn tất với exit code 0. Không bỏ qua lỗi, không đổi phiên bản toolchain để ép build, không lấy APK tồn tại từ lần chạy trước. Kiểm tra cả Debug APK và Release APK bằng `aapt dump badging`; Release APK là unsigned cho tới khi chủ sở hữu cung cấp khóa ký an toàn.

## Xác minh artifact

Thu Debug APK và Release APK mới từ đúng workspace/run, kiểm tra package `com.multicloud.mcm`, versionName `1.6.3`, versionCode `12`, variant, asset provenance và SHA-256. Debug APK phải debug-signed để cài thử; Release APK unsigned không được gọi là bản phát hành cài đặt cuối cùng. Lưu build log cùng checksum để truy ngược chính xác source đã build. Build pass vẫn chưa thay thế cho kiểm thử cài đặt trên Android và kết nối RouterOS 6/7 thực tế.

## Ranh giới trạng thái

Các kiểm tra source tĩnh, Room migration, UI contract, regression guard và ZIP integrity đã chạy. Android Gradle/KAPT, Android JUnit, lint, APK assembly, cài đặt thiết bị và WAN/DDNS acceptance chưa được xác nhận trong môi trường tạo gói này. Không đánh dấu release hoặc tuyên bố APK hoạt động cho tới khi các cổng nghiệm thu trên đạt.
