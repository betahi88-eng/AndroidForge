"use strict";

let activeConnectionAttemptId = null;

function statusLabel(status) {
  switch (status) {
    case "READY": return "Đã xác thực · sẵn sàng";
    case "READY_LIMITED": return "Đã kết nối · giới hạn quyền";
    case "ONLINE": return "Đang đọc đủ dữ liệu";
    case "PARTIAL": return "Kết nối · thiếu một số mục";
    case "OFFLINE": return "Lỗi kết nối/đọc dữ liệu";
    default: return "Chưa kiểm tra";
  }
}

function endpointLabel(router) {
  if (router.endpointKind === "MIKROTIK_CLOUD") return "MIKROTIK CLOUD";
  if (router.endpointKind === "DDNS_DOMAIN") return "DDNS / DOMAIN";
  return "IP DIRECT";
}

function renderRouters() {
  const list = $("routerList");
  $("routerCount").textContent = String(state.routers.length);
  list.replaceChildren();
  if (state.routers.length === 0) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = "Chưa có Cloud/domain. Thêm kết nối MikroTik đầu tiên.";
    list.append(empty);
    state.selectedId = null;
    clearDashboard();
    $("refreshBtn").disabled = true;
    $("removeBtn").disabled = true;
    $("editBtn").disabled = true;
    $("refreshAllBtn").disabled = true;
    $("selectedName").textContent = "Chưa chọn thiết bị";
    $("selectedMeta").textContent = "Mỗi domain được quản lý độc lập";
    return;
  }
  if (!state.routers.some((router) => router.id === state.selectedId)) {
    state.selectedId = state.routers[0].id;
    clearDashboard();
  }
  const grouped = new Map();
  for (const router of state.routers) {
    const groupName = router.siteName || "Mặc định";
    if (!grouped.has(groupName)) grouped.set(groupName, []);
    grouped.get(groupName).push(router);
  }
  for (const [groupName, routers] of grouped) {
    const group = document.createElement("section");
    group.className = "router-group";
    const heading = document.createElement("h3");
    heading.textContent = groupName;
    group.append(heading);
    for (const router of routers) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = `router-item${router.id === state.selectedId ? " active" : ""}`;
      const title = document.createElement("b");
      title.textContent = router.name;
      const meta = document.createElement("span");
      const activeTransport = router.activeTransport || (router.connectionMode === "API_SSL" || (router.connectionMode === "AUTO" && Number(router.routerOsMajor) === 6) ? "API_SSL" : "REST_HTTPS");
      const serviceLabel = activeTransport === "API_SSL" ? "API-SSL" : "REST HTTPS";
      meta.textContent = `${router.host}:${router.port} · RouterOS ${router.routerOsVersion || router.routerOsMajor} · ${serviceLabel}`;
      const badge = document.createElement("em");
      badge.textContent = endpointLabel(router);
      const health = document.createElement("small");
      health.className = `router-health ${String(router.lastStatus || "UNKNOWN").toLowerCase()}`;
      const checkedValue = Number(router.lastCheckedAt);
      const checked = Number.isFinite(checkedValue) && checkedValue > 0
        ? new Date(checkedValue).toLocaleString()
        : "Chưa kiểm tra";
      health.textContent = `${statusLabel(router.lastStatus)} · ${checked}`;
      if (router.lastErrorCode || router.lastErrorMessage) {
        health.title = `${router.lastErrorCode || ""} ${router.lastErrorMessage || ""}`.trim();
      }
      button.append(title, meta, badge, health);
      button.addEventListener("click", () => {
        if (state.selectedId !== router.id) clearDashboard();
        state.selectedId = router.id;
        renderRouters();
        renderSelectedMeta();
        refreshSelected();
      });
      group.append(button);
    }
    list.append(group);
  }
  const locked = state.refreshAllBusy;
  $("refreshBtn").disabled = locked;
  $("removeBtn").disabled = locked;
  $("editBtn").disabled = locked;
  $("refreshAllBtn").disabled = locked;
  $("showAddBtn").disabled = locked;
  renderSelectedMeta();
}

function renderSelectedMeta() {
  const router = state.routers.find((item) => item.id === state.selectedId);
  if (!router) return;
  $("selectedName").textContent = router.name;
  const activeTransport = router.activeTransport || (router.connectionMode === "API_SSL" || (router.connectionMode === "AUTO" && Number(router.routerOsMajor) === 6) ? "API_SSL" : "REST_HTTPS");
  const serviceLabel = activeTransport === "API_SSL" ? "API-SSL" : "REST HTTPS";
  $("selectedMeta").textContent = `${router.siteName || "Mặc định"} · ${router.host}:${router.port} · ${serviceLabel} · RouterOS ${router.routerOsVersion || router.routerOsMajor} · ${router.username}`;
}

async function loadRouters() {
  const result = await nativeCall("listRouters");
  if (!result.ok) throw new Error(result.error || "Không đọc được danh sách Cloud/router.");
  state.routers = Array.isArray(result.routers) ? result.routers : [];
  renderRouters();
}

function resetRouterForm() {
  $("routerForm").reset();
  $("formTitle").textContent = "Thêm Router";
  $("routerPassword").required = true;
  $("routerPassword").placeholder = "Mật khẩu RouterOS";
  $("routerConnectionMode").value = "AUTO";
  $("routerPort").value = "";
  $("routerAdvancedOptions").open = false;
  $("connectionProgress").hidden = true;
  $("connectionLogsContent").hidden = true;
  $("connectionLogsContent").replaceChildren();
  activeConnectionAttemptId = null;
}

function showPanel(show) {
  $("addPanel").hidden = !show;
  if (show) $("routerHost").focus();
  if (!show) resetRouterForm();
}

function editSelectedRouter() {
  const router = state.routers.find((item) => item.id === state.selectedId);
  if (!router) return;
  resetRouterForm();
  $("formTitle").textContent = `Kết nối lại ${router.name}`;
  $("routerHost").value = router.host;
  $("routerUsername").value = router.username;
  $("routerPassword").required = true;
  $("routerConnectionMode").value = router.connectionMode || "AUTO";
  $("routerPort").value = String(router.port || "");
  showPanel(true);
}

function setConnectionProgress(message) {
  $("connectionProgress").hidden = false;
  $("connectionProgressText").textContent = message;
}

function closeConnectionDialog() {
  const dialog = $("connectionDialog");
  if (dialog.open) dialog.close();
  $("connectionDialogActions").replaceChildren();
}

function showConnectionDialog(title, message, fingerprintText, actions) {
  $("connectionDialogTitle").textContent = title;
  $("connectionDialogMessage").textContent = message;
  const fingerprint = $("connectionDialogFingerprints");
  fingerprint.hidden = !fingerprintText;
  fingerprint.textContent = fingerprintText || "";
  const container = $("connectionDialogActions");
  container.replaceChildren();
  for (const action of actions) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = `button ${action.primary ? "" : "ghost"}`;
    button.textContent = action.label;
    button.addEventListener("click", action.run, { once: true });
    container.append(button);
  }
  const dialog = $("connectionDialog");
  if (!dialog.open) dialog.showModal();
}

async function connectRouter(event) {
  event.preventDefault();
  const host = $("routerHost").value.trim();
  const username = $("routerUsername").value.trim();
  let password = $("routerPassword").value;
  const mode = $("routerConnectionMode").value || "AUTO";
  const rawPort = $("routerPort").value.trim();
  const port = rawPort ? Number(rawPort) : 0;
  if (!host || !username || !password) return toast("Nhập DDNS/Hostname, username và password.");
  if (rawPort && (!Number.isInteger(port) || port < 1 || port > 65535)) return toast("Cổng WAN phải là số nguyên từ 1 đến 65535.");
  const button = $("connectSubmitBtn");
  if (button.disabled) return;
  button.disabled = true;
  setConnectionProgress("Đang kết nối…");
  try {
    const result = await nativeCall("connectRouter", host, username, password, port, mode);
    // The native coordinator now owns the short-lived credential for TLS confirmation;
    // do not leave it in the WebView form or this async function after the bridge returns.
    password = "";
    $("routerPassword").value = "";
    await handleConnectionResult(result);
  } catch (error) {
    $("connectionProgress").hidden = true;
    toast(error.message || "Không thể kết nối Router.");
  } finally {
    password = "";
    $("routerPassword").value = "";
    button.disabled = false;
  }
}

async function handleConnectionResult(result) {
  const stateName = result.state || "ERROR";
  if (stateName === "FIRST_TIME_PIN") {
    $("connectionProgress").hidden = true;
    activeConnectionAttemptId = result.attemptId;
    showConnectionDialog(
      "Xác nhận TLS lần đầu",
      `${result.host || $("routerHost").value}:${result.port || "cổng đã dò"} · ${result.protocol || "dịch vụ được dò"}. ${result.message || "Đối chiếu SHA-256 của đúng endpoint này qua kênh tin cậy trước khi xác nhận."}`,
      `${result.fingerprint}\n\n${result.diagnostics ? JSON.stringify(result.diagnostics, null, 2) : ""}`,
      [
        { label: "Hủy", run: cancelPendingConnection },
        { label: "Xác nhận lần đầu", primary: true, run: confirmPendingConnection }
      ]
    );
    return;
  }
  if (stateName === "TLS_CHANGED" && result.attemptId) {
    $("connectionProgress").hidden = true;
    activeConnectionAttemptId = result.attemptId;
    showConnectionDialog(
      "Thay đổi chứng chỉ TLS",
      `Chứng chỉ của endpoint ${result.host || $("routerHost").value}:${result.port || "cổng đã dò"} · ${result.protocol || "dịch vụ đã lưu"} đã thay đổi. Đối chiếu fingerprint cũ và mới của đúng dịch vụ này qua kênh tin cậy trước khi cập nhật.`,
      `Fingerprint cũ:
${result.oldFingerprint}

Fingerprint mới:
${result.newFingerprint}

Chẩn đoán:
${result.diagnostics ? JSON.stringify(result.diagnostics, null, 2) : "Không có trace"}`,
      [
        { label: "Hủy", run: cancelPendingConnection },
        { label: "Tin tưởng & cập nhật", primary: true, run: confirmPendingConnection }
      ]
    );
    return;
  }
  if (stateName === "PORTS_UNREACHABLE") {
    $("connectionProgress").hidden = true;
    showConnectionDialog(
      "Không kết nối được tới cổng nào",
      result.message || "Kiểm tra dịch vụ, WAN port, NAT và firewall của Router.",
      result.diagnostics ? JSON.stringify(result.diagnostics, null, 2) : null,
      [
        { label: "Đóng", run: closeConnectionDialog },
        { label: "Sao chép nhật ký", primary: true, run: () => {
          const trace = result.diagnostics ? JSON.stringify(result.diagnostics, null, 2) : result.message || "Không có trace";
          if (navigator.clipboard?.writeText) navigator.clipboard.writeText(trace).then(() => toast("Đã sao chép nhật ký."), () => toast("Không thể sao chép; hãy chụp màn hình."));
          else toast("Hãy chụp màn hình nhật ký.");
        } }
      ]
    );
    return;
  }
  if (stateName === "READY_LIMITED") {
    activeConnectionAttemptId = null;
    $("connectionProgress").hidden = true;
    showConnectionDialog("Thiếu quyền đọc", "Đã xác thực Router, nhưng tài khoản chưa có đủ quyền đọc dữ liệu. Profile được lưu ở chế độ giới hạn; monitoring bị ẩn.", null, [
      { label: "OK", primary: true, run: async () => { closeConnectionDialog(); await finishConnectedRouter(result); } }
    ]);
    return;
  }
  if (stateName === "READY") {
    activeConnectionAttemptId = null;
    $("connectionProgress").hidden = true;
    showConnectionDialog(
      "Đã kết nối",
      `${result.host}
RouterOS ${result.routerOsVersion} · ${result.protocol} · ${result.latencyMs}ms`,
      null,
      [{ label: "Vào Dashboard", primary: true, run: async () => { closeConnectionDialog(); await finishConnectedRouter(result); } }]
    );
    return;
  }
  $("connectionProgress").hidden = true;
  if (stateName === "TLS_CHANGED") {
    toast("Fingerprint thay đổi trong lúc xác thực. Đã dừng để bảo vệ profile; hãy kết nối lại và xác nhận chứng chỉ mới.");
    return;
  }
  const diagnosticText = result.diagnostics ? JSON.stringify(result.diagnostics, null, 2) : [
    `State: ${stateName}`,
    `REST: ${result.restResult || "—"} · ${result.restMessage || "—"}`,
    `API-SSL: ${result.apiSslResult || "—"} · ${result.apiSslMessage || "—"}`
  ].join("\n");
  showConnectionDialog(
    "Kết nối thất bại · nhật ký chẩn đoán",
    result.message || `Kết nối thất bại: ${stateName}`,
    diagnosticText,
    [
      { label: "Đóng", run: closeConnectionDialog },
      { label: "Sao chép nhật ký", primary: true, run: () => {
        if (navigator.clipboard?.writeText) {
          navigator.clipboard.writeText(diagnosticText)
            .then(() => toast("Đã sao chép nhật ký."))
            .catch(() => toast("Không thể sao chép; hãy chụp màn hình nhật ký."));
        } else {
          toast("Thiết bị không hỗ trợ sao chép; hãy chụp màn hình nhật ký.");
        }
      } }
    ]
  );
}

async function confirmPendingConnection() {
  closeConnectionDialog();
  const attemptId = activeConnectionAttemptId;
  if (!attemptId) return;
  setConnectionProgress("Đang xác thực và thực hiện READ_CHECK trên giao thức đã dò…");
  try {
    const result = await nativeCall("confirmConnection", attemptId, "TRUST");
    activeConnectionAttemptId = null;
    await handleConnectionResult(result);
  } catch (error) {
    activeConnectionAttemptId = null;
    $("connectionProgress").hidden = true;
    toast(error.message || "Không thể tiếp tục xác thực.");
  }
}

async function cancelPendingConnection() {
  closeConnectionDialog();
  const attemptId = activeConnectionAttemptId;
  activeConnectionAttemptId = null;
  if (attemptId) await nativeCall("cancelConnection", attemptId).catch(() => {});
  $("connectionProgress").hidden = true;
  $("routerPassword").value = "";
}

async function finishConnectedRouter(result) {
  resetRouterForm();
  $("addPanel").hidden = true;
  await loadRouters();
  if (result.id) state.selectedId = result.id;
  renderRouters();
  renderSelectedMeta();
  const router = state.routers.find((item) => item.id === state.selectedId);
  if (router?.accessLevel === "LIMITED") {
    clearDashboard();
    setStatus("Đã kết nối · Thiếu quyền đọc", "warn");
    $("warnings").hidden = false;
    $("warnings").textContent = "Router đã xác thực nhưng tài khoản chưa có quyền đọc system/resource. Dashboard monitoring được ẩn cho đến khi tài khoản được cấp quyền phù hợp.";
  } else if (state.selectedId) {
    refreshSelected();
  }
  toast("Profile Router đã được lưu an toàn.");
}

async function openConnectionLogs() {
  const selected = state.routers.find((item) => item.id === state.selectedId);
  if (!selected) return toast("Chọn một Router để mở nhật ký kết nối.");
  const panel = $("connectionLogsContent");
  panel.hidden = false;
  panel.textContent = "Đang đọc nhật ký…";
  try {
    const result = await nativeCall("connectionLogs", selected.id);
    if (!result.ok) throw new Error(result.error || "Không đọc được nhật ký.");
    panel.replaceChildren();
    const logs = Array.isArray(result.logs) ? result.logs : [];
    if (!logs.length) {
      panel.textContent = "Chưa có nhật ký kết nối cho profile này.";
      return;
    }
    for (const item of logs) {
      const entry = document.createElement("article");
      entry.className = "connection-log-entry";
      const heading = document.createElement("b");
      heading.textContent = `${new Date(item.attemptedAt).toLocaleString()} · ${item.finalState} · ${item.durationMs}ms`;
      const details = document.createElement("small");
      const restTrace = item.restProbeDetails || {};
      const apiTrace = item.apiSslProbeDetails || {};
      details.textContent = `DNS ${item.dnsResolver || "—"} · IP ${(item.resolvedIps || []).join(", ") || "—"} · REST ${item.restResult} (${item.restAuthDurationMs || 0}ms auth) · API-SSL ${item.apiSslResult} (${item.apiSslAuthDurationMs || 0}ms auth) · Chọn ${item.selectedProtocol || "—"}`;
      const trace = document.createElement("small");
      trace.textContent = `${restTrace.port || 443}: TCP ${restTrace.tcpResult || "—"}, TLS ${restTrace.tlsResult || "—"}, ${restTrace.tcpDurationMs || 0}/${restTrace.tlsDurationMs || 0}ms, SHA-256 ${restTrace.fingerprintSha256 || "—"} · ${apiTrace.port || 8729}: TCP ${apiTrace.tcpResult || "—"}, TLS ${apiTrace.tlsResult || "—"}, ${apiTrace.tcpDurationMs || 0}/${apiTrace.tlsDurationMs || 0}ms, SHA-256 ${apiTrace.fingerprintSha256 || "—"}`;
      const note = document.createElement("p");
      note.textContent = item.detail || "";
      entry.append(heading, details, trace, note);
      panel.append(entry);
    }
  } catch (error) {
    panel.textContent = error.message || "Không đọc được nhật ký.";
  }
}

async function removeSelected() {
  const router = state.routers.find((item) => item.id === state.selectedId);
  if (!router || !window.confirm(`Gỡ “${router.name}” (${router.host}) khỏi MCM?`)) return;
  try {
    const result = await nativeCall("removeRouter", router.id);
    if (!result.ok) throw new Error(result.error || "Không gỡ được router.");
    await loadRouters();
    if (state.selectedId) refreshSelected();
    toast("Đã gỡ router và lịch sử cục bộ.");
  } catch (error) {
    toast(error.message);
  }
}


async function refreshAllRouters() {
  if (state.refreshAllBusy || state.routers.length === 0) return;
  if (state.refreshing) return toast("Đang làm mới router đang chọn. Thử kiểm tra tất cả sau khi hoàn tất.");
  state.refreshAllBusy = true;
  const button = $("refreshAllBtn");
  const summary = $("refreshAllSummary");
  button.disabled = true;
  $("refreshBtn").disabled = true;
  $("editBtn").disabled = true;
  $("removeBtn").disabled = true;
  $("showAddBtn").disabled = true;
  button.textContent = "Đang kiểm tra từng Cloud…";
  summary.textContent = "Đang kết nối tuần tự; không gửi đồng thời lệnh tới mọi router.";
  try {
    const result = await nativeCall("refreshAllRouters", $("pingTarget").value.trim(), state.selectedId || "");
    if (!result.ok) throw new Error(result.error || "Không kiểm tra được danh sách router.");
    await loadRouters();
    summary.textContent = `Tổng ${result.total}: ${result.online} đầy đủ · ${result.partial} thiếu dữ liệu phụ · ${result.offline} lỗi · ${result.limited || 0} giới hạn quyền.`;
    if (result.selectedSnapshot && state.selectedId) {
      renderSnapshot(result.selectedSnapshot);
      const warnings = result.selectedSnapshot.warnings || [];
      setStatus(warnings.length ? "Đã kết nối · thiếu dữ liệu phụ" : "Đã kết nối", warnings.length ? "warn" : "good");
      await loadHistory();
    } else if (state.selectedId) {
      const selectedResult = (result.results || []).find((item) => item.id === state.selectedId);
      if (selectedResult && !selectedResult.ok) {
        clearDashboard();
        if (selectedResult.status === "READY_LIMITED") {
          setStatus("Router đang chọn · Thiếu quyền đọc", "warn");
          summary.textContent += " Router đang chọn đã được xác thực, monitoring bị ẩn do thiếu quyền đọc.";
        } else {
          setStatus("Router đang chọn OFFLINE · Dữ liệu cũ đã được ẩn", "bad");
          summary.textContent += ` Router đang chọn: ${selectedResult.error || "không kết nối được"}.`;
        }
      }
    }
    toast("Đã kiểm tra xong các Cloud/router.");
  } catch (error) {
    summary.textContent = error.message;
    toast(error.message);
  } finally {
    state.refreshAllBusy = false;
    button.disabled = state.routers.length === 0;
    $("refreshBtn").disabled = !state.selectedId;
    $("editBtn").disabled = !state.selectedId;
    $("removeBtn").disabled = !state.selectedId;
    $("showAddBtn").disabled = false;
    button.textContent = "↻ Kiểm tra tất cả Cloud";
    renderRouters();
  }
}


async function discoverMikroTik() {
  const button = $("discoverBtn");
  const panel = $("discoveryPanel");
  const results = $("discoveryResults");
  panel.hidden = false;
  results.replaceChildren();
  const loading = document.createElement("p");
  loading.className = "empty";
  loading.textContent = "Đang dò MNDP trong mạng Wi-Fi hiện tại…";
  results.append(loading);
  button.disabled = true;
  try {
    const response = await nativeCall("discoverMikroTik");
    if (!response.ok) throw new Error(response.error || "Không thể dò thiết bị trong LAN.");
    results.replaceChildren();
    const devices = Array.isArray(response.devices) ? response.devices : [];
    if (devices.length === 0) {
      const empty = document.createElement("p");
      empty.className = "empty";
      empty.textContent = "Không tìm thấy thiết bị MNDP. Kiểm tra cùng VLAN/Wi-Fi, quyền multicast và Neighbor Discovery trên MikroTik; có thể nhập IP thủ công.";
      results.append(empty);
      return;
    }
    for (const device of devices) {
      const card = document.createElement("article");
      card.className = "discovery-item";
      const heading = document.createElement("b");
      heading.textContent = device.identity || "MikroTik";
      const detail = document.createElement("small");
      detail.textContent = [device.advertisedIp || device.ip, device.board, device.version,
        device.interface, device.uptime, device.mac, device.advertisedIpv6].filter(Boolean).join(" · ");
      const choose = document.createElement("button");
      choose.type = "button";
      choose.className = "button secondary";
      choose.textContent = "Dùng thiết bị này";
      choose.addEventListener("click", () => {
        resetRouterForm();
        $("routerHost").value = device.advertisedIp || device.ip || "";
        showPanel(true);
        $("discoveryPanel").hidden = true;
        toast("Đã điền thông tin phát hiện. Hãy nhập tài khoản, mật khẩu và xác minh TLS.");
      });
      card.append(heading, detail, choose);
      results.append(card);
    }
  } catch (error) {
    results.replaceChildren();
    const failure = document.createElement("p");
    failure.className = "empty";
    failure.textContent = error.message || "Dò LAN thất bại.";
    results.append(failure);
  } finally {
    button.disabled = false;
  }
}



// Android Back closes the dialog; pending trust attempts must be cancelled as well.
const connectionDialog = $("connectionDialog");
connectionDialog.addEventListener("cancel", (event) => {
  event.preventDefault();
  if (activeConnectionAttemptId) cancelPendingConnection();
  else closeConnectionDialog();
});
