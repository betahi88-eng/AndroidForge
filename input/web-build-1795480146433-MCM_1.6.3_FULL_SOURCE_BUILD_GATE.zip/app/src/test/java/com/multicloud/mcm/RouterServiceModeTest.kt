package com.multicloud.mcm

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Test

class RouterServiceModeTest {
    @Test fun autoUsesConventionalPortsInParallelWhenPortIsBlank() {
        assertEquals(RouterProbePorts(443, 8729), RouterServiceMode.AUTO.probePorts(0))
    }

    @Test fun autoUsesTheSameCustomWanPortForBothProtocolProbes() {
        assertEquals(RouterProbePorts(18443, 18443), RouterServiceMode.AUTO.probePorts(18443))
    }

    @Test fun explicitRestUsesOnlyRestAtCustomOrDefaultPort() {
        assertEquals(RouterProbePorts(443, null), RouterServiceMode.REST_HTTPS.probePorts(0))
        assertEquals(RouterProbePorts(2443, null), RouterServiceMode.REST_HTTPS.probePorts(2443))
    }

    @Test fun explicitApiSslUsesOnlyApiSslAtCustomOrDefaultPort() {
        assertEquals(RouterProbePorts(null, 8729), RouterServiceMode.API_SSL.probePorts(0))
        assertEquals(RouterProbePorts(null, 18729), RouterServiceMode.API_SSL.probePorts(18729))
    }

    @Test fun invalidStoredModeFallsBackToAutoButInvalidUserModeIsRejected() {
        assertEquals(RouterServiceMode.AUTO, RouterServiceMode.fromStorage("LEGACY"))
        assertThrows(IllegalArgumentException::class.java) { RouterServiceMode.fromUserInput("WINBOX") }
    }

    @Test fun rejectsInvalidPortsAndWinboxMode() {
        assertThrows(IllegalArgumentException::class.java) { RouterServiceMode.AUTO.probePorts(65536) }
        assertThrows(IllegalArgumentException::class.java) { RouterServiceMode.AUTO.probePorts(-1) }
        assertThrows(IllegalArgumentException::class.java) { RouterServiceMode.fromUserInput("WINBOX") }
    }

    @Test fun autoPrefersRouterOsNativeProtocolButFallsBackToTheOtherAuthenticatedTransport() {
        assertEquals(RouterTransport.REST_HTTPS,
            RouterServiceMode.AUTO.selectAuthenticatedTransport(7, restAuthenticated = true, apiSslAuthenticated = true))
        assertEquals(RouterTransport.API_SSL,
            RouterServiceMode.AUTO.selectAuthenticatedTransport(7, restAuthenticated = false, apiSslAuthenticated = true))
        assertEquals(RouterTransport.API_SSL,
            RouterServiceMode.AUTO.selectAuthenticatedTransport(6, restAuthenticated = true, apiSslAuthenticated = true))
        assertEquals(RouterTransport.REST_HTTPS,
            RouterServiceMode.AUTO.selectAuthenticatedTransport(6, restAuthenticated = true, apiSslAuthenticated = false))
        assertNull(RouterServiceMode.AUTO.selectAuthenticatedTransport(7, restAuthenticated = false, apiSslAuthenticated = false))
    }

    @Test fun explicitTransportNeverSilentlyFallsBack() {
        assertNull(RouterServiceMode.REST_HTTPS.selectAuthenticatedTransport(7, false, true))
        assertNull(RouterServiceMode.API_SSL.selectAuthenticatedTransport(7, true, false))
        assertThrows(IllegalArgumentException::class.java) {
            RouterServiceMode.REST_HTTPS.selectAuthenticatedTransport(6, true, true)
        }
    }

    @Test fun autoMonitoringUsesTheTransportThatActuallyPassedReadCheck() {
        assertEquals(RouterTransport.API_SSL, RouterServiceMode.AUTO.resolveForProfile(7, "API_SSL"))
        assertEquals(RouterTransport.REST_HTTPS, RouterServiceMode.AUTO.resolveForProfile(7, "REST_HTTPS"))
        assertEquals(RouterTransport.REST_HTTPS, RouterServiceMode.AUTO.resolveForProfile(7, null))
        assertEquals(RouterTransport.API_SSL, RouterServiceMode.AUTO.resolveForProfile(6, null))
        assertEquals(RouterTransport.REST_HTTPS, RouterServiceMode.REST_HTTPS.resolveForProfile(7, "API_SSL"))
    }


    @Test fun autoFallbackIsLimitedToEndpointOrProtocolFailures() {
        assertEquals(true, canTryAlternateTransport(RouterServiceMode.AUTO, "HTTP_404", false, true))
        assertEquals(true, canTryAlternateTransport(RouterServiceMode.AUTO, "NETWORK_TIMEOUT", false, true))
        assertEquals(true, canTryAlternateTransport(RouterServiceMode.AUTO, "TIMEOUT", false, true))
        assertEquals(true, canTryAlternateTransport(RouterServiceMode.AUTO, "CONNECT_REFUSED", false, true))
        assertEquals(true, canTryAlternateTransport(RouterServiceMode.AUTO, "TLS_PROTOCOL", false, true))
        assertEquals(true, canTryAlternateTransport(RouterServiceMode.AUTO, "API_PROTOCOL", false, true))
        assertEquals(true, canTryAlternateTransport(RouterServiceMode.AUTO, "NETWORK", false, true))
        assertEquals(false, canTryAlternateTransport(RouterServiceMode.AUTO, "AUTH_FAILED", false, true))
        assertEquals(false, canTryAlternateTransport(RouterServiceMode.AUTO, "READ_DENIED", false, true))
        assertEquals(false, canTryAlternateTransport(RouterServiceMode.AUTO, "TLS_FINGERPRINT_MISMATCH", false, true))
        assertEquals(false, canTryAlternateTransport(RouterServiceMode.AUTO, "TLS_HOSTNAME", false, true))
        assertEquals(false, canTryAlternateTransport(RouterServiceMode.AUTO, "TLS_CERT_VALIDITY", false, true))
        assertEquals(false, canTryAlternateTransport(RouterServiceMode.AUTO, "TLS_HANDSHAKE", false, true))
        assertEquals(false, canTryAlternateTransport(RouterServiceMode.AUTO, "HTTP_404", true, true))
        assertEquals(false, canTryAlternateTransport(RouterServiceMode.AUTO, "HTTP_404", false, false))
        assertEquals(false, canTryAlternateTransport(RouterServiceMode.API_SSL, "NETWORK_TIMEOUT", false, true))
    }

    @Test fun connectionFailureNormalizationKeepsProtocolMismatchSeparateFromCertificateFailures() {
        assertEquals("TLS_PROTOCOL", normalizeTransportFailureCode("TLS_PROTOCOL"))
        assertEquals("TLS_HOSTNAME", normalizeTransportFailureCode("TLS_HOSTNAME"))
        assertEquals("TLS_CERT_VALIDITY", normalizeTransportFailureCode("TLS_CERT_VALIDITY"))
        assertEquals("TLS_HANDSHAKE", normalizeTransportFailureCode("TLS_HANDSHAKE"))
        assertEquals("TLS_CHANGED", normalizeTransportFailureCode("TLS_FINGERPRINT_MISMATCH"))
        assertEquals("NETWORK_TIMEOUT", normalizeTransportFailureCode("TIMEOUT"))
        assertEquals("TCP_REFUSED", normalizeTransportFailureCode("CONNECT_REFUSED"))
    }

    @Test fun autoResolvesRouterOsAndExplicitApiSslWorksOnBoth() {
        assertEquals(RouterTransport.REST_HTTPS, RouterServiceMode.AUTO.resolve(7))
        assertEquals(RouterTransport.API_SSL, RouterServiceMode.AUTO.resolve(6))
        assertEquals(RouterTransport.API_SSL, RouterServiceMode.API_SSL.resolve(7))
        assertEquals(RouterTransport.API_SSL, RouterServiceMode.API_SSL.resolve(6))
        assertNull(RouterServiceMode.REST_HTTPS.probePorts(443).apiSslPort)
        assertThrows(IllegalArgumentException::class.java) { RouterServiceMode.REST_HTTPS.resolve(6) }
    }
}
