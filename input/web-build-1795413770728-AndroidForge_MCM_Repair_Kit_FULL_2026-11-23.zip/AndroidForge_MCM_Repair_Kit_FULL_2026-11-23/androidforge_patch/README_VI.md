# Bộ sửa AndroidForge để build MCM 1.6.3 đúng source

**Phân loại:** bộ vá kỹ thuật / chưa phải bản phát hành APK. Không thay đổi router, MikroTik, DNS, DDNS hay dữ liệu trên điện thoại.

## 1. Vấn đề đã xác định

1. `scripts/acquire_zip.py` trước đây lấy ZIP đầu tiên trong `input/` khi không có `zip_path`. Nếu thư mục có nhiều ZIP, AndroidForge có thể build nhầm dự án.
2. Log Flutter trong `harmony_patched` là một lần build khác, không phải MCM native. Log đó thất bại do Flutter yêu cầu Gradle 8.14 trong khi image đang dùng Gradle 8.9.
3. Log native MCM báo `RouterOs7Repository.kt:37:65`. Dòng gọi `row.stringValue("type").orEmpty()` giống nhau trong source 1.5.1, 1.6.0 và 1.6.1. Kotlin standard library định nghĩa `String?.orEmpty()` từ Kotlin 1.0; vì vậy lỗi ở dòng này không chứng minh DNS fallback là nguyên nhân. Source 1.6.2/1.6.3 đã chuyển logic đó sang `RouterOs7InterfaceParser.kt` với giá trị mặc định null-safe. Bộ vá khóa đúng archive 1.6.3 này bằng SHA-256 để chặn source cũ hoặc source bị thay đổi.
4. Workflow cũ có thể tiếp tục thu thập APK sau build lỗi. Nó không ràng buộc APK được thu với package/version của source đang build.
5. Bước self-heal chung có thể sửa các file Gradle. MCM cần được giữ nguyên source và dùng cấu hình toolchain riêng.

## 2. Nội dung bộ vá

- `scripts/acquire_zip.py`: từ chối tự chọn khi `input/` có 0 hoặc nhiều hơn 1 ZIP; bắt buộc path chính xác. Kiểm tra ZIP/CRC và ghi SHA-256.
- `scripts/validate_mcm_source.py`: so SHA-256 của ZIP đã tải với file đã giải nén; kiểm tra `SOURCE_IDENTITY.txt`, native Gradle, applicationId, versionName/versionCode; từ chối Flutter/harmony và parser cũ. Bản vá này còn pin đúng SHA-256 của archive MCM 1.6.3 đã đối chiếu.
- `scripts/configure_mcm_toolchain.py`: MCM dùng JDK 17 và Gradle 8.7 trở lên; cấu hình không sửa source.
- `scripts/collect_apk.py`: với MCM chỉ thu đúng `app/build/outputs/apk/debug/app-debug.apk`; đọc manifest bằng `apkanalyzer` hoặc `aapt`; bắt buộc đúng package và version; ghi SHA-256. Generic project vẫn giữ dạng output tương thích build summary cũ.
- `patch_androidforge_workflow.py`: cập nhật workflow theo các cổng kiểm tra trên, tạo file `.bak`, không sửa trực tiếp `main` từ ChatGPT.
- `MCM_SOURCE/`: source MCM 1.6.3 đã đồng bộ tài liệu versionCode.

## 3. Cách áp dụng

1. Giải nén bộ vá này.
2. Clone repository `anhtranmng-sys/AndroidForge` về máy. Chưa thay đổi `main`.
3. Trước khi thay đổi repository, chạy bộ test đi kèm trong thư mục vừa giải nén bộ vá:

   ```bash
   python3 -m unittest discover -s tests -p 'test_*.py' -v
   ```

   Kết quả mong đợi: **14/14 PASS**. Test này kiểm tra ZIP selection, checksum, identity MCM, toolchain, APK manifest và việc patch workflow trên fixture.
4. Chép `patch_androidforge_workflow.py` vào root repository; chép 4 file trong `scripts/` đè/thêm vào `scripts/` của AndroidForge. Sau đó chạy từ root repository:

   ```bash
   python3 patch_androidforge_workflow.py
   git diff --check
   git diff
   ```

   Script tạo backup `.github/workflows/build-android.yml.bak`; nếu cấu trúc workflow khác với baseline đã kiểm tra, script sẽ dừng thay vì tự vá một phần.
5. Chép ZIP trong `MCM_SOURCE/` vào `input/` của AndroidForge và commit source + bộ vá vào một branch riêng.
6. Chạy workflow **Build Android APK** với các lựa chọn:
   - `zip_source`: `input-directory`
   - `zip_path`: `input/MCM_1.6.3_RECONCILED_DDNS_KOTLIN_SOURCE_NOT_RELEASE_FIXED.zip`
   - `project_profile`: `mcm-native`
   - `build_variant`: `debug`
7. Chỉ chấp nhận kết quả khi Actions hoàn tất các task `:app:clean`, `:app:testDebugUnitTest`, `:app:lintDebug`, `:app:assembleDebug` và bước thu thập APK xác minh đúng `com.multicloud.mcm`, `1.6.3`, versionCode `12`.

MCM được ép build debug; lựa chọn build variant chung không thể khiến MCM chạy sang Flutter, release hoặc bundle. Nếu source sai, hash sai, parser cũ, cấu hình Gradle không đúng, test/lint/compile lỗi hoặc APK manifest sai thì workflow phải thất bại.

## 4. Toolchain

MCM source dùng AGP 8.6.1, Kotlin 2.0.21, compileSdk 35 và JDK 17. AGP 8.6 yêu cầu Gradle tối thiểu 8.7 và JDK 17; AndroidForge image có Gradle 8.9/JDK 17 là phù hợp. Không dùng Gradle 8.9 cho Flutter project có yêu cầu 8.14; đó là luồng build riêng.

## 5. Trạng thái xác minh

- MCM 1.6.3 preflight: PASS.
- MCM source checks, Room migration checks, WebView contract checks và XML checks: PASS.
- ZIP CRC và SHA-256: PASS.
- Bộ kiểm thử bộ vá cục bộ: 14/14 PASS.
- Android Gradle build/APK thật: **chưa chạy trong môi trường hiện tại** vì không có Android SDK/Gradle 8.7+ tại đây. Không tuyên bố đã có APK.
- GitHub connector từ phiên làm việc này vẫn trả HTTP 403 khi tạo branch. Vì vậy chưa thể tự commit bộ vá hoặc kích hoạt Actions trên repository từ ChatGPT.

## 6. Bảo toàn dữ liệu

Bộ vá chỉ thay đổi mã nguồn workflow/build trong AndroidForge và tài liệu source MCM. Không sửa RouterOS, cấu hình mạng, DDNS, DNS trên router, credential MCM hoặc database trên điện thoại.
