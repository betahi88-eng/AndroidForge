from __future__ import annotations

import importlib.util
import json
import os
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest import mock

PATCH_ROOT = Path(__file__).resolve().parents[1]
REPO = PATCH_ROOT.parent
sys.path.insert(0, str(PATCH_ROOT / "scripts"))


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


acquire = load_module("acquire_zip", PATCH_ROOT / "scripts" / "acquire_zip.py")
collector = load_module("collect_apk", PATCH_ROOT / "scripts" / "collect_apk.py")
validator = load_module("validate_mcm_source", PATCH_ROOT / "scripts" / "validate_mcm_source.py")
configure = load_module("configure_mcm_toolchain", PATCH_ROOT / "scripts" / "configure_mcm_toolchain.py")
patcher = load_module("patch_androidforge_workflow", PATCH_ROOT / "patch_androidforge_workflow.py")


class AcquireZipTests(unittest.TestCase):
    def make_zip(self, path: Path) -> None:
        with zipfile.ZipFile(path, "w") as archive:
            archive.writestr("marker.txt", path.name)

    def test_ambiguous_input_directory_fails_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            input_dir = root / "input"
            input_dir.mkdir()
            self.make_zip(input_dir / "first.zip")
            self.make_zip(input_dir / "second.zip")
            with mock.patch.object(acquire, "INPUT_DIR", input_dir), mock.patch.object(acquire, "REPO_ROOT", root):
                with self.assertRaisesRegex(RuntimeError, "Ambiguous"):
                    acquire.select_input_zip(None)

    def test_single_input_zip_is_selected(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            input_dir = root / "input"
            input_dir.mkdir()
            candidate = input_dir / "only.zip"
            self.make_zip(candidate)
            with mock.patch.object(acquire, "INPUT_DIR", input_dir), mock.patch.object(acquire, "REPO_ROOT", root):
                self.assertEqual(candidate, acquire.select_input_zip(None))

    def test_explicit_path_outside_input_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            input_dir = root / "input"
            input_dir.mkdir()
            outside = root / "source.zip"
            self.make_zip(outside)
            with mock.patch.object(acquire, "INPUT_DIR", input_dir), mock.patch.object(acquire, "REPO_ROOT", root):
                with self.assertRaisesRegex(RuntimeError, "inside input"):
                    acquire.select_input_zip(str(outside))

    def test_corrupt_zip_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            input_dir = root / "input"
            input_dir.mkdir()
            corrupt = input_dir / "bad.zip"
            corrupt.write_bytes(b"not a zip")
            with mock.patch.object(acquire, "INPUT_DIR", input_dir), mock.patch.object(acquire, "REPO_ROOT", root):
                with self.assertRaisesRegex(RuntimeError, "valid ZIP"):
                    acquire.select_input_zip(None)


class McmSourceValidationTests(unittest.TestCase):
    def test_reconciled_mcm_source_preflight_passes(self) -> None:
        source_zip = PATCH_ROOT / "MCM_SOURCE" / "MCM_1.6.3_RECONCILED_DDNS_KOTLIN_SOURCE_NOT_RELEASE_FIXED.zip"
        self.assertTrue(source_zip.is_file(), f"Missing bundled MCM source archive: {source_zip}")
        with tempfile.TemporaryDirectory() as temp:
            with zipfile.ZipFile(source_zip) as archive:
                archive.extractall(temp)
            source_root = Path(temp)
            result = validator.validate_mcm(source_root)
            self.assertEqual("true", result["is_mcm"])
            self.assertEqual("com.multicloud.mcm", result["expected_package"])
            self.assertEqual("1.6.3", result["expected_version_name"])
            self.assertEqual("12", result["expected_version_code"])
            self.assertEqual("MCM-1.6.3-RECONCILED-001", result["source_id"])

    def test_source_identity_rejects_old_or_mismatched_version(self) -> None:
        source_zip = PATCH_ROOT / "MCM_SOURCE" / "MCM_1.6.3_RECONCILED_DDNS_KOTLIN_SOURCE_NOT_RELEASE_FIXED.zip"
        with tempfile.TemporaryDirectory() as temp:
            with zipfile.ZipFile(source_zip) as archive:
                archive.extractall(temp)
            identity = Path(temp) / "SOURCE_IDENTITY.txt"
            identity.write_text(identity.read_text(encoding="utf-8").replace(
                "VERSION_CODE=12", "VERSION_CODE=11"
            ), encoding="utf-8")
            with self.assertRaisesRegex(RuntimeError, "pinned to MCM 1.6.3"):
                validator.validate_mcm(Path(temp))

    def test_mcm_source_archive_must_match_pinned_sha256(self) -> None:
        source_zip = PATCH_ROOT / "MCM_SOURCE" / "MCM_1.6.3_RECONCILED_DDNS_KOTLIN_SOURCE_NOT_RELEASE_FIXED.zip"
        with tempfile.TemporaryDirectory() as temp:
            changed_zip = Path(temp) / "altered.zip"
            with zipfile.ZipFile(source_zip, "r") as original, zipfile.ZipFile(changed_zip, "w") as changed:
                for member in original.infolist():
                    changed.writestr(member, original.read(member.filename))
                changed.writestr("UNEXPECTED.txt", "modified source archive")
            extracted = Path(temp) / "source"
            extracted.mkdir()
            with zipfile.ZipFile(changed_zip) as archive:
                archive.extractall(extracted)
            output = Path(temp) / "identity.json"
            argv = [
                "validate_mcm_source.py", "--root", str(extracted), "--zip", str(changed_zip),
                "--zip-sha256", validator.sha256_file(changed_zip), "--profile", "mcm-native",
                "--output", str(output),
            ]
            with mock.patch.object(sys, "argv", argv), self.assertRaisesRegex(
                RuntimeError, "does not match the pinned reconciled 1.6.3 archive"
            ):
                validator.main()
            self.assertFalse(output.exists())

    def test_source_digest_binding_rejects_a_different_archive_hash(self) -> None:
        source_zip = PATCH_ROOT / "MCM_SOURCE" / "MCM_1.6.3_RECONCILED_DDNS_KOTLIN_SOURCE_NOT_RELEASE_FIXED.zip"
        with tempfile.TemporaryDirectory() as temp:
            with zipfile.ZipFile(source_zip) as archive:
                archive.extractall(temp)
            output = Path(temp) / "identity.json"
            argv = [
                "validate_mcm_source.py", "--root", temp, "--zip", str(source_zip),
                "--zip-sha256", "0" * 64, "--profile", "mcm-native", "--output", str(output),
            ]
            with mock.patch.object(sys, "argv", argv), self.assertRaisesRegex(
                RuntimeError, "Selected ZIP digest changed"
            ):
                validator.main()
            self.assertFalse(output.exists())


class ApkCollectorTests(unittest.TestCase):
    def test_strict_manifest_mismatch_raises(self) -> None:
        with self.assertRaisesRegex(RuntimeError, "manifest mismatch"):
            collector.validate_expected_identity(
                "wrong.package", "1.6.3", "12",
                "com.multicloud.mcm", "1.6.3", "12",
            )

    def test_strict_manifest_exact_match_passes(self) -> None:
        collector.validate_expected_identity(
            "com.multicloud.mcm", "1.6.3", "12",
            "com.multicloud.mcm", "1.6.3", "12",
        )

    def test_strict_collection_copies_only_the_verified_apk(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "project"
            apk_dir = root / "app/build/outputs/apk/debug"
            apk_dir.mkdir(parents=True)
            apk = apk_dir / "app-debug.apk"
            apk.write_bytes(b"new-build-apk-fixture")
            output = Path(temp) / "output"
            report = Path(temp) / "collect.json"
            argv = [
                "collect_apk.py", "--root", str(root), "--variant", "debug",
                "--exact-apk", "app/build/outputs/apk/debug/app-debug.apk",
                "--expected-package", "com.multicloud.mcm",
                "--expected-version-name", "1.6.3", "--expected-version-code", "12",
                "--output-dir", str(output), "--output-json", str(report),
            ]
            with mock.patch.object(collector, "read_apk_identity", return_value=("com.multicloud.mcm", "1.6.3", "12")), mock.patch.object(sys, "argv", argv):
                self.assertEqual(0, collector.main())
            result = json.loads(report.read_text(encoding="utf-8"))
            self.assertTrue(result["verified"])
            self.assertEqual(1, result["apk_count"])
            self.assertEqual("com.multicloud.mcm", result["package"])
            self.assertTrue(Path(result["primary_apk"]).is_file())
            self.assertEqual(64, len(result["sha256"]))



class McmToolchainTests(unittest.TestCase):
    def test_mcm_toolchain_accepts_jdk17_and_gradle89_without_source_mutation(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "source"
            root.mkdir()
            output = Path(temp) / "toolchain.json"
            argv = ["configure_mcm_toolchain.py", "--root", str(root), "--output", str(output)]
            with mock.patch.object(configure.shutil, "which", return_value="/usr/bin/tool"), \
                 mock.patch.object(configure, "run", side_effect=['openjdk version "17.0.13"', "Gradle 8.9\nBuild time:"]), \
                 mock.patch.object(sys, "argv", argv):
                self.assertEqual(0, configure.main())
            result = json.loads(output.read_text(encoding="utf-8"))
            self.assertEqual("17", result["jdk_version"])
            self.assertEqual("8.9", result["gradle_version"])
            self.assertEqual(2, len(result["build_commands"]))
            self.assertIn(":app:clean", result["build_commands"][0])
            self.assertFalse(result["source_mutation"])
            self.assertFalse((root / "local.properties").exists())

    def test_mcm_toolchain_rejects_gradle_below_agp_minimum(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "source"
            root.mkdir()
            output = Path(temp) / "toolchain.json"
            argv = ["configure_mcm_toolchain.py", "--root", str(root), "--output", str(output)]
            with mock.patch.object(configure.shutil, "which", return_value="/usr/bin/tool"), \
                 mock.patch.object(configure, "run", side_effect=['openjdk version "17.0.13"', "Gradle 8.6\n"]), \
                 mock.patch.object(sys, "argv", argv):
                with self.assertRaisesRegex(RuntimeError, "requires Gradle 8.7"):
                    configure.main()


class WorkflowPatcherTests(unittest.TestCase):
    def test_workflow_patch_adds_identity_gate_and_debug_only_mcm_build(self) -> None:
        fixture = '''on:
  workflow_dispatch:
    inputs:
      zip_path:
        description: "Some description"
        required: false
        type: string
        default: ""
      zip_url:
        description: "URL"
        required: false
        type: string
        default: ""
      build_variant:
        type: choice
        default: "auto"
steps:
      - name: Extract source ZIP
        id: extract
        run: python3 scripts/extract_zip.py --zip "${{ steps.acquire.outputs.zip_path }}"
      - name: Configure toolchain
        id: toolchain
        run: |
          python3 scripts/setup_environment.py \\
            --root "${{ steps.extract.outputs.project_root }}" \\
            --detect detection.json \\
            --android-sdk "$ANDROID_HOME" \\
            --output toolchain.json
          echo "::group::Toolchain JSON"
          cat toolchain.json
          echo "::endgroup::"
      - name: Self-heal project (auto-fix common issues)
        id: self_heal
        run: |
          python3 scripts/self_heal.py

      # Step 11: Build the project (writes build.json)
      - name: Build project
        id: build
        continue-on-error: true
        run: |
          python3 scripts/build_project.py || true

      # Step 12: Collect APKs
      - name: Collect APKs
        id: collect
        if: always()
        run: |
          python3 scripts/collect_apk.py || true

      # Step 13: Upload APK artifact
      - name: Upload APK artifact
        if: steps.collect.outputs.apk_count != '0' && steps.collect.outputs.apk_count != ''
      - name: Upload AAB artifact
        if: steps.collect.outputs.apk_count != '0' && steps.collect.outputs.apk_count != ''
      - name: Diagnose failure
        if: steps.build.outputs.build_succeeded != 'true'
        run: |
          python3 "$GITHUB_WORKSPACE/scripts/diagnose_failure.py"
      - name: Fail if build failed
        if: steps.build.outputs.build_succeeded != 'true'
        run: |
          echo "::error::Android build failed."
'''
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "build-android.yml"
            path.write_text(fixture, encoding="utf-8")
            patcher.patch_workflow(path)
            content = path.read_text(encoding="utf-8")
            try:
                import yaml
            except ImportError:
                yaml = None
            if yaml is not None:
                yaml.safe_load(content)
            self.assertIn("project_profile:", content)
            self.assertIn("Validate source identity", content)
            self.assertIn("configure_mcm_toolchain.py", content)
            self.assertIn("if: steps.validate.outputs.is_mcm != 'true'", content)
            self.assertIn(":app:clean", content)
            self.assertIn(":app:testDebugUnitTest :app:lintDebug :app:assembleDebug", content)
            self.assertIn("--exact-apk", content)
            self.assertNotIn("continue-on-error: true", content)
            self.assertIn("if: always() && steps.build.outputs.build_succeeded != 'true'", content)
            self.assertTrue(path.with_suffix(".yml.bak").is_file())


if __name__ == "__main__":
    unittest.main(verbosity=2)
