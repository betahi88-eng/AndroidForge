# Kết quả đối chiếu MCM 1.5.x → 1.6.x và AndroidForge

## Kết luận về lỗi Kotlin

Đối chiếu trực tiếp các archive cho thấy:

| Chuyển phiên bản | Thay đổi liên quan build |
|---|---|
| 1.5.1 → 1.6.0 | AGP/Kotlin/KAPT giữ nguyên; `app/build.gradle.kts` chỉ đổi version; thêm Router Service Mode. |
| 1.6.0 → 1.6.1 | Thêm DNS-over-HTTPS resolver và wiring; AGP/Kotlin/KAPT không đổi. |
| 1.6.1 → 1.6.2 | Tách parser interface nullable sang file riêng và thêm test hồi quy. |
| 1.6.2 → 1.6.3 | Giữ parser riêng, thêm source identity, tăng versionCode lên 12. |

Vì vậy không tìm thấy bằng chứng về một lần nâng Kotlin/AGP gây vỡ tương thích giữa các bản 1.5.x và 1.6.x.

`RouterOs7Repository.kt` trong MCM 1.5.1, 1.6.0 và 1.6.1 đều có đúng biểu thức:

```kotlin
type = row.stringValue("type").orEmpty(),
```

Helper trong cùng file trả về `String?`. Kotlin standard library có extension `inline fun String?.orEmpty(): String` từ Kotlin 1.0. Các source 1.5.1/1.6.0/1.6.1 cũng có cùng AGP 8.6.1, Kotlin Gradle Plugin 2.0.21, KAPT 2.0.21 và cùng các dependency chính. Vì thế log nullable tại dòng 37 không tự chứng minh có một regression do DNS fallback. Log không chứa SHA-256 ZIP hoặc source tree đã biên dịch nên không xác định được chính xác archive của run đó.

MCM 1.6.2 tách parser thành `RouterOs7InterfaceParser.kt`, sử dụng `readNonBlankString("type") ?: ""`; 1.6.3 giữ sửa này. Trong 1.6.3, `RouterOs7Repository.kt` gọi `toInterfaceSnapshotOrNull()` và không còn biểu thức cũ. Nếu build mới vẫn báo cùng biểu thức/dòng cũ, source đang build không phải source 1.6.3 đã được xác minh.

## Kết luận về các log AndroidForge

- Log `flutter build apk` trong `workspace/harmony_patched` là dự án Flutter khác và dừng vì Gradle 8.9 thấp hơn mức Flutter 8.14 yêu cầu. Đây không phải bằng chứng MCM native thất bại.
- Log native trong `workspace/app` chạy `assembleDebug`, `assembleRelease`, `bundleDebug`; debug/release đều qua `kaptGenerateStubs` và `kapt`, sau đó dừng tại `compileDebugKotlin`/`compileReleaseKotlin` ở `RouterOs7Repository.kt:37:65`. Log không ghi source ZIP name/hash. Không thể khẳng định nó được build từ một ZIP cụ thể chỉ từ log này.
- `Kapt currently doesn't support language version 2.0+. Falling back to 1.9.` là cảnh báo; log tiếp tục chạy `kaptDebugKotlin` thành công và thất bại ở `compileDebugKotlin` sau đó. Đây không phải task failure đầu tiên.
- Workflow cũ lấy ZIP đầu tiên từ `input/` nếu `zip_path` trống, nên có nguy cơ chọn sai source. Bộ vá mới chuyển hành vi đó thành fail-closed.

## MCM 1.6.3 identity đã sửa tài liệu

- `app/build.gradle.kts`: versionName `1.6.3`, versionCode `12`.
- `SOURCE_IDENTITY.txt`: versionName `1.6.3`, versionCode `12`.
- Đã đồng bộ lại `BUILD_STATUS.md`, `README.md`, hướng dẫn AndroidForge và script đóng gói; không đổi code version hoặc applicationId.
- Application ID: `com.multicloud.mcm`.

## Kiểm tra thực hiện

- ZIP CRC: PASS cho 1.5.1, 1.6.0, 1.6.1, 1.6.2, 1.6.3.
- `scripts/androidforge-preflight.sh`: PASS.
- `scripts/verify-source.sh`: PASS cho static checks; báo Android Gradle test/lint/APK SKIPPED do workspace hiện tại thiếu Gradle + Android SDK Platform 35.
- `scripts/verify-room-migrations.py`: PASS.
- `scripts/verify-ui-contract.py`: PASS.
- Android XML: PASS.
- Kotlin parser smoke test trên Kotlin 1.9 với stub `JSONObject`: 4/4 PASS; đây là compile/test phần parser độc lập, không thay thế Gradle Android build.
- Bộ vá AndroidForge: 14/14 unit tests PASS (ZIP ambiguity/CRC/path, source identity, Gradle/JDK gate, APK identity pass/fail, workflow patch anchors).
- Không có APK nào được tạo hoặc xác minh trong môi trường này. Môi trường hiện tại có JDK 21 và kotlinc 1.9.0, nhưng không có Gradle hoặc Android SDK Platform 35 để chạy full Android build.

## Nguồn tương thích chính thức

- Kotlin Standard Library: [`String?.orEmpty()`](https://kotlinlang.org/api/core/kotlin-stdlib/kotlin.text/or-empty.html) đã có từ Kotlin 1.0.
- Android Gradle Plugin 8.6: yêu cầu tối thiểu Gradle 8.7 và JDK 17 ([release notes](https://developer.android.com/build/releases/agp-8-6-0-release-notes)).
