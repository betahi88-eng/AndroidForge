$ErrorActionPreference = "Stop"
$Repo = (Get-Location).Path
if (-not (Test-Path (Join-Path $Repo ".git"))) { throw "Chay tai thu muc goc AndroidForge." }
if (git status --porcelain) { throw "Working tree phai sach truoc khi ap dung." }
git fetch origin
git switch main
git pull --ff-only origin main
$branch = "fix/mcm-strict-source-build-2026-11-22"
git switch -c $branch
$Kit = Split-Path -Parent $MyInvocation.MyCommand.Path
$Patch = Join-Path $Kit "androidforge_patch"
Copy-Item (Join-Path $Patch "scripts") (Join-Path $Repo "scripts") -Recurse -Force
Copy-Item (Join-Path $Patch "patch_androidforge_workflow.py") $Repo -Force
New-Item -ItemType Directory -Force (Join-Path $Repo "input") | Out-Null
$archive = "MCM_1.6.3_RECONCILED_DDNS_KOTLIN_SOURCE_NOT_RELEASE_FIXED.zip"
Copy-Item (Join-Path $Kit "input\$archive") (Join-Path $Repo "input") -Force
$expected = (Get-Content (Join-Path $Kit "input\$archive.sha256") -Raw).Split(" ")[0]
$actual = (Get-FileHash (Join-Path $Repo "input\$archive") -Algorithm SHA256).Hash.ToLower()
if ($actual -ne $expected) { throw "MCM SHA-256 mismatch." }
python (Join-Path $Repo "patch_androidforge_workflow.py") (Join-Path $Repo ".github\workflows\build-android.yml")
git diff --check
Write-Host "Da ap dung tren nhanh $branch. Hay review git diff; script khong push/merge."
