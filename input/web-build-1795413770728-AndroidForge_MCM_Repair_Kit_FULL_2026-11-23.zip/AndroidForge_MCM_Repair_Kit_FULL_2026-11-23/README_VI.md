# AndroidForge – MCM Strict Build Repair Kit

## Mục tiêu
Khóa pipeline vào đúng ZIP nguồn MCM đã chỉ định; từ chối chọn ZIP tùy tiện; xác minh SHA-256/source identity; build native Gradle; không che lỗi; chỉ thu APK sau khi build thành công và xác minh manifest.

## Kết quả điều tra đã xác nhận
- Workflow cũ chọn ZIP đầu tiên theo thứ tự filesystem khi không chỉ định `zip_path`.
- Run #2 đã chọn nhầm `web-build-1792392797313-harmony_music_windows_android_fix.zip`, nhận diện Flutter và chạy Flutter build. Đây không phải bằng chứng MCM native Gradle build bị lỗi.
- Workflow cũ có `continue-on-error`, `|| true`, collector chạy `always()` và fallback metadata giả; các cơ chế này có thể làm sai lệch trạng thái thành công/thất bại.
- Log Kotlin riêng báo nullable receiver tại `RouterOs7Repository.kt:37:65`, nhưng log không ghi tên archive/SHA nên chưa thể chứng minh chính xác source đã compile.
- `String?.orEmpty()` là API Kotlin hợp lệ; không quy kết bản thân biểu thức đó là nguyên nhân.
- Bộ kiểm thử patch đã chạy trước đó: 14/14 PASS. Đây là unit tests cho patch, không phải full Android build.

## MCM source kèm theo
- File: `MCM_1.6.3_RECONCILED_DDNS_KOTLIN_SOURCE_NOT_RELEASE_FIXED.zip`
- SHA-256: `6313e1b28d2e7fa18fd56f20f8a4d91d6abf81a0027d1fe44e33e48a94ea1f0b`
- Source ID: `MCM-1.6.3-RECONCILED-001`
- Application ID: `com.multicloud.mcm`
- Version: `1.6.3` / versionCode `12`
- Native Android Gradle/Kotlin source; không phải APK.

## Áp dụng
1. Giải nén kit.
2. Mở terminal tại thư mục gốc repository AndroidForge.
3. Bảo đảm working tree sạch.
4. Windows: chạy `APPLY_TO_ANDROIDFORGE.ps1`; Linux/macOS: chạy `bash APPLY_TO_ANDROIDFORGE.sh`.
5. Script tạo nhánh `fix/mcm-strict-source-build-2026-11-22`, chép patch và MCM source, kiểm SHA, áp patch workflow và chạy `git diff --check`.
6. Review `git diff` trước khi commit/push. Không tự động push, merge hoặc release.

## GitHub Actions input
- `zip_source=input-directory`
- `zip_path=input/MCM_1.6.3_RECONCILED_DDNS_KOTLIN_SOURCE_NOT_RELEASE_FIXED.zip`
- `project_profile=mcm-native`
- `build_variant=debug`

Chỉ chấp nhận APK khi Gradle build thành công và manifest xác nhận `com.multicloud.mcm`, version `1.6.3`, versionCode `12`.

## Giới hạn
- Gói này chưa chứa APK và chưa chứng minh full Android build thành công.
- Môi trường kiểm tra trước đó thiếu Android SDK Platform 35/Gradle phù hợp để build hoàn chỉnh.
- GitHub API trả HTTP 403 khi thử tạo nhánh từ xa; không có căn cứ xác nhận remote branch/commit/PR đã được tạo.
- Không merge/release trước khi workflow chạy thành công và artifact được kiểm tra.
