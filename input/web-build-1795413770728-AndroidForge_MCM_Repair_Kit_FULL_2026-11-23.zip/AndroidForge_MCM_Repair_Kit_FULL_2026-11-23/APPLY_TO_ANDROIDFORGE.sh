#!/usr/bin/env bash
set -euo pipefail
repo="$(pwd)"
[[ -d "$repo/.git" ]] || { echo "Run at AndroidForge repository root"; exit 1; }
[[ -z "$(git status --porcelain)" ]] || { echo "Working tree must be clean"; exit 1; }
git fetch origin
git switch main
git pull --ff-only origin main
branch="fix/mcm-strict-source-build-2026-11-22"
git switch -c "$branch"
kit="$(cd "$(dirname "$0")" && pwd)"
cp -R "$kit/androidforge_patch/scripts" "$repo/"
cp "$kit/androidforge_patch/patch_androidforge_workflow.py" "$repo/"
mkdir -p "$repo/input"
archive="MCM_1.6.3_RECONCILED_DDNS_KOTLIN_SOURCE_NOT_RELEASE_FIXED.zip"
cp "$kit/input/$archive" "$repo/input/$archive"
expected="$(awk '{print $1}' "$kit/input/$archive.sha256")"
actual="$(sha256sum "$repo/input/$archive" | awk '{print $1}')"
[[ "$actual" == "$expected" ]] || { echo "MCM SHA-256 mismatch"; exit 1; }
python3 "$repo/patch_androidforge_workflow.py" "$repo/.github/workflows/build-android.yml"
git diff --check
echo "Applied on $branch. Review git diff; no push/merge performed."
