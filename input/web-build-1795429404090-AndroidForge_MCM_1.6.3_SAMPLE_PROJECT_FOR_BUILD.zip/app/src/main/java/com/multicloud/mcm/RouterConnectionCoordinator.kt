package com.multicloud.mcm

import com.multicloud.mcm.data.ConnectionAttemptLogEntity
import com.multicloud.mcm.data.McmDatabase
import com.multicloud.mcm.data.RouterEntity
import com.multicloud.mcm.routeros.RouterOs6ApiClient
import com.multicloud.mcm.security.SecureCredentialStore
import com.multicloud.mcm.security.TlsFingerprintInspector
import com.multicloud.mcm.security.TlsProbeException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.selects.select
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetAddress
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Direct DDNS connection flow. It is read-only: only TCP/TLS probes and RouterOS read calls
 * are sent. It never changes RouterOS services, firewall, NAT, DDNS or user configuration.
 */
class RouterConnectionCoordinator(
    private val database: McmDatabase,
    private val credentials: SecureCredentialStore
) {
    private val profiles = McmRouterProfileService(database, credentials)
    private val pending = ConcurrentHashMap<String, PendingAttempt>()

    suspend fun start(rawHost: String, username: String, password: String): JSONObject =
        withTimeoutOrNull(TOTAL_CONNECTION_TIMEOUT_MS) { startInternal(rawHost, username, password) }
            ?: failure("NETWORK_TIMEOUT", "Quá thời gian kết nối tối đa 30 giây.")

    private suspend fun startInternal(rawHost: String, username: String, password: String): JSONObject {
        val startedAt = System.currentTimeMillis()
        pending.entries.removeAll { startedAt - it.value.startedAt > PENDING_TTL_MS }
        val host = RouterHostValidator.normalize(rawHost)
        require(username.isNotBlank()) { "Username không được để trống." }
        require(password.isNotEmpty()) { "Password không được để trống." }
        val existing = profiles.findByHost(host)
        val resolution = try {
            RouterDnsResolver.resolveDetailed(host)
        } catch (error: DnsResolutionException) {
            existing?.let { writeDnsFailureLog(it.id, startedAt, error.failureCode, error.message ?: "DNS resolution failed") }
            return failure(error.failureCode, error.message ?: "DNS resolution failed")
                .put("elapsedMs", System.currentTimeMillis() - startedAt)
        } catch (error: Exception) {
            existing?.let { writeDnsFailureLog(it.id, startedAt, "DNS_FAILED", error.message ?: "Không phân giải được hostname.") }
            return failure("DNS_FAILED", error.message ?: "Không phân giải được hostname.")
                .put("elapsedMs", System.currentTimeMillis() - startedAt)
        }

        val oldPin = existing?.tlsSha256Pin?.takeIf(String::isNotBlank)
        val probes = probeBoth(host, resolution.addresses, oldPin)
        val candidate = probes.firstOrNull { it.transport == RouterTransport.REST_HTTPS && it.fingerprint != null }
            ?: probes.firstOrNull { it.fingerprint != null }

        if (oldPin != null) {
            val changed = probes.firstOrNull { it.fingerprint != null && !it.fingerprint.equals(oldPin, true) }
            if (changed != null) {
                val attempt = PendingAttempt(
                    id = UUID.randomUUID().toString(), host = host, username = username, password = password,
                    existing = existing, resolution = resolution, probes = probes,
                    oldPin = oldPin, candidatePin = changed.fingerprint!!, startedAt = startedAt
                )
                pending[attempt.id] = attempt
                return JSONObject()
                    .put("ok", false).put("state", "TLS_CHANGED")
                    .put("attemptId", attempt.id)
                    .put("oldFingerprint", oldPin)
                    .put("newFingerprint", changed.fingerprint)
                    .put("message", "Chứng chỉ TLS của ${changed.port} đã thay đổi. Kết nối đã dừng để chờ xác nhận bảo mật.")
            }
            return authenticateAndPersist(
                PendingAttempt(UUID.randomUUID().toString(), host, username, password, existing,
                    resolution, probes, oldPin, oldPin, startedAt), oldPin
            )
        }

        if (candidate == null) {
            val result = classifyProbeFailure(host, probes, System.currentTimeMillis() - startedAt)
            existing?.let { writeProbeFailureLog(it.id, startedAt, resolution, probes, result.optString("state"), result.optString("message")) }
            return result
        }
        val attempt = PendingAttempt(
            id = UUID.randomUUID().toString(), host = host, username = username, password = password,
            existing = existing, resolution = resolution, probes = probes,
            oldPin = null, candidatePin = candidate.fingerprint!!, startedAt = startedAt
        )
        pending[attempt.id] = attempt
        return JSONObject()
            .put("ok", false).put("state", "FIRST_TIME_PIN")
            .put("attemptId", attempt.id)
            .put("fingerprint", candidate.fingerprint)
            .put("port", candidate.port)
            .put("message", "Đối chiếu SHA-256 đầy đủ qua kênh tin cậy trước khi xác nhận lần đầu.")
    }

    suspend fun confirm(attemptId: String, decision: String): JSONObject =
        withTimeoutOrNull(TOTAL_CONNECTION_TIMEOUT_MS) { confirmInternal(attemptId, decision) }
            ?: failure("NETWORK_TIMEOUT", "Quá thời gian xác thực tối đa 30 giây.")

    private suspend fun confirmInternal(attemptId: String, decision: String): JSONObject {
        val attempt = pending.remove(attemptId)
            ?: return failure("ATTEMPT_EXPIRED", "Phiên kết nối không còn tồn tại. Hãy bắt đầu lại.")
        if (!decision.equals("TRUST", ignoreCase = true)) {
            return JSONObject().put("ok", false).put("state", "CANCELLED").put("message", "Đã hủy xác nhận chứng chỉ.")
        }
        val pin = attempt.candidatePin
        return authenticateAndPersist(attempt, pin, tlsPinConfirmed = true)
    }

    fun cancel(attemptId: String): JSONObject {
        pending.remove(attemptId)
        return JSONObject().put("ok", true).put("state", "CANCELLED")
    }

    private suspend fun probeBoth(
        host: String,
        addresses: List<InetAddress>,
        expectedPin: String? = null
    ): List<BranchProbe> = coroutineScope {
        // Probe both endpoints in parallel. A previously pinned certificate change is a
        // security stop: cancel the other branch as soon as it is detected.
        val branches = listOf(
            async(Dispatchers.IO) {
                withTimeoutOrNull(PROBE_BRANCH_TIMEOUT_MS) {
                    probeBranch(host, 443, RouterTransport.REST_HTTPS, addresses, expectedPin)
                } ?: BranchProbe(
                    RouterTransport.REST_HTTPS, 443, "NETWORK_TIMEOUT", null, null, 0, 0,
                    PROBE_BRANCH_TIMEOUT_MS, "REST probe exceeded its independent time budget"
                )
            },
            async(Dispatchers.IO) {
                withTimeoutOrNull(PROBE_BRANCH_TIMEOUT_MS) {
                    probeBranch(host, 8729, RouterTransport.API_SSL, addresses, expectedPin)
                } ?: BranchProbe(
                    RouterTransport.API_SSL, 8729, "NETWORK_TIMEOUT", null, null, 0, 0,
                    PROBE_BRANCH_TIMEOUT_MS, "API-SSL probe exceeded its independent time budget"
                )
            }
        )
        val first = select<Pair<Int, BranchProbe>> {
            branches[0].onAwait { 0 to it }
            branches[1].onAwait { 1 to it }
        }
        if (first.second.code == "TLS_CHANGED") {
            val otherIndex = 1 - first.first
            branches[otherIndex].cancel()
            val other = BranchProbe(
                if (otherIndex == 0) RouterTransport.REST_HTTPS else RouterTransport.API_SSL,
                if (otherIndex == 0) 443 else 8729,
                "CANCELLED", null, null, 0, 0, 0,
                "Sibling probe cancelled after TLS fingerprint change"
            )
            if (first.first == 0) listOf(first.second, other) else listOf(other, first.second)
        } else {
            val second = branches[1 - first.first].await()
            if (first.first == 0) listOf(first.second, second) else listOf(second, first.second)
        }
    }

    private suspend fun probeBranch(
        host: String,
        port: Int,
        transport: RouterTransport,
        addresses: List<InetAddress>,
        expectedPin: String?
    ): BranchProbe {
        val started = System.currentTimeMillis()
        return try {
            val result = TlsFingerprintInspector.probe(host, port, addresses)
            val state = if (expectedPin != null && !result.fingerprint.equals(expectedPin, ignoreCase = true)) {
                "TLS_CHANGED"
            } else "TLS_OK"
            BranchProbe(transport, port, state, result.fingerprint, result.resolvedIp,
                result.tcpDurationMs, result.tlsDurationMs, System.currentTimeMillis() - started,
                if (state == "TLS_CHANGED") "Pinned TLS fingerprint changed" else null)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: TlsProbeException) {
            BranchProbe(transport, port, error.failureCode, null, null, 0, 0,
                System.currentTimeMillis() - started, "${error.failureStage}: ${error.message}")
        } catch (error: Exception) {
            BranchProbe(transport, port, "ERROR", null, null, 0, 0,
                System.currentTimeMillis() - started, error.message)
        }
    }

    private suspend fun authenticateAndPersist(
        attempt: PendingAttempt,
        pin: String,
        tlsPinConfirmed: Boolean = false
    ): JSONObject = coroutineScope {
        val restProbe = attempt.probes.first { it.transport == RouterTransport.REST_HTTPS }
        val apiProbe = attempt.probes.first { it.transport == RouterTransport.API_SSL }
        val restDeferred = async(Dispatchers.IO) {
            withTimeoutOrNull(REST_AUTH_BRANCH_TIMEOUT_MS) {
                val authStarted = System.currentTimeMillis()
                authenticateRest(attempt, restProbe, pin).copy(durationMs = System.currentTimeMillis() - authStarted)
            } ?: BranchAuth(RouterTransport.REST_HTTPS, 443, "NETWORK_TIMEOUT", null, restProbe.resolvedIp, "REST authentication/read check timed out")
        }
        val apiDeferred = async(Dispatchers.IO) {
            withTimeoutOrNull(API_AUTH_BRANCH_TIMEOUT_MS) {
                val authStarted = System.currentTimeMillis()
                authenticateApi(attempt, apiProbe, pin).copy(durationMs = System.currentTimeMillis() - authStarted)
            } ?: BranchAuth(RouterTransport.API_SSL, 8729, "NETWORK_TIMEOUT", null, apiProbe.resolvedIp, "API-SSL authentication/read check timed out")
        }
        // Both branches start before either result is awaited; each has an independent deadline.
        val (rest, api) = awaitAll(restDeferred, apiDeferred)
        attempt.authDurations[RouterTransport.REST_HTTPS] = rest.durationMs
        attempt.authDurations[RouterTransport.API_SSL] = api.durationMs
        val decision = decide(rest, api)
        if (decision.finalState == "TLS_CHANGED") {
            val changedProbes = runCatching {
                probeBoth(attempt.host, attempt.resolution.addresses, expectedPin = pin)
            }.getOrDefault(emptyList())
            val changed = changedProbes.firstOrNull { it.fingerprint != null && !it.fingerprint.equals(pin, true) }
            if (changed?.fingerprint != null) {
                val retry = PendingAttempt(
                    id = UUID.randomUUID().toString(), host = attempt.host, username = attempt.username,
                    password = attempt.password, existing = attempt.existing, resolution = attempt.resolution,
                    probes = changedProbes, oldPin = pin, candidatePin = changed.fingerprint,
                    startedAt = attempt.startedAt
                )
                pending[retry.id] = retry
                return@coroutineScope JSONObject()
                    .put("ok", false).put("state", "TLS_CHANGED").put("attemptId", retry.id)
                    .put("oldFingerprint", pin).put("newFingerprint", changed.fingerprint)
                    .put("message", "Fingerprint thay đổi trong lúc xác thực. Kết nối đã dừng để chờ xác nhận.")
            }
        }
        if (decision.finalState != "READY" && decision.finalState != "READY_LIMITED") {
            logFailure(attempt, rest, api, decision.finalState, decision.message)
            return@coroutineScope JSONObject()
                .put("ok", false).put("state", decision.finalState)
                .put("message", decision.message)
                .put("restResult", rest.code).put("apiSslResult", api.code)
                .put("elapsedMs", System.currentTimeMillis() - attempt.startedAt)
        }

        val selected = decision.selected ?: return@coroutineScope failure("ERROR", "Không xác định được giao thức đã xác thực.")
        val successful = if (selected == RouterTransport.REST_HTTPS) rest else api
        val version = successful.version ?: if (selected == RouterTransport.REST_HTTPS) "7" else null
        val major = version?.substringBefore('.')?.toIntOrNull()
            ?: attempt.existing?.routerOsMajor
            ?: if (selected == RouterTransport.REST_HTTPS) 7 else 0
        if (major !in 6..7) {
            logFailure(attempt, rest, api, "ERROR", "RouterOS version missing or unsupported")
            return@coroutineScope failure("ERROR", "Không xác định được RouterOS 6/7 từ dữ liệu Router thực tế.")
        }
        val latency = System.currentTimeMillis() - attempt.startedAt
        val payload = JSONObject()
            .put("name", attempt.existing?.name ?: attempt.host)
            .put("siteName", attempt.existing?.siteName ?: "Mặc định")
            .put("host", attempt.host)
            .put("port", selected.port)
            .put("routerOsMajor", major)
            .put("connectionMode", if (selected == RouterTransport.REST_HTTPS) "REST_HTTPS" else "API_SSL")
            .put("username", attempt.username)
            .put("password", attempt.password)
            .put("tlsSha256Pin", pin)
            .put("lastResolvedIp", successful.resolvedIp ?: attempt.probes.firstOrNull { it.resolvedIp != null }?.resolvedIp.orEmpty())
            .put("dnsResolver", attempt.resolution.source)
            .put("fallbackAvailable", rest.code == "OK" && api.code == "OK")
            .put("routerOsVersion", successful.version ?: if (selected == RouterTransport.REST_HTTPS) "7" else "")
            .put("accessLevel", if (decision.finalState == "READY") "FULL" else "LIMITED")
            .put("lastStatus", decision.finalState)
            .put("lastConnectionLatencyMs", latency)
            .put("tlsPinConfirmed", tlsPinConfirmed)
        if (attempt.existing != null) payload.put("id", attempt.existing.id)
        val routerId = try {
            profiles.saveRouter(payload.toString())
        } catch (error: Exception) {
            val safeDetail = redactSecret(error.message ?: "Profile persistence failed", attempt.password)
            logFailure(attempt, rest, api, "ERROR", safeDetail)
            return@coroutineScope failure("ERROR", "Đã xác thực Router nhưng không thể lưu profile an toàn. Kiểm tra nhật ký kỹ thuật.")
        }
        logSuccess(routerId, attempt, rest, api, decision, latency)
        JSONObject()
            .put("ok", true).put("state", decision.finalState)
            .put("id", routerId)
            .put("host", attempt.host)
            .put("routerOsVersion", successful.version ?: "RouterOS $major")
            .put("protocol", if (selected == RouterTransport.REST_HTTPS) "REST" else "API-SSL")
            .put("port", selected.port)
            .put("latencyMs", latency)
            .put("fallbackAvailable", rest.code == "OK" && api.code == "OK")
            .put("dnsResolver", attempt.resolution.source)
            .put("resolvedIp", successful.resolvedIp ?: JSONObject.NULL)
            .put("message", if (decision.finalState == "READY") "Đã kết nối và đọc được dữ liệu Router." else "Đã xác thực Router nhưng tài khoản chưa đủ quyền đọc.")
            .put("warnings", JSONArray().apply {
                if (rest.code != "OK") put("REST: ${redactSecret(rest.message, attempt.password)}")
                if (api.code != "OK") put("API-SSL: ${redactSecret(api.message, attempt.password)}")
            })
    }

    private suspend fun authenticateRest(attempt: PendingAttempt, probe: BranchProbe, pin: String): BranchAuth {
        if (probe.fingerprint == null) return probe.toAuth()
        if (!probe.fingerprint.equals(pin, ignoreCase = true)) return BranchAuth(
            RouterTransport.REST_HTTPS, 443, "TLS_FINGERPRINT_MISMATCH", null, probe.resolvedIp,
            "REST certificate differs from the accepted profile pin"
        ).copy(code = "TLS_UNTRUSTED_BRANCH")
        val client = RouterOs7Client(
            attempt.host, 443, attempt.username, attempt.password, pin,
            connectTimeoutMs = 5_000, readTimeoutMs = 5_000, writeTimeoutMs = 5_000, callTimeoutMs = 8_000,
            resolvedAddresses = attempt.resolution.addresses
        )
        return when (val result = client.get("system/resource")) {
            is McmResult.Failure -> BranchAuth(RouterTransport.REST_HTTPS, 443, mapFailure(result.code), null, probe.resolvedIp, result.message)
            is McmResult.Success -> {
                val row = result.value.optJSONObject(0)
                if (row == null) BranchAuth(RouterTransport.REST_HTTPS, 443, "READ_DENIED", null, probe.resolvedIp, "REST returned no system resource row")
                else BranchAuth(RouterTransport.REST_HTTPS, 443, "OK", row.optString("version").takeIf(String::isNotBlank), probe.resolvedIp, "Read check succeeded")
            }
        }
    }

    private suspend fun authenticateApi(attempt: PendingAttempt, probe: BranchProbe, pin: String): BranchAuth {
        if (probe.fingerprint == null) return probe.toAuth()
        if (!probe.fingerprint.equals(pin, ignoreCase = true)) return BranchAuth(
            RouterTransport.API_SSL, 8729, "TLS_FINGERPRINT_MISMATCH", null, probe.resolvedIp,
            "API-SSL certificate differs from the accepted profile pin"
        ).copy(code = "TLS_UNTRUSTED_BRANCH")
        val client = RouterOs6ApiClient(
            attempt.host, 8729, attempt.username, attempt.password, pin,
            connectTimeoutMs = 5_000, loginReadTimeoutMs = 8_000, commandReadTimeoutMs = 5_000,
            resolvedAddresses = attempt.resolution.addresses
        )
        return when (val result = client.execute("/system/resource/print")) {
            is McmResult.Failure -> BranchAuth(RouterTransport.API_SSL, 8729, mapFailure(result.code), null, probe.resolvedIp, result.message)
            is McmResult.Success -> {
                val row = result.value.firstOrNull()
                if (row == null) BranchAuth(RouterTransport.API_SSL, 8729, "READ_DENIED", null, probe.resolvedIp, "API-SSL returned no system resource row")
                else BranchAuth(RouterTransport.API_SSL, 8729, "OK", row["version"], probe.resolvedIp, "Read check succeeded")
            }
        }
    }

    private fun mapFailure(code: String): String = when (code) {
        "AUTH" -> "AUTH_FAILED"
        "PERMISSION", "READ_DENIED" -> "READ_DENIED"
        "TIMEOUT", "NETWORK_TIMEOUT" -> "NETWORK_TIMEOUT"
        "CONNECT_REFUSED", "TCP_REFUSED" -> "TCP_REFUSED"
        "TLS_FINGERPRINT_MISMATCH" -> "TLS_CHANGED"
        "TLS", "TLS_PROTOCOL", "TLS_HANDSHAKE", "TLS_HOSTNAME" -> "TLS_FAILED"
        else -> code
    }

    private fun decide(rest: BranchAuth, api: BranchAuth): Decision {
        if (rest.code == "TLS_CHANGED" || api.code == "TLS_CHANGED") {
            return Decision("TLS_CHANGED", null, false, "Fingerprint thay đổi trong lúc xác thực. Đã dừng kết nối để bảo vệ profile.")
        }
        if (rest.code == "OK" && api.code == "OK") return Decision("READY", RouterTransport.REST_HTTPS, true, "Both transports authenticated")
        if (rest.code == "OK") return Decision("READY", RouterTransport.REST_HTTPS, false, "REST authenticated; API-SSL unavailable or not authorized")
        if (api.code == "OK") return Decision("READY", RouterTransport.API_SSL, false, "API-SSL authenticated; REST unavailable or not authorized")
        if (rest.code == "READ_DENIED" || api.code == "READ_DENIED") {
            val selected = if (rest.code == "READ_DENIED") RouterTransport.REST_HTTPS else RouterTransport.API_SSL
            return Decision("READY_LIMITED", selected, false, "Authenticated but the account cannot read the required system resource")
        }
        if (rest.code == "AUTH_FAILED" || api.code == "AUTH_FAILED") {
            return Decision("AUTH_FAILED", null, false, "RouterOS rejected the supplied credentials on the tested management endpoints")
        }
        val codes = setOf(rest.code, api.code)
        if (codes.all { it == "NETWORK_TIMEOUT" }) return Decision("NETWORK_TIMEOUT", null, false, "Both management endpoints timed out")
        if (codes.all { it == "TCP_REFUSED" || it == "TLS_FAILED" || it == "PORTS_UNREACHABLE" }) {
            return Decision("PORTS_UNREACHABLE", null, false, "Neither REST HTTPS nor API-SSL is reachable as a TLS RouterOS service")
        }
        if ("NETWORK_TIMEOUT" in codes) return Decision("NETWORK_TIMEOUT", null, false, "At least one management endpoint did not respond before its timeout")
        return Decision("ERROR", null, false, "Could not authenticate or read RouterOS data: REST=${rest.code}, API-SSL=${api.code}")
    }

    private fun classifyProbeFailure(host: String, probes: List<BranchProbe>, elapsed: Long): JSONObject {
        val codes = probes.map { it.code }.toSet()
        val state = when {
            codes.all { it == "NETWORK_TIMEOUT" } -> "NETWORK_TIMEOUT"
            codes.all { it == "TCP_REFUSED" || it == "TLS_FAILED" || it == "PORTS_UNREACHABLE" } -> "PORTS_UNREACHABLE"
            "NETWORK_TIMEOUT" in codes -> "NETWORK_TIMEOUT"
            else -> "PORTS_UNREACHABLE"
        }
        val output = failure(state, if (state == "PORTS_UNREACHABLE") {
            "Không kết nối được dịch vụ TLS trên REST HTTPS 443 và API-SSL 8729 của $host."
        } else "Mạng không phản hồi trong thời gian chờ khi kiểm tra REST HTTPS 443 và API-SSL 8729.")
        output.put("elapsedMs", elapsed)
            .put("restResult", probes.firstOrNull { it.transport == RouterTransport.REST_HTTPS }?.code)
            .put("apiSslResult", probes.firstOrNull { it.transport == RouterTransport.API_SSL }?.code)
        return output
    }

    private suspend fun logFailure(attempt: PendingAttempt, rest: BranchAuth, api: BranchAuth, state: String, detail: String) {
        val routerId = attempt.existing?.id ?: return
        writeLog(routerId, attempt, rest.code, api.code, null, state, detail, System.currentTimeMillis() - attempt.startedAt)
    }

    private suspend fun logSuccess(routerId: String, attempt: PendingAttempt, rest: BranchAuth, api: BranchAuth, decision: Decision, duration: Long) {
        writeLog(routerId, attempt, rest.code, api.code, decision.selected?.name, decision.finalState, decision.message, duration)
    }

    private suspend fun writeLog(
        routerId: String,
        attempt: PendingAttempt,
        restResult: String,
        apiResult: String,
        selected: String?,
        state: String,
        detail: String,
        duration: Long
    ) {
        val ipArray = JSONArray().apply { attempt.resolution.addresses.forEach { put(it.hostAddress ?: "") } }
        val safeDetail = detail.replace(attempt.password, "[REDACTED]").take(500)
        database.connectionAttemptLogDao().insert(
            ConnectionAttemptLogEntity(
                id = attempt.id,
                routerId = routerId,
                attemptedAtEpochMs = attempt.startedAt,
                durationMs = duration,
                dnsResolver = attempt.resolution.source,
                resolvedIps = ipArray.toString(),
                restResult = restResult,
                apiSslResult = apiResult,
                restProbeDetails = probeDetails(attempt.probes.first { it.transport == RouterTransport.REST_HTTPS }).toString(),
                apiSslProbeDetails = probeDetails(attempt.probes.first { it.transport == RouterTransport.API_SSL }).toString(),
                restAuthDurationMs = attempt.authDurations[RouterTransport.REST_HTTPS] ?: 0L,
                apiSslAuthDurationMs = attempt.authDurations[RouterTransport.API_SSL] ?: 0L,
                selectedProtocol = selected,
                finalState = state,
                detail = safeDetail
            )
        )
    }

    private suspend fun writeDnsFailureLog(
        routerId: String,
        startedAt: Long,
        state: String,
        detail: String
    ) {
        val emptyTrace = JSONObject().put("tcpResult", "NOT_RUN").put("tlsResult", "NOT_RUN")
        database.connectionAttemptLogDao().insert(
            ConnectionAttemptLogEntity(
                id = UUID.randomUUID().toString(), routerId = routerId,
                attemptedAtEpochMs = startedAt, durationMs = System.currentTimeMillis() - startedAt,
                dnsResolver = "NONE", resolvedIps = "[]", restResult = "NOT_RUN", apiSslResult = "NOT_RUN",
                restProbeDetails = emptyTrace.toString(), apiSslProbeDetails = emptyTrace.toString(),
                restAuthDurationMs = 0, apiSslAuthDurationMs = 0, selectedProtocol = null,
                finalState = state, detail = detail.take(500)
            )
        )
    }

    private suspend fun writeProbeFailureLog(
        routerId: String,
        startedAt: Long,
        resolution: RouterDnsResolver.Resolution,
        probes: List<BranchProbe>,
        state: String,
        detail: String
    ) {
        val byTransport = probes.associateBy { it.transport }
        val ips = JSONArray().apply { resolution.addresses.forEach { put(it.hostAddress ?: "") } }
        database.connectionAttemptLogDao().insert(
            ConnectionAttemptLogEntity(
                id = UUID.randomUUID().toString(), routerId = routerId,
                attemptedAtEpochMs = startedAt, durationMs = System.currentTimeMillis() - startedAt,
                dnsResolver = resolution.source, resolvedIps = ips.toString(),
                restResult = byTransport[RouterTransport.REST_HTTPS]?.code ?: "NOT_RUN",
                apiSslResult = byTransport[RouterTransport.API_SSL]?.code ?: "NOT_RUN",
                restProbeDetails = byTransport[RouterTransport.REST_HTTPS]?.let(::probeDetails)?.toString() ?: "{}",
                apiSslProbeDetails = byTransport[RouterTransport.API_SSL]?.let(::probeDetails)?.toString() ?: "{}",
                restAuthDurationMs = 0, apiSslAuthDurationMs = 0, selectedProtocol = null,
                finalState = state, detail = detail.take(500)
            )
        )
    }

    private fun BranchProbe.toAuth(): BranchAuth = BranchAuth(transport, port, code, null, resolvedIp, detail ?: code)

    private fun probeDetails(probe: BranchProbe): JSONObject = JSONObject()
        .put("port", probe.port)
        .put("tcpResult", when {
            probe.fingerprint != null -> "CONNECTED"
            probe.detail?.contains("TCP_CONNECT") == true -> probe.code
            else -> "UNKNOWN_OR_CONNECTED"
        })
        .put("tlsResult", when {
            probe.fingerprint != null -> "VERIFIED"
            probe.detail?.contains("TLS_HANDSHAKE") == true -> probe.code
            else -> "NOT_REACHED_OR_TIMEOUT"
        })
        .put("fingerprintSha256", probe.fingerprint ?: JSONObject.NULL)
        .put("resolvedIp", probe.resolvedIp ?: JSONObject.NULL)
        .put("tcpDurationMs", probe.tcpDurationMs)
        .put("tlsDurationMs", probe.tlsDurationMs)
        .put("probeDurationMs", probe.elapsedMs)
        .put("detail", probe.detail ?: JSONObject.NULL)

    private fun redactSecret(value: String, secret: String): String =
        if (secret.isEmpty()) value.take(500) else value.replace(secret, "[REDACTED]").take(500)

    private fun failure(state: String, message: String): JSONObject =
        JSONObject().put("ok", false).put("state", state).put("message", message)

    private data class PendingAttempt(
        val id: String,
        val host: String,
        val username: String,
        val password: String,
        val existing: RouterEntity?,
        val resolution: RouterDnsResolver.Resolution,
        val probes: List<BranchProbe>,
        val oldPin: String?,
        val candidatePin: String,
        val startedAt: Long,
        val authDurations: MutableMap<RouterTransport, Long> = ConcurrentHashMap()
    )

    private data class BranchProbe(
        val transport: RouterTransport,
        val port: Int,
        val code: String,
        val fingerprint: String?,
        val resolvedIp: String?,
        val tcpDurationMs: Long,
        val tlsDurationMs: Long,
        val elapsedMs: Long = 0,
        val detail: String? = null
    )

    private data class BranchAuth(
        val transport: RouterTransport,
        val port: Int,
        val code: String,
        val version: String?,
        val resolvedIp: String?,
        val message: String,
        val durationMs: Long = 0L
    )

    private data class Decision(
        val finalState: String,
        val selected: RouterTransport?,
        val fallbackAvailable: Boolean,
        val message: String,
        val durationMs: Long = 0L
    )

    companion object {
        private const val TOTAL_CONNECTION_TIMEOUT_MS = 30_000L
        private const val PROBE_BRANCH_TIMEOUT_MS = 10_500L
        private const val REST_AUTH_BRANCH_TIMEOUT_MS = 8_000L
        // RouterOS API login is budgeted at 8s and READ_CHECK at 5s.
        private const val API_AUTH_BRANCH_TIMEOUT_MS = 13_000L
        private const val PENDING_TTL_MS = 5 * 60 * 1000L
    }
}
