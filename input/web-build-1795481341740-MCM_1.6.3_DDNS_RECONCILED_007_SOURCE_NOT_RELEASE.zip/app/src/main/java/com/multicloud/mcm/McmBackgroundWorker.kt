package com.multicloud.mcm

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.multicloud.mcm.data.McmDatabase
import com.multicloud.mcm.data.MetricHistoryEntity
import com.multicloud.mcm.security.SecureCredentialStore
import com.multicloud.mcm.routeros.RouterOs6ApiClient
import com.multicloud.mcm.routeros.RouterOs6Repository
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.CancellationException
import androidx.room.Room

/** Best-effort background health samples. WorkManager's periodic minimum interval is 15 minutes. */
class McmBackgroundWorker(context: Context, parameters: WorkerParameters) : CoroutineWorker(context, parameters) {
    override suspend fun doWork(): Result = withTimeout(10 * 60 * 1_000L) {
        val database = Room.databaseBuilder(applicationContext, McmDatabase::class.java, "mcm.db")
            .addMigrations(*McmDatabase.ALL_MIGRATIONS)
            .build()
        val credentials = SecureCredentialStore(applicationContext)
        try {
            val routers = database.routerDao().getAll()
            routers.forEach { router ->
                // Limited profiles are authenticated but do not authorize monitoring reads.
                // Keep READY_LIMITED intact; do not mark them OFFLINE from a forbidden query.
                if (router.accessLevel == "LIMITED") return@forEach
                val now = System.currentTimeMillis()
                var effectiveRouter = router
                var selectedTransport = RouterTransport.REST_HTTPS
                var endpointPort = router.port
                var servicePin = ""
                try {
                    selectedTransport = RouterServiceMode.fromStorage(router.connectionMode)
                        .resolveForProfile(router.routerOsMajor, router.activeTransport)
                    servicePin = router.tlsPinFor(selectedTransport, endpointPort)
                        ?: throw IllegalStateException("TLS_PIN_MISSING: Chưa có fingerprint đã xác nhận cho ${selectedTransport.name} tại cổng $endpointPort.")
                    val password = credentials.get(router.credentialAlias)
                        ?: throw IllegalStateException("CREDENTIAL_UNAVAILABLE: Không tìm thấy mật khẩu đã mã hóa.")
                    val resolution = RouterDnsResolver.resolveDetailed(router.host)
                    var resource = readCoreResource(selectedTransport, router.host, endpointPort, router.username, password, servicePin, resolution.addresses)
                    var fallbackWarning: String? = null
                    if (resource is McmResult.Failure) {
                        val alternate = selectedTransport.alternate()
                        val alternatePort = router.tlsPinPortFor(alternate)
                        val alternatePin = alternatePort?.let { router.tlsPinFor(alternate, it) }
                        if (canTryAlternateTransport(RouterServiceMode.fromStorage(router.connectionMode), resource.code, false, alternatePin != null) &&
                            alternatePort != null && alternatePin != null) {
                            val primaryFailure = resource
                            val alternateResult = readCoreResource(alternate, router.host, alternatePort, router.username, password, alternatePin, resolution.addresses)
                            when (alternateResult) {
                                is McmResult.Success -> {
                                    fallbackWarning = "AUTO fallback ${selectedTransport.name}:$endpointPort (${primaryFailure.code}) -> ${alternate.name}:$alternatePort"
                                    selectedTransport = alternate
                                    endpointPort = alternatePort
                                    servicePin = alternatePin
                                    resource = alternateResult
                                    effectiveRouter = router.copy(
                                        port = endpointPort,
                                        activeTransport = selectedTransport.name,
                                        tlsSha256Pin = servicePin,
                                        lastStatus = "PARTIAL",
                                        lastErrorCode = "AUTO_FALLBACK",
                                        lastErrorMessage = fallbackWarning,
                                        lastCheckedAtEpochMs = now
                                    )
                                }
                                is McmResult.Failure -> {
                                    resource = McmResult.Failure(
                                        primaryFailure.code,
                                        "${primaryFailure.message} Fallback ${alternate.name}:$alternatePort failed (${alternateResult.code})."
                                    )
                                }
                            }
                        }
                    }
                    when (resource) {
                        is McmResult.Success -> {
                            val values = resource.value
                            effectiveRouter = effectiveRouter.copy(
                                lastSeenAtEpochMs = now,
                                lastStatus = if (fallbackWarning == null) "ONLINE" else "PARTIAL",
                                lastErrorCode = if (fallbackWarning == null) null else "AUTO_FALLBACK",
                                lastErrorMessage = fallbackWarning,
                                lastCheckedAtEpochMs = now,
                                lastResolvedIp = resolution.addresses.firstOrNull()?.hostAddress ?: router.lastResolvedIp,
                                dnsResolver = resolution.source,
                                routerOsVersion = values.version ?: router.routerOsVersion
                            )
                            database.routerDao().upsert(effectiveRouter)
                            values.cpuLoadPercent?.let {
                                database.metricDao().insert(MetricHistoryEntity(routerId = router.id, metricKey = "cpu_load", value = it.toDouble(), unit = "%", recordedAtEpochMs = now))
                            }
                            if (values.freeMemoryBytes != null && values.totalMemoryBytes != null && values.totalMemoryBytes > 0) {
                                val used = 100.0 * (values.totalMemoryBytes - values.freeMemoryBytes).coerceAtLeast(0) / values.totalMemoryBytes.toDouble()
                                database.metricDao().insert(MetricHistoryEntity(routerId = router.id, metricKey = "memory_used", value = used, unit = "%", recordedAtEpochMs = now))
                            }
                        }
                        is McmResult.Failure -> database.routerDao().upsert(effectiveRouter.copy(
                            lastStatus = "OFFLINE", lastErrorCode = resource.code,
                            lastErrorMessage = resource.message.take(240), lastCheckedAtEpochMs = now
                        ))
                    }
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (error: DnsResolutionException) {
                    database.routerDao().upsert(effectiveRouter.copy(
                        lastStatus = "OFFLINE", lastErrorCode = error.failureCode,
                        lastErrorMessage = (error.message ?: "DNS resolution failed").take(240),
                        lastCheckedAtEpochMs = now
                    ))
                } catch (error: Exception) {
                    val message = error.message ?: "Không rõ lỗi nền"
                    val code = message.substringBefore(':').takeIf { it.matches(Regex("[A-Z0-9_]{2,48}")) } ?: "BACKGROUND_FAILED"
                    database.routerDao().upsert(effectiveRouter.copy(
                        lastStatus = "OFFLINE", lastErrorCode = code,
                        lastErrorMessage = message.take(240), lastCheckedAtEpochMs = now
                    ))
                }
            }
            database.metricDao().deleteBefore(System.currentTimeMillis() - 30L * 24L * 60L * 60L * 1_000L)
            Result.success()
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            Result.retry()
        } finally {
            database.close()
        }
    }

    private suspend fun readCoreResource(
        transport: RouterTransport,
        host: String,
        port: Int,
        username: String,
        password: String,
        pin: String,
        addresses: List<java.net.InetAddress>
    ): McmResult<SystemResource> = when (transport) {
        RouterTransport.REST_HTTPS -> RouterOs7Repository(
            RouterOs7Client(host, port, username, password, pin, resolvedAddresses = addresses)
        ).readSystemResource()
        RouterTransport.API_SSL -> RouterOs6Repository(
            RouterOs6ApiClient(host, port, username, password, pin, resolvedAddresses = addresses)
        ).readSystemResource()
    }
}
