# MCM — Project State

**Source baseline:** 1.6.0 — Direct DDNS / selectable service / user-controlled WAN port
**Current reconciled candidate:** 1.6.3 — `MCM-1.6.3-DDNS-RECONCILED-007`  
**State:** Engineering source / NOT RELEASE  
**Baseline:** `MCM_1.5.1_DIRECT_DDNS_MULTI_STORE_SOURCE_NOT_RELEASE.zip`  
**Checkpoint:** `MCM-160-DIRECT-DDNS-SERVICE-PORT-001` — 2026-11-22

## Scope held

- Android-only native Kotlin + local WebView assets + Room + Android Keystore.
- Multiple independent MikroTik profiles grouped by store/site.
- Direct hostname/DDNS/IP connection only; no MCM backend, VPS, VPN/WireGuard, relay or router agent.
- Read-only RouterOS monitoring plus bounded ping diagnostics.
- No router configuration writes or automatic changes.

## 1.6.0 source changes

- Added a persisted per-router `connectionMode`: AUTO, REST_HTTPS or API_SSL.
- Service protocol is independent from RouterOS family and numeric port. REST_HTTPS requires RouterOS 7; API_SSL is supported on RouterOS 6/7.
- Kept port as user-editable 1–65535 WAN-facing endpoint; a manually entered port is preserved while switching OS/service, and an already saved profile port is always treated as user-owned even when it equals a conventional default.
- Added Room v3→v4 migration with `connectionMode='AUTO'` for existing profiles; existing port, credentials, fingerprint and metric history are preserved.
- Foreground monitor and WorkManager background checks use the same saved protocol mode and custom port.
- UI explicitly explains that WinBox TCP 8291 is not a supported MCM protocol; port 8291 works only when it actually serves or maps to REST HTTPS/API-SSL.
- TCP diagnostic message no longer implies TCP reachability proves service compatibility.

## Preserved functionality

- Multi-store profile management, encrypted credentials, SHA-256 leaf pinning.
- RouterOS 7 REST adapter and RouterOS 6 native API-SSL adapter, including legacy challenge login.
- CPU/RAM, interface counters/rates, Cloud DDNS, PPPoE, ARP, DHCP, Netwatch, Bridge Host, VLAN and bounded ping reads.
- MNDP LAN discovery, per-router health/error persistence, local history/charts and sequential Refresh All.

## Validation status in this workspace

- Source ZIP parent archive SHA-256: `d4494f331c4d0e642c0a6799dfc871ecb2d60deec391c08e5206e152fa63a77b` (1.5.1 baseline).
- `scripts/androidforge-preflight.sh`: PASS (native Android Gradle/Kotlin flat-root project).
- `scripts/verify-source.sh`: PASS for JavaScript, Python compile, Room migration SQL preservation, WebView DOM contract, shell syntax and Android XML.
- Standalone Kotlin `RouterServiceMode` smoke checks: PASS with local kotlinc 1.9.0; this is not a substitute for Gradle compilation.
- Source ZIP CRC/root layout/SHA-256: verified on the final archive and recorded in its sidecar.
- Android Gradle compile/KAPT/JUnit/Lint/APK and live RouterOS/Android acceptance: NOT RUN. The workspace lacks Gradle 8.7 and Android SDK Platform 35; its Java is 21, not required JDK 17.

## Safety

No MikroTik config, firewall, NAT, DDNS, service, IP or port has been changed. No credentials from any router are included in the source archive. Do not publish management ports without source restrictions and a least-privilege account.


## 1.6.3 endpoint integration candidate — 23/11/2026

- Parent source: `AndroidForge_MCM_1.6.3_SAMPLE_PROJECT_BUILD_FIX_002.zip` (SHA-256 `7e5872d18df840f7367de787d7f15818191bd2402612efa1fe2162c96cd6337a`).
- Đã hoàn thiện kết nối custom WAN port/service mode qua Advanced UI, bridge, coordinator, TLS probe, authenticated READ_CHECK và Room profile.
- AUTO mặc định dò 443/8729 song song; AUTO port tùy chỉnh dò cả hai transport tại cùng port; mode chỉ định chỉ dò một service.
- Foreground và background monitoring tái sử dụng port/mode đã lưu.
- Source static/UI/Room checks và 9 assertion service-mode smoke PASS.
- Gradle/KAPT/JUnit/lint/APK và live Android/RouterOS acceptance vẫn NOT RUN; đây chưa phải release APK.


## 1.6.3 DDNS TLS pin correction — 23/11/2026

- The security rule is two independent checks: the operator confirms the exact leaf SHA-256 fingerprint, and the certificate SAN/CN must match the DDNS hostname used for SNI/Host. A self-signed certificate does not waive hostname or certificate-validity checks.
- REST and API-SSL use strict hostname verification and exact leaf pinning. The earlier note that a pin could bypass SAN/CN matching was incorrect and is superseded by this rule.
- AUTO fallback now selects only a transport that passed authenticated READ_CHECK, preferring REST on ROS7 and API-SSL on ROS6.
- Diagnostics expose DNS resolver/IPs, per-port TCP/TLS results/timings, negotiated TLS version/cipher, authentication/READ_CHECK details, and a copy-log action.
- Static/UI/Room checks and local TLS/pin/AUTO smoke PASS. Full Gradle/JUnit/lint/APK and live WAN acceptance remain NOT RUN.


## 1.6.3 per-service TLS pin reconciliation — 23/11/2026

- Nâng Room schema từ v7 lên v8; mỗi router lưu riêng `tlsRestSha256Pin` + `tlsRestPinPort` và `tlsApiSslSha256Pin` + `tlsApiSslPinPort`.
- Migration v7→v8 chỉ chuyển legacy pin khi active transport cũ hoặc mode giao thức cố định xác định được service. Profile AUTO không có `activeTransport` là mơ hồ: giữ lại legacy pin nhưng không tái sử dụng và yêu cầu xác nhận pin riêng.
- Foreground và WorkManager chọn pin theo đúng service + WAN port; thiếu pin tương ứng thì fail closed.
- AUTO chỉ thử nhánh thay thế sau lỗi endpoint/protocol. Nó có thể dùng lại pin đã xác nhận trước đây cho đúng service + port; nếu chưa có thì yêu cầu xác nhận fingerprint riêng. AUTH/READ_DENIED không bị bypass.
- Sửa CI source identity gate 004→005 và kiểm tra legacy API login phải nhận `!done`.
- SQL migration simulation, UI contract, provenance, JavaScript/Python/shell/XML checks được chạy lại; full Android Gradle/JUnit/lint/APK và live RouterOS test vẫn NOT RUN.
- Candidate 006: hostname verification chuẩn hóa theo DNS SAN/IP SAN/CN fallback an toàn; response REST giới hạn; WebView chỉ tải asset nội bộ và xóa password sau native call. API-SSL modern/legacy mock, TLS fingerprint inspector và SAN/IP/wildcard smoke đã PASS theo `BUILD_STATUS.md`.

- Foreground refresh, Refresh All và WorkManager dùng cùng quy tắc AUTO fallback có pin độc lập theo service + WAN port; sau core read thành công mới cập nhật active endpoint, báo PARTIAL/AUTO_FALLBACK; không failover qua AUTH/READ_DENIED/TLS identity failures. DNS failure ghi OFFLINE với mã DNS riêng.

- Khóa lại scope hostname: chỉ DDNS/domain và IPv4 literal; từ chối nhập IPv6 literal theo kế hoạch 1.6.3 (hostname vẫn có thể phân giải bản ghi AAAA).


## Latest build correction

Candidate 007 fixes the Kotlin sealed-result smart-cast errors identified in `AndroidForge-logs (1).zip`. FIX_002 is kept only as a source reference; no APK or successful build evidence from that ZIP is claimed. Candidate 007 remains NOT RELEASE until AndroidForge runs the full Android build and returns verifiable artifacts.
