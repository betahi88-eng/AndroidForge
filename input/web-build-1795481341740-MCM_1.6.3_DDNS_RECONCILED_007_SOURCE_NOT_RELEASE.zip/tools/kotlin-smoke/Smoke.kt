package com.multicloud.mcm

import com.multicloud.mcm.data.RouterEntity
import com.multicloud.mcm.routeros.RouterOsApiCodec
import com.multicloud.mcm.security.RouterTlsHostnameVerifier
import com.multicloud.mcm.security.TlsErrorClassifier
import java.io.ByteArrayInputStream
import java.io.*
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate

private sealed interface McmResult<out T> {
 data class Success<T>(val value:T):McmResult<T>
 data class Failure(val code:String,val message:String):McmResult<Nothing>
}

private fun backgroundFallback(primary:McmResult<String>, alternate:McmResult<String>):McmResult<String> {
 var resource = primary
 if (resource is McmResult.Failure) {
  val primaryFailure = resource
  when (alternate) {
   is McmResult.Success -> resource = alternate
   is McmResult.Failure -> resource = McmResult.Failure(primaryFailure.code, "${primaryFailure.message}; fallback ${alternate.code}: ${alternate.message}")
  }
 }
 return resource
}

private fun foregroundFallback(primary:McmResult<String>, alternate:McmResult<String>):McmResult<String> {
 var resource = primary
 if (resource is McmResult.Failure) {
  val primaryFailure = resource
  when (alternate) {
   is McmResult.Success -> resource = alternate
   is McmResult.Failure -> resource = McmResult.Failure(primaryFailure.code, "${primaryFailure.message}; fallback ${alternate.code}: ${alternate.message}")
  }
 }
 return resource
}

private var passed=0
private fun checkThat(ok:Boolean, label:String) { if(!ok) error("FAIL: $label"); passed++ }
private inline fun rejects(label:String, block:()->Unit) { try { block() } catch (_:IllegalArgumentException) { passed++; return }; error("FAIL: $label should reject") }
fun main(args:Array<String>) {
 // Read-only policy: allowed reads and bounded ping; mutations rejected.
 RouterOsReadOnlyPolicy.validateRestGet("/system/resource")
 RouterOsReadOnlyPolicy.validateApiCommand("/interface/print", emptyMap())
 RouterOsReadOnlyPolicy.validateRestPing("ping", setOf("address","count","interval"), "1.1.1.1", "5", "200ms")
 RouterOsReadOnlyPolicy.validateApiCommand("/ping", mapOf("address" to "1.1.1.1", "count" to "5", "interval" to "200ms"))
 rejects("REST path mutation") { RouterOsReadOnlyPolicy.validateRestGet("/system/script") }
 rejects("REST ping oversized count") { RouterOsReadOnlyPolicy.validateRestPing("ping", setOf("address","count","interval"), "1.1.1.1", "101", "200ms") }
 rejects("REST arbitrary POST") { RouterOsReadOnlyPolicy.validateRestPing("system/reboot", emptySet(), "", "1", "200ms") }
 rejects("API mutation") { RouterOsReadOnlyPolicy.validateApiCommand("/system/reboot", emptyMap()) }
 rejects("API injected attribute") { RouterOsReadOnlyPolicy.validateApiCommand("/system/resource/print", mapOf("=numbers" to "0")) }
 // Host validation.
 checkThat(RouterHostValidator.normalize(" HTTPS://HMD0B6SQG3R.SN.MYNETNAME.NET/ ")=="hmd0b6sqg3r.sn.mynetname.net", "DDNS normalization")
 checkThat(RouterHostValidator.normalize("192.168.1.1")=="192.168.1.1", "IPv4 normalization")
 rejects("HTTP downgrade") { RouterHostValidator.normalize("http://router.example.test") }
 rejects("IPv6 literal") { RouterHostValidator.normalize("2001:db8::1") }
 rejects("port embedded in host") { RouterHostValidator.normalize("router.example.test:8729") }
 // Service selection / port handling / failover gate.
 checkThat(RouterServiceMode.AUTO.probePorts(0)==RouterProbePorts(443,8729), "AUTO default ports")
 checkThat(RouterServiceMode.AUTO.probePorts(9443)==RouterProbePorts(9443,9443), "AUTO custom port")
 checkThat(RouterServiceMode.REST_HTTPS.probePorts(9443)==RouterProbePorts(9443,null), "REST custom port")
 checkThat(RouterServiceMode.API_SSL.probePorts(9443)==RouterProbePorts(null,9443), "API custom port")
 checkThat(RouterServiceMode.AUTO.selectAuthenticatedTransport(7,false,true)==RouterTransport.API_SSL, "AUTO authenticated alternate")
 checkThat(!canTryAlternateTransport(RouterServiceMode.AUTO,"AUTH",false,true), "no auth failover")
 checkThat(!canTryAlternateTransport(RouterServiceMode.AUTO,"TLS_HOSTNAME",false,true), "no TLS identity failover")
 checkThat(canTryAlternateTransport(RouterServiceMode.AUTO,"NETWORK_TIMEOUT",false,true), "timeout failover allowed only with pin")
 checkThat(!canTryAlternateTransport(RouterServiceMode.AUTO,"NETWORK_TIMEOUT",false,false), "no unpinned failover")
 val legacy=RouterEntity(tlsSha256Pin="old",port=9443,activeTransport="REST_HTTPS")
 checkThat(legacy.tlsPinFor(RouterTransport.REST_HTTPS,9443)=="old", "legacy pin bound to known transport")
 checkThat(legacy.tlsPinFor(RouterTransport.API_SSL,9443)==null, "legacy pin not reused across transport")
 val ambiguous=legacy.copy(activeTransport=null)
 checkThat(ambiguous.tlsPinFor(RouterTransport.REST_HTTPS,9443)==null, "ambiguous legacy pin not reused")
 // API codec round trip and credential challenge handling.
 val bytes=ByteArrayOutputStream(); RouterOsApiCodec.writeSentence(DataOutputStream(bytes), listOf("/system/resource/print", "=.proplist=cpu-load,uptime"))
 val words=RouterOsApiCodec.readSentence(DataInputStream(ByteArrayInputStream(bytes.toByteArray())))
 checkThat(words==listOf("/system/resource/print", "=.proplist=cpu-load,uptime"), "API sentence round trip")
 checkThat(RouterOsApiCodec.legacyChallenge(listOf("=ret=0123456789abcdef"))=="0123456789abcdef", "legacy challenge parse")
 checkThat(RouterOsApiCodec.isCredentialRejected(listOf("!trap","=message=invalid user name or password")), "credential rejection detection")
 rejects("API oversized word") { RouterOsApiCodec.writeSentence(DataOutputStream(ByteArrayOutputStream()), listOf("x".repeat(1024*1024+1))) }
 // TLS hostname verifier using supplied X509 fixture.
 val cert=CertificateFactory.getInstance("X.509").generateCertificate(File(args[0]).inputStream()) as X509Certificate
 checkThat(RouterTlsHostnameVerifier.verifyCertificate("router.example.test",cert), "DNS SAN exact match")
 checkThat(RouterTlsHostnameVerifier.verifyCertificate("node.wild.example.test",cert), "one-label wildcard SAN")
 checkThat(!RouterTlsHostnameVerifier.verifyCertificate("deep.node.wild.example.test",cert), "multi-label wildcard rejected")
 checkThat(!RouterTlsHostnameVerifier.verifyCertificate("wrong.example.test",cert), "wrong hostname rejected")
 checkThat(RouterTlsHostnameVerifier.verifyCertificate("127.0.0.1",cert), "IP SAN exact match")
 checkThat(!RouterTlsHostnameVerifier.verifyCertificate("127.0.0.2",cert), "IP mismatch rejected")
 val cnOnly=CertificateFactory.getInstance("X.509").generateCertificate(File(args[1]).inputStream()) as X509Certificate
 checkThat(RouterTlsHostnameVerifier.verifyCertificate("router-local-only",cnOnly), "CN fallback only when DNS SAN absent")
 checkThat(!RouterTlsHostnameVerifier.verifyCertificate("router.example.test",cnOnly), "CN mismatch rejected")
 // Kotlin sealed-result narrowing regression from AndroidForge log (1).
 val primaryFailure = McmResult.Failure("NETWORK_TIMEOUT", "primary timeout")
 val alternateFailure = McmResult.Failure("TCP_REFUSED", "alternate refused")
 val bgFailure = backgroundFallback(primaryFailure, alternateFailure)
 checkThat(bgFailure is McmResult.Failure && bgFailure.code=="NETWORK_TIMEOUT" && bgFailure.message.contains("TCP_REFUSED"), "background fallback failure branch is properly narrowed")
 val bgSuccess = backgroundFallback(primaryFailure, McmResult.Success("monitoring data"))
 checkThat(bgSuccess is McmResult.Success && bgSuccess.value=="monitoring data", "background fallback success remains selected")
 val fgFailure = foregroundFallback(primaryFailure, alternateFailure)
 checkThat(fgFailure is McmResult.Failure && fgFailure.code=="NETWORK_TIMEOUT" && fgFailure.message.contains("TCP_REFUSED"), "foreground fallback failure branch is properly narrowed")
 val fgSuccess = foregroundFallback(primaryFailure, McmResult.Success("monitoring data"))
 checkThat(fgSuccess is McmResult.Success && fgSuccess.value=="monitoring data", "foreground fallback success remains selected")
 // REST body limits must apply to both declared and streamed lengths.
 checkThat(RestResponseBounds.readUtf8(ByteArrayInputStream("hello".toByteArray()),5,8)=="hello", "REST normal body")
 checkThat(RestResponseBounds.readUtf8(ByteArrayInputStream("123456789".toByteArray()),-1,8)==null, "REST streamed overflow")
 checkThat(RestResponseBounds.readUtf8(ByteArrayInputStream("hello".toByteArray()),9,8)==null, "REST declared overflow")
 checkThat(RestResponseBounds.allowsRows(10_000) && !RestResponseBounds.allowsRows(10_001), "REST row ceiling")
 checkThat(!TlsErrorClassifier.isProtocolMismatch(IllegalStateException("socket closed")), "non-protocol error classification")
 checkThat(TlsErrorClassifier.isProtocolMismatch(IllegalStateException("WRONG_VERSION_NUMBER")), "protocol mismatch classification")
 println("Kotlin/JVM source smoke PASS: $passed assertions")
}
