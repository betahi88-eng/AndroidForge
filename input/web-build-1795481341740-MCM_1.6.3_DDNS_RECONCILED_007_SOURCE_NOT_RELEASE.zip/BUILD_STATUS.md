# MCM 1.6.3 — build and acceptance status

Source identity: `MCM-1.6.3-DDNS-RECONCILED-007`  
Parent source: `MCM_1.6.3_DDNS_RECONCILED_005_SOURCE_NOT_RELEASE.zip`
Reference sample (not build-success evidence): `AndroidForge_MCM_1.6.3_SAMPLE_PROJECT_BUILD_FIX_002.zip`  
Parent SHA-256: `be09a41a4ca9ab7325553c400b8e5ecc5b309817a549e2239c4f94199c2380cf`  
Application ID: `com.multicloud.mcm`  
Version: `1.6.3` (`versionCode=12`)  
Room schema: `8`

## Candidate 007 changes

- Candidate 007 carries forward candidate 006 functional/security scope and fixes the latest AndroidForge Kotlin compile diagnostics in `McmBackgroundWorker.kt` and `McmMonitoringService.kt`. Both alternate transport outcomes are now exhaustively narrowed with `when (alternateResult)`, and `.code` is read only in the `McmResult.Failure` branch.
- The provided `AndroidForge-logs (1).zip` shows `assembleDebug`, `assembleRelease`, and `bundleDebug` failing at Kotlin compilation on the two old accesses. No APK/AAB is contained in that log bundle.
- FIX_002 is retained as an upstream sample-source reference only. The available FIX_002 ZIP contains no APK/AAB and no success log; it is not designated a verified buildable baseline.

## Candidate 006 carried-forward changes

- Preserves direct native Android Kotlin/Gradle app, multi-router profiles, encrypted credentials, DNS fallback, TLS identity checks, diagnostics, metrics, histories, UI and existing RouterOS 6/7 adapters.
- Separates REST HTTPS and API-SSL SHA-256 pins by service and exact WAN port; Room v7→v8 migration carries legacy pins only to the service that can be inferred safely.
- AUTO failover is consistent for first connection, individual refresh, Refresh All and WorkManager: only endpoint/protocol failures qualify; the alternate service must have its own matching, previously confirmed pin or request a separate confirmation. AUTH, permission, TLS hostname, certificate validity and fingerprint mismatch do not trigger failover.
- DNS failures are stored as OFFLINE diagnostics rather than appearing as an unexplained refresh error. A successful failover updates the active transport/port only after the alternate endpoint passes the core authenticated resource read.
- Adds a central read-only policy at both RouterOS transports. REST is limited to the monitoring GET allowlist and bounded ping POST; API-SSL is limited to the monitoring `/print` allowlist and bounded ping. Configuration mutations, reboot, firewall, NAT, service and user commands are denied before network I/O.
- Bounds API-SSL untrusted response processing: 1 MiB per word, 128 words and 4 MiB per sentence, 16 MiB per command response and maximum 10,000 response rows.
- Uses explicit X.509 endpoint identity matching (DNS SAN, IP SAN, and legacy CN only when no DNS SAN exists), with one-label wildcard handling. The same verifier is used by REST HTTPS, API-SSL and first-use certificate inspection; default JVM hostname-verifier behavior on raw TLS sockets is not relied upon.
- Limits REST responses to 16 MiB and 10,000 rows using a bounded stream reader; bounds are checked even when the server omits Content-Length. The WebView is restricted to packaged same-origin assets, and the submitted password is cleared from its field and transient JS variable after the native call returns.
- Treats old AUTO profiles with no recorded active transport as ambiguous during v7→v8 migration. Their former single pin is retained as data but is not reused for either protocol until a service-specific pin is explicitly confirmed.
- Documents RouterOS least-privilege policy: `read,api` for API-SSL; `read,api,rest-api` for REST; optional `test` only for integrated ping. No `write`, `policy` or `reboot` permissions are required.
- Rejects manually entered IPv6 literals as scoped out; a DDNS hostname may still resolve to IPv6 addresses.
- Keeps three primary Add Router inputs and the closed Advanced section for service mode/WAN port. No new product features outside the established scope were added.

## Historical build-log reconciliation

- AndroidForge logs (6) and (7) show the old `selected.port` / cascading `put` compiler errors in `RouterConnectionCoordinator.kt`. Log (7) also shows that the runner used Gradle 8.9, not the project-pinned Gradle 8.7; it fails all attempted debug/release Kotlin compile tasks. The logs do not contain a source archive hash.
- Candidate 006 removes `selected.port`; it uses the authenticated probe's `successful.port`. The 11-assertion regression guard checks this exact correction. This source check does not prove that AndroidForge has built candidate 006.

## Checks actually run in this workspace (24/11/2026)

- `scripts/androidforge-preflight.sh`: **PASS** (native Android project identity and pinned package/toolchain settings).
- `scripts/verify-source.sh` with `MCM_SKIP_GRADLE=1`: **PASS** on candidate 007 (source identity, JavaScript, Python, shell, XML, Room migration, UI contract, 13 regression assertions and provenance checks).
- `scripts/verify-room-migrations.py`: **PASS** (v1→v8; profile, metrics, counters and connection logs preserved; service pins separated by transport and port; ambiguous AUTO legacy pin is not reused).
- `scripts/verify-ui-contract.py`: **PASS** (75 unique DOM IDs, exactly three primary inputs, advanced section closed by default).
- `scripts/verify-build-regressions.py`: **PASS (13 assertions)**, including both new guards for `alternateResult.code` inside explicit `McmResult.Failure` branches.
- `scripts/verify-kotlin-smoke.sh`: **PASS — 44 assertions**, compiled from the actual pure Kotlin source files with Kotlin/JVM 1.9.0. Coverage includes read-only policy, bounded ping, hostname normalization, IPv4/DDNS, service/port selection, failover gates, transport-scoped legacy pins, API codec, DNS SAN/IP SAN/CN fallback/wildcards, TLS error classification and REST body/row bounds. Only Room entity and DNS IP utility are test doubles.
- `scripts/verify-provenance.py`: **PASS** (all tracked source/document/script hashes match the manifest).
- JavaScript `node --check`, Python `py_compile`, shell `bash -n`, and Android XML parsing: **PASS**.
- ZIP CRC and Android project-root structure: **PASS**.

The GitHub Actions workflow and local build script are configured to run Debug and Release APK/AAB tasks, verify package/version metadata with Android `aapt`, and retain build/test reports. These pipeline changes are source-checked only; they have not yet run on a remote Android runner.

## Not run / release blockers

- This runtime has OpenJDK 21.0.12 and Kotlin/JVM 1.9.0, but no JDK 17, Gradle 8.7, Android SDK Platform 35, or Android Build Tools 35.0.0. Network access to fetch the toolchain is unavailable here.
- Therefore Android Gradle/KAPT project compilation, full Android JUnit task, Android lint, Debug/Release APK/AAB assembly, APK manifest verification, install on a phone/emulator and live RouterOS 6/7 WAN/DDNS tests are **NOT RUN**. There is no APK in this workspace or historical source archive.
- AndroidForge/GitHub CI was not run: no connected AndroidForge fork/repository or authorized CI session is available in this workspace. No access token should be pasted into chat.

**Decision: FULL SOURCE PACKAGE / NOT RELEASE / NOT FULLY ACCEPTED.** Static and focused JVM smoke checks do not establish a successful Android build or live RouterOS operation. Do not distribute this as a verified APK until the pinned Android toolchain, Gradle/JUnit/lint/Debug+Release APK+AAB and device/router acceptance gates pass.
