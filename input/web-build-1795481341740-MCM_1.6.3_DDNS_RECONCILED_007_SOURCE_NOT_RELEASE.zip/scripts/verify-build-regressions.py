#!/usr/bin/env python3
"""Guard against the exact AndroidForge regressions found in historical logs."""
from pathlib import Path
import re
ROOT = Path(__file__).resolve().parents[1]
def read(rel):
    p = ROOT / rel
    if not p.is_file():
        raise SystemExit(f"FAIL: missing {rel}")
    return p.read_text(encoding="utf-8")
checks = []
def require(condition, message):
    if not condition:
        raise SystemExit("FAIL: " + message)
    checks.append(message)

dns = read("app/src/main/java/com/multicloud/mcm/DohDnsResolver.kt")
ros7 = read("app/src/main/java/com/multicloud/mcm/RouterOs7Client.kt")
coordinator = read("app/src/main/java/com/multicloud/mcm/RouterConnectionCoordinator.kt")
mode = read("app/src/main/java/com/multicloud/mcm/RouterServiceMode.kt")
bridge = read("app/src/main/java/com/multicloud/mcm/McmJavascriptBridge.kt")
ui = read("app/src/main/assets/www/router-ui.js")
html = read("app/src/main/assets/www/index.html")
db = read("app/src/main/java/com/multicloud/mcm/data/McmDatabase.kt")
monitor = read("app/src/main/java/com/multicloud/mcm/McmMonitoringService.kt")
worker = read("app/src/main/java/com/multicloud/mcm/McmBackgroundWorker.kt")

require(".dns(object : Dns {" in dns, "DoH resolver uses valid OkHttp Dns object expression")
require(".dns(object : Dns {" in ros7, "RouterOS 7 client uses valid OkHttp Dns object expression")
require("selected.port" not in coordinator, "historical unresolved selected.port expression is absent")
require("val selectedPort = successful.port" in coordinator, "persisted port comes from the authenticated successful probe")
require("fun probePorts(requestedPort: Int)" in mode, "AUTO/custom/explicit service port mapping exists")
require("requestedPort: Int" in coordinator and "serviceMode.probePorts(requestedPort)" in coordinator, "coordinator consumes requested WAN port end-to-end")
require("port: Int, connectionMode: String" in bridge and "start(host, username, password, port, connectionMode)" in bridge, "native bridge forwards WAN port and service mode")
require('nativeCall("connectRouter", host, username, password, port, mode)' in ui, "Web UI sends WAN port and service mode to native bridge")
require('id="routerPort"' in html and 'id="routerConnectionMode"' in html and 'id="routerAdvancedOptions"' in html, "Advanced UI exposes port/service selector")
require("MIGRATION_7_8" in db and "tlsRestPinPort" in db and "tlsApiSslPinPort" in db, "Room v8 migration separates service pins by exact port")
require("var endpointPort = router.port" in monitor and "var endpointPort = router.port" in worker, "foreground and background reuse saved endpoint port")
def alternate_code_is_failure_narrowed(source):
    start = source.find("when (alternateResult)")
    if start < 0:
        return False
    success_branch = source.find("is McmResult.Success ->", start)
    failure_branch = source.find("is McmResult.Failure ->", start)
    code_read = source.find("alternateResult.code", start)
    return success_branch >= 0 and failure_branch > success_branch and code_read > failure_branch

require(alternate_code_is_failure_narrowed(worker), "background fallback reads alternateResult.code only inside the sealed Failure branch")
require(alternate_code_is_failure_narrowed(monitor), "foreground fallback reads alternateResult.code only inside the sealed Failure branch")
print(f"Historical build regression guards: PASS ({len(checks)} assertions)")
for item in checks:
    print(" - " + item)
