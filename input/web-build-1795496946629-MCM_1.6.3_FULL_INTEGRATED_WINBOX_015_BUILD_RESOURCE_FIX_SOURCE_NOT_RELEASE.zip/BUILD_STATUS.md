# MCM 1.6.3 — Build and acceptance status

Source identity: `MCM-1.6.3-FULL-INTEGRATED-WINBOX-015`  
Parent build-confirmed baseline: `MCM_1.6.3_DDNS_RECONCILED_007_SOURCE_NOT_RELEASE.zip`  
Parent SHA-256: `493cdf9ec77e15958073a63452e30fd3ea259a91e8a9bdd44ca35315584e6f96`  
Application ID: `com.multicloud.mcm`  
Version: `1.6.3` (`versionCode=12`)  
Room schema: `8`

## Integrated scope

- Preserves the 007 source baseline and the existing multi-router, DNS fallback, REST HTTPS, API-SSL, TLS identity, Keystore/AES-GCM, Room history, and read-only monitoring behavior.
- Adds `WINBOX_CLI` as a distinct explicit transport through service selector, coordinator, profile persistence, foreground refresh and background core health checks.
- WinBox uses modern EC-SRP5 authentication, M2 encrypted frames (AES-128-CBC + HMAC-SHA1), mepty terminal and fixed read-only command allowlist. RouterOS 6.43+; legacy MD5 login is not supported.
- Reads identity/resource and optional interface, cloud, PPP active, ARP, DHCP lease, Netwatch, Bridge Host, VLAN and Bridge VLAN menus. ROS7 7.13+ reads JSON serialization; earlier versions use the as-value parser. Optional failures are individually surfaced as PARTIAL; no fake zeros.
- WinBox does not use TLS; no REST/API certificate pin is applied. It is not used as AUTO fallback.
- Adds `lab/` with a Containerlab 0.83+ RouterOS 7 CHR topology, GNS3/QEMU RouterOS 6 setup example, CoreDNS example, environment/probe scripts and a Maestro UI-flow draft.

## Checks actually executed in this workspace

- Parent 007 archive SHA-256 independently recomputed and matches the recorded value.
- `WinboxCliConnector.kt` standalone Kotlin/JVM compile: **PASS**.
- Connector + repository Kotlin type-check with temporary signatures for Android JSON/coroutine/model types: **PASS**; this does not prove Android project compilation.
- `scripts/verify-winbox-smoke.sh`: **PASS** — EC-SRP5 known-answer vectors, WinBox stream-key vectors, 10 AES/HMAC round trips, exact 14-chunk boundary, tamper/HMAC rejection, VT100/prompt handling, RouterOS 6 as-value/list parsing, CLI error rejection and read-only command allowlist. Connector/repository Kotlin/JVM compile uses temporary signatures for Android/JSON/coroutine types.
- `scripts/verify-kotlin-smoke.sh`: **PASS — 48 assertions**. This is a Kotlin/JVM smoke suite with test doubles, not Android Gradle/JUnit.

## Not run / release blockers

- Android Gradle/KAPT project compile, Android JUnit, lint, Debug/Release APK/AAB: **NOT RUN** (no Gradle 8.7 / Android SDK Platform 35 / JDK 17 in this runtime).
- Android Emulator + Maestro/Appium: **NOT RUN**. Maestro YAML is a draft; its selectors must be confirmed on the actual emulator.
- RouterOS CHR live tests: **NOT RUN** (no Docker/Containerlab/QEMU in this runtime).
- Public DDNS/WAN/NAT test from an external VPS: **NOT RUN**. The Containerlab CHR management VRF tests management plane only; it is not evidence of WAN NAT reachability.

**Decision: integrated engineering source / SOURCE_NOT_RELEASE.** This is not an APK build and no real-router connection success is claimed. Do not label it release until Android build gates, live CHR 6/7 tests and an external-network test pass.


## Build-resource collision guard (015)

- Added an Android packaging exclusion for `META-INF/versions/15/OSGI-INF/MANIFEST.MF`. This is non-runtime OSGi bundle metadata and the exact duplicate resource reported by the AndroidForge `mergeDebugJavaResource` / `mergeReleaseJavaResource` failures (JSch 2.28.8 and BouncyCastle 1.86).
- This guard addresses that specific merge-resource collision if those dependencies are present in the AndroidForge dependency graph. It does not prove an APK build. The supplied failure logs compiled a different workspace source (including `SshRouterOsClient.kt` and JSch/BouncyCastle dependencies), whereas source 014 has neither those dependencies nor that SSH client. Re-import/sync this exact 015 source before rebuilding so the build is not using a stale workspace.
