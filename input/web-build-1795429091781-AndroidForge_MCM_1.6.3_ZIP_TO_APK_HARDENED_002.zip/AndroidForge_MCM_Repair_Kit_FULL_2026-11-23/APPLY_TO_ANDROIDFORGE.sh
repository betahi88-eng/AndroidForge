#!/usr/bin/env bash
set -euo pipefail
repo="$(pwd)"
[[ -d "$repo/.git" ]] || { echo "Run at AndroidForge repository root"; exit 1; }
[[ -z "$(git status --porcelain)" ]] || { echo "Working tree must be clean"; exit 1; }
branch="fix/mcm-1.6.3-zip-root-hotfix"
git switch -c "$branch"
kit="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$repo/scripts" "$repo/tests" "$repo/input"
for file in "$kit"/androidforge_patch/scripts/*.py; do cp "$file" "$repo/scripts/"; done
for file in "$kit"/androidforge_patch/tests/*.py; do cp "$file" "$repo/tests/"; done
cp "$kit/androidforge_patch/patch_androidforge_workflow.py" "$repo/"
archive="MCM_1.6.3_RECONCILED_DDNS_KOTLIN_SOURCE_DERIVED_PATCH_001.zip"
cp "$kit/input/$archive" "$repo/input/$archive"
cp "$kit/input/$archive.sha256" "$repo/input/$archive.sha256"
expected="$(awk '{print $1}' "$kit/input/$archive.sha256")"
actual="$(sha256sum "$repo/input/$archive" | awk '{print $1}')"
[[ "$actual" == "$expected" ]] || { echo "MCM SHA-256 mismatch"; exit 1; }
python3 "$repo/patch_androidforge_workflow.py" --workflow "$repo/.github/workflows/build-android.yml"
python3 -m compileall -q "$repo/scripts" "$repo/tests" "$repo/patch_androidforge_workflow.py"
python3 -m unittest discover -s "$repo/tests" -v
git diff --check
echo "Applied on $branch from the current HEAD. main was not checked out or modified; no push/merge/release performed. Review git diff."
