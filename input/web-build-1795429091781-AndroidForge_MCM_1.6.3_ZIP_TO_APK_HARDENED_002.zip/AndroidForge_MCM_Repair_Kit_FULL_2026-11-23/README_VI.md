# AndroidForge – MCM 1.6.3 ZIP → APK Hotfix

## 1. Lỗi được xác nhận từ log mới

Ba log mới nhất (`build-1795419952-2.log`, `build-1795419954-2.log`, `build-1795419957-2.log`) cùng chạy Gradle tại:

`AndroidForge_MCM_Repair_Kit_FULL_2026-11-23`

Gradle báo thư mục không có `settings.gradle`/`settings.gradle.kts` hoặc `build.gradle`. Cả `assembleDebug`, `assembleRelease` và `bundleDebug` đều dừng ngay trong 2 giây.

Đây là lỗi chọn ZIP/project root: AndroidForge đã giải nén **Repair Kit** rồi chạy Gradle trên thư mục Repair Kit. Chưa có bằng chứng ba lệnh này đã compile source MCM; không được quy lỗi này cho Kotlin.

## 2. Hotfix lần này

- `resolve_mcm_source.py`: nhận ZIP được AndroidForge acquire; nếu đó là Repair Kit/wrapper thì tìm đúng ZIP MCM dẫn xuất bên trong bằng SHA-256 đã khóa. Không tìm thấy đúng hash thì dừng trước Gradle.
- `extract_zip.py`: giải nén an toàn, chặn path traversal/symlink ZIP, tìm đúng project root có Gradle settings + root build + module `:app`. Không bao giờ trả về thư mục giải nén chỉ vì nó tồn tại.
- `patch_androidforge_workflow.py`: thêm bước resolve MCM source trước Extract; mặc định `project_profile=mcm-native`; dùng đường dẫn/hash của source đã resolve cho extract, validate, provenance và collector.
- Hạ quyền `GITHUB_TOKEN` của job build xuống read-only; source ZIP có thể chứa Gradle build logic không được phép thừa hưởng quyền ghi repo/release.
- Sửa image GHCR sang image do chính repository hiện tại publish, thay vì hard-code `professional-x`.
- Sửa Builder web: mỗi lần upload ZIP tạo branch riêng `androidforge/web-build-<timestamp>`, commit ZIP và dispatch workflow trên branch đó; không ghi vào `main`.
- Builder nhận diện MCM 1.6.3 để gửi `project_profile=mcm-native`; dự án khác dùng `auto`. Khi không có Release, giao diện kiểm tra Actions artifacts và hướng dẫn tải từ run tương ứng.
- Workflow tự provision JDK 17 (`actions/setup-java@v6`), Gradle 8.7 (`gradle/actions/setup-gradle@v6`) và Android SDK (`android-actions/setup-android@v4` + sdkmanager Platform 35/Build Tools 35.0.0), sau đó validator vẫn kiểm tra đúng phiên bản trước build. AGP 8.6.1 và Kotlin 2.0.21 giữ nguyên trong source.
- Không tự release; không push/merge; chỉ tạo branch riêng khi áp dụng.

## 3. Source bị khóa

**Source gốc**  
`androidforge_patch/MCM_SOURCE/LOCKED_BASE/MCM_1.6.3_RECONCILED_DDNS_KOTLIN_SOURCE_NOT_RELEASE_FIXED-1.zip`  
SHA-256: `6313e1b28d2e7fa18fd56f20f8a4d91d6abf81a0027d1fe44e33e48a94ea1f0b`

**Source dẫn xuất được build**  
`input/MCM_1.6.3_RECONCILED_DDNS_KOTLIN_SOURCE_DERIVED_PATCH_001.zip`  
SHA-256: `6b2f810a430f69d172a81dedafb0f3729e1c5c6f3170db3367426e3c77a59f45`

Identity: `MCM-1.6.3-RECONCILED-001`, `com.multicloud.mcm`, version `1.6.3`, versionCode `12`.

Nếu người dùng chọn ZIP Repair Kit mới làm đầu vào AndroidForge, resolver sẽ lấy source dẫn xuất chính xác nằm bên trong, không build thư mục Repair Kit.

## 4. Kiểm thử hotfix

- AndroidForge hardening + regression tests: **29/29 PASS** sau khi sửa test fixture và bổ sung kiểm tra frontend branch/artifact.
- Direct pinned source → resolver: PASS.
- Delivery/wrapper ZIP chứa source dẫn xuất → resolver trích đúng source hash: PASS.
- Repair Kit cũ không chứa source dẫn xuất → bị từ chối trước Gradle: PASS.
- MCM source ZIP → strict extractor tìm đúng Gradle root và `:app`: PASS.
- Repair Kit wrapper → strict extractor từ chối, không trả thư mục wrapper: PASS.
- ZIP path traversal → bị từ chối: PASS.
- Workflow fixture được vá để resolve source trước extract, validate hash, chạy strict toolchain và chỉ collect sau build thành công: PASS.
- Frontend fixture: upload/dispatch chỉ trên branch riêng, không PATCH default branch; MCM luôn build debug và không chạy nhầm desktop; hiển thị Actions artifacts khi không có Release: PASS.
- ZIP safety: giới hạn dung lượng, số member, tổng kích thước giải nén và tỷ lệ nén; chặn ZIP bomb, member trùng tên, symlink và special-file: PASS.
- Workflow token permissions: read-only; container image trỏ tới GHCR của repository đang chạy: PASS.

Các test trên là kiểm thử script/workflow fixture, **không phải** GitHub Actions run thật hay APK thật. Apply script cũng đã chạy end-to-end trên một repository Git giả lập: tạo branch, vá workflow + frontend, chạy 29 tests và `git diff --check` đều PASS. GitHub repo thật chưa bị sửa.

## 5. Cách áp dụng

1. Giải nén gói hotfix.
2. Mở terminal tại thư mục gốc repository AndroidForge (phải có `.git` và `.github/workflows/build-android.yml`).
3. Chạy `bash APPLY_TO_ANDROIDFORGE.sh`; Windows dùng `APPLY_TO_ANDROIDFORGE.ps1`.
4. Script yêu cầu working tree sạch, tạo branch riêng `fix/mcm-1.6.3-zip-root-hotfix`, cài scripts/tests, copy source ZIP, kiểm tra SHA và vá workflow. Không checkout/sửa `main`, không push, merge hay release.
5. Script tự chạy compileall + 29 regression tests + `git diff --check`. Nó chỉ tạo branch local, không push/merge. Sau khi chủ repo tự push branch này, mở GitHub Actions, chọn workflow **Build Android APK**, chọn đúng branch `fix/mcm-1.6.3-zip-root-hotfix`, nhập `project_profile=mcm-native`, `zip_source=input-directory`, `zip_path=input/MCM_1.6.3_RECONCILED_DDNS_KOTLIN_SOURCE_DERIVED_PATCH_001.zip`, `build_variant=debug`. Không chạy workflow trên `main`.

## 6. Giới hạn nghiệm thu

Môi trường hiện tại chỉ có JDK 21; không có Gradle 8.7, JDK 17 hoặc Android SDK Platform 35/build-tools. GitHub connector đọc được repo nhưng từ chối thao tác tạo branch (403); không có quyền thực thi workflow mới từ phiên này. Vì vậy chưa thể xác minh compile Kotlin/Gradle, lint, APK manifest hoặc cài APK thật. **Không có APK MCM 1.6.3 được tạo; pipeline thật vẫn CHƯA NGHIỆM THU.**

**Trạng thái: ZIP→project-root hotfix đã kiểm thử bằng regression suite; pipeline thật và APK vẫn CHƯA NGHIỆM THU.**
