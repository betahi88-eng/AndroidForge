$ErrorActionPreference = "Stop"
$Repo = (Get-Location).Path
if (-not (Test-Path (Join-Path $Repo ".git"))) { throw "Run at the AndroidForge repository root." }
if (git status --porcelain) { throw "Working tree must be clean before applying the patch." }
$branch = "fix/mcm-1.6.3-zip-root-hotfix"
git switch -c $branch
if ($LASTEXITCODE -ne 0) { throw "Could not create isolated patch branch." }
$Kit = Split-Path -Parent $MyInvocation.MyCommand.Path
$Patch = Join-Path $Kit "androidforge_patch"
$Scripts = Join-Path $Repo "scripts"
New-Item -ItemType Directory -Force $Scripts | Out-Null
New-Item -ItemType Directory -Force (Join-Path $Repo "input") | Out-Null
$Tests = Join-Path $Repo "tests"
New-Item -ItemType Directory -Force $Tests | Out-Null
Get-ChildItem (Join-Path $Patch "scripts") -Filter "*.py" -File | ForEach-Object {
    Copy-Item $_.FullName $Scripts -Force
}
Get-ChildItem (Join-Path $Patch "tests") -Filter "*.py" -File | ForEach-Object {
    Copy-Item $_.FullName $Tests -Force
}
Copy-Item (Join-Path $Patch "patch_androidforge_workflow.py") $Repo -Force
$archive = "MCM_1.6.3_RECONCILED_DDNS_KOTLIN_SOURCE_DERIVED_PATCH_001.zip"
Copy-Item (Join-Path $Kit "input\$archive") (Join-Path $Repo "input\$archive") -Force
Copy-Item (Join-Path $Kit "input\$archive.sha256") (Join-Path $Repo "input\$archive.sha256") -Force
$expected = (Get-Content (Join-Path $Kit "input\$archive.sha256") -Raw).Split(" ")[0]
$actual = (Get-FileHash (Join-Path $Repo "input\$archive") -Algorithm SHA256).Hash.ToLower()
if ($actual -ne $expected) { throw "MCM SHA-256 mismatch." }
python (Join-Path $Repo "patch_androidforge_workflow.py") --workflow (Join-Path $Repo ".github\workflows\build-android.yml")
if ($LASTEXITCODE -ne 0) { throw "Workflow/frontend patch failed." }
python -m compileall -q (Join-Path $Repo "scripts") (Join-Path $Repo "tests") (Join-Path $Repo "patch_androidforge_workflow.py")
if ($LASTEXITCODE -ne 0) { throw "Python syntax validation failed." }
python -m unittest discover -s (Join-Path $Repo "tests") -v
if ($LASTEXITCODE -ne 0) { throw "AndroidForge hardening regression suite failed." }
git diff --check
if ($LASTEXITCODE -ne 0) { throw "git diff --check failed." }
Write-Host "Applied on $branch from current HEAD. main was not checked out or modified; no push/merge/release performed. Review git diff."
