# Kết quả kiểm toán bổ sung – ZIP → APK

## Phát hiện từ repository AndroidForge thật
- `build-android.yml` hard-code container `ghcr.io/professional-x/...` trong khi image workflow publish theo `github.repository_owner`; fork có thể kéo nhầm image hoặc image không tồn tại.
- Job build cấp `contents:write` và `actions:write` trong khi chạy source ZIP do người dùng tải lên. Gradle build logic là mã thực thi không tin cậy; đây là rủi ro lộ token/quyền ghi.
- Build frontend cũ tạo commit ZIP trực tiếp lên default branch, rồi dispatch workflow trên default branch. Điều này làm thay đổi `main` chỉ để tải input.
- Sau khi tắt automatic Release để bảo vệ quy trình, frontend cũ chỉ tìm Release assets và không nhận biết Actions artifacts; kết quả build thành công có thể bị hiển thị như không có APK.
- Ba bài test trong hotfix cũ phụ thuộc đường dẫn tuyệt đối `/mnt/data/...`, khiến suite fail khi chạy trong workspace khác.

## Sửa chữa trong bản hardening hiện tại
- Hạ permissions build workflow xuống `contents:read`, `actions:read`, `packages:read`; tắt lưu checkout credentials trong `.git/config`.
- Container image dùng `ghcr.io/${{ github.repository_owner }}/androidforge-build-env:latest`.
- Web Builder tạo branch riêng `androidforge/web-build-<timestamp>`, commit input ZIP và dispatch đúng branch; không PATCH default branch.
- UI gửi profile `mcm-native` cho ZIP MCM 1.6.3, `auto` cho dự án khác; fallback tìm Actions artifacts khi không có Release.
- Test fixture tự tạo wrapper ZIP tạm, không tham chiếu đường dẫn người dùng/máy cố định.
- ZIP safety dùng giới hạn tài nguyên và từ chối ZIP bomb, duplicate member, symlink/special-file; tải URL chỉ nhận HTTPS và giới hạn 100 MB.

## Regression
- 29/29 Python tests PASS, gồm 26 hardening/extractor tests, 1 frontend branch/artifact patch test và 2 ZIP safety tests.
- Source hash, resolver, extractor, identity, toolchain preflight và strict collector fixture PASS.
- Python syntax PASS.

## Giới hạn nghiệm thu
Không có checkout Git thực của `anhtranmng-sys/AndroidForge` vì GitHub connector không cấp quyền ghi và không cung cấp archive binary. Môi trường hiện tại chỉ có JDK 21, không có Gradle 8.7, JDK 17 hoặc Android SDK 35. Do đó chưa chạy patch trực tiếp trên repository thật, chưa chạy GitHub Actions, chưa compile Android/Kotlin và chưa tạo APK thật. Không được tuyên bố ZIP→APK đã nghiệm thu.
