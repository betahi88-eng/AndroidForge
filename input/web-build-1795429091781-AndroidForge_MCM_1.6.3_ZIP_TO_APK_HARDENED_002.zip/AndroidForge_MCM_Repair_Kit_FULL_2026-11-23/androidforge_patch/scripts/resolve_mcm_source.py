#!/usr/bin/env python3
"""Resolve the exact pinned MCM source ZIP from either a direct ZIP or a wrapper ZIP.

AndroidForge previously treated an AndroidForge Repair Kit ZIP as the project
source. This resolver never extracts/builds a wrapper. It accepts only the
pinned derived MCM archive, either directly or as a nested ZIP member.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
import zipfile
from pathlib import Path
from zip_safety import validate_zip_file_size, validate_zip_metadata

EXPECTED_SHA256 = "6b2f810a430f69d172a81dedafb0f3729e1c5c6f3170db3367426e3c77a59f45"
EXPECTED_NAME = "MCM_1.6.3_RECONCILED_DDNS_KOTLIN_SOURCE_DERIVED_PATCH_001.zip"


def digest_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def digest_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def validate_source_archive_bytes(data: bytes, member_name: str) -> None:
    if digest_bytes(data) != EXPECTED_SHA256:
        raise RuntimeError(f"Nested ZIP is not the pinned MCM 1.6.3 source: {member_name}")
    import io
    with zipfile.ZipFile(io.BytesIO(data), "r") as source:
        bad = source.testzip()
        if bad:
            raise RuntimeError(f"Pinned MCM source ZIP CRC failure: {bad}")
        names = set(source.namelist())
        required = {
            "settings.gradle.kts",
            "build.gradle.kts",
            "app/build.gradle.kts",
            "SOURCE_IDENTITY.txt",
            "app/src/main/AndroidManifest.xml",
        }
        missing = sorted(required - names)
        if missing:
            raise RuntimeError("Pinned MCM ZIP is missing project-root files: " + ", ".join(missing))
        identity = source.read("SOURCE_IDENTITY.txt").decode("utf-8", "replace")
        if "APPLICATION_ID=com.multicloud.mcm" not in identity or "VERSION_NAME=1.6.3" not in identity or "VERSION_CODE=12" not in identity:
            raise RuntimeError("Pinned MCM ZIP identity marker does not match MCM 1.6.3")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidate", required=True, help="ZIP selected by AndroidForge's existing acquisition step")
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--output-json", default="mcm-source-resolution.json")
    args = parser.parse_args()

    candidate = Path(args.candidate).resolve()
    output_dir = Path(args.output_dir).resolve()
    if not candidate.is_file():
        raise RuntimeError(f"Acquired source candidate is not a valid ZIP: {candidate}")
    validate_zip_file_size(candidate)
    if not zipfile.is_zipfile(candidate):
        raise RuntimeError(f"Acquired source candidate is not a valid ZIP: {candidate}")

    candidate_hash = digest_file(candidate)
    selected_bytes: bytes | None = None
    selected_name = candidate.name
    if candidate_hash == EXPECTED_SHA256:
        selected_bytes = candidate.read_bytes()
    else:
        matches: dict[str, tuple[str, bytes]] = {}
        with zipfile.ZipFile(candidate, "r") as wrapper:
            validate_zip_metadata(wrapper, label="Wrapper ZIP")
            bad = wrapper.testzip()
            if bad:
                raise RuntimeError(f"Wrapper ZIP CRC failure at {bad}")
            for info in wrapper.infolist():
                if info.is_dir() or not info.filename.lower().endswith(".zip"):
                    continue
                # The only accepted nested archive is a small, pinned source ZIP.
                if info.file_size > 5 * 1024 * 1024:
                    continue
                try:
                    payload = wrapper.read(info)
                except (KeyError, RuntimeError, zipfile.BadZipFile):
                    continue
                digest = digest_bytes(payload)
                if digest == EXPECTED_SHA256:
                    matches[digest] = (info.filename, payload)
        if len(matches) != 1:
            nested = []
            with zipfile.ZipFile(candidate, "r") as wrapper:
                nested = [i.filename for i in wrapper.infolist() if not i.is_dir() and i.filename.lower().endswith(".zip")]
            raise RuntimeError(
                "BUILD_STOPPED_INVALID_PROJECT: selected ZIP is a wrapper/Repair Kit, not the pinned MCM source; "
                f"expected exactly one nested source with SHA-256 {EXPECTED_SHA256}, found {len(matches)}. "
                f"Nested ZIP entries: {nested}"
            )
        selected_name, selected_bytes = next(iter(matches.values()))

    assert selected_bytes is not None
    validate_source_archive_bytes(selected_bytes, selected_name)
    output_dir.mkdir(parents=True, exist_ok=True)
    target = output_dir / EXPECTED_NAME
    target.write_bytes(selected_bytes)
    actual = digest_file(target)
    if actual != EXPECTED_SHA256:
        raise RuntimeError("Resolved MCM source hash changed while writing workspace copy")

    result = {
        "status": "PASS",
        "input_candidate": str(candidate),
        "input_candidate_sha256": candidate_hash,
        "resolved_source_name": EXPECTED_NAME,
        "resolved_source_member": selected_name,
        "resolved_source_path": str(target),
        "resolved_source_sha256": actual,
        "source_id": "MCM-1.6.3-RECONCILED-001",
        "application_id": "com.multicloud.mcm",
        "version_name": "1.6.3",
        "version_code": 12,
        "project_kind": "NATIVE_ANDROID_GRADLE_KOTLIN",
    }
    output_json = Path(args.output_json)
    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(json.dumps(result, indent=2), encoding="utf-8")
    github_output = os.environ.get("GITHUB_OUTPUT")
    if github_output:
        with open(github_output, "a", encoding="utf-8") as stream:
            stream.write(f"zip_path={target}\n")
            stream.write(f"zip_name={EXPECTED_NAME}\n")
            stream.write(f"zip_sha256={actual}\n")
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"MCM SOURCE RESOLUTION FAILED: {error}", file=sys.stderr)
        raise SystemExit(2)
