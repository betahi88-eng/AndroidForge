#!/usr/bin/env python3
"""Shared ZIP bomb/resource-bound validation for untrusted build inputs."""
from __future__ import annotations
import zipfile

MAX_ARCHIVE_BYTES = 100 * 1024 * 1024
MAX_MEMBERS = 100_000
MAX_MEMBER_UNCOMPRESSED = 512 * 1024 * 1024
MAX_TOTAL_UNCOMPRESSED = 2 * 1024 * 1024 * 1024
MAX_COMPRESSION_RATIO = 1_000


def validate_zip_metadata(archive: zipfile.ZipFile, *, label: str = "ZIP") -> None:
    infos = archive.infolist()
    if len(infos) > MAX_MEMBERS:
        raise RuntimeError(f"{label} exceeds member-count limit ({len(infos)} > {MAX_MEMBERS})")
    total = 0
    seen: set[str] = set()
    for info in infos:
        name = info.filename.replace("\\", "/")
        if name in seen:
            raise RuntimeError(f"{label} contains duplicate member path: {name}")
        seen.add(name)
        if info.flag_bits & 0x1:
            raise RuntimeError(f"{label} contains encrypted member: {name}")
        if info.file_size < 0 or info.compress_size < 0:
            raise RuntimeError(f"{label} contains invalid size metadata: {name}")
        if info.file_size > MAX_MEMBER_UNCOMPRESSED:
            raise RuntimeError(f"{label} member exceeds uncompressed size limit: {name}")
        total += info.file_size
        if total > MAX_TOTAL_UNCOMPRESSED:
            raise RuntimeError(f"{label} exceeds total uncompressed size limit")
        if info.file_size and not info.compress_size:
            raise RuntimeError(f"{label} has suspicious zero-byte compressed member: {name}")
        if info.compress_size and info.file_size / info.compress_size > MAX_COMPRESSION_RATIO:
            raise RuntimeError(f"{label} member compression ratio exceeds limit: {name}")


def validate_zip_file_size(path) -> None:
    size = path.stat().st_size
    if size <= 0 or size > MAX_ARCHIVE_BYTES:
        raise RuntimeError(f"ZIP file size must be between 1 byte and {MAX_ARCHIVE_BYTES} bytes; got {size}")
