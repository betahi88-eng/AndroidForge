from pathlib import Path
import importlib.util
import sys
import tempfile
import unittest
import zipfile

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
from zip_safety import validate_zip_metadata


class ZipSafetyTests(unittest.TestCase):
    def test_extreme_compression_ratio_is_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            archive_path = Path(temp) / "ratio.zip"
            with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
                archive.writestr("zeros.bin", b"0" * (3 * 1024 * 1024))
            with zipfile.ZipFile(archive_path) as archive:
                with self.assertRaisesRegex(RuntimeError, "compression ratio exceeds limit"):
                    validate_zip_metadata(archive)

    def test_duplicate_member_names_are_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            archive_path = Path(temp) / "duplicate.zip"
            with zipfile.ZipFile(archive_path, "w") as archive:
                archive.writestr("same.txt", "first")
                archive.writestr("same.txt", "second")
            with zipfile.ZipFile(archive_path) as archive:
                with self.assertRaisesRegex(RuntimeError, "duplicate member path"):
                    validate_zip_metadata(archive)


if __name__ == "__main__":
    unittest.main()
