from pathlib import Path
import importlib.util
import sys
import tempfile
import unittest

PATCH_ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("patch_androidforge_workflow", PATCH_ROOT / "patch_androidforge_workflow.py")
patcher = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = patcher
spec.loader.exec_module(patcher)


class FrontendPatcherTests(unittest.TestCase):
    def test_build_isolated_branch_and_artifact_fallback(self):
        fixture = r'''
        const commitPath = `input/web-build-${timestamp}-${safeName}`;
        // 3e. Update the branch ref to point to the new commit (fast-forward).
        //     If another push moved the branch concurrently (HTTP 422),
        //     retry the tree+commit/ref flow once on the new HEAD.
        appendLog(`→ Updating ref refs/heads/${repoInfo.default_branch}…`);
        els.uploadStatus.textContent = "updating branch…";
        try {
          await apiJson(`/repos/${c.owner}/${c.repo}/git/refs/heads/${repoInfo.default_branch}`, {
            method: "PATCH",
            body: JSON.stringify({ sha: newCommitSha, force: false }),
            headers: { "Content-Type": "application/json" },
          });
          window._currentCommitSha = newCommitSha;
        } catch (e) {
          if (e.status !== 422) throw e;
          appendLog(`  ⚠ Branch moved concurrently; retrying on new HEAD…`);
          const refRes2 = await apiJson(`/repos/${c.owner}/${c.repo}/git/refs/heads/${repoInfo.default_branch}`);
          const curHead2 = refRes2.object.sha;
          const commitObj2 = await apiJson(`/repos/${c.owner}/${c.repo}/git/commits/${curHead2}`);
          const treeRes2 = await apiJson(`/repos/${c.owner}/${c.repo}/git/trees`, {
            method: "POST",
            body: JSON.stringify({
              base_tree: commitObj2.tree.sha,
              tree: [{ path: commitPath, mode: "100644", type: "blob", sha: blobSha }],
            }),
            headers: { "Content-Type": "application/json" },
          });
          const newCommitRes2 = await apiJson(`/repos/${c.owner}/${c.repo}/git/commits`, {
            method: "POST",
            body: JSON.stringify({
              message: commitMessage,
              tree: treeRes2.sha,
              parents: [curHead2],
            }),
            headers: { "Content-Type": "application/json" },
          });
          await apiJson(`/repos/${c.owner}/${c.repo}/git/refs/heads/${repoInfo.default_branch}`, {
            method: "PATCH",
            body: JSON.stringify({ sha: newCommitRes2.sha, force: false }),
            headers: { "Content-Type": "application/json" },
          });
          window._currentCommitSha = newCommitRes2.sha;
          appendLog(`  ✓ Ref updated on retry (commit ${newCommitRes2.sha.substring(0, 7)})`);
        }
        appendLog(`  ✓ ${commitPath} committed`);
        const androidInputs = { enable_ndk: els.enableNdk.checked, };
            enable_ndk: els.enableNdk.checked,
            build_variant: els.variant.value,
        const wantAndroid = (targetChoice === "android" || targetChoice === "all");
        const wantDesktop = (targetChoice !== "android");
        const androidDispatch = { ref: repoInfo.default_branch, inputs };
        const desktopDispatch = { ref: repoInfo.default_branch, inputs };
        const dispatchedRuns = (runs.workflow_runs || []).filter(r =>
          r.head_branch === repoInfo.default_branch && r.event === "workflow_dispatch"
        );
          if (collectedAssets.length === 0) {
            appendLog(`[result] no assets found in any release`);
            els.resultContent.innerHTML += `<div class="status warn">No APK / desktop binaries were found in any output release. Use the GitHub run link above to check.</div>`;
          } else {
        }
        '''
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "index.html"
            path.write_text(fixture, encoding="utf-8")
            patcher.patch_frontend(path)
            result = path.read_text(encoding="utf-8")
            self.assertIn("androidforge/web-build-${timestamp}", result)
            self.assertIn("refs/heads/${buildBranch}", result)
            self.assertNotIn('method: "PATCH"', result)
            self.assertNotIn("ref: repoInfo.default_branch, inputs", result)
            self.assertIn('project_profile: isMcmSource ? "mcm-native" : "auto"', result)
            self.assertIn('build_variant: isMcmSource ? "debug" : els.variant.value', result)
            self.assertIn("const isMcmSource =", result)
            self.assertIn("const wantDesktop = !isMcmSource", result)
            self.assertIn("actions/runs/${runId}/artifacts", result)
            self.assertIn("r.head_branch === buildBranch", result)


if __name__ == "__main__":
    unittest.main()
