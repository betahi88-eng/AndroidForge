# MCM 1.6.3 — Build status and acceptance boundary

Source identity: `MCM-1.6.3-RECONCILED-001`  
Integration patch: `MCM-1.6.3-ENDPOINT-INTEGRATION-002`  
Parent source: `AndroidForge_MCM_1.6.3_SAMPLE_PROJECT_BUILD_FIX_002.zip`  
Parent SHA-256: `7e5872d18df840f7367de787d7f15818191bd2402612efa1fe2162c96cd6337a`  
Application ID: `com.multicloud.mcm`  
Version: `1.6.3` (`versionCode=12`)

## Work completed in this candidate

- Preserved the existing native Kotlin project and its already implemented DNS fallback, TLS pinning, encrypted credentials, Room v6, RouterOS adapters, monitoring snapshots, MNDP discovery, per-router history/charts and sequential refresh-all.
- Completed the previously disconnected custom WAN port/service-mode path: Advanced UI → WebView bridge → connection coordinator → TLS probe → authenticated READ_CHECK → persisted Room profile.
- Kept exactly three primary Add Router inputs and one primary “Lưu & Kết nối” action. Technical port/service options remain hidden in a closed-by-default Advanced section.
- AUTO with blank port probes REST/443 and API-SSL/8729 in parallel; AUTO with a custom port probes both protocols on that same WAN port; explicit service mode probes only that service.
- Persists the exact port that passed TLS + READ_CHECK and uses saved mode/port for foreground and background monitoring.
- Added a focused RouterServiceMode JUnit matrix and updated source/UI verification gates.

## Verified in this environment

- `bash scripts/verify-source.sh`: PASS for Native Android project identity, JavaScript syntax, Python syntax, shell syntax, Android XML, Room v1→v6 preservation and UI contract.
- `python3 scripts/verify-ui-contract.py`: PASS; exactly three primary inputs, hidden advanced port/service controls, one primary action.
- `python3 scripts/verify-room-migrations.py`: PASS; router profiles, metrics, interface counters and connection-attempt logs preserved through schema v6.
- Local `kotlinc` compile + service/port smoke: PASS (9 assertions covering AUTO/default/custom, explicit REST/API-SSL, RouterOS compatibility and invalid ports).
- ZIP CRC and source provenance are verified at packaging time.

## Not verified / blocked

This runtime has OpenJDK 21 but no pinned JDK 17, Gradle 8.7 or Android SDK Platform 35/build-tools. Therefore Gradle/KAPT compile, Android JUnit task, lint, `assembleDebug`, APK manifest validation, emulator/phone installation and live RouterOS 6/7 WAN/DDNS acceptance are **NOT RUN**. No APK is included and no live router was contacted.

This is an engineering source candidate, not a release APK. Do not represent static checks or the Kotlin service-mode smoke as a full Android build or real-network acceptance.
