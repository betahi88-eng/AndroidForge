# Cập nhật kiểm toán MCM 1.6.3 — 23/11/2026

Bản audit cũ bên dưới phản ánh MCM 1.6.0. Kết quả đối chiếu source lịch sử và phần tích hợp hiện tại được ghi riêng trong `PORT_MODE_RECONCILIATION_VI.md`. Parent build source là FIX_002 (SHA-256 `7e5872d18df840f7367de787d7f15818191bd2402612efa1fe2162c96cd6337a`). Candidate đã nối custom WAN port/service mode từ UI qua native bridge, coordinator, TLS/READ_CHECK và Room; source/UI/Room checks cùng Kotlin service-mode smoke đạt. Gradle build, APK và RouterOS thực tế vẫn NOT RUN.

---

# MCM 1.6.0 — Full source audit and implementation report

## Kết luận

Đã lấy source MCM 1.5.1 Direct-DDNS/Multi-Store mới nhất trong Library làm baseline, kiểm tra cấu trúc, các adapter RouterOS, phần profile/Room, UI form, chẩn đoán endpoint, foreground monitor, WorkManager và build scripts. Đã triển khai thay đổi source 1.6.0 để tách giao thức dịch vụ khỏi port và phiên bản RouterOS; không thay đổi cấu hình router thật.

**Trạng thái:** Engineering source / NOT RELEASE. Không có APK được build trong workspace hiện tại.

## Vấn đề được xử lý

1. Ở 1.5.1, port vốn đã là trường riêng per-router và được truyền đến DNS/TCP diagnostic, TLS inspector, REST/API-SSL client và background worker.
2. Nhưng giao thức thực tế bị suy ra cứng từ RouterOS major: ROS7 REST HTTPS, ROS6 API-SSL. UI không cho chọn protocol riêng.
3. `routerOs` change listener luôn ghi đè port về 443/8729, kể cả khi người dùng đã nhập port WAN tùy chỉnh.
4. Màn hình chưa giải thích rõ rằng TCP 8291 của WinBox không phải REST/API-SSL; việc WinBox kết nối thành công không chứng minh MCM có thể đọc dữ liệu.
5. Room profile chưa lưu protocol selection độc lập.

## Source changes 1.6.0

- Thêm `RouterServiceMode`: AUTO, REST_HTTPS, API_SSL và resolver protocol có kiểm tra tương thích.
- REST_HTTPS chỉ hợp lệ cho RouterOS 7; API_SSL cho RouterOS 6 hoặc 7; AUTO giữ hành vi cũ.
- `RouterEntity` thêm `connectionMode`; Room database nâng từ version 3 lên 4 bằng migration thêm cột `connectionMode TEXT NOT NULL DEFAULT 'AUTO'`.
- MainActivity và WorkManager đều đăng ký migration v3→v4.
- Profile save/list lưu và trả `connectionMode`, validate port là integer 1..65535.
- Monitoring foreground và background đều resolve cùng service mode và tiếp tục dùng port saved per profile.
- UI bổ sung service selector, WAN port editor, gợi ý port theo protocol, giữ port thủ công khi đổi OS/service, cảnh báo khi nhập 8291.
- DNS/TCP message phân biệt socket reachability với TLS/service/authentication.
- Thêm unit tests cho service resolution và nâng migration/UI contract checks.
- Cập nhật version 1.6.0 / versionCode 9, CI and AndroidForge version gates, tài liệu, changelog and package script.

## WinBox boundary — không tuyên bố sai khả năng

MCM không nói giao thức WinBox. Nếu 8291 đang chạy WinBox, MCM không thể lấy dữ liệu qua đó chỉ bằng đổi port. Người dùng có thể nhập bất kỳ cổng WAN 1..65535, nhưng cổng đó phải thực sự kết thúc ở dịch vụ REST HTTPS hoặc API-SSL mà MCM hỗ trợ. Có thể dùng NAT/port forwarding để ánh xạ một cổng ngoài tùy chọn tới đúng listener bên trong; MCM không tự tạo quy tắc NAT/firewall.

## Bảo toàn và an toàn

- Existing profiles migrate as AUTO; the DB migration leaves hostname, WAN port, RouterOS major, credentials alias, TLS pin, health fields and monitoring tables intact.
- Port/service changes are local profile metadata only. MCM does not mutate RouterOS services, firewall, NAT, DDNS, addresses or user accounts.
- TLS fingerprint remains mandatory; capture is not treated as trust until independently verified.
- No plaintext API, HTTP fallback, WinBox protocol implementation, VPN, VPS or relay added.

## Validation boundary

Source checks completed:
- AndroidForge flat-root project preflight: PASS.
- `scripts/verify-source.sh`: PASS for JS, Python compile, Room SQL migration preservation, DOM/port/protocol contract, shell syntax and Android XML.
- Room migration simulation: PASS for v1→v2→v3→v4, v2→v3→v4 and v3→v4.
- WebView contract: PASS (73 unique HTML IDs and 57 JS DOM lookups).
- Standalone `RouterServiceMode` Kotlin smoke tests: PASS with local kotlinc 1.9.0; this is not a complete application compile.
- Final source archive CRC and root layout: PASS; SHA-256 sidecar is supplied with the archive.

Not run / not verified:
- Full Gradle compilation, Room KAPT, Android JUnit tests, lint, APK assembly and APK signing.
- Physical Android installation, live WAN/DDNS reachability and RouterOS 6/7 hardware acceptance.

The workspace lacks Gradle 8.7 and Android SDK Platform 35, and has Java 21 rather than the required JDK 17. Therefore this package is engineering source / NOT RELEASE. Final source package and next steps are documented in `BUILD_STATUS.md` and `NEXT_ACTION_VI.md`.
