package com.multicloud.mcm

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Credentials
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.X509TrustManager

/** RouterOS 7 REST client. Only HTTPS with a manually verified SHA-256 leaf certificate pin. */
class RouterOs7Client(
    private val host: String,
    private val port: Int,
    private val username: String,
    private val password: String,
    expectedPinHex: String
) {
    private val normalizedPin = normalizePin(expectedPinHex)
    private val trustManager = object : X509TrustManager {
        override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
        override fun checkClientTrusted(chain: Array<out X509Certificate>, authType: String) {
            throw CertificateException("Client certificate authentication is not supported")
        }
        override fun checkServerTrusted(chain: Array<out X509Certificate>, authType: String) {
            val leaf = chain.firstOrNull() ?: throw CertificateException("Router sent no TLS certificate")
            val actual = sha256(leaf.encoded)
            if (!MessageDigest.isEqual(actual.toByteArray(), normalizedPin.toByteArray())) {
                throw CertificateException("Router TLS certificate fingerprint mismatch")
            }
        }
    }

    private val http = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .callTimeout(30, TimeUnit.SECONDS)
        .sslSocketFactory(
            SSLContext.getInstance("TLS").apply {
                init(null, arrayOf(trustManager), SecureRandom())
            }.socketFactory,
            trustManager
        )
        .build()

    private fun url(path: String): String {
        require(path.matches(Regex("[A-Za-z0-9_./-]+"))) { "Invalid RouterOS REST path" }
        require(host.isNotBlank() && port in 1..65535)
        return "https://$host:$port/rest/${path.trimStart('/')}"
    }

    suspend fun get(path: String): McmResult<JSONArray> = withContext(Dispatchers.IO) {
        execute(Request.Builder().url(url(path)).get().build())
    }

    suspend fun post(path: String, payload: JSONObject): McmResult<JSONArray> = withContext(Dispatchers.IO) {
        val body = payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        execute(Request.Builder().url(url(path)).post(body).build())
    }

    private fun execute(request: Request): McmResult<JSONArray> {
        val authenticated = request.newBuilder()
            .header("Authorization", Credentials.basic(username, password))
            .header("Accept", "application/json")
            .build()
        return try {
            http.newCall(authenticated).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val detail = runCatching { JSONObject(body).optString("message") }.getOrNull()
                    McmResult.Failure("HTTP_${response.code}", detail?.takeIf(String::isNotBlank)
                        ?: "RouterOS REST trả HTTP ${response.code}.")
                } else {
                    val trimmed = body.trim()
                    val result = when {
                        trimmed.isBlank() -> JSONArray()
                        trimmed.startsWith("[") -> JSONArray(trimmed)
                        trimmed.startsWith("{") -> JSONArray().put(JSONObject(trimmed))
                        else -> return McmResult.Failure("REST_FORMAT", "Phản hồi REST không phải JSON hợp lệ.")
                    }
                    McmResult.Success(result)
                }
            }
        } catch (e: javax.net.ssl.SSLException) {
            McmResult.Failure("TLS", "Không xác minh được chứng chỉ TLS của router. Kiểm tra SHA-256 fingerprint.")
        } catch (e: Exception) {
            McmResult.Failure("NETWORK", e.message ?: "Không thể kết nối router.")
        }
    }

    companion object {
        fun normalizePin(value: String): String {
            val candidate = value.trim().substringAfterLast('=', value.trim())
            val pin = candidate.replace(Regex("[:\\s]"), "").uppercase()
            require(pin.matches(Regex("[A-F0-9]{64}"))) {
                "SHA-256 fingerprint phải gồm đúng 64 ký tự hex (có thể ngăn cách bằng dấu hai chấm)."
            }
            return pin
        }

        fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256")
            .digest(bytes).joinToString("") { "%02X".format(it.toInt() and 0xFF) }
    }
}
