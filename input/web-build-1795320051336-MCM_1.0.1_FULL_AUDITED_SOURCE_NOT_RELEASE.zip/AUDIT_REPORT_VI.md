# MCM 1.0.1 — Báo cáo audit source và khả năng build

## Kết luận điều hành

Gói này là **Android native Kotlin/Gradle source**, không phải Flutter. Source ZIP có thể giải nén và qua các kiểm tra tĩnh được liệt kê bên dưới. Đây **không phải APK đã biên dịch**. Trong môi trường audit hiện tại không có Gradle 8.7, Android SDK Platform 35/Build Tools 35.0.0 và không truy cập được kho tải phụ thuộc; do đó không thể chạy Android Gradle Plugin, kapt/Room, JUnit qua Gradle, lint hoặc assembleDebug. Không được coi các kiểm tra tĩnh là bằng chứng APK chạy được.

## 1. Nhận diện dự án và build baseline

- Root Gradle project: `MikroTikMultiCloudMonitor`
- Application ID / namespace: `com.multicloud.mcm`
- Android Gradle Plugin: 8.6.1
- Kotlin Gradle Plugin: 2.0.21
- Gradle baseline: 8.7
- JDK: 17
- compileSdk / targetSdk: 35; minSdk: 26
- Android Build Tools: 35.0.0
- Không có `pubspec.yaml`, `harmony_patched`, hoặc Gradle Wrapper JAR.
- CI riêng của source cài JDK 17, Android SDK 35 và Gradle 8.7; build Debug, không ký release.
- AndroidForge là workflow ngoài repository này. ZIP chỉ hướng dẫn chọn đúng `zip_path`; không có bằng chứng đã upload hoặc dispatch AndroidForge.

## 2. Kiểm tra source / giao diện / package

| Hạng mục | Kết quả |
|---|---|
| Project identity và file Gradle bắt buộc | PASS |
| ZIP extraction và CRC | PASS |
| JavaScript `node --check` | PASS |
| Python mock server `py_compile` | PASS |
| Shell `bash -n` | PASS |
| Android Manifest / styles / network security XML parse | PASS |
| Source tree kiểm tra file key/certificate/keystore | Không phát hiện file private key/keystore trong package |
| Kotlin/Android full compile | NOT RUN |
| Room kapt / schema generation | NOT RUN |
| JUnit qua Gradle | NOT RUN |
| Android Lint | NOT RUN |
| APK assemble / install | NOT RUN |

Ngoài các kiểm tra trên, đã chạy Kotlin/JVM smoke harness độc lập cho một tập con không phụ thuộc Android: API sentence framing với nhiều độ dài word, parse attribute, định dạng legacy login response, RouterOS 6 partial/total packet loss và duplicate sequence rejection. Harness dùng Kotlin compiler cài sẵn và stub riêng cho duration parser; đây **không phải** biên dịch toàn bộ app hay thay thế JUnit.

## 3. Kiểm tra nhóm tính năng

| Nhóm | Tình trạng trong source | Giới hạn / điều kiện nghiệm thu |
|---|---|---|
| Nhiều router | Room profiles; add/list/remove | Chưa có sửa profile; muốn đổi thông tin phải xóa và thêm lại |
| RouterOS 7 | HTTPS REST resource/interface/ping | Cần xác minh JSON thực tế của `/rest/ping` trên phiên bản RouterOS triển khai |
| RouterOS 6 | API-SSL, direct login và legacy challenge/MD5 | Cần xác minh certificate/API login và cấu trúc `/ping` trên từng minor version |
| TLS | SHA-256 pin bắt buộc, fail closed trong client; inspector chỉ đọc fingerprint | Người vận hành phải đối chiếu fingerprint qua kênh độc lập trước khi lưu |
| Credential | AES-256-GCM; key không exportable trong Android Keystore | Chưa test backup/restore, đổi thiết bị hoặc mất key |
| CPU/RAM/uptime/version | Đọc từ system resource | Chỉ hiển thị trường router trả về hợp lệ |
| PPPoE | Phân loại interface theo type/name, hiển thị running/total | Chưa có thống kê PPPoE session từ `/ppp/active` |
| RX/TX Mbps | Tính từ delta byte counter / thời gian | Mẫu đầu tiên, counter reset hoặc interface thay đổi sẽ chưa có tốc độ |
| ICMP packet loss | Tách biệt RX/TX; ROS7 yêu cầu counter sent/received; ROS6 đếm reply sau `!done` | ROS7 không có final counter hoặc total loss không chứng minh được thì trả invalid, không tự suy đoán |
| Lịch sử | CPU/RAM/ICMP lưu local; 60 điểm/chart; retention 30 ngày | Background worker chỉ ghi CPU/RAM; ICMP và interface rate chỉ ghi khi app refresh foreground |
| Refresh | UI refresh mỗi 30 giây khi app visible; WorkManager định kỳ tối thiểu 15 phút | Chưa đo latency, pin, RAM hoặc tải router trên thiết bị thật |
| Netwatch / cloud / export | Chưa có | Ngoài phạm vi source milestone này |

## 4. Lỗi build đã xử lý trong gói

- Chuẩn hóa shell line continuation trong bước `sdkmanager` của workflow source.
- Kiểm tra chuỗi regex chuẩn hóa TLS pin trong Kotlin: source hiện dùng `Regex("[:\\s]")`, là dạng escape hợp lệ của Kotlin string.
- Bổ sung regression test chuẩn hóa fingerprint và cập nhật kiểm tra source/Android XML trong CI.
- Cập nhật script verify source để không nhầm static checks với Gradle build; nếu thiếu Gradle/SDK, script ghi rõ build bị skip.

## 5. Rủi ro còn mở — không được đánh dấu PASS

1. Chạy `:app:testDebugUnitTest`, `:app:lintDebug`, `:app:assembleDebug` trên runner có JDK 17 + Gradle 8.7 + SDK 35.
2. Xác minh APK tồn tại, package `com.multicloud.mcm`, version 1.0.1 và SHA-256 từ cùng một workflow run.
3. Cài APK trên Android 8+ và Android hiện hành; kiểm tra WebView, Room, Android Keystore, background worker, app restart, offline/reconnect và xóa profile.
4. RouterOS 7: login, certificate mismatch, permission denied, interface list, ping success/partial loss/total loss/missing counter.
5. RouterOS 6: API-SSL TLS pin, direct login, legacy login, `!trap`, `!done`, ping partial/total loss, sequence duplicate/missing.
6. Chạy nhiều router đồng thời, đo thời gian refresh, timeout, CPU/RAM/pin và tải RouterOS.

## 6. Lệnh build nghiệm thu

```bash
gradle --no-daemon :app:testDebugUnitTest :app:lintDebug :app:assembleDebug
```

APK Debug mong đợi:

`app/build/outputs/apk/debug/app-debug.apk`

**Trạng thái cuối:** Engineering source / NOT RELEASE. Chưa có APK được xác minh; chưa có kiểm thử phần cứng RouterOS hoặc thiết bị Android thật.
