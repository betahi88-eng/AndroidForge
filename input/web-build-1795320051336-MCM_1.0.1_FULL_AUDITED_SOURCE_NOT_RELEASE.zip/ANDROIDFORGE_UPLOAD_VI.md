# Build MCM with AndroidForge (Vietnamese)

## Source ZIP identity

Use only `MCM_1.0.1_FULL_AUDITED_SOURCE_NOT_RELEASE.zip`. The archive root must contain `settings.gradle.kts`, `build.gradle.kts`, `app/`, and `.github/` is not required by AndroidForge's source-project detector.

Expected Android identity:

- Gradle project: `MikroTikMultiCloudMonitor`
- Application ID: `com.multicloud.mcm`
- Android Gradle Plugin: 8.6.1
- Kotlin: 2.0.21
- JDK: 17
- Gradle: 8.7
- compileSdk / targetSdk: 35
- minSdk: 26

This is a native Android Gradle/Kotlin project, not Flutter. It intentionally has no `pubspec.yaml`.

## AndroidForge UI inputs

1. Upload this exact ZIP into the AndroidForge repository's `input/` directory.
2. Start workflow `Build Android APK`.
3. Select `zip_source=input-directory`.
4. Set `zip_path` to the exact committed path, e.g. `input/MCM_1.0.1_FULL_AUDITED_SOURCE_NOT_RELEASE.zip`.
5. Set `build_variant=debug`; keep `enable_ndk=false`.
6. Inspect `Detect project type` output before proceeding. It must say Gradle/Android and must not mention Flutter, `pubspec.yaml`, or `harmony_patched`.
7. Inspect the selected `project_root`; it must contain `settings.gradle.kts` and `app/build.gradle.kts`.
8. Download the APK artifact only if the build step reports success and `app/build/outputs/apk/debug/app-debug.apk` exists.

If detection selects Flutter or another project directory, stop. Do not attempt to fix MCM's Gradle configuration based on that unrelated build log.

## Local build

Requires JDK 17, Gradle 8.7, Android SDK Platform 35 and Build Tools 35.0.0. Run:

```bash
./scripts/setup-and-build.sh
```

The source ZIP does not include Gradle Wrapper JAR. Use AndroidForge or install the pinned Gradle version locally.

## Release status

Engineering source only. No signed release APK is included. Hardware tests against RouterOS 6/7 and Android device acceptance remain required.
