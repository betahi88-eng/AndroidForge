# MCM 1.6.3 — WinBox CLI transport investigation

## Decision

MCM adds an independent WinBox CLI diagnostic path over TCP/8291. This is not the graphical WinBox client and does not claim to implement every WinBox Native/M2 management operation. It uses the encrypted EC-SRP5 M2 channel and RouterOS `mepty` terminal handler to open a CLI session, then runs only two fixed read-only checks: `/system/identity/print` and `/system/resource/print`.

The diagnostic is separate from the existing REST/API-SSL connection flow. It does not save a router profile, alter the selected transport, or claim that the complete monitoring dashboard now runs over WinBox CLI.

## Protocol flow

1. Resolve the DDNS hostname through the existing Android DNS → Google DoH → Cloudflare DoH chain.
2. Open TCP to each resolved address on the independent WinBox WAN port (default 8291); it is not reused from the REST/API-SSL WAN port field.
3. Perform the modern EC-SRP5 challenge/response. The login name carries the terminal `+c` option; the password validator uses the account name before `+`.
4. Verify the router's server confirmation before deriving the encrypted stream keys.
5. Encrypt/decrypt M2 frames using AES-CBC and HMAC-SHA1, with length validation and a 16 MiB frame ceiling.
6. Open a `mepty` terminal session (handler 76), acknowledge terminal readiness, service output pulls and cumulative byte acknowledgements, and answer the VT100 cursor-position probe.
7. Execute only the fixed read-only identity/resource commands and return their output as diagnostics.

Legacy pre-6.43 MD5 login is deliberately not implemented. The encrypted terminal path requires modern EC-SRP5 support. RouterOS 6.43+ is the protocol floor for this path; live acceptance is still required for the exact RouterOS 6 and 7 releases in scope.

## Source research

- `danikf/tik4net` WinBox CLI implementation: https://github.com/danikf/tik4net
- WinBox M2 protocol implementation reference: `tik4net/Winbox/M2Message.cs`, `WinboxM2Protocol.cs`, `WinboxChunkFraming.cs`.
- EC-SRP5 reference and published known-answer vectors: `tik4net/Crypto/EcSrp5Client.cs`, `tik4net.unittests/Golden/EcSrp5HandshakeVectorTests.cs`, `tik4net.unittests/Golden/ecsrp5-handshake.txt`.
- RouterOS official documentation: https://help.mikrotik.com/docs/

The Android implementation is a Kotlin implementation of the protocol flow, not a bundled .NET dependency. `licenses/Apache-2.0.txt` and `THIRD_PARTY_NOTICES.md` preserve the reference project's license notice.

## Security boundaries

- Password is never written to diagnostics or logs.
- Password proof is sent through EC-SRP5; subsequent M2 traffic is AES/HMAC protected.
- The terminal command executor has an exact allowlist of two commands; no arbitrary command input is exposed to JavaScript.
- The diagnostic is read-only and does not change RouterOS configuration. RouterOS account policy must permit WinBox login and read access; the app does not attempt to modify user/group policy.
- The app closes the socket after the diagnostic; it does not retain a terminal session.
- BigInteger EC arithmetic is not claimed to be constant-time. This implementation remains a diagnostic/integration candidate until Android device performance and side-channel/security review are completed.
- No certificate pin is used for WinBox; mutual password proof is the protocol authentication. It is not interchangeable with TLS certificate identity pinning.

## Verification completed locally

- Kotlin/JVM compilation of `WinboxCliConnector.kt`: PASS.
- EC-SRP5 public key, client confirmation and shared-secret known-answer vectors: PASS against the published tik4net vector.
- Stream-key derivation vectors: PASS.
- AES/HMAC encrypted-frame round trips for payload lengths 0, 1, 11, 12, 13, 27, 28, 44 and 300 bytes: PASS.
- JavaScript syntax checks for modified WebView files: PASS.

## Not yet verified

- Android Gradle project compilation, JUnit task, lint, APK build and install: NOT RUN in this workspace (required Android toolchain unavailable).
- Live WinBox login and terminal commands against the user's RouterOS 6/7 devices: NOT RUN; no credentials or router access were supplied to the development environment.
- Full MCM dashboard monitoring over WinBox CLI: NOT IMPLEMENTED in this diagnostic slice. Existing monitoring still uses its saved REST/API-SSL transport.
