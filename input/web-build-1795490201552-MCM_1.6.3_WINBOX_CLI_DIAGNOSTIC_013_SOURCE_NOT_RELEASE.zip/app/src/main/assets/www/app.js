"use strict";

$("showAddBtn").addEventListener("click", () => { resetRouterForm(); showPanel(true); });
$("discoverBtn").addEventListener("click", discoverMikroTik);
$("closeDiscoveryBtn").addEventListener("click", () => { $("discoveryPanel").hidden = true; });
$("closeAddBtn").addEventListener("click", () => showPanel(false));
$("routerForm").addEventListener("submit", connectRouter);
$("openConnectionLogsBtn").addEventListener("click", openConnectionLogs);
$("testWinboxCliBtn").addEventListener("click", testWinboxCli);
$("refreshBtn").addEventListener("click", refreshSelected);
$("removeBtn").addEventListener("click", removeSelected);
$("editBtn").addEventListener("click", editSelectedRouter);
$("refreshAllBtn").addEventListener("click", refreshAllRouters);
$("interfaceHistorySelect").addEventListener("change", () => {
  state.selectedInterfaceName = $("interfaceHistorySelect").value || null;
  loadInterfaceHistory();
});
async function refreshNetworkContext() {
  const node = $("networkContext");
  if (!node) return;
  try {
    const response = await nativeCall("getNetworkState");
    if (!response.ok) throw new Error(response.error || "Không đọc được trạng thái mạng.");
    const network = response.network || {};
    const labels = { WIFI: "Wi-Fi", CELLULAR: "Di động", ETHERNET: "Ethernet", UNKNOWN: "Chưa xác định" };
    const transport = labels[network.transport] || "Chưa xác định";
    node.textContent = `${transport} · ${network.internetValidated ? "Internet đã xác thực" : "Chưa xác thực Internet"}`;
    node.className = `network-context${network.networkAvailable ? "" : " offline"}`;
    node.title = "MCM kết nối trực tiếp qua MikroTik Cloud DDNS tới WAN public; cần kiểm tra DNS, cổng và firewall của từng router.";
  } catch (error) {
    node.textContent = "Không đọc được trạng thái mạng";
    node.className = "network-context offline";
  }
}

document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible") {
    refreshNetworkContext();
    if (state.selectedId) refreshSelected();
  }
});

(async function boot() {
  try {
    await loadRouters();
    await refreshNetworkContext();
    setStatus("Sẵn sàng", "good");
    if (state.selectedId) refreshSelected();
  } catch (error) {
    setStatus("Native bridge lỗi", "bad");
    toast(error.message);
  }
  state.timer = window.setInterval(() => {
    if (document.visibilityState === "visible") {
      refreshNetworkContext();
      if (state.selectedId) refreshSelected();
    }
  }, 30000);
})();
