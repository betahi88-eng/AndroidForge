package com.multicloud.mcm.routeros

import java.io.Closeable
import java.io.EOFException
import java.io.InputStream
import java.io.OutputStream
import java.math.BigInteger
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.atomic.AtomicReference
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Read-only RouterOS terminal over the encrypted WinBox M2 channel (TCP/8291).
 * Protocol implementation follows the publicly documented EC-SRP5/M2 terminal flow.
 * Only the modern encrypted EC-SRP5 path is accepted; legacy pre-6.43 MD5 is deliberately disabled.
 */
class WinboxCliConnector(
    private val host: String,
    private val port: Int = 8291,
    private val username: String,
    private val password: String,
    private val connectTimeoutMs: Int = 7000,
    private val ioTimeoutMs: Int = 7000
) : Closeable {
    private val socket = Socket()
    private lateinit var input: InputStream
    private lateinit var output: OutputStream
    private lateinit var keys: StreamKeys
    private var requestId = 0
    private var sessionId = -1
    private var ackBytes = 0L
    private val random = SecureRandom()

    data class Result(
        val authenticated: Boolean, val terminalOpened: Boolean, val identity: String?, val resource: String?,
        val stage: String, val detail: String, val tcpMs: Long, val authMs: Long,
        val terminalOpenMs: Long, val shellReadyMs: Long, val readCheckMs: Long
    )

    fun connectAndRead(): Result {
        require(host.isNotBlank() && port in 1..65535) { "WinBox endpoint is invalid." }
        require(username.isNotBlank() && username.length <= 128) { "WinBox username is invalid." }
        require(password.isNotEmpty() && password.length <= 1024) { "WinBox password is invalid or too long." }
        val stage = AtomicReference("TCP_CONNECT")
        val stageStarted = AtomicReference(System.nanoTime())
        val timings = LongArray(4)
        try {
            socket.tcpNoDelay = true
            socket.connect(InetSocketAddress(host, port), connectTimeoutMs)
            timings[0] = elapsedMs(stageStarted.get())
            socket.soTimeout = ioTimeoutMs
            input = socket.getInputStream()
            output = socket.getOutputStream()
            stage.set("EC_SRP5_AUTH"); stageStarted.set(System.nanoTime())
            authenticate()
            timings[1] = elapsedMs(stageStarted.get())
            stage.set("MEPTY_TERMINAL_OPEN"); stageStarted.set(System.nanoTime())
            openTerminal()
            timings[2] = elapsedMs(stageStarted.get())
            stage.set("SHELL_READY"); stageStarted.set(System.nanoTime())
            val initial = readUntilPrompt(8000)
            timings[3] = elapsedMs(stageStarted.get())
            stage.set("READ_CHECK"); stageStarted.set(System.nanoTime())
            val identity = executeReadOnly("/system/identity/print", 7000)
            val resource = executeReadOnly("/system/resource/print", 7000)
            val readCheckMs = elapsedMs(stageStarted.get())
            return Result(true, true, identity.ifBlank { null }, resource.ifBlank { null }, stage.get(),
                "WinBox EC-SRP5 authenticated; terminal opened; read-only commands completed. ${initial.take(240)}",
                timings[0], timings[1], timings[2], timings[3], readCheckMs)
        } catch (e: Exception) {
            throw WinboxCliException(classify(e), stage.get(), elapsedMs(stageStarted.get()), e.message ?: e.javaClass.simpleName, e)
        }
    }

    private fun elapsedMs(startNanos: Long) = ((System.nanoTime() - startNanos) / 1_000_000L).coerceAtLeast(0)

    private fun authenticate(): String {
        val loginName = if ('+' in username) username else "$username+c"
        val account = loginName.substringBefore('+')
        val privateKey = ByteArray(32).also(random::nextBytes)
        val public = EcSrp5.publicKey(privateKey)
        val hello = loginName.toByteArray(StandardCharsets.UTF_8) + byteArrayOf(0) + public.first + byteArrayOf(public.second.toByte())
        writeRaw(byteArrayOf(hello.size.toByte(), 0x06) + hello)
        val header = readExact(2)
        val len = header[0].toInt() and 0xff
        val tag = header[1].toInt() and 0xff
        if (tag != 0x06) throw IllegalStateException("WinBox EC-SRP5 expected encrypted challenge tag 0x06; received 0x${tag.toString(16)}")
        if (len != 49) throw IllegalStateException("WinBox EC-SRP5 challenge length $len; expected 49. This is not a valid modern WinBox handshake.")
        val challenge = readExact(len)
        val xB = challenge.copyOfRange(0, 32)
        val parityB = challenge[32].toInt() and 0xff
        val salt = challenge.copyOfRange(33, 49)
        val validator = EcSrp5.sha256(salt + EcSrp5.sha256("$account:$password".toByteArray(StandardCharsets.UTF_8)))
        val gamma = EcSrp5.publicKey(validator).first
        val v = EcSrp5.redp1(gamma, 1)
        val wB = EcSrp5.liftX(BigInteger(1, xB), parityB)
        val j = EcSrp5.sha256(public.first + xB)
        val base = EcSrp5.add(wB, v)
        val exponent = (BigInteger(1, validator).multiply(BigInteger(1, j)).mod(EcSrp5.r).add(BigInteger(1, privateKey))).mod(EcSrp5.r)
        val zPoint = EcSrp5.multiply(exponent, base)
        val zMont = EcSrp5.toMontgomery(zPoint).first
        val clientConfirmation = EcSrp5.sha256(j + zMont)
        val expectedServerConfirmation = EcSrp5.sha256(j + clientConfirmation + zMont)
        writeRaw(byteArrayOf(clientConfirmation.size.toByte(), 0x06) + clientConfirmation)
        val serverHeader = readExact(2)
        val serverLen = serverHeader[0].toInt() and 0xff
        if ((serverHeader[1].toInt() and 0xff) != 0x06) {
            val refusal = readExact(serverLen).toString(StandardCharsets.UTF_8)
            throw SecurityException("RouterOS rejected WinBox authentication/protocol: ${refusal.take(160)}")
        }
        val serverProof = readExact(serverLen)
        if (!MessageDigest.isEqual(serverProof, expectedServerConfirmation)) {
            val refusal = serverProof.toString(StandardCharsets.UTF_8).take(160)
            throw SecurityException(if (refusal.isNotBlank()) "RouterOS refused WinBox login: $refusal" else "WinBox EC-SRP5 server confirmation mismatch; credentials or protocol proof rejected.")
        }
        keys = StreamKeys.derive(EcSrp5.sha256(zMont))
        return "EC-SRP5 proof verified"
    }

    private fun openTerminal() {
        requestId = (requestId + 1) and 0xff
        val terminalOpenRequestId = requestId
        val request = m2(sysTo(intArrayOf(76)), sysFrom(), byteArrayOf(5,0,0xff.toByte(),1),
            byteArrayOf(6,0,0xff.toByte(),0x09,terminalOpenRequestId.toByte()),
            u32Sys(0xFF0007, 0x0A0065), stringField(1, password), stringField(2, "vt102"),
            u32Field(3, 80), u32Field(4, 25))
        sendEncrypted(request)
        val deadline = System.nanoTime() + 7_000_000_000L
        while (System.nanoTime() < deadline) {
            val frame = receiveEncrypted(remainingMs(deadline))
            val echoedRequestId = parseU8OrU32(frame, 0xFF0006)
            if (echoedRequestId != null && echoedRequestId != terminalOpenRequestId) continue
            val parsedId = parseU8OrU32(frame, 0xFE0001)
            if (parsedId != null) { sessionId = parsedId; break }
            val err = parseU8OrU32(frame, 0xFF0008) ?: 0
            if (err != 0) throw SecurityException("WinBox mepty terminal open refused; RouterOS M2 error 0x${err.toString(16)}")
        }
        if (sessionId < 0) throw java.net.SocketTimeoutException("WinBox authenticated, but RouterOS did not open a mepty terminal session.")
        sendEncrypted(m2(sysTo(intArrayOf(76)), sysFrom(), sessionField(sessionId), u32Sys(0xFF0007, 0x0A0067), u32Field(3, 0)))
    }

    private fun readUntilPrompt(timeoutMs: Int): String = readTerminalCommand(null, timeoutMs)

    private fun executeReadOnly(command: String, timeoutMs: Int): String {
        val allowed = setOf("/system/identity/print", "/system/resource/print")
        require(command in allowed) { "WinBox CLI command is outside the diagnostic read-only allowlist." }
        return readTerminalCommand(command, timeoutMs)
    }

    private fun readTerminalCommand(command: String?, timeoutMs: Int): String {
        if (command != null) sendTerminalInput((command + "\r").toByteArray(StandardCharsets.UTF_8))
        val sb = StringBuilder()
        val deadline = System.nanoTime() + timeoutMs * 1_000_000L
        var lastDataAt = System.nanoTime()
        var lastPullAt = 0L
        var firstData = command == null
        var cursorProbeTail = ""
        while (System.nanoTime() < deadline) {
            if (socket.getInputStream().available() > 0) {
                val frame = receiveEncrypted(remainingMs(deadline))
                val payload = parseUserVariable(frame, 2)
                if (payload != null && payload.isNotEmpty()) {
                    val text = payload.toString(StandardCharsets.UTF_8)
                    if (sb.length + text.length > 1_048_576) throw IllegalStateException("WinBox terminal output exceeded the 1 MiB diagnostic limit.")
                    sb.append(text)
                    ackBytes += payload.size
                    lastDataAt = System.nanoTime()
                    firstData = true
                    cursorProbeTail = (cursorProbeTail + text).takeLast(16)
                    if (cursorProbeTail.contains("\u001b[6n")) {
                        sendTerminalInput("\u001b[1;80R".toByteArray(StandardCharsets.US_ASCII))
                        cursorProbeTail = ""
                    }
                }
                if (parseU8OrU32(frame, 0xFF0007) == 0x0A0066) break
            } else {
                val now = System.nanoTime()
                if (firstData && now - lastDataAt > 450_000_000L) break
                if (now - lastPullAt > 120_000_000L) { sendPull(); lastPullAt = now }
                Thread.sleep(20)
            }
        }
        if (command != null && sb.isEmpty()) throw java.net.SocketTimeoutException("WinBox terminal returned no output for read-only command: $command")
        val cleaned = stripAnsi(sb.toString()).trim()
        if (command != null) {
            val markers = if (command == "/system/identity/print") listOf("name", "identity") else listOf("version", "uptime", "cpu-load", "free-memory")
            if (markers.none { cleaned.contains(it, ignoreCase = true) }) {
                throw IllegalStateException("WinBox terminal answered, but $command output did not contain expected read-only fields. Output: ${cleaned.take(180)}")
            }
        }
        return cleaned
    }

    private fun sendPull() = sendTerminalInput(null)
    private fun sendTerminalInput(bytes: ByteArray?) {
        val fields = mutableListOf(sysTo(intArrayOf(76)), sysFrom(), sessionField(sessionId), u32Sys(0xFF0007, 0x0A0067))
        if (bytes != null) fields.add(rawField(2, bytes))
        fields.add(u32Field(3, ackBytes.toInt()))
        sendEncrypted(m2(*fields.toTypedArray()))
    }

    private fun sendEncrypted(message: ByteArray) = writeChunked(keys.encrypt(message), 0x06)

    private fun receiveEncrypted(timeoutMs: Int): ByteArray {
        // Once a frame starts, finish it with a generous socket timeout; interrupting a partial encrypted frame
        // would desynchronize the TCP byte stream and invalidate the session.
        socket.soTimeout = maxOf(ioTimeoutMs, timeoutMs).coerceAtLeast(1000)
        val assembled = ArrayList<Byte>()
        var first = true
        while (true) {
            val hdr = readExact(2)
            val n = hdr[0].toInt() and 0xff
            val tag = hdr[1].toInt() and 0xff
            if (first && n == 0 && tag == 0xff) continue // exact-255-byte frame terminator
            if (first && tag != 0x06) throw IllegalStateException("WinBox M2 frame tag mismatch: 0x${tag.toString(16)}")
            if (!first && tag != 0xff) throw IllegalStateException("WinBox M2 continuation tag mismatch: 0x${tag.toString(16)}")
            first = false
            assembled.addAll(readExact(n).toList())
            if (assembled.size > 16 * 1024 * 1024) throw IllegalStateException("WinBox encrypted frame exceeded the 16 MiB safety limit.")
            if (n < 255 || (assembled.size >= 2 && assembled.size == 18 + (((assembled[0].toInt() and 0xff) shl 8) or (assembled[1].toInt() and 0xff)))) break
        }
        return keys.decrypt(assembled.toByteArray())
    }

    private fun writeChunked(data: ByteArray, firstTag: Int) {
        var offset = 0
        var tag = firstTag
        while (true) {
            val count = minOf(255, data.size - offset)
            output.write(byteArrayOf(count.toByte(), tag.toByte()))
            if (count > 0) output.write(data, offset, count)
            offset += count
            if (count < 255) break
            tag = 0xff
        }
        output.flush()
    }

    private fun writeRaw(bytes: ByteArray) { output.write(bytes); output.flush() }
    private fun readExact(size: Int): ByteArray {
        val result = ByteArray(size); var offset = 0
        while (offset < size) { val n = input.read(result, offset, size - offset); if (n < 0) throw EOFException("WinBox peer closed during frame read"); offset += n }
        return result
    }
    private fun remainingMs(deadline: Long) = ((deadline - System.nanoTime()) / 1_000_000L).toInt().coerceAtLeast(1)
    private fun classify(e: Exception): String = when (e) {
        is java.net.SocketTimeoutException -> "WINBOX_TIMEOUT"
        is java.net.ConnectException -> "WINBOX_TCP_REFUSED"
        is SecurityException -> "WINBOX_AUTH_OR_PROTOCOL"
        is EOFException -> "WINBOX_PEER_CLOSED"
        else -> "WINBOX_PROTOCOL_ERROR"
    }

    override fun close() { runCatching { socket.close() } }

    class WinboxCliException(val code: String, val stage: String, val stageElapsedMs: Long, message: String, cause: Throwable) : Exception(message, cause)

    internal data class StreamKeys(val sendAes: ByteArray, val receiveAes: ByteArray, val sendHmac: ByteArray, val receiveHmac: ByteArray) {
        fun encrypt(message: ByteArray): ByteArray {
            val mac = hmac(sendHmac, message)
            val body = message + mac
            val pad = 15 - (body.size % 16)
            val padded = body + ByteArray(pad + 1) { pad.toByte() }
            val iv = ByteArray(16).also(SecureRandom()::nextBytes)
            val cipher = Cipher.getInstance("AES/CBC/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(sendAes, "AES"), IvParameterSpec(iv))
            val encrypted = cipher.doFinal(padded)
            return byteArrayOf((encrypted.size shr 8).toByte(), encrypted.size.toByte()) + iv + encrypted
        }
        fun decrypt(frame: ByteArray): ByteArray {
            require(frame.size >= 34 && frame.size % 16 == 2) { "Malformed encrypted WinBox frame." }
            val declaredCipherLength = ((frame[0].toInt() and 255) shl 8) or (frame[1].toInt() and 255)
            require(declaredCipherLength == frame.size - 18) { "WinBox encrypted frame length field does not match the received frame." }
            val iv = frame.copyOfRange(2, 18)
            val cipher = Cipher.getInstance("AES/CBC/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(receiveAes, "AES"), IvParameterSpec(iv))
            val plain = cipher.doFinal(frame.copyOfRange(18, frame.size))
            val padByte = plain.last()
            val strip = (padByte.toInt() and 0xff) + 1
            require(strip <= plain.size && plain.size - strip >= 20 && plain.copyOfRange(plain.size - strip, plain.size).all { it == padByte }) { "Invalid WinBox frame padding." }
            val content = plain.copyOfRange(0, plain.size - strip)
            val message = content.copyOfRange(0, content.size - 20)
            val expected = hmac(receiveHmac, message)
            require(MessageDigest.isEqual(expected, content.copyOfRange(content.size - 20, content.size))) { "WinBox frame HMAC verification failed." }
            return message
        }
        companion object {
            fun derive(secret: ByteArray): StreamKeys {
                val sendMagic = "On the client side, this is the send key; on the server side, it is the receive key.".toByteArray(StandardCharsets.US_ASCII)
                val recvMagic = "On the client side, this is the receive key; on the server side, it is the send key.".toByteArray(StandardCharsets.US_ASCII)
                val pad = ByteArray(40) { 0xf2.toByte() }
                val zeros = ByteArray(40)
                fun expand(magic: ByteArray): ByteArray {
                    val seed = MessageDigest.getInstance("SHA-1").digest(secret + zeros + magic + pad).copyOf(16)
                    val h1 = hmac(ByteArray(64), seed)
                    var previous = ByteArray(0); val result = ByteArrayOutputStreamCompat()
                    for (i in 1..2) { previous = hmac(h1, previous + byteArrayOf(i.toByte())); result.write(previous) }
                    return result.toByteArray().copyOf(36)
                }
                val send = expand(sendMagic); val receive = expand(recvMagic)
                return StreamKeys(send.copyOfRange(0,16), receive.copyOfRange(0,16), send.copyOfRange(16,36), receive.copyOfRange(16,36))
            }
        }
    }

    internal object EcSrp5 {
        val p = BigInteger("7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffed",16)
        val r = BigInteger("1000000000000000000000000000000014def9dea2f79cd65812631a5cf5d3ed",16)
        val a = BigInteger("2aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa984914a144",16)
        private val montA = BigInteger.valueOf(486662)
        private val shift = montA.multiply(BigInteger.valueOf(3).modInverse(p)).mod(p)
        data class Point(val x: BigInteger, val y: BigInteger, val infinity: Boolean = false)
        private val infinity = Point(BigInteger.ZERO, BigInteger.ZERO, true)
        private val g = liftX(BigInteger.valueOf(9), 0)
        fun sha256(b: ByteArray) = MessageDigest.getInstance("SHA-256").digest(b)
        fun publicKey(priv: ByteArray): Pair<ByteArray, Int> = toMontgomery(multiply(BigInteger(1, priv), g))
        fun toMontgomery(pt: Point): Pair<ByteArray, Int> {
            val x = pt.x.subtract(shift).mod(p)
            return Pair(toBe32(x), pt.y.testBit(0).let { if (it) 1 else 0 })
        }
        fun liftX(xMont: BigInteger, parity: Int): Point {
            val x = xMont.mod(p)
            val y2 = x.modPow(BigInteger.valueOf(3), p).add(montA.multiply(x.modPow(BigInteger.valueOf(2),p))).add(x).mod(p)
            val roots = sqrt(y2) ?: throw IllegalArgumentException("Invalid EC-SRP5 point.")
            val y = roots.firstOrNull { it.testBit(0) == (parity != 0) } ?: roots[0]
            return Point(x.add(shift).mod(p), y)
        }
        fun redp1(seed: ByteArray, parity: Int): Point {
            var x = sha256(seed)
            while (true) {
                val x2 = sha256(x)
                try { return liftX(BigInteger(1, x2), parity) } catch (_: IllegalArgumentException) { x = toBe32(BigInteger(1,x).add(BigInteger.ONE)) }
            }
        }
        fun add(q: Point, z: Point): Point {
            if (q.infinity) return z; if (z.infinity) return q
            if (q.x == z.x) return if (q.y == z.y) double(q) else infinity
            val lambda = z.y.subtract(q.y).mod(p).multiply(z.x.subtract(q.x).mod(p).modInverse(p)).mod(p)
            val x3 = lambda.multiply(lambda).subtract(q.x).subtract(z.x).mod(p)
            val y3 = lambda.multiply(q.x.subtract(x3).mod(p)).subtract(q.y).mod(p)
            return Point(x3,y3)
        }
        private fun double(q: Point): Point {
            if (q.infinity || q.y == BigInteger.ZERO) return infinity
            val numerator = BigInteger.valueOf(3).multiply(q.x.multiply(q.x).mod(p)).add(a).mod(p)
            val denominator = BigInteger.valueOf(2).multiply(q.y).mod(p)
            val lambda = numerator.multiply(denominator.modInverse(p)).mod(p)
            val x3 = lambda.multiply(lambda).subtract(q.x.shiftLeft(1)).mod(p)
            val y3 = lambda.multiply(q.x.subtract(x3).mod(p)).subtract(q.y).mod(p)
            return Point(x3,y3)
        }
        fun multiply(k0: BigInteger, point: Point): Point {
            var k = k0.mod(r); var addend = point; var result = infinity
            while (k.signum() > 0) { if (k.testBit(0)) result = add(result, addend); addend = double(addend); k = k.shiftRight(1) }
            return result
        }
        private fun sqrt(n0: BigInteger): List<BigInteger>? {
            val n = n0.mod(p); if (n == BigInteger.ZERO) return listOf(BigInteger.ZERO, BigInteger.ZERO)
            if (n.modPow(p.subtract(BigInteger.ONE).shiftRight(1),p) != BigInteger.ONE) return null
            var q = p.subtract(BigInteger.ONE); var s=0
            while (!q.testBit(0)) { q=q.shiftRight(1); s++ }
            var z=BigInteger.valueOf(2)
            while (z.modPow(p.subtract(BigInteger.ONE).shiftRight(1),p) != p.subtract(BigInteger.ONE)) z=z.add(BigInteger.ONE)
            var m=s; var c=z.modPow(q,p); var t=n.modPow(q,p); var x=n.modPow(q.add(BigInteger.ONE).shiftRight(1),p)
            while (true) {
                if (t==BigInteger.ONE) return listOf(x,p.subtract(x))
                var i=1; var temp=t.multiply(t).mod(p)
                while (temp!=BigInteger.ONE) { temp=temp.multiply(temp).mod(p); i++ }
                val b=c.modPow(BigInteger.ONE.shiftLeft(m-i-1),p)
                m=i; c=b.multiply(b).mod(p); t=t.multiply(c).mod(p); x=x.multiply(b).mod(p)
            }
        }
        private fun toBe32(n: BigInteger): ByteArray {
            val src=n.toByteArray().let { if (it.size>1 && it[0]==0.toByte()) it.copyOfRange(1,it.size) else it }
            require(src.size<=32); return ByteArray(32).also { System.arraycopy(src,0,it,32-src.size,src.size) }
        }
    }

    private companion object {
        fun hmac(key: ByteArray, data: ByteArray): ByteArray = Mac.getInstance("HmacSHA1").run { init(SecretKeySpec(key,"HmacSHA1")); doFinal(data) }
    }
    private class ByteArrayOutputStreamCompat { private val chunks=ArrayList<ByteArray>(); fun write(b:ByteArray){chunks.add(b)}; fun toByteArray():ByteArray=chunks.fold(ByteArray(0)){a,b->a+b} }

    private fun m2(vararg fields: ByteArray) = byteArrayOf(0x4d,0x32) + fields.fold(ByteArray(0)){a,b->a+b}
    private fun sysTo(path:IntArray)=u32ArraySys(0xFF0001,path)
    private fun sysFrom()=u32ArraySys(0xFF0002,intArrayOf(0,8))
    private fun u32ArraySys(key:Int, values:IntArray):ByteArray { val b=ByteBuffer.allocate(6+values.size*4).order(ByteOrder.LITTLE_ENDIAN); b.put(key.toByte()); b.put((key ushr 8).toByte()); b.put((key ushr 16).toByte()); b.put(0x88.toByte()); b.putShort(values.size.toShort()); values.forEach{b.putInt(it)}; return b.array() }
    private fun u32Sys(key:Int,value:Int)=byteArrayOf(key.toByte(),(key ushr 8).toByte(),(key ushr 16).toByte(),0x08)+ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(value).array()
    private fun u32Field(key:Int,value:Int)=u32Sys(key,value)
    private fun stringField(key:Int,value:String):ByteArray { val data=value.toByteArray(StandardCharsets.UTF_8); val len=if(data.size<=255) byteArrayOf(data.size.toByte()) else ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN).putShort(data.size.toShort()).array(); return byteArrayOf(key.toByte(),0,0,if(data.size<=255)0x21.toByte() else 0x20.toByte()) + len + data }
    private fun rawField(key:Int,data:ByteArray):ByteArray { val len=if(data.size<=255) byteArrayOf(data.size.toByte()) else ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN).putShort(data.size.toShort()).array(); return byteArrayOf(key.toByte(),0,0,if(data.size<=255)0x31.toByte() else 0x30.toByte()) + len + data }
    private fun sessionField(id:Int)=if(id<=255) byteArrayOf(1,0,0xfe.toByte(),0x09,id.toByte()) else u32Sys(0xFE0001,id)
    internal data class ParsedField(val key: Int, val type: Int, val valueStart: Int, val valueLength: Int, val end: Int)
    internal fun fields(data: ByteArray): Sequence<ParsedField> = sequence {
        if (data.size < 2 || data[0] != 0x4d.toByte() || data[1] != 0x32.toByte()) return@sequence
        var p = 2
        while (p + 4 <= data.size) {
            val fieldStart = p
            val key = (data[p].toInt() and 255) or ((data[p+1].toInt() and 255) shl 8) or ((data[p+2].toInt() and 255) shl 16)
            val type = data[p+3].toInt() and 255
            p += 4
            val width = when (type and 3) { 1 -> 1; 2 -> 4; else -> 2 }
            fun readLen(): Int { if (p + width > data.size) return -1; var n=0; repeat(width){ n = n or ((data[p++].toInt() and 255) shl (8*it)) }; return n }
            val size = when (type) {
                0x00,0x01 -> 0
                0x09 -> 1
                0x08 -> 4
                0x10 -> 8
                0x18 -> 16
                0x21,0x31 -> { val n=readLen(); if(n<0) return@sequence; n }
                0x20,0x30,0x29,0x28,0x2a,0x22,0x32 -> { val n=readLen(); if(n<0) return@sequence; n }
                0x88,0x89,0x8a -> { val count=readLen(); if(count<0 || p+count*4>data.size) return@sequence; p += count*4; 0 }
                0x80,0x81,0x82 -> { val count=readLen(); if(count<0 || p+count>data.size) return@sequence; p += count; 0 }
                0x90,0x91,0x92 -> { val count=readLen(); if(count<0 || p+count*8>data.size) return@sequence; p += count*8; 0 }
                0x98,0x99,0x9a -> { val count=readLen(); if(count<0 || p+count*16>data.size) return@sequence; p += count*16; 0 }
                0xa0,0xa1,0xa2,0xa8,0xa9,0xaa,0xb0,0xb1,0xb2 -> {
                    val count=readLen(); if(count<0) return@sequence
                    repeat(count){ val n=readLen(); if(n<0 || p+n>data.size) return@sequence; p += n }
                    0
                }
                else -> return@sequence
            }
            val valueStart = p
            if (size < 0 || p + size > data.size) return@sequence
            p += size
            yield(ParsedField(key,type,valueStart,size,p))
            if (p <= fieldStart) return@sequence
        }
    }
    internal fun parseU8OrU32(data:ByteArray,key:Int):Int? {
        val f=fields(data).firstOrNull{it.key==key} ?: return null
        return when(f.type){
            0x09 -> data[f.valueStart].toInt() and 255
            0x08 -> ByteBuffer.wrap(data,f.valueStart,4).order(ByteOrder.LITTLE_ENDIAN).int
            else -> null
        }
    }
    internal fun parseUserVariable(data:ByteArray,key:Int):ByteArray? {
        val f=fields(data).firstOrNull{it.key==key && (it.type==0x31 || it.type==0x30 || it.type==0x21 || it.type==0x20 || it.type==0x32 || it.type==0x22)} ?: return null
        return data.copyOfRange(f.valueStart,f.end)
    }

    private fun stripAnsi(value:String)=value.replace(Regex("\\u001B\\[[0-?]*[ -/]*[@-~]"),"").replace(Regex("\\u001B\\][^\\u0007]*(?:\\u0007|\\u001B\\\\)"),"")
}

