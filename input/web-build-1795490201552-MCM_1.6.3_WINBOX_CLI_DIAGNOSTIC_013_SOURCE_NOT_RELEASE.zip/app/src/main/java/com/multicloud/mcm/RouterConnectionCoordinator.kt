package com.multicloud.mcm

import com.multicloud.mcm.data.ConnectionAttemptLogEntity
import com.multicloud.mcm.data.McmDatabase
import com.multicloud.mcm.data.RouterEntity
import com.multicloud.mcm.routeros.RouterOs6ApiClient
import com.multicloud.mcm.security.SecureCredentialStore
import com.multicloud.mcm.security.TlsFingerprintInspector
import com.multicloud.mcm.security.TlsProbeException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.selects.select
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetAddress
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Direct DDNS connection flow. It is read-only: only TCP/TLS probes and RouterOS read calls
 * are sent. It never changes RouterOS services, firewall, NAT, DDNS or user configuration.
 */

class RouterConnectionCoordinator(
    private val database: McmDatabase,
    private val credentials: SecureCredentialStore
) {
    private val profiles = McmRouterProfileService(database, credentials)
    private val pending = ConcurrentHashMap<String, PendingAttempt>()

    /** Independent WinBox CLI authentication/read probe. Does not alter or save the router profile. */
    suspend fun testWinboxCli(rawHost: String, username: String, password: String, requestedPort: Int = 8291): JSONObject =
        withContext(Dispatchers.IO) {
            val started = System.currentTimeMillis()
            val host = RouterHostValidator.normalize(rawHost)
            require(username.isNotBlank()) { "Username không được để trống." }
            require(password.isNotEmpty()) { "Password không được để trống." }
            require(requestedPort in 1..65535) { "Cổng WinBox phải từ 1 đến 65535." }
            val resolution = try { RouterDnsResolver.resolveDetailed(host) } catch (e: Exception) {
                return@withContext JSONObject().put("ok", false).put("state", "DNS_FAILED")
                    .put("diagnostics", JSONObject().put("stage", "DNS").put("host", host).put("detail", e.message ?: e.javaClass.simpleName))
            }
            val attempts = org.json.JSONArray()
            for (address in resolution.addresses) {
                val addressStarted = System.currentTimeMillis()
                try {
                    val result = com.multicloud.mcm.routeros.WinboxCliConnector(
                        host = address.hostAddress, port = requestedPort, username = username, password = password
                    ).use { it.connectAndRead() }
                    attempts.put(JSONObject().put("ip", address.hostAddress).put("result", "READ_CHECK_OK")
                        .put("elapsedMs", System.currentTimeMillis() - addressStarted)
                        .put("stage", result.stage).put("tcpMs", result.tcpMs).put("authMs", result.authMs)
                        .put("terminalOpenMs", result.terminalOpenMs).put("shellReadyMs", result.shellReadyMs)
                        .put("readCheckMs", result.readCheckMs).put("authenticated", result.authenticated)
                        .put("terminalOpened", result.terminalOpened).put("identity", result.identity)
                        .put("resource", result.resource).put("detail", result.detail))
                    return@withContext JSONObject().put("ok", true).put("state", "WINBOX_READ_CHECK_OK")
                        .put("host", host).put("port", requestedPort).put("dnsSource", resolution.source)
                        .put("addresses", org.json.JSONArray(resolution.addresses.map { it.hostAddress }))
                        .put("stage", result.stage).put("attempts", attempts)
                        .put("elapsedMs", System.currentTimeMillis() - started)
                } catch (e: com.multicloud.mcm.routeros.WinboxCliConnector.WinboxCliException) {
                    attempts.put(JSONObject().put("ip", address.hostAddress).put("result", e.code)
                        .put("elapsedMs", System.currentTimeMillis() - addressStarted).put("stage", e.stage)
                        .put("stageElapsedMs", e.stageElapsedMs).put("detail", e.message ?: e.javaClass.simpleName))
                }
            }
            JSONObject().put("ok", false).put("state", "WINBOX_FAILED").put("host", host)
                .put("port", requestedPort).put("dnsSource", resolution.source)
                .put("addresses", org.json.JSONArray(resolution.addresses.map { it.hostAddress }))
                .put("stage", attempts.optJSONObject(attempts.length() - 1)?.optString("stage", "WINBOX_PROTOCOL") ?: "WINBOX_PROTOCOL").put("attempts", attempts)
                .put("elapsedMs", System.currentTimeMillis() - started)
        }

    suspend fun start(
        rawHost: String,
        username: String,
        password: String,
        requestedPort: Int = 0,
        requestedMode: String = "AUTO"
    ): JSONObject = withTimeoutOrNull(TOTAL_CONNECTION_TIMEOUT_MS) {
        startInternal(rawHost, username, password, requestedPort, requestedMode)
    } ?: failure("NETWORK_TIMEOUT", "Quá thời gian kết nối tối đa 30 giây.")

    private suspend fun startInternal(
        rawHost: String,
        username: String,
        password: String,
        requestedPort: Int,
        requestedMode: String
    ): JSONObject {
        val startedAt = System.currentTimeMillis()
        pending.entries.removeAll { startedAt - it.value.startedAt > PENDING_TTL_MS }
        val host = RouterHostValidator.normalize(rawHost)
        require(username.isNotBlank()) { "Username không được để trống." }
        require(password.isNotEmpty()) { "Password không được để trống." }
        require(requestedPort == 0 || requestedPort in 1..65535) { "Port phải là số nguyên từ 1 đến 65535." }
        val serviceMode = RouterServiceMode.fromUserInput(requestedMode)
        val existing = profiles.findByHost(host)
        val resolution = try {
            RouterDnsResolver.resolveDetailed(host)
        } catch (error: DnsResolutionException) {
            if (existing != null) {
                val checkedAt = System.currentTimeMillis()
                database.routerDao().upsert(existing.copy(
                    lastStatus = "OFFLINE", lastErrorCode = error.failureCode,
                    lastErrorMessage = (error.message ?: "DNS resolution failed").take(240),
                    lastCheckedAtEpochMs = checkedAt
                ))
                writeDnsFailureLog(existing.id, startedAt, error.failureCode, error.message ?: "DNS resolution failed")
            }
            return failure(error.failureCode, error.message ?: "DNS resolution failed")
                .put("diagnostics", JSONObject().put("stage", "DNS").put("host", host)
                    .put("failureCode", error.failureCode).put("detail", error.message ?: "DNS resolution failed"))
                .put("elapsedMs", System.currentTimeMillis() - startedAt)
        } catch (error: Exception) {
            if (existing != null) {
                val checkedAt = System.currentTimeMillis()
                database.routerDao().upsert(existing.copy(
                    lastStatus = "OFFLINE", lastErrorCode = "DNS_FAILED",
                    lastErrorMessage = (error.message ?: "Không phân giải được hostname.").take(240),
                    lastCheckedAtEpochMs = checkedAt
                ))
                writeDnsFailureLog(existing.id, startedAt, "DNS_FAILED", error.message ?: "Không phân giải được hostname.")
            }
            return failure("DNS_FAILED", error.message ?: "Không phân giải được hostname.")
                .put("diagnostics", JSONObject().put("stage", "DNS").put("host", host)
                    .put("failureCode", "DNS_FAILED").put("detail", error.javaClass.simpleName + ": " + (error.message ?: "no detail")))
                .put("elapsedMs", System.currentTimeMillis() - startedAt)
        }

        val storedTransport = RouterTransport.fromStorage(existing?.activeTransport)
            ?: existing?.let { RouterServiceMode.fromStorage(it.connectionMode).resolveForProfile(it.routerOsMajor, it.activeTransport) }
        val requestedTransport = when (serviceMode) {
            RouterServiceMode.AUTO -> storedTransport ?: RouterTransport.REST_HTTPS
            RouterServiceMode.REST_HTTPS -> RouterTransport.REST_HTTPS
            RouterServiceMode.API_SSL -> RouterTransport.API_SSL
        }
        // A stored pin is valid only for the exact service/port transport it was confirmed on.
        // Changing REST ↔ API-SSL requires a separate first-use confirmation.
        val probePorts = serviceMode.probePorts(requestedPort)
        val requestedEndpointPort = when (requestedTransport) {
            RouterTransport.REST_HTTPS -> probePorts.restPort
            RouterTransport.API_SSL -> probePorts.apiSslPort
        } ?: requestedTransport.port
        val oldPin = existing?.tlsPinFor(requestedTransport, requestedEndpointPort)
        // Probe both endpoints in AUTO, but a certificate pin belongs to exactly one
        // transport. Never reuse a www-ssl fingerprint for api-ssl (or vice versa).
        val probes = probeBoth(host, resolution.addresses, expectedPin = null,
            serviceMode = serviceMode, requestedPort = requestedPort)
        val candidate = when (serviceMode) {
            RouterServiceMode.REST_HTTPS -> probes.firstOrNull { it.transport == RouterTransport.REST_HTTPS && it.fingerprint != null }
            RouterServiceMode.API_SSL -> probes.firstOrNull { it.transport == RouterTransport.API_SSL && it.fingerprint != null }
            RouterServiceMode.AUTO -> probes.firstOrNull { it.transport == RouterTransport.REST_HTTPS && it.fingerprint != null }
                ?: probes.firstOrNull { it.transport == RouterTransport.API_SSL && it.fingerprint != null }
        }

        if (oldPin != null) {
            // A router can assign different certificates to www-ssl and api-ssl.
            // Only the previously authenticated transport owns this profile's pin.
            val pinnedTransport = requestedTransport
            val changed = probes.firstOrNull {
                it.transport == pinnedTransport && it.fingerprint != null && !it.fingerprint.equals(oldPin, true)
            }
            if (changed != null) {
                val attempt = PendingAttempt(
                    id = UUID.randomUUID().toString(), host = host, username = username, password = password,
                    existing = existing, resolution = resolution, probes = probes,
                    oldPin = oldPin, candidatePin = changed.fingerprint!!, startedAt = startedAt,
                    serviceMode = serviceMode, pinTransport = pinnedTransport, requestedPort = requestedPort
                )
                pending[attempt.id] = attempt
                return JSONObject()
                    .put("ok", false).put("state", "TLS_CHANGED")
                    .put("attemptId", attempt.id)
                    .put("host", host).put("protocol", pinnedTransport.name)
                    .put("oldFingerprint", oldPin)
                    .put("newFingerprint", changed.fingerprint)
                    .put("port", changed.port)
                    .put("diagnostics", connectionDiagnostics(host, resolution, probes))
                    .put("message", "Chứng chỉ TLS của ${changed.port} đã thay đổi. Kết nối đã dừng để chờ xác nhận bảo mật.")
            }
            return authenticateAndPersist(
                PendingAttempt(UUID.randomUUID().toString(), host, username, password, existing,
                    resolution, probes, oldPin, oldPin, startedAt, serviceMode = serviceMode,
                    pinTransport = pinnedTransport, requestedPort = requestedPort), oldPin
            )
        }

        if (candidate == null) {
            val result = classifyProbeFailure(host, resolution, probes, System.currentTimeMillis() - startedAt)
            existing?.let { writeProbeFailureLog(it.id, startedAt, resolution, probes, result.optString("state"), result.optString("message")) }
            return result
        }
        val attempt = PendingAttempt(
            id = UUID.randomUUID().toString(), host = host, username = username, password = password,
            existing = existing, resolution = resolution, probes = probes,
            oldPin = null, candidatePin = candidate.fingerprint!!, startedAt = startedAt,
            serviceMode = serviceMode, pinTransport = candidate.transport, requestedPort = requestedPort
        )
        pending[attempt.id] = attempt
        return JSONObject()
            .put("ok", false).put("state", "FIRST_TIME_PIN")
            .put("attemptId", attempt.id)
            .put("host", host).put("protocol", candidate.transport.name)
            .put("fingerprint", candidate.fingerprint)
            .put("port", candidate.port)
            .put("diagnostics", connectionDiagnostics(host, resolution, probes))
            .put("message", "Đối chiếu SHA-256 đầy đủ qua kênh tin cậy trước khi xác nhận lần đầu.")
    }

    suspend fun confirm(attemptId: String, decision: String): JSONObject =
        withTimeoutOrNull(TOTAL_CONNECTION_TIMEOUT_MS) { confirmInternal(attemptId, decision) }
            ?: failure("NETWORK_TIMEOUT", "Quá thời gian xác thực tối đa 30 giây.")

    private suspend fun confirmInternal(attemptId: String, decision: String): JSONObject {
        val attempt = pending.remove(attemptId)
            ?: return failure("ATTEMPT_EXPIRED", "Phiên kết nối không còn tồn tại. Hãy bắt đầu lại.")
        if (!decision.equals("TRUST", ignoreCase = true)) {
            return JSONObject().put("ok", false).put("state", "CANCELLED").put("message", "Đã hủy xác nhận chứng chỉ.")
        }
        val pin = attempt.candidatePin
        return authenticateAndPersist(attempt, pin, tlsPinConfirmed = true)
    }

    fun cancel(attemptId: String): JSONObject {
        pending.remove(attemptId)
        return JSONObject().put("ok", true).put("state", "CANCELLED")
    }

    private suspend fun probeBoth(
        host: String,
        addresses: List<InetAddress>,
        expectedPin: String? = null,
        serviceMode: RouterServiceMode = RouterServiceMode.AUTO,
        requestedPort: Int = 0
    ): List<BranchProbe> = coroutineScope {
        val probePorts = serviceMode.probePorts(requestedPort)
        val restPort = probePorts.restPort
        val apiPort = probePorts.apiSslPort
        val endpoints = listOfNotNull(
            restPort?.let { RouterTransport.REST_HTTPS to it },
            apiPort?.let { RouterTransport.API_SSL to it }
        )
        val deferred = endpoints.map { (transport, port) ->
            async(Dispatchers.IO) {
                withTimeoutOrNull(PROBE_BRANCH_TIMEOUT_MS) {
                    probeBranch(host, port, transport, addresses, expectedPin)
                } ?: BranchProbe(transport, port, "NETWORK_TIMEOUT", null, null, 0, 0,
                    PROBE_BRANCH_TIMEOUT_MS, "${transport.name} probe exceeded its independent time budget")
            }
        }
        val results = deferred.awaitAll().associateBy { it.transport }
        listOf(
            results[RouterTransport.REST_HTTPS] ?: BranchProbe(
                RouterTransport.REST_HTTPS, restPort ?: RouterTransport.REST_HTTPS.port,
                "NOT_RUN", null, null, 0, 0, 0, "REST not selected by service mode"
            ),
            results[RouterTransport.API_SSL] ?: BranchProbe(
                RouterTransport.API_SSL, apiPort ?: RouterTransport.API_SSL.port,
                "NOT_RUN", null, null, 0, 0, 0, "API-SSL not selected by service mode"
            )
        )
    }

    private suspend fun probeBranch(
        host: String,
        port: Int,
        transport: RouterTransport,
        addresses: List<InetAddress>,
        expectedPin: String?
    ): BranchProbe {
        val started = System.currentTimeMillis()
        return try {
            val result = TlsFingerprintInspector.probe(host, port, addresses)
            val state = if (expectedPin != null && !result.fingerprint.equals(expectedPin, ignoreCase = true)) {
                "TLS_CHANGED"
            } else "TLS_OK"
            BranchProbe(transport, port, state, result.fingerprint, result.resolvedIp,
                result.tcpDurationMs, result.tlsDurationMs, System.currentTimeMillis() - started,
                if (state == "TLS_CHANGED") "Pinned TLS fingerprint changed" else null,
                result.tlsVersion, result.cipherSuite)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: TlsProbeException) {
            BranchProbe(transport, port, error.failureCode, null, error.resolvedIp,
                error.tcpDurationMs, error.tlsDurationMs, System.currentTimeMillis() - started,
                "${error.failureStage}: ${error.message}; cause=${error.cause?.javaClass?.simpleName ?: "none"}: ${error.cause?.message ?: "no cause detail"}")
        } catch (error: Exception) {
            BranchProbe(transport, port, "ERROR", null, null, 0, 0,
                System.currentTimeMillis() - started, error.message)
        }
    }

    private suspend fun authenticateAndPersist(
        attempt: PendingAttempt,
        pin: String,
        tlsPinConfirmed: Boolean = false
    ): JSONObject = coroutineScope {
        val restProbe = attempt.probes.first { it.transport == RouterTransport.REST_HTTPS }
        val apiProbe = attempt.probes.first { it.transport == RouterTransport.API_SSL }
        val restSkipped = BranchAuth(RouterTransport.REST_HTTPS, restProbe.port, "NOT_RUN_PIN_REQUIRED", null,
            restProbe.resolvedIp, "REST was not authenticated because its certificate has not been independently pinned")
        val apiSkipped = BranchAuth(RouterTransport.API_SSL, apiProbe.port, "NOT_RUN_PIN_REQUIRED", null,
            apiProbe.resolvedIp, "API-SSL was not authenticated because its certificate has not been independently pinned")
        val (rest, api) = if (attempt.pinTransport == RouterTransport.REST_HTTPS) {
            val auth = async(Dispatchers.IO) {
                withTimeoutOrNull(REST_AUTH_BRANCH_TIMEOUT_MS) {
                    val authStarted = System.currentTimeMillis()
                    authenticateRest(attempt, restProbe, pin).copy(durationMs = System.currentTimeMillis() - authStarted)
                } ?: BranchAuth(RouterTransport.REST_HTTPS, restProbe.port, "NETWORK_TIMEOUT", null, restProbe.resolvedIp, "REST authentication/read check timed out")
            }.await()
            auth to apiSkipped
        } else {
            val auth = async(Dispatchers.IO) {
                withTimeoutOrNull(API_AUTH_BRANCH_TIMEOUT_MS) {
                    val authStarted = System.currentTimeMillis()
                    authenticateApi(attempt, apiProbe, pin).copy(durationMs = System.currentTimeMillis() - authStarted)
                } ?: BranchAuth(RouterTransport.API_SSL, apiProbe.port, "NETWORK_TIMEOUT", null, apiProbe.resolvedIp, "API-SSL authentication/read check timed out")
            }.await()
            restSkipped to auth
        }
        attempt.authDurations[RouterTransport.REST_HTTPS] = rest.durationMs
        attempt.authDurations[RouterTransport.API_SSL] = api.durationMs
        val decision = decide(rest, api)
        if (decision.finalState == "TLS_CHANGED") {
            val changedTransport = when {
                rest.code == "TLS_CHANGED" -> RouterTransport.REST_HTTPS
                api.code == "TLS_CHANGED" -> RouterTransport.API_SSL
                else -> null
            }
            val changedProbes = runCatching {
                probeBoth(attempt.host, attempt.resolution.addresses, expectedPin = null,
                    serviceMode = attempt.serviceMode, requestedPort = attempt.requestedPort)
            }.getOrDefault(emptyList())
            val changed = changedProbes.firstOrNull {
                it.transport == changedTransport && it.fingerprint != null && !it.fingerprint.equals(pin, true)
            }
            if (changed?.fingerprint != null) {
                val retry = PendingAttempt(
                    id = UUID.randomUUID().toString(), host = attempt.host, username = attempt.username,
                    password = attempt.password, existing = attempt.existing, resolution = attempt.resolution,
                    probes = changedProbes, oldPin = pin, candidatePin = changed.fingerprint,
                    startedAt = attempt.startedAt, serviceMode = attempt.serviceMode,
                    pinTransport = changed.transport, requestedPort = attempt.requestedPort,
                    fallbackAttempted = attempt.fallbackAttempted
                )
                pending[retry.id] = retry
                return@coroutineScope JSONObject()
                    .put("ok", false).put("state", "TLS_CHANGED").put("attemptId", retry.id)
                    .put("host", attempt.host).put("protocol", changed.transport.name)
                    .put("oldFingerprint", pin).put("newFingerprint", changed.fingerprint)
                    .put("port", changed.port)
                    .put("message", "Fingerprint thay đổi trong lúc xác thực. Kết nối đã dừng để chờ xác nhận.")
            }
        }
        if (decision.finalState != "READY" && decision.finalState != "READY_LIMITED") {
            val activeAuth = if (attempt.pinTransport == RouterTransport.REST_HTTPS) rest else api
            val alternateTransport = if (attempt.pinTransport == RouterTransport.REST_HTTPS) RouterTransport.API_SSL else RouterTransport.REST_HTTPS
            val alternateProbe = attempt.probes.firstOrNull { it.transport == alternateTransport }
            val alternateCanBeTried = canTryAlternateTransport(
                attempt.serviceMode, activeAuth.code, attempt.fallbackAttempted, alternateProbe?.fingerprint != null
            )
            if (alternateCanBeTried && alternateProbe != null) {
                val alternateStoredPin = attempt.existing?.tlsPinFor(alternateTransport, alternateProbe.port)
                val alternateFingerprint = alternateProbe.fingerprint!!
                val retry = PendingAttempt(
                    id = UUID.randomUUID().toString(), host = attempt.host, username = attempt.username,
                    password = attempt.password, existing = attempt.existing, resolution = attempt.resolution,
                    probes = attempt.probes, oldPin = alternateStoredPin,
                    candidatePin = alternateStoredPin ?: alternateFingerprint,
                    startedAt = attempt.startedAt, serviceMode = attempt.serviceMode,
                    pinTransport = alternateTransport, requestedPort = attempt.requestedPort,
                    fallbackAttempted = true
                )
                if (alternateStoredPin != null && !alternateFingerprint.equals(alternateStoredPin, true)) {
                    retry.copy(oldPin = alternateStoredPin, candidatePin = alternateFingerprint).also { pending[it.id] = it }
                    return@coroutineScope JSONObject()
                        .put("ok", false).put("state", "TLS_CHANGED").put("attemptId", retry.id)
                        .put("host", attempt.host).put("protocol", alternateTransport.name)
                        .put("oldFingerprint", alternateStoredPin).put("newFingerprint", alternateFingerprint)
                        .put("port", alternateProbe.port)
                        .put("message", "Fingerprint của dịch vụ dự phòng đã thay đổi. Cần xác nhận riêng trước khi kết nối.")
                }
                if (alternateStoredPin != null) {
                    return@coroutineScope authenticateAndPersist(retry, alternateStoredPin)
                }
                pending[retry.id] = retry
                return@coroutineScope JSONObject()
                    .put("ok", false).put("state", "FIRST_TIME_PIN").put("attemptId", retry.id)
                    .put("host", attempt.host).put("fingerprint", retry.candidatePin).put("port", alternateProbe.port)
                    .put("protocol", alternateTransport.name)
                    .put("message", "Giao thức ưu tiên không vượt qua READ_CHECK. Cần xác nhận fingerprint riêng của ${alternateTransport.name} trước khi thử nhánh này.")
            }
            logFailure(attempt, rest, api, decision.finalState, decision.message)
            return@coroutineScope JSONObject()
                .put("ok", false).put("state", decision.finalState)
                .put("message", decision.message)
                .put("restResult", rest.code).put("apiSslResult", api.code)
                .put("restMessage", redactSecret(rest.message, attempt.password))
                .put("apiSslMessage", redactSecret(api.message, attempt.password))
                .put("diagnostics", connectionDiagnostics(attempt.host, attempt.resolution, attempt.probes)
                    .put("stage", "AUTH_READ_CHECK")
                    .put("restAuth", JSONObject().put("code", rest.code).put("port", rest.port).put("durationMs", rest.durationMs).put("detail", redactSecret(rest.message, attempt.password)))
                    .put("apiSslAuth", JSONObject().put("code", api.code).put("port", api.port).put("durationMs", api.durationMs).put("detail", redactSecret(api.message, attempt.password))))
                .put("elapsedMs", System.currentTimeMillis() - attempt.startedAt)
        }

        val decisionSelected = decision.selected ?: return@coroutineScope failure("ERROR", "Không xác định được giao thức đã xác thực.")
        val initial = if (decisionSelected == RouterTransport.REST_HTTPS) rest else api
        val version = initial.version ?: if (decisionSelected == RouterTransport.REST_HTTPS) "7" else null
        val major = version?.substringBefore('.')?.toIntOrNull()
            ?: attempt.existing?.routerOsMajor
            ?: if (decisionSelected == RouterTransport.REST_HTTPS) 7 else 0
        if (major !in 6..7) {
            logFailure(attempt, rest, api, "ERROR", "RouterOS version missing or unsupported")
            return@coroutineScope failure("ERROR", "Không xác định được RouterOS 6/7 từ dữ liệu Router thực tế.")
        }
        val selected = try {
            attempt.serviceMode.selectAuthenticatedTransport(
                major,
                restAuthenticated = rest.code == "OK" || rest.code == "READ_DENIED",
                apiSslAuthenticated = api.code == "OK" || api.code == "READ_DENIED"
            )
        } catch (error: IllegalArgumentException) {
            logFailure(attempt, rest, api, "PROTOCOL_INCOMPATIBLE", error.message ?: "Protocol incompatible")
            return@coroutineScope failure("PROTOCOL_INCOMPATIBLE", error.message ?: "Giao thức không tương thích với RouterOS.")
        }
        if (selected == null) {
            logFailure(attempt, rest, api, "PROTOCOL_INCOMPATIBLE", "No compatible authenticated transport for RouterOS $major")
            return@coroutineScope JSONObject()
                .put("ok", false).put("state", "PROTOCOL_INCOMPATIBLE")
                .put("message", "Không có giao thức tương thích nào vượt qua READ_CHECK.")
                .put("restResult", rest.code).put("apiSslResult", api.code)
                .put("restMessage", redactSecret(rest.message, attempt.password))
                .put("apiSslMessage", redactSecret(api.message, attempt.password))
                .put("diagnostics", connectionDiagnostics(attempt.host, attempt.resolution, attempt.probes)
                    .put("stage", "AUTH_READ_CHECK")
                    .put("restAuth", JSONObject().put("code", rest.code).put("port", rest.port).put("detail", redactSecret(rest.message, attempt.password)))
                    .put("apiSslAuth", JSONObject().put("code", api.code).put("port", api.port).put("detail", redactSecret(api.message, attempt.password))))
        }
        val successful = if (selected == RouterTransport.REST_HTTPS) rest else api
        val latency = System.currentTimeMillis() - attempt.startedAt
        // Persist the exact WAN-facing port that passed TLS + authenticated READ_CHECK.
        val selectedPort = successful.port
        val payload = JSONObject()
            .put("name", attempt.existing?.name ?: attempt.host)
            .put("siteName", attempt.existing?.siteName ?: "Mặc định")
            .put("host", attempt.host)
            .put("port", selectedPort)
            .put("routerOsMajor", major)
            .put("connectionMode", attempt.serviceMode.storageValue)
            .put("activeTransport", selected.name)
            .put("username", attempt.username)
            .put("password", attempt.password)
            .put("tlsSha256Pin", pin)
            .put("tlsRestSha256Pin", if (selected == RouterTransport.REST_HTTPS) pin else attempt.existing?.tlsRestSha256Pin ?: JSONObject.NULL)
            .put("tlsRestPinPort", if (selected == RouterTransport.REST_HTTPS) selectedPort else attempt.existing?.tlsRestPinPort ?: JSONObject.NULL)
            .put("tlsApiSslSha256Pin", if (selected == RouterTransport.API_SSL) pin else attempt.existing?.tlsApiSslSha256Pin ?: JSONObject.NULL)
            .put("tlsApiSslPinPort", if (selected == RouterTransport.API_SSL) selectedPort else attempt.existing?.tlsApiSslPinPort ?: JSONObject.NULL)
            .put("lastResolvedIp", successful.resolvedIp ?: attempt.probes.firstOrNull { it.resolvedIp != null }?.resolvedIp.orEmpty())
            .put("dnsResolver", attempt.resolution.source)
            .put("fallbackAvailable", false)
            .put("routerOsVersion", successful.version ?: if (selected == RouterTransport.REST_HTTPS) "7" else "")
            .put("accessLevel", if (decision.finalState == "READY") "FULL" else "LIMITED")
            .put("lastStatus", decision.finalState)
            .put("lastConnectionLatencyMs", latency)
            .put("tlsPinConfirmed", tlsPinConfirmed)
        if (attempt.existing != null) payload.put("id", attempt.existing.id)
        val routerId = try {
            profiles.saveRouter(payload.toString())
        } catch (error: Exception) {
            val safeDetail = redactSecret(error.message ?: "Profile persistence failed", attempt.password)
            logFailure(attempt, rest, api, "ERROR", safeDetail)
            return@coroutineScope failure("ERROR", "Đã xác thực Router nhưng không thể lưu profile an toàn. Kiểm tra nhật ký kỹ thuật.")
        }
        logSuccess(routerId, attempt, rest, api, decision, latency, selected)
        JSONObject()
            .put("ok", true).put("state", decision.finalState)
            .put("id", routerId)
            .put("host", attempt.host)
            .put("routerOsVersion", successful.version ?: "RouterOS $major")
            .put("protocol", if (selected == RouterTransport.REST_HTTPS) "REST" else "API-SSL")
            .put("port", selectedPort)
            .put("connectionMode", attempt.serviceMode.storageValue)
            .put("activeTransport", selected.name)
            .put("latencyMs", latency)
            .put("fallbackAvailable", false)
            .put("dnsResolver", attempt.resolution.source)
            .put("resolvedIp", successful.resolvedIp ?: JSONObject.NULL)
            .put("message", if (decision.finalState == "READY") "Đã kết nối và đọc được dữ liệu Router." else "Đã xác thực Router nhưng tài khoản chưa đủ quyền đọc.")
            .put("warnings", JSONArray().apply {
                if (rest.code != "OK" && rest.code != "NOT_RUN" && rest.code != "NOT_RUN_PIN_REQUIRED") put("REST: ${redactSecret(rest.message, attempt.password)}")
                if (api.code != "OK" && api.code != "NOT_RUN" && api.code != "NOT_RUN_PIN_REQUIRED") put("API-SSL: ${redactSecret(api.message, attempt.password)}")
            })
    }

    private suspend fun authenticateRest(attempt: PendingAttempt, probe: BranchProbe, pin: String): BranchAuth {
        if (probe.fingerprint == null) return probe.toAuth()
        if (!probe.fingerprint.equals(pin, ignoreCase = true)) return BranchAuth(
            RouterTransport.REST_HTTPS, probe.port, "TLS_FINGERPRINT_MISMATCH", null, probe.resolvedIp,
            "REST certificate differs from the accepted profile pin"
        ).copy(code = "TLS_UNTRUSTED_BRANCH")
        val client = RouterOs7Client(
            attempt.host, probe.port, attempt.username, attempt.password, pin,
            connectTimeoutMs = 5_000, readTimeoutMs = 5_000, writeTimeoutMs = 5_000, callTimeoutMs = 8_000,
            resolvedAddresses = attempt.resolution.addresses
        )
        return when (val result = client.get("system/resource")) {
            is McmResult.Failure -> BranchAuth(RouterTransport.REST_HTTPS, probe.port, mapFailure(result.code), null, probe.resolvedIp, result.message)
            is McmResult.Success -> {
                val row = result.value.optJSONObject(0)
                if (row == null) BranchAuth(RouterTransport.REST_HTTPS, probe.port, "READ_DENIED", null, probe.resolvedIp, "REST returned no system resource row")
                else BranchAuth(RouterTransport.REST_HTTPS, probe.port, "OK", row.optString("version").takeIf(String::isNotBlank), probe.resolvedIp, "Read check succeeded")
            }
        }
    }

    private suspend fun authenticateApi(attempt: PendingAttempt, probe: BranchProbe, pin: String): BranchAuth {
        if (probe.fingerprint == null) return probe.toAuth()
        if (!probe.fingerprint.equals(pin, ignoreCase = true)) return BranchAuth(
            RouterTransport.API_SSL, probe.port, "TLS_FINGERPRINT_MISMATCH", null, probe.resolvedIp,
            "API-SSL certificate differs from the accepted profile pin"
        ).copy(code = "TLS_UNTRUSTED_BRANCH")
        val client = RouterOs6ApiClient(
            attempt.host, probe.port, attempt.username, attempt.password, pin,
            connectTimeoutMs = 5_000, loginReadTimeoutMs = 8_000, commandReadTimeoutMs = 5_000,
            resolvedAddresses = attempt.resolution.addresses
        )
        return when (val result = client.execute("/system/resource/print")) {
            is McmResult.Failure -> BranchAuth(RouterTransport.API_SSL, probe.port, mapFailure(result.code), null, probe.resolvedIp, result.message)
            is McmResult.Success -> {
                val row = result.value.firstOrNull()
                if (row == null) BranchAuth(RouterTransport.API_SSL, probe.port, "READ_DENIED", null, probe.resolvedIp, "API-SSL returned no system resource row")
                else BranchAuth(RouterTransport.API_SSL, probe.port, "OK", row["version"], probe.resolvedIp, "Read check succeeded")
            }
        }
    }

    private fun mapFailure(code: String): String = normalizeTransportFailureCode(code)

    private fun decide(rest: BranchAuth, api: BranchAuth): Decision {
        if (rest.code == "TLS_CHANGED" || api.code == "TLS_CHANGED") {
            return Decision("TLS_CHANGED", null, false, "Fingerprint thay đổi trong lúc xác thực. Đã dừng kết nối để bảo vệ profile.")
        }
        if (rest.code == "OK" && api.code == "OK") return Decision("READY", RouterTransport.REST_HTTPS, true, "Both transports authenticated")
        if (rest.code == "OK") return Decision("READY", RouterTransport.REST_HTTPS, false, "REST authenticated; API-SSL unavailable or not authorized")
        if (api.code == "OK") return Decision("READY", RouterTransport.API_SSL, false, "API-SSL authenticated; REST unavailable or not authorized")
        if (rest.code == "READ_DENIED" || api.code == "READ_DENIED") {
            val selected = if (rest.code == "READ_DENIED") RouterTransport.REST_HTTPS else RouterTransport.API_SSL
            return Decision("READY_LIMITED", selected, false, "Authenticated but the account cannot read the required system resource")
        }
        if (rest.code == "AUTH_FAILED" || api.code == "AUTH_FAILED") {
            return Decision("AUTH_FAILED", null, false, "RouterOS rejected the supplied credentials on the tested management endpoints")
        }
        val tested = listOf(rest, api).filter { it.code != "NOT_RUN" && it.code != "NOT_RUN_PIN_REQUIRED" }
        val codes = tested.map { it.code }.toSet()
        if (tested.isNotEmpty() && tested.all { it.code == "NETWORK_TIMEOUT" }) return Decision("NETWORK_TIMEOUT", null, false, "Selected management endpoint timed out")
        if (tested.any { it.code in setOf("TLS_FAILED", "TLS_HANDSHAKE", "TLS_HOSTNAME", "TLS_CERT_VALIDITY") }) {
            return Decision("TLS_ERROR", null, false, "TLS certificate identity or handshake validation failed; automatic fallback was blocked.")
        }
        if (tested.isNotEmpty() && tested.all { it.code == "TCP_REFUSED" || it.code == "TLS_PROTOCOL" || it.code == "PORTS_UNREACHABLE" }) {
            return Decision("PORTS_UNREACHABLE", null, false, "Selected WAN port does not expose the selected RouterOS TLS service")
        }
        if ("NETWORK_TIMEOUT" in codes) return Decision("NETWORK_TIMEOUT", null, false, "A selected management endpoint did not respond before its timeout")
        return Decision("ERROR", null, false, "Could not authenticate or read RouterOS data: REST=${rest.code}, API-SSL=${api.code}")
    }

    private fun classifyProbeFailure(
        host: String,
        resolution: RouterDnsResolver.Resolution,
        probes: List<BranchProbe>,
        elapsed: Long
    ): JSONObject {
        val tested = probes.filter { it.code != "NOT_RUN" }
        val codes = tested.map { it.code }.toSet()
        val state = when {
            tested.isNotEmpty() && tested.all { it.code == "NETWORK_TIMEOUT" } -> "NETWORK_TIMEOUT"
            tested.any { it.code in setOf("TLS_FAILED", "TLS_HANDSHAKE", "TLS_HOSTNAME", "TLS_CERT_VALIDITY") } -> "TLS_ERROR"
            tested.isNotEmpty() && tested.all { it.code == "TCP_REFUSED" || it.code == "TLS_PROTOCOL" || it.code == "PORTS_UNREACHABLE" } -> "PORTS_UNREACHABLE"
            "NETWORK_TIMEOUT" in codes -> "NETWORK_TIMEOUT"
            else -> "PORTS_UNREACHABLE"
        }
        val endpointSummary = tested.joinToString("; ") { "${it.transport.name}:${it.port}=${it.code}" }
        val output = failure(state, if (state == "PORTS_UNREACHABLE") {
            "Không truy cập được dịch vụ đã chọn tại $host. $endpointSummary"
        } else "Hết thời gian chờ khi kiểm tra dịch vụ tại $host. $endpointSummary")
        output.put("elapsedMs", elapsed)
            .put("restResult", probes.firstOrNull { it.transport == RouterTransport.REST_HTTPS }?.code)
            .put("apiSslResult", probes.firstOrNull { it.transport == RouterTransport.API_SSL }?.code)
            .put("diagnostics", connectionDiagnostics(host, resolution, probes).put("stage", "TCP_TLS_PROBE"))
        return output
    }

    private suspend fun logFailure(attempt: PendingAttempt, rest: BranchAuth, api: BranchAuth, state: String, detail: String) {
        val routerId = attempt.existing?.id ?: return
        writeLog(routerId, attempt, rest.code, api.code, null, state, detail, System.currentTimeMillis() - attempt.startedAt)
    }

    private suspend fun logSuccess(
        routerId: String,
        attempt: PendingAttempt,
        rest: BranchAuth,
        api: BranchAuth,
        decision: Decision,
        duration: Long,
        selectedTransport: RouterTransport
    ) {
        writeLog(routerId, attempt, rest.code, api.code, selectedTransport.name, decision.finalState, decision.message, duration)
    }

    private suspend fun writeLog(
        routerId: String,
        attempt: PendingAttempt,
        restResult: String,
        apiResult: String,
        selected: String?,
        state: String,
        detail: String,
        duration: Long
    ) {
        val ipArray = JSONArray().apply { attempt.resolution.addresses.forEach { put(it.hostAddress ?: "") } }
        val safeDetail = detail.replace(attempt.password, "[REDACTED]").take(500)
        database.connectionAttemptLogDao().insert(
            ConnectionAttemptLogEntity(
                id = attempt.id,
                routerId = routerId,
                attemptedAtEpochMs = attempt.startedAt,
                durationMs = duration,
                dnsResolver = attempt.resolution.source,
                resolvedIps = ipArray.toString(),
                restResult = restResult,
                apiSslResult = apiResult,
                restProbeDetails = probeDetails(attempt.probes.first { it.transport == RouterTransport.REST_HTTPS }).toString(),
                apiSslProbeDetails = probeDetails(attempt.probes.first { it.transport == RouterTransport.API_SSL }).toString(),
                restAuthDurationMs = attempt.authDurations[RouterTransport.REST_HTTPS] ?: 0L,
                apiSslAuthDurationMs = attempt.authDurations[RouterTransport.API_SSL] ?: 0L,
                selectedProtocol = selected,
                finalState = state,
                detail = safeDetail
            )
        )
    }

    private suspend fun writeDnsFailureLog(
        routerId: String,
        startedAt: Long,
        state: String,
        detail: String
    ) {
        val emptyTrace = JSONObject().put("tcpResult", "NOT_RUN").put("tlsResult", "NOT_RUN")
        database.connectionAttemptLogDao().insert(
            ConnectionAttemptLogEntity(
                id = UUID.randomUUID().toString(), routerId = routerId,
                attemptedAtEpochMs = startedAt, durationMs = System.currentTimeMillis() - startedAt,
                dnsResolver = "NONE", resolvedIps = "[]", restResult = "NOT_RUN", apiSslResult = "NOT_RUN",
                restProbeDetails = emptyTrace.toString(), apiSslProbeDetails = emptyTrace.toString(),
                restAuthDurationMs = 0, apiSslAuthDurationMs = 0, selectedProtocol = null,
                finalState = state, detail = detail.take(500)
            )
        )
    }

    private suspend fun writeProbeFailureLog(
        routerId: String,
        startedAt: Long,
        resolution: RouterDnsResolver.Resolution,
        probes: List<BranchProbe>,
        state: String,
        detail: String
    ) {
        val byTransport = probes.associateBy { it.transport }
        val ips = JSONArray().apply { resolution.addresses.forEach { put(it.hostAddress ?: "") } }
        database.connectionAttemptLogDao().insert(
            ConnectionAttemptLogEntity(
                id = UUID.randomUUID().toString(), routerId = routerId,
                attemptedAtEpochMs = startedAt, durationMs = System.currentTimeMillis() - startedAt,
                dnsResolver = resolution.source, resolvedIps = ips.toString(),
                restResult = byTransport[RouterTransport.REST_HTTPS]?.code ?: "NOT_RUN",
                apiSslResult = byTransport[RouterTransport.API_SSL]?.code ?: "NOT_RUN",
                restProbeDetails = byTransport[RouterTransport.REST_HTTPS]?.let(::probeDetails)?.toString() ?: "{}",
                apiSslProbeDetails = byTransport[RouterTransport.API_SSL]?.let(::probeDetails)?.toString() ?: "{}",
                restAuthDurationMs = 0, apiSslAuthDurationMs = 0, selectedProtocol = null,
                finalState = state, detail = detail.take(500)
            )
        )
    }

    private fun connectionDiagnostics(
        host: String,
        resolution: RouterDnsResolver.Resolution,
        probes: List<BranchProbe>
    ): JSONObject = JSONObject()
        .put("host", host)
        .put("dns", JSONObject().put("source", resolution.source)
            .put("addresses", JSONArray().apply { resolution.addresses.forEach { put(it.hostAddress ?: "") } }))
        .put("endpoints", JSONArray().apply {
            probes.forEach { probe ->
                put(JSONObject().put("service", probe.transport.name).put("port", probe.port)
                    .put("result", probe.code).put("resolvedIp", probe.resolvedIp ?: JSONObject.NULL)
                    .put("tcpMs", probe.tcpDurationMs).put("tlsMs", probe.tlsDurationMs)
                    .put("elapsedMs", probe.elapsedMs).put("fingerprint", probe.fingerprint ?: JSONObject.NULL)
                    .put("tlsVersion", probe.tlsVersion ?: JSONObject.NULL)
                    .put("cipherSuite", probe.cipherSuite ?: JSONObject.NULL)
                    .put("detail", probe.detail ?: JSONObject.NULL))
            }
        })

    private fun BranchProbe.toAuth(): BranchAuth = BranchAuth(transport, port, code, null, resolvedIp, detail ?: code)

    private fun probeDetails(probe: BranchProbe): JSONObject = JSONObject()
        .put("port", probe.port)
        .put("tcpResult", when {
            probe.tcpDurationMs > 0 -> "CONNECTED"
            probe.detail?.contains("TCP_CONNECT") == true -> probe.code
            else -> "NOT_CONFIRMED"
        })
        .put("tlsResult", when {
            probe.fingerprint != null -> "CERTIFICATE_CAPTURED_AWAITING_PIN"
            probe.detail?.contains("TLS_HANDSHAKE") == true -> probe.code
            probe.tcpDurationMs > 0 -> "FAILED_AFTER_TCP_CONNECT"
            else -> "NOT_REACHED_OR_TIMEOUT"
        })
        .put("fingerprintSha256", probe.fingerprint ?: JSONObject.NULL)
        .put("resolvedIp", probe.resolvedIp ?: JSONObject.NULL)
        .put("tcpDurationMs", probe.tcpDurationMs)
        .put("tlsDurationMs", probe.tlsDurationMs)
        .put("probeDurationMs", probe.elapsedMs)
        .put("detail", probe.detail ?: JSONObject.NULL)

    private fun redactSecret(value: String, secret: String): String =
        if (secret.isEmpty()) value.take(500) else value.replace(secret, "[REDACTED]").take(500)

    private fun failure(state: String, message: String): JSONObject =
        JSONObject().put("ok", false).put("state", state).put("message", message)

    private data class PendingAttempt(
        val id: String,
        val host: String,
        val username: String,
        val password: String,
        val existing: RouterEntity?,
        val resolution: RouterDnsResolver.Resolution,
        val probes: List<BranchProbe>,
        val oldPin: String?,
        val candidatePin: String,
        val startedAt: Long,
        val serviceMode: RouterServiceMode = RouterServiceMode.AUTO,
        val pinTransport: RouterTransport = RouterTransport.REST_HTTPS,
        val requestedPort: Int = 0,
        val fallbackAttempted: Boolean = false,
        val authDurations: MutableMap<RouterTransport, Long> = ConcurrentHashMap()
    )

    private data class BranchProbe(
        val transport: RouterTransport,
        val port: Int,
        val code: String,
        val fingerprint: String?,
        val resolvedIp: String?,
        val tcpDurationMs: Long,
        val tlsDurationMs: Long,
        val elapsedMs: Long = 0,
        val detail: String? = null,
        val tlsVersion: String? = null,
        val cipherSuite: String? = null
    )

    private data class BranchAuth(
        val transport: RouterTransport,
        val port: Int,
        val code: String,
        val version: String?,
        val resolvedIp: String?,
        val message: String,
        val durationMs: Long = 0L
    )

    private data class Decision(
        val finalState: String,
        val selected: RouterTransport?,
        val fallbackAvailable: Boolean,
        val message: String,
        val durationMs: Long = 0L
    )

    companion object {
        private const val TOTAL_CONNECTION_TIMEOUT_MS = 30_000L
        private const val PROBE_BRANCH_TIMEOUT_MS = 10_500L
        private const val REST_AUTH_BRANCH_TIMEOUT_MS = 8_000L
        // RouterOS API login is budgeted at 8s and READ_CHECK at 5s.
        private const val API_AUTH_BRANCH_TIMEOUT_MS = 13_000L
        private const val PENDING_TTL_MS = 5 * 60 * 1000L
    }
}
