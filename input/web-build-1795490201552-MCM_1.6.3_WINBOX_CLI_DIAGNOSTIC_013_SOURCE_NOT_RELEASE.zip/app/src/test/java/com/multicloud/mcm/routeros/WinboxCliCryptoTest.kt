package com.multicloud.mcm.routeros

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.math.BigInteger
import java.nio.charset.StandardCharsets

class WinboxCliCryptoTest {
    private fun hex(value: String) = value.chunked(2).map { it.toInt(16).toByte() }.toByteArray()

    @Test fun ecSrp5MatchesPublishedRouterOsKnownAnswerVector() {
        val privateA = ByteArray(32) { (it + 1).toByte() }
        val salt = ByteArray(16) { (0xA0 + it).toByte() }
        val publicA = WinboxCliConnector.EcSrp5.publicKey(privateA)
        assertArrayEquals(hex("718F0034BA92AADE2EB5495170DB6AA13F5D8C29F2C575942EB2D6390788A50A"), publicA.first)
        assertTrue(publicA.second == 1)

        val challenge = hex("680CE593193F1D7FF4764EDC0712EF541433F744516814B6A3C7577310F7DA0300A0A1A2A3A4A5A6A7A8A9AAABACADAEAF")
        val xB = challenge.copyOfRange(0, 32)
        val parityB = challenge[32].toInt() and 255
        val validator = WinboxCliConnector.EcSrp5.sha256(
            salt + WinboxCliConnector.EcSrp5.sha256("admin:t4n-secret".toByteArray(StandardCharsets.UTF_8))
        )
        val gamma = WinboxCliConnector.EcSrp5.publicKey(validator).first
        val v = WinboxCliConnector.EcSrp5.redp1(gamma, 1)
        val pointB = WinboxCliConnector.EcSrp5.liftX(BigInteger(1, xB), parityB)
        val j = WinboxCliConnector.EcSrp5.sha256(publicA.first + xB)
        val exponent = (BigInteger(1, validator).multiply(BigInteger(1, j)).mod(WinboxCliConnector.EcSrp5.r)
            .add(BigInteger(1, privateA))).mod(WinboxCliConnector.EcSrp5.r)
        val z = WinboxCliConnector.EcSrp5.toMontgomery(
            WinboxCliConnector.EcSrp5.multiply(exponent, WinboxCliConnector.EcSrp5.add(pointB, v))
        ).first
        val clientConfirmation = WinboxCliConnector.EcSrp5.sha256(j + z)
        assertArrayEquals(hex("E898C15526EA844B23196E7012747495652C1373D9F16908DA0AA44A9C58E5F0"), clientConfirmation)
        assertArrayEquals(hex("BAEAAF1A5C581D7B1984F13E50D7AF00694263854D2075B18C5F4EC74AF24689"), WinboxCliConnector.EcSrp5.sha256(z))
    }

    @Test fun m2ParserSkipsArraysAndBooleanFieldsBeforeSessionFields() {
        val message = hex("4D32" +
            "0100FF8801004C000000" +
            "0200FF8802000000000008000000" +
            "0500FF01" +
            "0600FF0907" +
            "0100FE0911" +
            "020000310568656C6C6F")
        val probe = WinboxCliConnector("127.0.0.1", 8291, "u", "p")
        assertTrue(probe.parseU8OrU32(message, 0xFF0006) == 7)
        assertTrue(probe.parseU8OrU32(message, 0xFE0001) == 17)
        assertArrayEquals("hello".toByteArray(StandardCharsets.UTF_8), probe.parseUserVariable(message, 2)!!)
        probe.close()
    }

    @Test fun encryptedFramesRoundTripAndRejectWrongHmac() {
        val client = WinboxCliConnector.StreamKeys.derive(hex("EC071E0A0136C837C051CEE6A7713EDBAEA6936712D1A3CA37E84FEE3226E61D"))
        val server = WinboxCliConnector.StreamKeys(client.receiveAes, client.sendAes, client.receiveHmac, client.sendHmac)
        for (size in listOf(0, 1, 11, 12, 13, 27, 28, 44, 300)) {
            val message = ByteArray(size) { (it * 7 + 3).toByte() }
            val frame = client.encrypt(message)
            assertArrayEquals(message, server.decrypt(frame))
        }
        val sample = client.encrypt("M2-golden".toByteArray(StandardCharsets.UTF_8))
        val tampered = sample.copyOf().also { it[it.lastIndex] = (it.last().toInt() xor 1).toByte() }
        var rejected = false
        try { server.decrypt(tampered) } catch (_: Exception) { rejected = true }
        assertTrue(rejected)
    }

    @Test fun streamKeyDerivationMatchesPublishedVector() {
        val keys = WinboxCliConnector.StreamKeys.derive(hex("EC071E0A0136C837C051CEE6A7713EDBAEA6936712D1A3CA37E84FEE3226E61D"))
        assertArrayEquals(hex("2C3320D2AF211ADFD4D2A9BCF57DDE04"), keys.sendAes)
        assertArrayEquals(hex("B47DE81D1EFF98797D76A47460905584"), keys.receiveAes)
        assertArrayEquals(hex("BF5183A25889AD982C33B9B8F8DFA83FBD367745"), keys.sendHmac)
        assertArrayEquals(hex("54EEA56D698EA3A7A171DFEB3115E14BE77FF7D7"), keys.receiveHmac)
    }
}
