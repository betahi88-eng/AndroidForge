# ANDROIDFORGE — ĐẦU VÀO ZIP → APK MCM 1.6.3

## Nhận diện đúng gói

- Tên gói: `MCM_1.6.3_DDNS_RECONCILED_007_SOURCE_NOT_RELEASE.zip`
- Source ID: `MCM-1.6.3-WINBOX-CLI-DIAGNOSTIC-013`
- Project: MikroTik Multi-Cloud Monitor (MCM)
- Application ID: `com.multicloud.mcm`
- Version: `1.6.3` (`versionCode=12`)
- Loại: Android native / Kotlin / Gradle; module `:app`
- Min SDK: 26; Compile SDK / Target SDK: 35
- JDK: 17; Gradle: 8.7; AGP: 8.6.1; Kotlin: 2.0.21

Đây là source project ở trạng thái **SOURCE CANDIDATE — NOT RELEASE**, không phải APK và chưa được xác nhận build Android thành công. Không dùng Repair Kit hoặc một ZIP lịch sử thay cho gói trên.

## Cấu trúc đầu vào bắt buộc

Giải nén ZIP trực tiếp thành project root. Các tệp sau phải nằm ngay tại root, không nằm trong một thư mục con:

- `settings.gradle.kts`
- `build.gradle.kts`
- `app/build.gradle.kts`
- `app/src/main/AndroidManifest.xml`

AndroidForge phải chạy Gradle từ đúng thư mục root này và nhận diện module `:app`. Không chạy Gradle từ thư mục cha hoặc từ thư mục Repair Kit.

## Cấu hình build

Dùng đúng toolchain đã khóa: JDK 17, Gradle 8.7, AGP 8.6.1, Kotlin 2.0.21, Android SDK Platform 35 và Build Tools 35.0.0.

Gói source **không kèm Gradle Wrapper**. Vì vậy không chạy `./gradlew`; runner phải cung cấp Gradle 8.7 và gọi Gradle hệ thống:

```bash
gradle --version
gradle --no-daemon clean
gradle --no-daemon :app:testDebugUnitTest
gradle --no-daemon :app:lintDebug
gradle --no-daemon :app:assembleDebug :app:bundleDebug
gradle --no-daemon :app:assembleRelease :app:bundleRelease
```

Hoặc dùng script kiểm tra toolchain và chạy các tác vụ tương đương:

```bash
bash scripts/setup-and-build.sh
```

Trước khi build, runner có thể chạy kiểm tra nguồn:

```bash
bash scripts/androidforge-preflight.sh
MCM_SKIP_GRADLE=1 bash scripts/verify-source.sh
```

## Tiêu chí nhận APK

Chỉ chấp nhận artifact của chính lần chạy hiện tại khi `clean`, `testDebugUnitTest`, `lintDebug`, `assembleDebug`, `bundleDebug`, `assembleRelease` và `bundleRelease` đều trả mã 0. Kiểm tra cả Debug APK và Release APK bằng `aapt dump badging`: package `com.multicloud.mcm`, version `1.6.3` / code `12`, sau đó ghi SHA-256. Debug APK được debug-sign để cài thử; Release APK hiện là unsigned vì dự án không chứa khóa ký phát hành. Không lấy APK cũ có sẵn hoặc suy luận thành công từ việc ZIP giải nén được.

**Tình trạng hiện tại:** chưa có APK đã build/kiểm tra trong gói này. Gradle/KAPT, Android JUnit, lint, Debug/Release APK/AAB, cài đặt trên điện thoại và thử RouterOS WAN/DDNS thực tế vẫn là các cổng nghiệm thu chưa chạy.
