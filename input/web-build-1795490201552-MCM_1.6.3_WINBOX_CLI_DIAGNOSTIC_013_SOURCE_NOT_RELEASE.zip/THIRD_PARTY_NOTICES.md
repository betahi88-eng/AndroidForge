# Third-party notices

## tik4net — protocol research reference

The WinBox CLI implementation and protocol behavior in this candidate were researched against `danikf/tik4net`:
https://github.com/danikf/tik4net

The repository is distributed under the Apache License, Version 2.0. The Kotlin implementation in MCM is an independent implementation of the documented/reference protocol flow; no .NET assembly is bundled. The license text is included at `licenses/Apache-2.0.txt`.

Copyright and trademark rights in MikroTik, RouterOS and WinBox remain with their respective owners. MCM is not an official MikroTik product.
