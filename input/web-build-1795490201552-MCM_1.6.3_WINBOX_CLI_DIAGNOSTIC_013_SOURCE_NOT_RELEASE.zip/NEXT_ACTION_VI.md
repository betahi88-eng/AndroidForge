# Việc còn lại trước nghiệm thu MCM 1.6.3

1. Build đúng source candidate 013 trên AndroidForge bằng JDK 17 / Gradle 8.7 / AGP 8.6.1 / Kotlin 2.0.21 / SDK 35; chạy unit tests, lint và assembleDebug.
2. Cài APK trên Android thật; chạy Advanced → “Kiểm tra WinBox CLI · TCP 8291” với router được ủy quyền.
3. Kiểm tra log tách biệt TCP_CONNECT, EC_SRP5_AUTH, MEPTY_TERMINAL_OPEN, SHELL_READY và READ_CHECK trên ít nhất một RouterOS 6.49.x và một RouterOS 7.x.
4. Đối chiếu kết quả WinBox CLI với WinBox Android chính thức; xác nhận identity/resource khớp.
5. Chỉ sau khi các kiểm tra trên đạt mới triển khai repository monitoring đầy đủ qua WinBox CLI, ánh xạ các bảng interface, cloud, PPPoE, ARP, DHCP, Netwatch, Bridge Host và VLAN.
6. Không thay đổi cấu hình router, không ghi dữ liệu cấu hình và không bật thêm dịch vụ để thử nghiệm.

Candidate 013 hiện là source engineering / NOT RELEASE. Android Gradle/APK và live RouterOS acceptance chưa chạy trong workspace này.
