# AndroidForge patch — MCM 1.6.3 (bản ứng viên kỹ thuật)

## Nội dung

- `input/`: ZIP source dẫn xuất MCM 1.6.3 đã khóa SHA-256; dùng làm ZIP đầu vào của AndroidForge.
- `androidforge_patch/scripts/`: kiểm tra SHA/source, cấu hình toolchain cố định, ghi build provenance và thu APK theo manifest thật.
- `androidforge_patch/patch_androidforge_workflow.py`: vá workflow với kiểm tra source trước build, đường build native cố định cho MCM, gate thu artifact và chặn release tự động.
- `androidforge_patch/MCM_SOURCE/LOCKED_BASE/`: source gốc người dùng cung cấp, giữ nguyên để đối chiếu.
- `APPLY_TO_ANDROIDFORGE.sh` / `.ps1`: áp dụng patch trên nhánh mới trong checkout AndroidForge có working tree sạch.

## Định danh source

- Source ID: `MCM-1.6.3-RECONCILED-001`
- Patch ID: `MCM-1.6.3-ANDROIDFORGE-HARDENED-001`
- Package: `com.multicloud.mcm`
- Version: `1.6.3` / code `12`
- SHA-256 source gốc: `6313e1b28d2e7fa18fd56f20f8a4d91d6abf81a0027d1fe44e33e48a94ea1f0b`
- SHA-256 source dẫn xuất: `6b2f810a430f69d172a81dedafb0f3729e1c5c6f3170db3367426e3c77a59f45`

## Toolchain khóa

JDK 17, Gradle 8.7, AGP 8.6.1, Kotlin 2.0.21, Android SDK Platform 35. Không tự nâng cấp hoặc sửa source để né lỗi môi trường.

## Áp dụng lên AndroidForge

1. Chuẩn bị clone/checkout AndroidForge đúng repo và working tree sạch; giữ nguyên `main`.
2. Chép cả thư mục kit này vào máy có repo AndroidForge.
3. Tại thư mục gốc AndroidForge, chạy `bash /path/to/kit/APPLY_TO_ANDROIDFORGE.sh` (Windows dùng `APPLY_TO_ANDROIDFORGE.ps1`).
4. Script tạo nhánh `fix/mcm-1.6.3-hardened-source-2026-11-23`, kiểm tra hash, tạo backup workflow và vá workflow. Nó không push, merge hay release.
5. Review `git diff`, chạy các test rồi mới tạo workflow run với lựa chọn `mcm-native` và đường dẫn ZIP đã khóa.

Repo AndroidForge thật chưa được cung cấp trong phiên này nên patch chưa được áp dụng vào repo thật; các script đã được kiểm thử trên fixture cục bộ.

## Kết quả và giới hạn xác minh

- AndroidForge hardening tests: 19/19 PASS.
- Extract sạch + MCM source SHA/provenance/project identity gate: PASS.
- Static source checks, Room migration simulation và mobile UI contract: PASS.
- Chưa chạy Gradle build, Android tests/lint hay APK thật do runtime thiếu JDK 17, Gradle 8.7 và Android SDK Platform 35/build-tools; DNS mạng runtime không phân giải được để provision toolchain.
- Không có APK trong gói này. Không dùng APK cũ hoặc APK fixture làm bằng chứng.
- Chưa chạy trên điện thoại/RouterOS thật; chưa nghiệm thu.
