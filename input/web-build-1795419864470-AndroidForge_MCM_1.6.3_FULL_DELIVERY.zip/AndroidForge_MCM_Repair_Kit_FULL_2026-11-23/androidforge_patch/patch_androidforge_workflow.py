#!/usr/bin/env python3
"""Safely patch AndroidForge's build-android.yml with the strict MCM build gate.

Run from the AndroidForge repository root after copying the replacement scripts:
    python3 patch_androidforge_workflow.py
A backup is written beside the workflow. The script refuses unknown workflow
layouts instead of silently applying a partial patch.
"""
from __future__ import annotations

import argparse
import re
import shutil
from pathlib import Path

PROJECT_PROFILE_INPUT = '''      project_profile:
        description: "Expected source type. Choose mcm-native for MCM 1.6.x; use auto for other projects."
        type: choice
        required: true
        default: "auto"
        options:
          - "auto"
          - "mcm-native"
'''

TOOLCHAIN_STEP = '''      - name: Configure toolchain
        id: toolchain
        run: |
          set -euo pipefail
          PROJECT_ROOT="${{ steps.extract.outputs.project_root }}"
          if [ "${{ steps.validate.outputs.is_mcm }}" = "true" ]; then
            python3 scripts/configure_mcm_toolchain.py --root "$PROJECT_ROOT" --output toolchain.json
          else
            python3 scripts/setup_environment.py \\
              --root "$PROJECT_ROOT" \\
              --detect detection.json \\
              --android-sdk "$ANDROID_HOME" \\
              --output toolchain.json
          fi
          echo "::group::Toolchain JSON"
          cat toolchain.json
          echo "::endgroup::"
'''

VALIDATE_STEP = '''      # ---------------------------------------------------------------------
      # Step 2b: Validate source identity and bind it to the downloaded ZIP hash
      # ---------------------------------------------------------------------
      - name: Validate source identity
        id: validate
        run: |
          set -euo pipefail
          python3 scripts/validate_mcm_source.py \\
            --root "${{ steps.extract.outputs.project_root }}" \\
            --zip "${{ steps.acquire.outputs.zip_path }}" \\
            --zip-sha256 "${{ steps.acquire.outputs.zip_sha256 }}" \\
            --profile "${{ inputs.project_profile || 'auto' }}" \\
            --output source_identity.json
          cat source_identity.json

'''

PROVENANCE_STEP = '''      - name: Write MCM build provenance
        id: provenance
        if: steps.validate.outputs.is_mcm == 'true'
        run: |
          set -euo pipefail
          python3 scripts/write_build_provenance.py \
            --root "${{ steps.extract.outputs.project_root }}" \
            --source-id "${{ steps.validate.outputs.source_id }}" \
            --patch-id "${{ steps.validate.outputs.patch_id }}" \
            --base-source-sha256 "${{ steps.validate.outputs.base_source_sha256 }}" \
            --source-zip-sha256 "${{ steps.validate.outputs.zip_sha256 }}"
          echo "MCM build provenance ready for the exact validated ZIP."
'''

BUILD_AND_COLLECT_STEPS = '''      # ---------------------------------------------------------------------
      # Step 11: Build the project (MCM uses a fixed native Gradle path)
      # ---------------------------------------------------------------------
      - name: Build project
        id: build
        run: |
          set -euo pipefail
          PROJECT_ROOT="${{ steps.extract.outputs.project_root }}"
          if [ "${{ steps.validate.outputs.is_mcm }}" = "true" ]; then
            export MCM_SOURCE_ZIP="${{ steps.acquire.outputs.zip_name }}"
            export MCM_SOURCE_SHA256="${{ steps.validate.outputs.zip_sha256 }}"
            echo "MCM source verified: ${{ steps.validate.outputs.source_id }}"
            echo "Source ZIP SHA-256: ${{ steps.validate.outputs.zip_sha256 }}"
            mkdir -p "$GITHUB_WORKSPACE/.androidforge/logs"
            MCM_LOG="$GITHUB_WORKSPACE/.androidforge/logs/mcm-gradle-build.log"
            python3 - "$GITHUB_WORKSPACE/build.json" "$MCM_LOG" <<'PYINIT'
          import json, sys
          with open(sys.argv[1], "w", encoding="utf-8") as handle:
              json.dump({"build_succeeded": False, "project_type": "gradle", "exit_code": -1, "log_file": sys.argv[2]}, handle, indent=2)
          PYINIT
            (
              cd "$PROJECT_ROOT"
              # Run clean in a separate Gradle invocation so it cannot be
              # reordered behind compile tasks in the requested task graph.
              gradle --no-daemon --no-build-cache --console=plain --stacktrace :app:clean
              gradle --no-daemon --no-build-cache --rerun-tasks --console=plain --stacktrace \
                :app:testDebugUnitTest :app:lintDebug :app:assembleDebug
            ) 2>&1 | tee "$MCM_LOG"
            test -s "$PROJECT_ROOT/app/build/outputs/apk/debug/app-debug.apk"
            python3 - "$GITHUB_WORKSPACE/build.json" "$MCM_LOG" <<'PYBUILD'
          import json, os, sys
          payload = {
              "build_succeeded": True,
              "project_type": "gradle",
              "successful_command": [
                  "gradle :app:clean", "&&",
                  "gradle :app:testDebugUnitTest :app:lintDebug :app:assembleDebug",
              ],
              "successful_commands": [
                  ["gradle", "--no-daemon", "--no-build-cache", "--console=plain", "--stacktrace", ":app:clean"],
                  ["gradle", "--no-daemon", "--no-build-cache", "--rerun-tasks", "--console=plain", "--stacktrace", ":app:testDebugUnitTest", ":app:lintDebug", ":app:assembleDebug"],
              ],
              "exit_code": 0,
              "log_file": sys.argv[2],
              "source_zip": os.environ.get("MCM_SOURCE_ZIP", ""),
              "source_sha256": os.environ.get("MCM_SOURCE_SHA256", ""),
              "source_id": "${{ steps.validate.outputs.source_id }}",
              "patch_id": "${{ steps.validate.outputs.patch_id }}",
          }
          with open(sys.argv[1], "w", encoding="utf-8") as handle:
              json.dump(payload, handle, indent=2)
          PYBUILD
            echo "build_succeeded=true" >> "$GITHUB_OUTPUT"
            echo "successful_command=gradle :app:clean ; gradle :app:testDebugUnitTest :app:lintDebug :app:assembleDebug" >> "$GITHUB_OUTPUT"
          else
            python3 "$GITHUB_WORKSPACE/scripts/build_project.py" \\
              --root "$PROJECT_ROOT" \\
              --detect "$GITHUB_WORKSPACE/detection.json" \\
              --toolchain "$GITHUB_WORKSPACE/toolchain.json" \\
              --variant "${{ inputs.build_variant || 'auto' }}" \\
              --log-dir "$GITHUB_WORKSPACE/.androidforge/logs" \\
              --output "$GITHUB_WORKSPACE/build.json"
          fi
          cat "$GITHUB_WORKSPACE/build.json"

      # ---------------------------------------------------------------------
      # Step 12: Collect APKs (only after a successful build)
      # ---------------------------------------------------------------------
      - name: Collect APKs
        id: collect
        if: steps.build.outcome == 'success'
        run: |
          set -euo pipefail
          PROJECT_ROOT="${{ steps.extract.outputs.project_root }}"
          if [ "${{ steps.validate.outputs.is_mcm }}" = "true" ]; then
            python3 "$GITHUB_WORKSPACE/scripts/collect_apk.py" \\
              --root "$PROJECT_ROOT" \\
              --variant debug \\
              --exact-apk "app/build/outputs/apk/debug/app-debug.apk" \\
              --expected-package "${{ steps.validate.outputs.expected_package }}" \\
              --expected-version-name "${{ steps.validate.outputs.expected_version_name }}" \\
              --expected-version-code "${{ steps.validate.outputs.expected_version_code }}" \\
              --expected-source-id "${{ steps.validate.outputs.source_id }}" \\
              --expected-patch-id "${{ steps.validate.outputs.patch_id }}" \\
              --expected-base-source-sha256 "${{ steps.validate.outputs.base_source_sha256 }}" \\
              --expected-source-zip-sha256 "${{ steps.validate.outputs.zip_sha256 }}" \\
              --build-started-epoch "${{ steps.provenance.outputs.build_started_epoch }}" \\
              --output-dir "$GITHUB_WORKSPACE/output" \\
              --output-json "$GITHUB_WORKSPACE/collect.json"
          else
            python3 "$GITHUB_WORKSPACE/scripts/collect_apk.py" \\
              --root "$PROJECT_ROOT" \\
              --variant "${{ inputs.build_variant || 'auto' }}" \\
              --output-dir "$GITHUB_WORKSPACE/output" \\
              --output-json "$GITHUB_WORKSPACE/collect.json"
          fi
          cat "$GITHUB_WORKSPACE/collect.json"

      # ---------------------------------------------------------------------
'''


def replace_once(content: str, old: str, new: str, label: str) -> str:
    count = content.count(old)
    if count != 1:
        raise RuntimeError(f"Cannot safely patch {label}: expected one anchor, found {count}")
    return content.replace(old, new, 1)


def disable_automatic_release_steps(content: str) -> str:
    """Hard-disable publishing commands/actions until the owner explicitly authorizes release."""
    lines = content.splitlines(keepends=True)
    starts = [index for index, line in enumerate(lines) if re.match(r"^      - (?:name|uses):", line)]
    release_markers = re.compile(
        r"(?:softprops/action-gh-release|actions/create-release|ncipollo/release-action|"
        r"marvinpinto/action-automatic-releases|gh\s+release\s+(?:create|upload)|"
        r"create[_-]release|publish[_-]release)",
        re.IGNORECASE,
    )
    for position, start in enumerate(starts):
        end = starts[position + 1] if position + 1 < len(starts) else len(lines)
        block = lines[start:end]
        step_name = block[0].strip().casefold()
        named_publish = "release" in step_name and any(word in step_name for word in ("publish", "create"))
        if not named_publish and not any(release_markers.search(line) for line in block):
            continue
        condition_index = next((i for i, line in enumerate(block) if re.match(r"^        if:\s*", line)), None)
        if condition_index is not None:
            block[condition_index] = "        if: false # Automatic release disabled; explicit owner authorization required\n"
        else:
            block.insert(1, "        if: false # Automatic release disabled; explicit owner authorization required\n")
        lines[start:end] = block
    return "".join(lines)


def patch_workflow(path: Path) -> None:
    content = path.read_text(encoding="utf-8")
    original = content

    # Add a project-profile selector while preserving existing inputs.
    zip_path_block = '''      zip_path:
        description: "Where should the workflow get the source ZIP from?"
        required: false
        type: string
        default: ""
'''
    # Current upstream description is longer, so use a bounded regex around zip_path.
    input_pattern = re.compile(
        r'(      zip_path:\n(?:        .*\n){4})(      zip_url:)', re.MULTILINE
    )
    matches = list(input_pattern.finditer(content))
    if len(matches) != 1:
        raise RuntimeError(f"Cannot safely add project_profile input: found {len(matches)} zip_path input blocks")
    match = matches[0]
    if "project_profile:" not in content:
        content = content[:match.end(1)] + PROJECT_PROFILE_INPUT + content[match.end(1):]

    # Make the zip_path description truthful: ambiguity now causes a hard failure.
    content = re.sub(
        r'(      zip_path:\n        description: )"[^"]*"',
        r'\1"Exact path relative to repository root, e.g. input/MCM_1.6.3_RECONCILED_DDNS_KOTLIN_SOURCE_DERIVED_PATCH_001.zip. Required for ambiguous input/."',
        content,
        count=1,
    )

    extract_anchor = '''      - name: Extract source ZIP
        id: extract
        run: python3 scripts/extract_zip.py --zip "${{ steps.acquire.outputs.zip_path }}"
'''
    if "      - name: Validate source identity" not in content:
        content = replace_once(content, extract_anchor, extract_anchor + "\n" + VALIDATE_STEP,
                               "source identity validation step")

    # MCM is preconfigured without self-heal or project-file mutation.
    toolchain_old = '''      - name: Configure toolchain
        id: toolchain
        run: |
          python3 scripts/setup_environment.py \\
            --root "${{ steps.extract.outputs.project_root }}" \\
            --detect detection.json \\
            --android-sdk "$ANDROID_HOME" \\
            --output toolchain.json
          echo "::group::Toolchain JSON"
          cat toolchain.json
          echo "::endgroup::"
'''
    if "configure_mcm_toolchain.py" not in content:
        content = replace_once(content, toolchain_old, TOOLCHAIN_STEP,
                               "MCM non-mutating toolchain configuration")

    self_heal_old = '''      - name: Self-heal project (auto-fix common issues)
        id: self_heal
        run: |
'''
    self_heal_new = '''      - name: Self-heal project (auto-fix common issues)
        id: self_heal
        if: steps.validate.outputs.is_mcm != 'true'
        run: |
'''
    if self_heal_new not in content:
        content = replace_once(content, self_heal_old, self_heal_new,
                               "skip self-heal for validated MCM source")

    # Replace build + collect in one bounded range, leaving Step 13 and later intact.
    start_marker = "      # Step 11: Build the project (writes build.json)"
    end_marker = "      # Step 13: Upload APK artifact"
    if "MCM uses a fixed native Gradle path" not in content:
        if content.count(start_marker) != 1 or content.count(end_marker) != 1:
            raise RuntimeError("Cannot safely replace build/collect block: expected upstream Step 11 and Step 13 markers")
        start = content.index(start_marker)
        end = content.index(end_marker)
        # Keep the separator line immediately preceding Step 13, to preserve the workflow's section style.
        prefix = content[:start]
        suffix = content[end:]
        content = prefix + PROVENANCE_STEP + "\n" + BUILD_AND_COLLECT_STEPS + suffix

    # Only publish an AAB when one was actually collected.
    aab_marker = "      - name: Upload AAB artifact"
    if aab_marker in content:
        pos = content.index(aab_marker)
        tail = content[pos:]
        tail = tail.replace(
            "if: steps.collect.outputs.apk_count != '0' && steps.collect.outputs.apk_count != ''",
            "if: steps.collect.outputs.aab_count != '0' && steps.collect.outputs.aab_count != ''",
            1,
        )
        content = content[:pos] + tail

    # Keep publication separate from build verification. No automatic release
    # step is permitted until the owner explicitly authorizes it.
    content = disable_automatic_release_steps(content)

    # A failed build must still run diagnosis and the final failure gate.
    content = content.replace(
        "        if: steps.build.outputs.build_succeeded != 'true'\n        run: |\n          python3 \"$GITHUB_WORKSPACE/scripts/diagnose_failure.py\"",
        "        if: always() && steps.build.outputs.build_succeeded != 'true'\n        run: |\n          python3 \"$GITHUB_WORKSPACE/scripts/diagnose_failure.py\"",
        1,
    )
    content = content.replace(
        "        if: steps.build.outputs.build_succeeded != 'true'\n        run: |\n          echo \"::error::Android build failed.",
        "        if: always() && steps.build.outputs.build_succeeded != 'true'\n        run: |\n          echo \"::error::Android build failed.",
        1,
    )

    if content.count("if: always() && steps.build.outputs.build_succeeded != 'true'") != 2:
        raise RuntimeError("Workflow failure diagnosis/final failure gates were not both patched")
    if content == original:
        raise RuntimeError("Workflow was already patched or no expected changes were applied")
    backup = path.with_suffix(path.suffix + ".bak")
    if not backup.exists():
        shutil.copy2(path, backup)
    path.write_text(content, encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workflow", default=".github/workflows/build-android.yml")
    args = parser.parse_args()
    path = Path(args.workflow)
    if not path.is_file():
        raise SystemExit(f"Workflow file not found: {path}")
    try:
        patch_workflow(path)
    except Exception as error:
        raise SystemExit(f"PATCH FAILED (no partial workflow write): {error}") from error
    print(f"Patched {path}; backup: {path}.bak")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
