# AndroidForge – MCM 1.6.3 Strict Build Repair Kit

## Mục tiêu

Khóa AndroidForge vào đúng source MCM 1.6.3; từ chối ZIP mơ hồ/không đúng hash; xác nhận project root Native Android Gradle trước build; kiểm tra toolchain cố định; không che lỗi; chỉ thu APK được tạo trong lần build hiện tại và có manifest đúng.

## Các gói source đi kèm

**Source gốc được giữ nguyên**
- File: `androidforge_patch/MCM_SOURCE/LOCKED_BASE/MCM_1.6.3_RECONCILED_DDNS_KOTLIN_SOURCE_NOT_RELEASE_FIXED-1.zip`
- SHA-256: `6313e1b28d2e7fa18fd56f20f8a4d91d6abf81a0027d1fe44e33e48a94ea1f0b`

**Source dẫn xuất đã áp patch**
- File: `input/MCM_1.6.3_RECONCILED_DDNS_KOTLIN_SOURCE_DERIVED_PATCH_001.zip`
- SHA-256: `6b2f810a430f69d172a81dedafb0f3729e1c5c6f3170db3367426e3c77a59f45`
- Source ID: `MCM-1.6.3-RECONCILED-001`
- Patch ID: `MCM-1.6.3-ANDROIDFORGE-HARDENED-001`
- Application ID: `com.multicloud.mcm`
- Version: `1.6.3` / versionCode `12`

Source dẫn xuất là source code, không phải APK và chưa được nghiệm thu bằng Gradle build.

## Kết quả kiểm tra cục bộ

- AndroidForge hardening tests: **19/19 PASS**.
- ZIP integrity, clean extraction, SHA/source/project identity validation: **PASS**.
- JavaScript/Python/shell syntax, Android XML, Room migration simulation v1→v6 và Mobile UI contract (3 input): **PASS**.
- Collector được kiểm tra bằng fixture APK để xác nhận logic; fixture không phải APK MCM.

## Toolchain cố định

JDK 17, Gradle 8.7, Android Gradle Plugin 8.6.1, Kotlin 2.0.21, Android SDK Platform 35. Môi trường thực hiện kiểm tra hiện chỉ có Java 21, không có Gradle 8.7 và Android SDK Platform 35/build-tools. Vì vậy chưa chạy được Kotlin/Gradle compile, Android unit-test task, lint hoặc `assembleDebug`; không có APK MCM 1.6.3 được tạo.

## Áp dụng vào repository AndroidForge

Repo AndroidForge thật chưa có trong workspace này nên patch chưa được áp dụng vào repo hoặc GitHub Actions thật. Khi có checkout repo:

1. Bảo đảm working tree sạch và đang ở branch/HEAD phù hợp; script không checkout hoặc sửa `main`.
2. Tại thư mục gốc repo, chạy `bash /path/to/kit/APPLY_TO_ANDROIDFORGE.sh`; Windows dùng `APPLY_TO_ANDROIDFORGE.ps1`.
3. Script tạo branch `fix/mcm-1.6.3-hardened-source-2026-11-23`, chép validator, tests, patcher và ZIP dẫn xuất, kiểm tra SHA, vá `.github/workflows/build-android.yml`, rồi chạy `git diff --check`.
4. Review toàn bộ diff trước khi tự quyết định commit/push. Script không push, merge hoặc release.
5. Chạy workflow với `project_profile=mcm-native`, `zip_source=input-directory`, `zip_path=input/MCM_1.6.3_RECONCILED_DDNS_KOTLIN_SOURCE_DERIVED_PATCH_001.zip`, `build_variant=debug`.

## Giới hạn nghiệm thu

Chưa chạy build Gradle thật, chưa cài APK lên thiết bị, chưa kiểm thử RouterOS 6/7 thực tế và chưa chạy GitHub Actions trên repo thật. **Trạng thái tổng thể: CHƯA NGHIỆM THU; không có APK bàn giao.**
