# Kết quả kiểm toán kỹ thuật — MCM 1.6.3 / AndroidForge

Ngày kiểm tra: 23/11/2026

## Đầu vào và provenance

Source ZIP gốc được giữ nguyên, SHA-256 `6313e1b28d2e7fa18fd56f20f8a4d91d6abf81a0027d1fe44e33e48a94ea1f0b`. Source dẫn xuất đã áp patch, SHA-256 `6b2f810a430f69d172a81dedafb0f3729e1c5c6f3170db3367426e3c77a59f45`. Source ID `MCM-1.6.3-RECONCILED-001`; Patch ID `MCM-1.6.3-ANDROIDFORGE-HARDENED-001`; package `com.multicloud.mcm`; version `1.6.3`; versionCode `12`. ZIP dẫn xuất được giải nén vào thư mục sạch và validator xác nhận đúng Native Android Gradle project với module `:app`.

## Đã thực hiện trên source dẫn xuất

- Tổ chức lại màn hình Thêm Router theo mobile-first: chỉ ba trường DDNS/Hostname, Username, Password; một nút chính “Lưu & Kết nối”; tùy chọn kỹ thuật/nhật ký đặt trong mục nâng cao.
- Tinh chỉnh bố cục responsive, màu sắc, khoảng cách, vùng chạm, safe-area và hiển thị trên màn hình hẹp.
- Bổ sung chuỗi Android DNS → Google DoH → Cloudflare DoH và truyền địa chỉ đã phân giải vào các nhánh kết nối/monitoring.
- Bổ sung probing REST HTTPS 443 và API-SSL 8729 song song; xác thực và READ_CHECK theo từng nhánh; chọn REST khi cả hai nhánh cùng thành công.
- Bổ sung luồng xác nhận TLS fingerprint lần đầu/thay đổi; không tự ghi đè fingerprint đã pin.
- Bổ sung lưu credential mã hóa bằng Android Keystore, profile nhiều Router, chuẩn hóa hostname khi tìm profile, log kết nối theo profile và Room migration lên schema v6.
- Đồng bộ đường monitoring nền/foreground; bỏ qua monitoring khi profile ở `READY_LIMITED`.
- Xử lý phân loại lỗi đăng nhập RouterOS API để tách auth rejection khỏi legacy-login fallback.

## Đã thực hiện trên AndroidForge patch kit

- ZIP selection fail-closed; không tự chọn ZIP đầu tiên khi có nhiều file.
- Hash và source identity gate; xác nhận project root Native Android, Gradle settings, module `:app` và toolchain.
- Khóa toolchain JDK 17 / Gradle 8.7 / AGP 8.6.1 / Kotlin 2.0.21 / SDK 35.
- Workflow MCM chạy clean → unit tests → lint → assembleDebug, không bỏ qua lỗi; collector chỉ chạy sau build success và xác minh manifest/provenance APK.
- Vô hiệu hóa bước tự động tạo/publish GitHub Release trong patch; không tự push/merge/release.
- Có apply script cho Linux/macOS và Windows; tạo branch mới từ HEAD hiện tại, yêu cầu working tree sạch, không checkout `main`.

## Kiểm tra đã chạy và kết quả

- AndroidForge hardening unit tests: **19/19 PASS**.
- ZIP integrity và clean extraction: **PASS**.
- SHA-256 source dẫn xuất, source ID, package/version và Native Gradle `:app` validation: **PASS**.
- JavaScript, Python và shell syntax; Android XML: **PASS**.
- Room SQL migration preservation simulation v1→v6: **PASS**.
- Mobile DDNS UI contract: **PASS** (72 unique IDs, đúng 3 input).
- `RouterOsApiCodec.kt` đã được compile riêng bằng Kotlin compiler 1.9.0 có sẵn; đây không phải Gradle project compile và không thay thế kiểm tra bằng Kotlin 2.0.21.
- APK collector test dùng fixture APK và mocked manifest để kiểm thử gate; không phải APK MCM, không chứng minh APK Android thực.

## Chưa thể kết luận / giới hạn

Môi trường chỉ có OpenJDK 21; không có JDK 17, Gradle 8.7 hoặc Android SDK Platform 35/build-tools. Do đó chưa chạy Gradle/Kotlin project compile, Android unit-test task, lint, `assembleDebug`, xác minh manifest của APK thật hoặc cài ứng dụng lên điện thoại. Không có APK MCM 1.6.3 được tạo.

Repo AndroidForge thật chưa được cung cấp trong workspace nên patch chưa được áp dụng vào repo thật và chưa có GitHub Actions run thật. Apply script chỉ được syntax-check, chưa chạy trên repo AndroidForge thực tế. Chưa kiểm thử thiết bị Android và RouterOS 6/7 thực; không có thay đổi nào được gửi tới Router thật.

**Kết luận: source dẫn xuất và công cụ hardening đã được sửa, đóng gói và kiểm tra tĩnh/unit-test cục bộ; toàn bộ dự án vẫn CHƯA NGHIỆM THU. Không có APK bàn giao.**
