# MCM 1.6.3 — candidate 008 build and acceptance status

Current source identity: `MCM-1.6.3-SSH-RECONCILED-008`  
Known-good parent: `MCM-1.6.3-DDNS-RECONCILED-007`  
Parent build status: user-confirmed APK build success on AndroidForge  
Application ID: `com.multicloud.mcm`  
Version: `1.6.3` (`versionCode=12`)  
Room schema: `9`

## Baseline preservation

- Candidate 008 is derived from the user-confirmed 007 source baseline.
- Existing REST HTTPS, API-SSL, TLS verification, independent TLS pins, DNS fallback, read-only boundaries, monitoring, history and UI are retained.
- No WinBox protocol, Telnet, MAC-Telnet, VPN, relay or router configuration writes are introduced.
- 007 remains the last user-confirmed successful APK build. Candidate 008 is not represented as already built.

## Candidate 008 changes

- Adds explicit SSH v2 transport using the maintained `com.github.mwiede:jsch` Java SSH2 client and Bouncy Castle provider support for Android Ed25519/XDH compatibility.
- Adds first-use SSH host-key capture with `PreferredAuthentications=none`; no password is sent before the host-key fingerprint is explicitly confirmed.
- SSH candidate uses password authentication only; SSH private-key login is not implemented. The RouterOS monitoring account needs `ssh,read`. RouterOS may refuse password login when a public key is already assigned to that user under `yes-if-no-key`.
- Adds independent SSH SHA-256 host-key pin, exact endpoint port and confirmation timestamp in Room v9.
- Rejects SSH host-key mismatch before password authentication.
- Adds a non-PTY SSH exec-channel RouterOS CLI adapter with a fixed read-only `print` allowlist, 12-second command timeout, 1.5 MB combined output cap and 10,000-row table cap.
- SSH negotiation is limited to Ed25519/RSA-SHA2, Curve25519/ECDH/group14-SHA256, AES-GCM/CTR and HMAC-SHA2; no weak-algorithm downgrade.
- Adds SSH foreground/background resource and monitoring collection with sequential commands on one session.
- Keeps AUTO behavior unchanged; SSH is explicit and is not an automatic insecure fallback.
- Adds research notes comparing RouterOS SSH, tik4net, JSch, SNMPv3 and excluded transports.

## Verification state

- AndroidForge source preflight and `scripts/verify-source.sh` static gate: PASS.
- JavaScript syntax, Python syntax, Android XML parsing: PASS.
- Mobile UI contract: PASS (75 unique IDs, 58 JS literal lookups, 3 primary inputs).
- Room v1→v9 migration simulation: PASS; existing profiles/history preserved and SSH pins stored separately.
- Historical build regression guards: PASS (22 assertions).
- Kotlin/JVM source smoke: PASS (48 assertions).
- SSH CLI parser smoke: PASS (8 assertions); SSH fingerprint/normalization smoke: PASS (5 assertions); SSH read-only policy smoke: PASS (6 assertions).
- SSH transport/repository/coordinator compile against API-compatible JSch and local dependency stubs: PASS; this is not a real Gradle dependency compile.
- Android Gradle compile / KAPT / JUnit / lint: NOT RUN.
- Debug APK / Release APK / AAB: NOT RUN.
- Live RouterOS 6 and RouterOS 7 SSH handshake, host-key pin and CLI parser: NOT RUN.
- No candidate 008 build-success claim is made.

## Required release gate

Run `scripts/androidforge-preflight.sh`, `scripts/verify-source.sh`, `:app:testDebugUnitTest`, `:app:lintDebug`, `:app:assembleDebug`, `:app:assembleRelease` and `:app:bundleRelease` on the same AndroidForge toolchain that built 007. Then test SSH host-key first-use, mismatch, password rejection, RouterOS 6/7 command output and read-only enforcement on authorized routers. Do not replace the 007 baseline APK until all gates pass.
