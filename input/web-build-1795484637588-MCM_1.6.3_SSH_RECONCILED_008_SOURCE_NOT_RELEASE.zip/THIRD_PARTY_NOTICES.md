# Third-party notices for candidate 008

- `com.github.mwiede:jsch:2.28.8` — pure Java SSH2 implementation, Revised BSD license (plus bundled zlib and jBCrypt notices as published by the project). Source/license: https://github.com/mwiede/jsch
- `org.bouncycastle:bcprov-jdk18on:1.86` — Bouncy Castle cryptography provider, Bouncy Castle License. Source/license: https://www.bouncycastle.org/licence.html

These libraries are used only by the native SSH transport. The app keeps SSH host-key pinning and read-only command enforcement in its own code; the dependency does not decide whether a host key is trusted or which RouterOS commands may be sent.
