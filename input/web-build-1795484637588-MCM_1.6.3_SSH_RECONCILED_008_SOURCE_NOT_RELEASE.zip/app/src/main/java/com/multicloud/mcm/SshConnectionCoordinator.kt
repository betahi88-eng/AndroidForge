package com.multicloud.mcm

import com.multicloud.mcm.data.McmDatabase
import com.multicloud.mcm.data.RouterEntity
import com.multicloud.mcm.security.SecureCredentialStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.jcraft.jsch.JSchException
import java.net.ConnectException
import java.net.SocketTimeoutException
import org.json.JSONObject
import java.net.InetAddress
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** First-use SSH host-key trust and read-only RouterOS authentication flow. */
internal class SshConnectionCoordinator(
    private val database: McmDatabase,
    private val credentials: SecureCredentialStore
) {
    private val profiles = McmRouterProfileService(database, credentials)
    private val pending = ConcurrentHashMap<String, PendingSshAttempt>()

    suspend fun start(rawHost: String, username: String, password: String, requestedPort: Int): JSONObject = withContext(Dispatchers.IO) {
        val started = System.currentTimeMillis()
        pending.entries.removeIf { started - it.value.startedAt > PENDING_TTL_MS }
        val host = RouterHostValidator.normalize(rawHost)
        require(username.isNotBlank() && password.isNotEmpty()) { "Username và password không được để trống." }
        require(requestedPort == 0 || requestedPort in 1..65535) { "Port không hợp lệ." }
        val port = requestedPort.takeIf { it > 0 } ?: 22
        val existing = profiles.findByHost(host)
        val resolution = try {
            RouterDnsResolver.resolveDetailed(host)
        } catch (error: Exception) {
            return@withContext failure("DNS_FAILED", "Không phân giải được hostname: ${error.message.orEmpty()}")
        }
        val fingerprint = try {
            SshRouterOsClient.inspectHostKey(host, port, username, resolution.addresses)
        } catch (error: Exception) {
            var root: Throwable = error
            while (root.cause != null && root.cause !== root) root = root.cause!!
            val code = when {
                root is SocketTimeoutException -> "NETWORK_TIMEOUT"
                root is ConnectException -> "CONNECT_REFUSED"
                root is JSchException && root.message.orEmpty().contains("algorithm negotiation", true) -> "SSH_ALGORITHM_UNSUPPORTED"
                else -> "SSH_HANDSHAKE_FAILED"
            }
            return@withContext failure(code, "Không hoàn tất được SSH handshake: ${root.message.orEmpty()}")
        }
        val oldPin = existing?.sshHostKeySha256Pin?.takeIf { existing.sshPinPort == port }
        if (oldPin != null && oldPin.equals(fingerprint, true)) {
            return@withContext authenticateAndSave(host, port, username, password, fingerprint, resolution.addresses, resolution.source, existing, started)
        }
        val attempt = PendingSshAttempt(
            id = UUID.randomUUID().toString(), host = host, port = port, username = username,
            password = password, fingerprint = fingerprint, oldPin = oldPin,
            addresses = resolution.addresses, dnsResolver = resolution.source,
            existing = existing, startedAt = started
        )
        pending[attempt.id] = attempt
        JSONObject()
            .put("ok", false)
            .put("state", if (oldPin == null) "FIRST_TIME_PIN" else "SSH_HOSTKEY_CHANGED")
            .put("attemptId", attempt.id)
            .put("host", host)
            .put("port", port)
            .put("protocol", "SSH")
            .put("fingerprint", fingerprint)
            .put("oldFingerprint", oldPin ?: JSONObject.NULL)
            .put("newFingerprint", fingerprint)
            .put("message", if (oldPin == null)
                "Đối chiếu SHA-256 với /ip/ssh/print → host-key-fingerprint (nếu phiên bản có hiển thị) qua kênh tin cậy; MCM chưa gửi mật khẩu."
            else "SSH host key đã thay đổi; đối chiếu lại fingerprint với /ip/ssh/print hoặc public host key đã xuất trước khi cập nhật.")
            .put("diagnostics", JSONObject()
                .put("stage", "SSH_HOST_KEY")
                .put("host", host)
                .put("port", port)
                .put("resolvedIps", org.json.JSONArray().apply { resolution.addresses.forEach { put(it.hostAddress) } })
                .put("dnsResolver", resolution.source))
    }

    fun hasPending(attemptId: String): Boolean = pending.containsKey(attemptId)

    suspend fun confirm(attemptId: String, decision: String): JSONObject {
        val attempt = pending.remove(attemptId)
            ?: return failure("ATTEMPT_EXPIRED", "Yêu cầu xác nhận SSH đã hết hạn.")
        if (System.currentTimeMillis() - attempt.startedAt > PENDING_TTL_MS) {
            return failure("ATTEMPT_EXPIRED", "Yêu cầu xác nhận SSH đã hết hạn; hãy kết nối lại.")
        }
        if (!decision.equals("TRUST", true)) return JSONObject().put("ok", false).put("state", "CANCELLED")
        return authenticateAndSave(
            attempt.host, attempt.port, attempt.username, attempt.password,
            attempt.fingerprint, attempt.addresses, attempt.dnsResolver, attempt.existing, attempt.startedAt
        )
    }

    fun cancel(attemptId: String): JSONObject {
        pending.remove(attemptId)
        return JSONObject().put("ok", true).put("state", "CANCELLED")
    }

    private suspend fun authenticateAndSave(
        host: String,
        port: Int,
        username: String,
        password: String,
        fingerprint: String,
        addresses: List<InetAddress>,
        dnsResolver: String,
        existing: RouterEntity?,
        startedAt: Long
    ): JSONObject {
        val client = SshRouterOsClient(host, port, username, password, fingerprint, addresses)
        try {
            when (val connected = client.connect()) {
                is McmResult.Failure -> return failure(
                    if (connected.code == "AUTH") "AUTH_FAILED" else connected.code,
                    if (connected.code == "AUTH") "RouterOS từ chối password (có thể sai mật khẩu hoặc user đã gán SSH public key với yes-if-no-key); MCM 008 hiện chưa hỗ trợ private-key login."
                    else connected.message
                )
                is McmResult.Success -> Unit
            }
            val resource = when (val read = client.readSystemResource()) {
                is McmResult.Failure -> return failure(read.code, read.message)
                is McmResult.Success -> read.value
            }
            val major = resource.version?.substringBefore('.')?.toIntOrNull()
                ?.takeIf { it == 6 || it == 7 }
                ?: return failure("ROUTEROS_VERSION_UNSUPPORTED", "Không xác định được RouterOS 6/7 từ phản hồi đã xác thực.")
            val payload = JSONObject()
                .put("name", existing?.name ?: host.take(64))
                .put("siteName", existing?.siteName ?: "Mặc định")
                .put("host", host)
                .put("port", port)
                .put("routerOsMajor", major)
                .put("routerOsVersion", resource.version)
                .put("username", username)
                .put("password", password)
                .put("connectionMode", "SSH")
                .put("activeTransport", "SSH")
                .put("tlsSha256Pin", "")
                .put("sshHostKeySha256Pin", fingerprint)
                .put("sshPinPort", port)
                .put("sshPinConfirmed", true)
                .put("lastStatus", "READY")
                .put("accessLevel", "READ_ONLY")
                .put("lastResolvedIp", addresses.firstOrNull()?.hostAddress ?: "")
                .put("dnsResolver", dnsResolver)
                .put("lastConnectionLatencyMs", System.currentTimeMillis() - startedAt)
            if (existing != null) payload.put("id", existing.id)
            val id = profiles.saveRouter(payload.toString())
            return JSONObject()
                .put("ok", true).put("state", "READY")
                .put("id", id).put("host", host).put("port", port)
                .put("protocol", "SSH").put("activeTransport", "SSH")
                .put("connectionMode", "SSH")
                .put("routerOsVersion", resource.version)
                .put("latencyMs", System.currentTimeMillis() - startedAt)
                .put("dnsResolver", dnsResolver)
                .put("resolvedIp", addresses.firstOrNull()?.hostAddress ?: JSONObject.NULL)
                .put("message", "SSH xác thực thành công; đã đọc được system/resource.")
        } finally {
            client.close()
        }
    }

    private companion object { const val PENDING_TTL_MS = 180_000L }

    private fun failure(code: String, message: String) = JSONObject()
        .put("ok", false).put("state", code).put("errorCode", code).put("message", message.take(240))

    private data class PendingSshAttempt(
        val id: String,
        val host: String,
        val port: Int,
        val username: String,
        val password: String,
        val fingerprint: String,
        val oldPin: String?,
        val addresses: List<InetAddress>,
        val dnsResolver: String,
        val existing: RouterEntity?,
        val startedAt: Long
    )
}
