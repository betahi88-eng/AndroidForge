#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
required=(settings.gradle.kts build.gradle.kts gradle.properties app/build.gradle.kts app/src/main/AndroidManifest.xml SOURCE_IDENTITY.txt app/src/main/java/com/multicloud/mcm/RouterOs7InterfaceParser.kt app/src/test/java/com/multicloud/mcm/RouterOs7RepositoryTest.kt)
for file in "${required[@]}"; do
  test -s "$file" || { echo "FAIL: missing required source file: $file" >&2; exit 1; }
done
test -d app/src/main/assets/www
test ! -e pubspec.yaml
test ! -e harmony_patched
grep -Fq 'MCM_SOURCE_ID=MCM-1.6.3-DDNS-RECONCILED-004' SOURCE_IDENTITY.txt
grep -Fq 'rootProject.name = "MikroTikMultiCloudMonitor"' settings.gradle.kts
grep -Fq 'id("com.android.application") version "8.6.1"' build.gradle.kts
grep -Fq 'id("org.jetbrains.kotlin.android") version "2.0.21"' build.gradle.kts
grep -Fq 'applicationId = "com.multicloud.mcm"' app/build.gradle.kts
grep -Fq 'compileSdk = 35' app/build.gradle.kts
grep -Fq 'versionName = "1.6.3"' app/build.gradle.kts
grep -Fq 'versionCode = 12' app/build.gradle.kts
grep -Fq 'readNonBlankString("type") ?: ""' app/src/main/java/com/multicloud/mcm/RouterOs7InterfaceParser.kt
sha256sum app/src/main/java/com/multicloud/mcm/RouterOs7Repository.kt app/src/main/java/com/multicloud/mcm/RouterOs7InterfaceParser.kt app/src/main/java/com/multicloud/mcm/RouterDnsResolver.kt
echo 'AndroidForge preflight PASS: MCM 1.6.3 native Android Gradle/Kotlin source identity verified.'
echo 'Expected project: MikroTikMultiCloudMonitor / com.multicloud.mcm / versionCode 12.'
