#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

for required in settings.gradle.kts build.gradle.kts app/build.gradle.kts app/src/main/AndroidManifest.xml; do
  test -s "$required" || { echo "Missing required Android project file: $required" >&2; exit 1; }
done
test -d app/src/main/java/com/multicloud/mcm
test ! -e pubspec.yaml
test ! -e harmony_patched
test -s app/src/test/java/com/multicloud/mcm/RouterOs7RepositoryTest.kt
test -s SOURCE_IDENTITY.txt
grep -q 'MCM_SOURCE_ID=MCM-1.6.3-DDNS-RECONCILED-004' SOURCE_IDENTITY.txt
grep -q 'versionCode = 12' app/build.gradle.kts
grep -q 'readNonBlankString("type") ?: ""' app/src/main/java/com/multicloud/mcm/RouterOs7InterfaceParser.kt
grep -q 'applicationId = "com.multicloud.mcm"' app/build.gradle.kts
grep -q 'versionName = "1.6.3"' app/build.gradle.kts
grep -q 'rootProject.name = "MikroTikMultiCloudMonitor"' settings.gradle.kts
grep -q 'connectionCoordinator.start(host, username, password, port, connectionMode)' app/src/main/java/com/multicloud/mcm/McmJavascriptBridge.kt
grep -q 'serviceMode.probePorts(requestedPort)' app/src/main/java/com/multicloud/mcm/RouterConnectionCoordinator.kt
grep -q 'val selectedPort = successful.port' app/src/main/java/com/multicloud/mcm/RouterConnectionCoordinator.kt
if grep -q 'selected\.port' app/src/main/java/com/multicloud/mcm/RouterConnectionCoordinator.kt; then
  echo 'Coordinator contains unresolved enum port access; use the authenticated branch port.' >&2
  exit 1
fi
grep -q 'attempt.host, probe.port' app/src/main/java/com/multicloud/mcm/RouterConnectionCoordinator.kt
grep -q 'router.host, router.port' app/src/main/java/com/multicloud/mcm/McmMonitoringService.kt
grep -q 'router.host, router.port' app/src/main/java/com/multicloud/mcm/McmBackgroundWorker.kt
grep -q 'hostnameVerifier(PinnedTlsHostnameVerifier)' app/src/main/java/com/multicloud/mcm/RouterOs7Client.kt
grep -q 'Sha256PinnedTrustManager' app/src/main/java/com/multicloud/mcm/RouterOs7Client.kt
grep -q 'Sha256PinnedTrustManager' app/src/main/java/com/multicloud/mcm/routeros/RouterOs6ApiClient.kt
! grep -q 'verifyPeerIdentity' app/src/main/java/com/multicloud/mcm/security/TlsFingerprintInspector.kt
! grep -q 'verifyPeerIdentity' app/src/main/java/com/multicloud/mcm/routeros/RouterOs6ApiClient.kt
grep -q 'selectAuthenticatedTransport' app/src/main/java/com/multicloud/mcm/RouterConnectionCoordinator.kt
grep -q 'put("activeTransport", selected.name)' app/src/main/java/com/multicloud/mcm/RouterConnectionCoordinator.kt
grep -q 'resolveForProfile(router.routerOsMajor, router.activeTransport)' app/src/main/java/com/multicloud/mcm/McmMonitoringService.kt
grep -q 'resolveForProfile(router.routerOsMajor, router.activeTransport)' app/src/main/java/com/multicloud/mcm/McmBackgroundWorker.kt
grep -q 'MIGRATION_6_7' app/src/main/java/com/multicloud/mcm/data/McmDatabase.kt
grep -q 'RouterOsApiCodec.legacyChallenge(reply)' app/src/main/java/com/multicloud/mcm/routeros/RouterOs6ApiClient.kt
test -s app/src/test/java/com/multicloud/mcm/PinnedTlsPolicyTest.kt
test -s app/src/test/java/com/multicloud/mcm/RouterServiceModeTest.kt

command -v node >/dev/null || { echo "Node.js is required for UI syntax checks." >&2; exit 1; }
command -v python3 >/dev/null || { echo "Python 3 is required for mock syntax checks." >&2; exit 1; }
command -v bash >/dev/null

while IFS= read -r -d '' file; do node --check "$file"; done < <(find app/src/main/assets/www -type f -name '*.js' -print0)
python3 -m py_compile tools/*.py scripts/verify-room-migrations.py scripts/verify-ui-contract.py
python3 scripts/verify-room-migrations.py
python3 scripts/verify-ui-contract.py
python3 - <<'PYXML'
import xml.etree.ElementTree as ET
ET.parse('app/src/main/AndroidManifest.xml')
ET.parse('app/src/main/res/values/styles.xml')
ET.parse('app/src/main/res/xml/network_security_config.xml')
print('Android XML: PASS')
PYXML
while IFS= read -r -d '' file; do bash -n "$file"; done < <(find scripts -type f -name '*.sh' -print0)
echo "Static source checks passed (project identity, JavaScript, Python, shell and Android XML)."

SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [[ "${MCM_SKIP_GRADLE:-0}" != "1" ]] && command -v gradle >/dev/null && [[ -n "$SDK_ROOT" && -f "$SDK_ROOT/platforms/android-35/android.jar" ]]; then
  gradle --no-daemon :app:testDebugUnitTest :app:lintDebug :app:assembleDebug
else
  echo "Android Gradle tests/lint/APK build SKIPPED: Gradle 8.7 and Android SDK Platform 35 are both required."
fi
