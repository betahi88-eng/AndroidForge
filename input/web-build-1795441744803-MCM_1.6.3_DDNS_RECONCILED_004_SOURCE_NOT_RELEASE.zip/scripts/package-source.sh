#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${1:-$(dirname "$ROOT")/MCM_1.6.3_DDNS_RECONCILED_004_SOURCE_NOT_RELEASE.zip}"
case "$OUT" in
  /*) ;;
  *) OUT="$PWD/$OUT" ;;
esac
case "$OUT" in
  "$ROOT"/*) echo "Choose an archive destination outside the source tree." >&2; exit 1 ;;
esac

bash "$ROOT/scripts/androidforge-preflight.sh"
bash "$ROOT/scripts/verify-source.sh"
mkdir -p "$(dirname "$OUT")"
rm -f "$OUT"
cd "$ROOT"
zip -qr "$OUT" . \
  -x '.git/*' '.gradle/*' '*/build/*' 'build/*' 'local.properties' \
     '*/__pycache__/*' '*.pyc' '*.apk' '*.aab' '*.jks' '*.keystore' \
     '*.pem' '*.key' '*.crt' '*.cer' '*.der' '*.p12' '*.pfx' '*.db' '*.sqlite' '*.sqlite3' '*.log' '.env' '.env.*' 'secrets.properties' '.mcm-test-cert/*'
unzip -t "$OUT" >/dev/null

# AndroidForge detects the project root from these files. They must be at ZIP root.
ARCHIVE_ENTRIES="$(unzip -Z1 "$OUT")"
for entry in settings.gradle.kts build.gradle.kts app/build.gradle.kts app/src/main/AndroidManifest.xml; do
  if ! printf '%s\n' "$ARCHIVE_ENTRIES" | grep -Fx -- "$entry" >/dev/null; then
    echo "Archive root validation failed: missing $entry" >&2
    exit 1
  fi
done
if printf '%s\n' "$ARCHIVE_ENTRIES" | grep -E '(^|/)(pubspec\.yaml|harmony_patched)(/|$)' >/dev/null; then
  echo "Archive contains Flutter project markers; refusing to package." >&2
  exit 1
fi

echo "Source archive: $OUT"
sha256sum "$OUT"
