package com.multicloud.mcm

import com.multicloud.mcm.routeros.RouterOsApiCodec
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RouterOsApiCodecTest {
    @Test fun recognizesModernLoginCredentialRejection() {
        assertTrue(RouterOsApiCodec.isCredentialRejected(listOf("!trap", "=message=invalid user name or password (6)")))
        assertTrue(RouterOsApiCodec.isCredentialRejected(listOf("!fatal", "=message=login failure")))
    }

    @Test fun doesNotTreatLegacyLoginSyntaxTrapAsBadPassword() {
        assertFalse(RouterOsApiCodec.isCredentialRejected(listOf("!trap", "=message=unknown parameter name")))
        assertFalse(RouterOsApiCodec.isCredentialRejected(listOf("!done", "=ret=1234")))
    }

    @Test fun extractsLegacyChallengeReturnedWithDone() {
        assertEquals("93b438ec9b80057c06dd9fe67d56aa9a", RouterOsApiCodec.legacyChallenge(
            listOf("!done", "=ret=93b438ec9b80057c06dd9fe67d56aa9a")
        ))
        assertNull(RouterOsApiCodec.legacyChallenge(listOf("!done")))
        assertNull(RouterOsApiCodec.legacyChallenge(listOf("!done", "=ret=not-hex")))
    }
}
