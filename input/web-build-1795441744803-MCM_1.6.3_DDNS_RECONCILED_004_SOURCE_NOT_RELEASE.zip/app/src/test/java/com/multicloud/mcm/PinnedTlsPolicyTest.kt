package com.multicloud.mcm

import com.multicloud.mcm.security.PinnedTlsHostnameVerifier
import com.multicloud.mcm.security.Sha256PinnedTrustManager
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate

class PinnedTlsPolicyTest {
    private fun fixture(): X509Certificate = javaClass.getResourceAsStream("/tls/routeros-selfsigned-cn-mismatch.fixture")!!.use {
        CertificateFactory.getInstance("X.509").generateCertificate(it) as X509Certificate
    }

    @Test fun acceptsSelfSignedCertificateOnlyWhenItsExactSha256PinMatches() {
        val certificate = fixture()
        val pin = RouterOs7Client.sha256(certificate.encoded)
        Sha256PinnedTrustManager(pin).checkServerTrusted(arrayOf(certificate), "RSA")
        assertThrows(java.security.cert.CertificateException::class.java) {
            Sha256PinnedTrustManager("00".repeat(32)).checkServerTrusted(arrayOf(certificate), "RSA")
        }
    }

    @Test fun exactPinStillRequiresCertificateValidityWindow() {
        val certificate = fixture()
        certificate.checkValidity()
        Sha256PinnedTrustManager(RouterOs7Client.sha256(certificate.encoded))
            .checkServerTrusted(arrayOf(certificate), "RSA")
    }

    @Test fun pinnedEndpointDoesNotRequireSelfSignedCertificateCnToEqualDdns() {
        val certificate = fixture()
        assertTrue(certificate.subjectX500Principal.name.contains("router-local-only"))
        assertTrue(PinnedTlsHostnameVerifier.verify("example.sn.mynetname.net", null))
    }
}
