package com.multicloud.mcm

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.multicloud.mcm.data.McmDatabase
import com.multicloud.mcm.data.MetricHistoryEntity
import com.multicloud.mcm.security.SecureCredentialStore
import com.multicloud.mcm.routeros.RouterOs6ApiClient
import com.multicloud.mcm.routeros.RouterOs6Repository
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.CancellationException
import androidx.room.Room

/** Best-effort background health samples. WorkManager's periodic minimum interval is 15 minutes. */
class McmBackgroundWorker(context: Context, parameters: WorkerParameters) : CoroutineWorker(context, parameters) {
    override suspend fun doWork(): Result = withTimeout(10 * 60 * 1_000L) {
        val database = Room.databaseBuilder(applicationContext, McmDatabase::class.java, "mcm.db")
            .addMigrations(*McmDatabase.ALL_MIGRATIONS)
            .build()
        val credentials = SecureCredentialStore(applicationContext)
        try {
            val routers = database.routerDao().getAll()
            routers.forEach { router ->
                // Limited profiles are authenticated but do not authorize monitoring reads.
                // Keep READY_LIMITED intact; do not mark them OFFLINE from a forbidden query.
                if (router.accessLevel == "LIMITED") return@forEach
                val now = System.currentTimeMillis()
                try {
                    val password = credentials.get(router.credentialAlias)
                        ?: throw IllegalStateException("CREDENTIAL_UNAVAILABLE: Không tìm thấy mật khẩu đã mã hóa.")
                    val resolution = RouterDnsResolver.resolveDetailed(router.host)
                    val selectedTransport = RouterServiceMode.fromStorage(router.connectionMode).resolveForProfile(router.routerOsMajor, router.activeTransport)
                    val resource = if (selectedTransport == RouterTransport.REST_HTTPS) {
                        RouterOs7Repository(
                            RouterOs7Client(
                                router.host, router.port, router.username, password, router.tlsSha256Pin,
                                resolvedAddresses = resolution.addresses
                            )
                        ).readSystemResource()
                    } else {
                        RouterOs6Repository(
                            RouterOs6ApiClient(
                                router.host, router.port, router.username, password, router.tlsSha256Pin,
                                resolvedAddresses = resolution.addresses
                            )
                        ).readSystemResource()
                    }
                    when (resource) {
                        is McmResult.Success -> {
                            val values = resource.value
                            database.routerDao().upsert(router.copy(
                                lastSeenAtEpochMs = now, lastStatus = "ONLINE", lastErrorCode = null,
                                lastErrorMessage = null, lastCheckedAtEpochMs = now,
                                lastResolvedIp = resolution.addresses.firstOrNull()?.hostAddress ?: router.lastResolvedIp,
                                dnsResolver = resolution.source,
                                routerOsVersion = values.version ?: router.routerOsVersion
                            ))
                            values.cpuLoadPercent?.let {
                                database.metricDao().insert(MetricHistoryEntity(routerId = router.id, metricKey = "cpu_load", value = it.toDouble(), unit = "%", recordedAtEpochMs = now))
                            }
                            if (values.freeMemoryBytes != null && values.totalMemoryBytes != null && values.totalMemoryBytes > 0) {
                                val used = 100.0 * (values.totalMemoryBytes - values.freeMemoryBytes).coerceAtLeast(0) / values.totalMemoryBytes.toDouble()
                                database.metricDao().insert(MetricHistoryEntity(routerId = router.id, metricKey = "memory_used", value = used, unit = "%", recordedAtEpochMs = now))
                            }
                        }
                        is McmResult.Failure -> database.routerDao().upsert(router.copy(
                            lastStatus = "OFFLINE", lastErrorCode = resource.code,
                            lastErrorMessage = resource.message.take(240), lastCheckedAtEpochMs = now
                        ))
                    }
                } catch (error: Exception) {
                    val message = error.message ?: "Không rõ lỗi nền"
                    val code = message.substringBefore(':').takeIf { it.matches(Regex("[A-Z0-9_]{2,48}")) } ?: "BACKGROUND_FAILED"
                    database.routerDao().upsert(router.copy(
                        lastStatus = "OFFLINE", lastErrorCode = code,
                        lastErrorMessage = message.take(240), lastCheckedAtEpochMs = now
                    ))
                }
            }
            database.metricDao().deleteBefore(System.currentTimeMillis() - 30L * 24L * 60L * 60L * 1_000L)
            Result.success()
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            Result.retry()
        } finally {
            database.close()
        }
    }
}
