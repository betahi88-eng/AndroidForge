package com.multicloud.mcm.security

import java.security.MessageDigest
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.SSLSession
import javax.net.ssl.X509TrustManager

/** Trusts exactly one leaf certificate identified by an independently confirmed SHA-256 pin. */
internal class Sha256PinnedTrustManager(expectedPinHex: String) : X509TrustManager {
    private val expectedPin = expectedPinHex.replace(Regex("[:\\s]"), "").uppercase().also {
        require(it.matches(Regex("[A-F0-9]{64}"))) { "Invalid SHA-256 certificate pin" }
    }

    override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()

    override fun checkClientTrusted(chain: Array<out X509Certificate>, authType: String) {
        throw CertificateException("Client certificate authentication is not supported")
    }

    override fun checkServerTrusted(chain: Array<out X509Certificate>, authType: String) {
        val leaf = chain.firstOrNull() ?: throw CertificateException("Router sent no TLS certificate")
        // Pinning authenticates the exact certificate, but it must not silently waive its validity window.
        leaf.checkValidity()
        val actual = MessageDigest.getInstance("SHA-256").digest(leaf.encoded)
            .joinToString("") { "%02X".format(it.toInt() and 0xFF) }
        if (!MessageDigest.isEqual(actual.toByteArray(), expectedPin.toByteArray())) {
            throw CertificateException("Router TLS certificate fingerprint mismatch")
        }
    }
}

/**
 * Must only be paired with Sha256PinnedTrustManager. The exact certificate pin, not a public
 * CA/hostname match, authenticates this self-managed RouterOS endpoint. DDNS is still used for SNI.
 */
internal object PinnedTlsHostnameVerifier : HostnameVerifier {
    override fun verify(hostname: String?, session: SSLSession?): Boolean = true
}
