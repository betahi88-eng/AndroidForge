# MCM 1.6.3 — Build status and acceptance boundary

Source identity: `MCM-1.6.3-DDNS-RECONCILED-004`  
Integration patch: `MCM-1.6.3-DDNS-RECONCILED-004`  
Parent source: `AndroidForge_MCM_1.6.3_SAMPLE_PROJECT_BUILD_FIX_002.zip`  
Parent SHA-256: `7e5872d18df840f7367de787d7f15818191bd2402612efa1fe2162c96cd6337a`  
Application ID: `com.multicloud.mcm`  
Version: `1.6.3` (`versionCode=12`)

## Work completed in this candidate

- Preserved the existing native Kotlin project and its already implemented DNS fallback, TLS pinning, encrypted credentials, Room v6, RouterOS adapters, monitoring snapshots, MNDP discovery, per-router history/charts and sequential refresh-all.
- Completed the previously disconnected custom WAN port/service-mode path: Advanced UI → WebView bridge → connection coordinator → TLS probe → authenticated READ_CHECK → persisted Room profile.
- Kept exactly three primary Add Router inputs and one primary “Lưu & Kết nối” action. Technical port/service options remain hidden in a closed-by-default Advanced section.
- AUTO with blank port probes REST/443 and API-SSL/8729 in parallel; AUTO with a custom port probes both protocols on that same WAN port; explicit service mode probes only that service.
- Persists the exact port that passed TLS + READ_CHECK and uses saved mode/port for foreground and background monitoring.
- Added a focused RouterServiceMode JUnit matrix and updated source/UI verification gates.

## Verified in this environment

- `bash scripts/verify-source.sh`: PASS for Native Android project identity, JavaScript syntax, Python syntax, shell syntax, Android XML, Room v1→v6 preservation and UI contract.
- `python3 scripts/verify-ui-contract.py`: PASS; exactly three primary inputs, hidden advanced port/service controls, one primary action.
- `python3 scripts/verify-room-migrations.py`: PASS; router profiles, metrics, interface counters and connection-attempt logs preserved through schema v7, including the new actual-transport field.
- Local `kotlinc` compile + service/port smoke: PASS (9 assertions covering AUTO/default/custom, explicit REST/API-SSL, RouterOS compatibility and invalid ports).
- ZIP CRC and source provenance are verified at packaging time.

## Not verified / blocked

This runtime has OpenJDK 21 but no pinned JDK 17, Gradle 8.7 or Android SDK Platform 35/build-tools. Therefore Gradle/KAPT compile, Android JUnit task, lint, `assembleDebug`, APK manifest validation, emulator/phone installation and live RouterOS 6/7 WAN/DDNS acceptance are **NOT RUN**. No APK is included and no live router was contacted. The targeted local mock tests do not substitute for those acceptance gates.

This is an engineering source candidate, not a release APK. Do not represent static checks or the Kotlin service-mode smoke as a full Android build or real-network acceptance.

## Follow-up diagnostic patch
- Added inline, structured failure diagnostics to first-time and repeat connection attempts: DNS source/IPs, REST/API-SSL port, TCP/TLS results and timings, certificate fingerprint, TLS failure cause, and authenticated READ_CHECK result/detail.
- First-time failures now display their trace directly in the app even when no Room router profile exists yet. Authentication details are redacted against the submitted password; no password or Authorization header is logged.
- Re-ran `bash scripts/verify-source.sh`: PASS. Full Gradle/APK build remains unavailable in this environment; build this source on AndroidForge before installing it.


## DDNS connection root-cause audit and corrective patch

- Found a concrete TLS identity conflict: the first-use flow captures and asks the user to confirm a SHA-256 leaf pin, but then separately rejected RouterOS certificates unless CN/SAN matched the IP Cloud DDNS hostname. RouterOS self-signed certificates commonly use a router-local CN. This could reject a reachable `www-ssl`/`api-ssl` endpoint even when TCP and TLS were otherwise available.
- Corrected REST and API-SSL to use the exact independently confirmed SHA-256 leaf pin as the trust anchor, while retaining DDNS SNI and HTTP Host. A changed certificate still fails closed; no CA/hostname bypass is used without the exact pin.
- Corrected AUTO transport selection: prefer REST for RouterOS 7 and API-SSL for RouterOS 6, but fall back only to the alternate transport that actually passed authenticated READ_CHECK. Explicit modes still never silently fall back.
- Fixed a persistence defect discovered in the full foreground/background path: AUTO previously stored the requested mode but not the actual transport that passed READ_CHECK. A RouterOS 7 router falling back to API-SSL could then be monitored incorrectly as REST on the API-SSL port. Schema v7 now stores `activeTransport`; foreground and background monitoring use that authenticated selection while retaining the user's AUTO preference.
- Fixed legacy RouterOS API login detection: some older devices return a `!done` response containing `=ret=<challenge>` even when the first login request includes a password. The client now detects and completes that challenge on the same TLS session instead of assuming it is already logged in.
- Failure diagnostics now retain attempted IP, TCP/TLS timings, TLS version/cipher when negotiated, and the underlying handshake cause. DNS failures include provider exception details. The app now displays/can copy diagnostics for DNS, timeout, authentication and protocol failures instead of hiding them in toast-only messages.
- Added tests using a self-signed test certificate whose CN deliberately differs from the DDNS hostname, checking exact-pin acceptance and mismatched-pin rejection; added AUTO fallback matrix tests, active-transport persistence resolution tests, and legacy challenge extraction tests.
- Targeted Kotlin/JVM compile of the API-SSL client, API codec and pinned trust manager: PASS with Kotlin 1.9/JDK 21 and isolated platform stubs (not an Android Gradle compile).
- Local TLS mock integration: modern RouterOS API login + `/system/resource/print` READ_CHECK PASS; legacy challenge-response returned with `!done` + `=ret` + same-session response PASS.
- Pure Kotlin core smoke: 8 assertions PASS for AUTO active-transport resolution and legacy challenge parsing.
- Full Gradle/JUnit/lint/APK build and live external RouterOS 6/7 WAN/DDNS connection remain NOT RUN in this environment.
