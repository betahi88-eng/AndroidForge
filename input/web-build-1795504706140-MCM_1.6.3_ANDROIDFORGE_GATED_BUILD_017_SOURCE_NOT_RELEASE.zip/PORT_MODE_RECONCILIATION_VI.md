# MCM 1.6.3 — Kết quả tích hợp WAN port / service mode

## Phát hiện từ lịch sử source

- `MCM_1.6.3_FULL_FUNCTIONAL_SOURCE_ANDROIDFORGE.zip` và `AndroidForge_MCM_1.6.3_SAMPLE_PROJECT_BUILD_FIX_002.zip` có 87 file chung và toàn bộ 87 file đó byte-identical; FIX_002 chỉ có thêm 8 tài liệu/build note.
- Bản `MCM_1.6.3_RECONCILED_DDNS_KOTLIN_SOURCE_DERIVED_PATCH_001.zip` chỉ khác FIX_002 ở 3 file Kotlin, trong đó coordinator dùng `selected.port` nhưng luồng connection chưa tích hợp trọn UI → bridge → coordinator. Không lấy patch đó làm nền build.
- FIX_002 là parent vì người dùng xác nhận đây là source đã build thành công trong AndroidForge.

## Phần đã có và được giữ nguyên

- DNS Android → Google DoH → Cloudflare DoH.
- REST HTTPS / RouterOS 7; API-SSL / RouterOS 6/7.
- TLS SHA-256 pin, xác nhận fingerprint, Keystore AES-GCM.
- Multi-router profiles, Room schema v6, monitoring, charts/history, MNDP, background worker.

## Phần được tích hợp trong candidate này

1. Ba trường chính không thay đổi: DDNS/Hostname, Username, Password.
2. Thêm service selector và WAN port trong Advanced; Advanced mặc định đóng và không tự bật khi sửa profile.
3. Nối port/mode từ JS sang `McmJavascriptBridge` rồi `RouterConnectionCoordinator`.
4. AUTO + port trống: REST 443 và API-SSL 8729 dò song song.
5. AUTO + port tùy chỉnh: cả hai transport thử cùng WAN port ngoài.
6. REST_HTTPS / API_SSL tường minh: chỉ thử giao thức được chọn; không tự downgrade/fallback.
7. TLS probe và READ_CHECK dùng đúng port thử; profile chỉ lưu port của transport xác thực thành công.
8. Foreground monitor và WorkManager dùng lại `router.port` + `router.connectionMode` đã lưu.
9. Nhật ký thể hiện đúng port thực tế và transport không được chạy là `NOT_RUN`.

## Kiểm tra

- UI contract: PASS.
- Room migration preservation: PASS.
- Source syntax/static gates: PASS.
- Kotlin service-mode/port smoke: PASS (9 assertions).
- Gradle compile/JUnit/lint/APK và RouterOS live acceptance: NOT RUN do thiếu toolchain/thiết bị trong runtime.
