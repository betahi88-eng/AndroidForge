# BUILD FIX 002 — Remove unresolved enum property from failing Kotlin call sites

## Evidence from AndroidForge logs (6) and (7)
Both log bundles report the exact same diagnostics in `RouterConnectionCoordinator.kt`:
- lines 262–263: unresolved `port` and chained `put`
- lines 291–292: unresolved `port` and chained `put`
The failure is at `:app:compileDebugKotlin` / `:app:compileReleaseKotlin`.
Log (7) shows `assembleDebug`, `bundleDebug` and `assembleRelease` all fail at Kotlin compilation. It runs from the project workspace root but reports Gradle 8.9 instead of the pinned 8.7. Neither log bundle contains the source archive or source hash, so neither proves which source snapshot was compiled.

## Additional source-side hardening in this package
The rebased candidate 006 keeps the authenticated probe as the source of truth: `val selectedPort = successful.port`. The saved port and returned JSON are derived from the exact branch that passed TLS and authenticated READ_CHECK, rather than from a guessed enum default. The old `selected.port` expression is absent from `RouterConnectionCoordinator.kt`.

The `RouterTransport.port` property added in BUILD FIX 001 remains, and unit assertions remain.

## Important Builder input check
The current package adds `scripts/verify-build-regressions.py`; it asserts that `selected.port` is absent and that `successful.port` supplies the persisted endpoint. The guard is part of `scripts/verify-source.sh`. A fresh AndroidForge build of the exact candidate 006 ZIP is still required; any repeated diagnostic must be reconciled against the exact uploaded ZIP hash and extracted source.

## Verification status
- `selected.port` is absent from the current coordinator.
- `scripts/verify-build-regressions.py`: PASS (11 assertions, including the historical error and the full WAN-port/service-mode handoff).
- ZIP CRC and root project structure: verified.
- Android Gradle build: NOT RUN here; Builder execution is still required.
