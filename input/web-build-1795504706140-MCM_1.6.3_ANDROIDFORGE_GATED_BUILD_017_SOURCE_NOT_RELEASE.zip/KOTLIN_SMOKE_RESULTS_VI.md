# Kết quả smoke test Kotlin/JVM — MCM 1.6.3 source 014

Ngày chạy: 24/11/2026.

- Kết quả: **PASS — 48 assertions** từ `bash scripts/verify-kotlin-smoke.sh`.
- Compiler: Kotlin/JVM 1.9.0; runtime OpenJDK 21.0.12.1.
- Smoke suite kế thừa kiểm tra các lớp Kotlin thuần từ baseline 007: read-only policy, host validation, service mode/failover, REST response bounds, RouterOS API codec, TLS hostname verification và TLS error classification.
- Có test doubles cho các kiểu phụ thuộc Android/Room để cô lập logic Kotlin thuần. Đây không phải Android Gradle compile.
- Các nhánh kiểm tra gồm allowlist chặn lệnh ghi, ping bị giới hạn, chuẩn hóa DDNS/IPv4, xác thực hostname và cổng, AUTO/custom port, failover không vượt qua lỗi AUTH/TLS identity hoặc pin chưa xác nhận, pin không bị dùng chéo transport, API sentence/challenge/credential rejection/giới hạn word, DNS SAN/IP SAN/CN fallback/wildcard, phân loại lỗi TLS, giới hạn REST body/rows và các nhánh kết quả foreground/background.

## Smoke test WinBox tích hợp

Lệnh `bash scripts/verify-winbox-smoke.sh` chạy riêng và **PASS**:

- EC-SRP5 public-key/client-proof/shared-secret known-answer vectors.
- WinBox stream-key vectors, 10 AES/HMAC round trips, kiểm tra frame boundary đúng 14 chunk và từ chối dữ liệu sai HMAC.
- VT100 terminal/prompt, ROS6 as-value/list boundaries, xử lý lỗi CLI và read-only command allowlist.
- Connector và repository được biên dịch ở chế độ Kotlin/JVM; repository type-check dùng temporary signatures cho các kiểu Android/JSON/coroutine. Đây là kiểm thử có phạm vi, không phải Android project build.

## Giới hạn chưa được xác minh

Các smoke test trên **không thay thế** Gradle/KAPT compile, Android JUnit, lint, APK/AAB build, Android Emulator/Maestro, kiểm thử RouterOS CHR live hoặc kết nối DDNS/WAN thực tế. Các hạng mục đó vẫn `NOT RUN` trong workspace hiện tại do thiếu toolchain/môi trường tương ứng.

Lệnh tái chạy:

```bash
bash scripts/verify-kotlin-smoke.sh
bash scripts/verify-winbox-smoke.sh
```
