# Third-party notices — MCM 1.6.3 candidate 014

WinBox CLI is a reverse-engineered protocol, not a MikroTik-published protocol standard. The implementation in `WinboxCliConnector.kt` was independently cross-checked against the public sources below. Review the specific upstream licenses before redistributing any changes to this adapter.

## tik4net

- Project: https://github.com/danikf/tik4net
- License: Apache License 2.0; full license retained at `licenses/Apache-2.0-tik4net.txt`.
- Role: independent reference for EC-SRP5, M2 framing, stream-key derivation, WinBox mepty terminal, terminal prompt handling, VT100 behavior, and RouterOS 6/7 CLI parsing behavior.

## winbox-terminal-protocol

- Project: https://github.com/subixonfire/winbox-terminal-protocol
- License: MIT; notice retained at `licenses/MIT-winbox-terminal-protocol.txt`.
- Role: independently maintained WinBox terminal protocol reference, including handshake and encrypted stream format.

The MCM Kotlin implementation is not a runtime dependency on either project. It is a separate Android implementation. No third-party CHR image is bundled; MikroTik CHR must be obtained from MikroTik and used under its applicable license.
