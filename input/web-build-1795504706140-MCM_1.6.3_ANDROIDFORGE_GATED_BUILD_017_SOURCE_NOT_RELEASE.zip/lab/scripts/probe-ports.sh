#!/usr/bin/env bash
set -euo pipefail
HOST="${1:?Usage: $0 <host> [winbox-port] [rest-port] [api-ssl-port]}"
WINBOX_PORT="${2:-8291}"
REST_PORT="${3:-443}"
API_SSL_PORT="${4:-8729}"
command -v nc >/dev/null || { echo 'nc (netcat) is required' >&2; exit 2; }
failed=0
for entry in "WINBOX_CLI:$WINBOX_PORT" "REST_HTTPS:$REST_PORT" "API_SSL:$API_SSL_PORT"; do
  name="${entry%%:*}"; port="${entry##*:}"
  if nc -z -w 3 "$HOST" "$port"; then printf '[TCP OPEN]   %-10s %s:%s\n' "$name" "$HOST" "$port"; else printf '[TCP FAIL]   %-10s %s:%s\n' "$name" "$HOST" "$port"; failed=$((failed+1)); fi
done
if [[ "$failed" -gt 0 ]]; then exit 1; fi
