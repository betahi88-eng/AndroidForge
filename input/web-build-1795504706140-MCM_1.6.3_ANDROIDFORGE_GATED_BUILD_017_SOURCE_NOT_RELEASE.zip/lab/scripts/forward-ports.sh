#!/usr/bin/env bash
set -euo pipefail
MGMT_IP="${1:-172.30.20.10}"
command -v socat >/dev/null 2>&1 || { echo "socat is required to forward Android Emulator host ports." >&2; exit 1; }
[[ "$MGMT_IP" =~ ^[0-9.]+$ ]] || { echo "Provide the CHR management IPv4 address." >&2; exit 1; }
STATE_DIR="${TMPDIR:-/tmp}/mcm-connection-lab-${UID}"
mkdir -p "$STATE_DIR"
chmod 700 "$STATE_DIR"

start_forward() {
  local host_port="$1" router_port="$2" pid_file="$STATE_DIR/${host_port}.pid" log_file="$STATE_DIR/${host_port}.log"
  if [[ -f "$pid_file" ]] && kill -0 "$(cat "$pid_file")" 2>/dev/null; then
    echo "Already running: 127.0.0.1:${host_port} -> ${MGMT_IP}:${router_port} (PID $(cat "$pid_file"))"
    return
  fi
  rm -f "$pid_file"
  nohup socat "TCP-LISTEN:${host_port},bind=127.0.0.1,reuseaddr,fork" "TCP:${MGMT_IP}:${router_port},connect-timeout=5" >"$log_file" 2>&1 &
  echo "$!" > "$pid_file"
  sleep 0.15
  kill -0 "$(cat "$pid_file")" 2>/dev/null || { cat "$log_file" >&2 || true; exit 1; }
  echo "Forward ready: 127.0.0.1:${host_port} -> ${MGMT_IP}:${router_port}"
}

start_forward 18291 8291
start_forward 18443 443
start_forward 18729 8729
cat <<'MSG'

Forwarders bind ONLY to host loopback. Android Emulator reaches them via 10.0.2.2.
DNS CoreDNS should map mcm-chr.test -> 10.0.2.2.
Run lab/scripts/stop-forward-ports.sh to stop them.
MSG
