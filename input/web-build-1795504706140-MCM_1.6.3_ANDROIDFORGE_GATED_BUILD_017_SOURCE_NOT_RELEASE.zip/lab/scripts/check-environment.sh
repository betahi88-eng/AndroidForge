#!/usr/bin/env bash
set -u
ok=0
warn=0
need() {
  local name="$1" cmd="$2"
  if command -v "$cmd" >/dev/null 2>&1; then
    printf '[OK]   %s: %s\n' "$name" "$(command -v "$cmd")"
    ok=$((ok+1))
  else
    printf '[MISS] %s: cần cài %s\n' "$name" "$cmd"
    warn=$((warn+1))
  fi
}
need "Docker" docker
need "Containerlab" containerlab
need "QEMU" qemu-system-x86_64
need "Android Debug Bridge" adb
need "Java" java
need "Gradle" gradle
need "Maestro" maestro
need "Wireshark/tshark" tshark
need "socat (tùy chọn port bridge)" socat
if [[ -e /dev/kvm ]]; then echo '[OK]   KVM: /dev/kvm'; ok=$((ok+1)); else echo '[WARN] KVM không có; CHR QEMU TCG sẽ boot chậm hơn.'; warn=$((warn+1)); fi
if [[ -n "${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}" ]]; then echo "[OK]   Android SDK: ${ANDROID_SDK_ROOT:-$ANDROID_HOME}"; ok=$((ok+1)); else echo '[MISS] Android SDK: đặt ANDROID_SDK_ROOT'; warn=$((warn+1)); fi
printf '\nKết quả: %s mục OK, %s mục cần bổ sung.\n' "$ok" "$warn"
[[ "$warn" -eq 0 ]]
