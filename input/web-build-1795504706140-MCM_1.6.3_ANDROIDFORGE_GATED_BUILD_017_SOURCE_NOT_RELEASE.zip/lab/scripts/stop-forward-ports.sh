#!/usr/bin/env bash
set -euo pipefail
STATE_DIR="${TMPDIR:-/tmp}/mcm-connection-lab-${UID}"
for port in 18291 18443 18729; do
  pid_file="$STATE_DIR/${port}.pid"
  if [[ -f "$pid_file" ]]; then
    pid="$(cat "$pid_file")"
    if kill -0 "$pid" 2>/dev/null; then kill "$pid"; echo "Stopped forwarder $port (PID $pid)"; fi
    rm -f "$pid_file"
  fi
done
rmdir "$STATE_DIR" 2>/dev/null || true
