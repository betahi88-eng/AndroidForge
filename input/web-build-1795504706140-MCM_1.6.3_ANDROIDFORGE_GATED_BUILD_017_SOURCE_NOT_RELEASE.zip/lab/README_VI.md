# Phòng kiểm thử tích hợp MCM — RouterOS thật

## Mục tiêu

Phòng lab này dùng MikroTik CHR/RouterOS thật; không giả lập REST JSON hoặc giao thức WinBox. MCM chạy trên Android Emulator, kết nối vào CHR qua port-forward chỉ bind trên loopback của máy chủ. Đây là cấu hình lab mẫu; chưa được khởi chạy trong workspace của gói nguồn này.

## 1. RouterOS 7 bằng Containerlab

Yêu cầu: Linux x86_64/arm64, Docker, Containerlab **0.82 trở lên**, RAM trống tối thiểu khoảng 2 GB cho CHR và có `/dev/kvm` để QEMU tăng tốc. Không có KVM thì QEMU TCG vẫn chạy nhưng boot chậm.

```bash
export MCM_LAB_USER='mcmtest'
export MCM_LAB_PASSWORD='replace-with-a-long-lab-only-password'
containerlab deploy -t lab/containerlab/mcm-routeros7.clab.yml
containerlab inspect -t lab/containerlab/mcm-routeros7.clab.yml
```

Image `mikrotik/chr:7.24.5` là image CHR chính thức. Containerlab `mikrotik_chr` dùng image đó trực tiếp; không phải tự build vrnetlab. `ether1` là management; các cổng dữ liệu bắt đầu từ `ether2`. Lab đặt IP management cố định `172.30.20.10` trong subnet `172.30.20.0/24` để host Linux có thể forward tới CHR.

**Không dùng `ports:` của Docker để forward dịch vụ CHR.** `mikrotik_chr` gắn `ether1` trong VRF `mgmt`, còn management services phản hồi trên RouterOS/ether1. Sau khi CHR healthy, chạy host-side forwarder:

```bash
bash lab/scripts/forward-ports.sh 172.30.20.10
bash lab/scripts/probe-ports.sh 127.0.0.1 18291 18443 18729
```

Các forwarder chỉ bind vào `127.0.0.1` của host, không mở dịch vụ cho LAN/Internet:

| Host loopback port | CHR management IP/port | MCM mode |
|---:|---|---|
| 18291 | 172.30.20.10:8291 | WinBox CLI |
| 18443 | 172.30.20.10:443 | REST HTTPS |
| 18729 | 172.30.20.10:8729 | API-SSL |

Android Emulator truy cập host loopback qua `10.0.2.2`. File `lab/dns/Corefile` ánh xạ `mcm-chr.test` thành `10.0.2.2`; chạy CoreDNS trên host và khởi động emulator với DNS lab (ví dụ `emulator @MyAVD -dns-server 10.0.2.2`). Trong MCM hãy nhập host `mcm-chr.test`, chọn mode và cổng tương ứng. Với REST/API-SSL, certificate script có SAN `DNS:mcm-chr.test` và `IP:10.0.2.2`; vẫn phải đi qua xác minh hostname, validity và xác nhận fingerprint bình thường.

Dừng các forwarder bằng:

```bash
bash lab/scripts/stop-forward-ports.sh
```

> **Giới hạn quan trọng của Containerlab CHR kind:** các service được đặt trong VRF `mgmt`; đây là đường management trực tiếp, không phải mô phỏng đường WAN/NAT/firewall qua interface dữ liệu. Không dùng kết quả lab này để kết luận cổng WAN ngoài Internet của router thực tế đã thông. Dùng GNS3/QEMU topology ở phần 2 cho bài kiểm thử NAT/data-plane.

## 2. RouterOS 6 và topology WAN bằng GNS3/QEMU

1. Tải CHR `.img`/`.vdi` chính thức từ trang MikroTik; không đưa image proprietary vào source ZIP.
2. Import CHR vào GNS3/QEMU, chọn RouterOS 6.49.x hoặc bản 6.x mục tiêu cần tương thích.
3. Nối ít nhất hai interface: management/test client và WAN/data-plane; dựng NAT/gateway/Linux client thành các node riêng.
4. Nạp `routeros6-services.rsc.example` vào CHR test router, sau khi kiểm tra phiên bản cú pháp. Không dùng script lab vào production.
5. Kiểm tra từng service và NAT route riêng biệt: WinBox TCP 8291, API-SSL TCP 8729. RouterOS 6 không có REST API.

CHR Free đủ dùng cho kiểm thử quản trị; license Free giới hạn upload 1 Mbps mỗi interface, do đó không dùng lab để benchmark thông lượng.

## 3. DNS/DDNS

`lab/dns/Corefile` là ví dụ CoreDNS để trả `mcm-chr.test` thành `10.0.2.2`. Cài CoreDNS riêng, chạy `sudo coredns -conf lab/dns/Corefile` trên host và cấu hình Android Emulator dùng DNS server `10.0.2.2` khi chạy kịch bản DNS. CoreDNS phải lắng nghe UDP/TCP 53 trên host interface mà emulator truy cập được. MCM thử Android system DNS trước, sau đó mới đến các DoH fallback đã có trong ứng dụng. Không thay đổi DNS của máy chủ/điện thoại đang sử dụng thật.

Để kiểm thử DNS thay đổi, sửa IP trong Corefile và reload CoreDNS; kiểm tra TTL/cache và log resolver. Kiểm thử NXDOMAIN/SERVFAIL/timeout bằng cấu hình CoreDNS riêng; không coi kết quả TCP port probe là bằng chứng đã xác thực RouterOS.

## 4. Chạy kiểm thử

```bash
bash lab/scripts/check-environment.sh
bash lab/scripts/forward-ports.sh 172.30.20.10
bash lab/scripts/probe-ports.sh 127.0.0.1 18291 18443 18729
```

Từ thư mục project:

```bash
maestro test lab/maestro/winbox-connect.yaml \
  -e MCM_LAB_HOST=mcm-chr.test \
  -e MCM_LAB_USER="$MCM_LAB_USER" \
  -e MCM_LAB_PASSWORD="$MCM_LAB_PASSWORD"
```

`probe-ports.sh` chỉ kiểm tra TCP connect; nó không kiểm tra EC-SRP5, TLS, HTTP auth hoặc đọc dữ liệu. File Maestro hiện là kịch bản mẫu và cần xác nhận selectors trong emulator trước khi dùng làm release gate; nó chưa được chạy. Kết quả integration hoàn chỉnh phải kết hợp log MCM, log CHR và PCAP/tshark.

## 5. Bộ test bắt buộc trước khi phát hành

- DNS A/AAAA, đổi IP, cache/TTL, NXDOMAIN, SERVFAIL, resolver timeout.
- Mỗi cổng WinBox/REST/API-SSL được kiểm tra độc lập: open, refused, timeout, reset.
- WinBox: EC-SRP5, server proof, M2/HMAC, mở terminal, prompt, `/system/identity/print`, `/system/resource/print`, các bảng monitoring.
- TLS: SAN khớp/không khớp, chứng chỉ hết hạn, fingerprint đổi, API-SSL không có cert.
- RouterOS 6: API-SSL và WinBox CLI; không chạy REST.
- RouterOS 7: REST HTTPS, API-SSL và WinBox CLI.
- Network: delay, jitter, packet loss, reconnect, Android background/resume.
- Dữ liệu: so sánh resource, interface, cloud, PPP active, ARP, DHCP, Netwatch, bridge host, VLAN và bridge VLAN với CHR reference client.
- Negative: sai mật khẩu, user không đủ quyền, parser nhận CLI error, bảng trống, terminal timeout.

MCM chỉ được đánh dấu ONLINE khi luồng xác thực và dữ liệu lõi thành công. Bảng tùy chọn lỗi phải giữ trạng thái unavailable/partial; không tạo số liệu 0 giả.

## 6. Dọn phòng lab

```bash
containerlab destroy -t lab/containerlab/mcm-routeros7.clab.yml --cleanup
```

Các host-side port forwarder chỉ listen trên `127.0.0.1`. Không expose CHR management ports ra LAN/Internet và không tái sử dụng mật khẩu lab cho router thật.

## 7. Phạm vi đã/ chưa được thực thi

- Source có topology Containerlab, cấu hình CHR 7 mẫu, ví dụ CHR 6 cho GNS3 và script kiểm tra môi trường.
- Không bao gồm image CHR vì image do MikroTik cung cấp và chịu điều kiện bản quyền/giấy phép riêng.
- Không có bằng chứng live-run trong source package này: cần chạy `containerlab deploy`, Android Emulator/ADB và Maestro tại một Linux host có Docker/KVM/Android SDK.
- Containerlab 0.82+ `mikrotik_chr` chạy management services trên management VRF của `ether1`; muốn kiểm chứng DDNS qua Internet/NAT phải thêm gateway và đường data-plane riêng trong GNS3/QEMU hoặc lab edge.
