# Isolated MCM integration-test CHR only. Never import this into a production router.
# Generate a local test CA and a server certificate valid for Android Emulator host alias 10.0.2.2.
/certificate/add name=mcm-lab-ca common-name=mcm-lab-ca days-valid=3650 key-usage=key-cert-sign,crl-sign
/certificate/sign mcm-lab-ca
:delay 3s
/certificate/add name=mcm-lab-server common-name=mcm-chr.test subject-alt-name=DNS:mcm-chr.test,IP:10.0.2.2 days-valid=365 key-usage=digital-signature,key-encipherment,tls-server
/certificate/sign mcm-lab-server ca=mcm-lab-ca
:delay 3s
/ip/service/set www-ssl certificate=mcm-lab-server disabled=no
/ip/service/set api-ssl certificate=mcm-lab-server disabled=no
/ip/service/set api disabled=yes
/ip/service/set www disabled=yes
/ip/service/set winbox disabled=no
