# BUILD FIX 001 — Kotlin compile errors in RouterConnectionCoordinator

## Root cause confirmed from AndroidForge logs
All three build attempts (`assembleDebug`, `bundleDebug`, `assembleRelease`) fail at:
`RouterConnectionCoordinator.kt` lines 262–263 and 291–292.

The code reads `selected.port`, but `RouterTransport` was declared without a `port` property:
`enum class RouterTransport { REST_HTTPS, API_SSL }`

The missing property triggers the unresolved `port` diagnostic and cascading unresolved `put` diagnostics in the chained `JSONObject` calls.

## Applied source correction
`RouterServiceMode.kt` now declares:
`enum class RouterTransport(val port: Int) { REST_HTTPS(443), API_SSL(8729) }`

This matches the existing connection probe configuration:
- REST_HTTPS → TCP/HTTPS port 443
- API_SSL → TCP/API-SSL port 8729

No protocol selection behavior, RouterOS support rules, TLS checks, credentials, or app identity were changed.

## Regression coverage
`RouterServiceModeTest` now asserts both transport port values in addition to the existing mode resolution tests.

## Verification status
- ZIP CRC and required project-root structure: verified when packaged.
- Source-level patch assertion: verified.
- Android Gradle build: NOT RUN in this environment. A fresh AndroidForge run is still required to confirm compilation and APK output.
- The Gradle 8.9 and KAPT language-version warning in the supplied logs are not the cause of this failure; the fatal diagnostics are the missing `RouterTransport.port` property.
