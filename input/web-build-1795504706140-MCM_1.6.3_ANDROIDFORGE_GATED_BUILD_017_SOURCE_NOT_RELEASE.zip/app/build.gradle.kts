plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.kapt")
}

android {
    namespace = "com.multicloud.mcm"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.multicloud.mcm"
        minSdk = 26
        targetSdk = 35
        versionCode = 12
        versionName = "1.6.3"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { buildConfig = true }
    testOptions { unitTests.isReturnDefaultValues = true }
}

kapt { correctErrorTypes = true }

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    kapt("androidx.room:room-compiler:2.6.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.json:json:20240303")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.9.0")
}

// Reject unexpected SSH/BouncyCastle dependencies in BOTH app variants.
// The failed AndroidForge workspace had these libraries in the base module runtime graph.
tasks.register("verifyMcmRuntimeDependencies") {
    group = "verification"
    description = "Fails if JSch or BouncyCastle appears in Debug or Release runtime dependencies."
    doLast {
        val runtimeConfigurations = listOf("debugRuntimeClasspath", "releaseRuntimeClasspath")
        val resolvedModules = runtimeConfigurations.flatMap { configurationName ->
            val configuration = configurations.findByName(configurationName)
                ?: error("Required Android runtime configuration is missing: $configurationName")
            configuration.incoming.resolutionResult.allComponents.mapNotNull { component ->
                component.moduleVersion?.let { module ->
                    Triple(configurationName, module.group, "${module.name}:${module.version}")
                }
            }
        }.distinct()
        val forbidden = resolvedModules.filter { (_, group, artifactAndVersion) ->
            val artifact = artifactAndVersion.substringBefore(':').lowercase()
            group.equals("com.github.mwiede", ignoreCase = true) ||
                group.equals("org.bouncycastle", ignoreCase = true) ||
                artifact.contains("jsch") || artifact.contains("bcprov")
        }.map { (configurationName, group, artifactAndVersion) ->
            "$configurationName -> $group:$artifactAndVersion"
        }.sorted()
        check(forbidden.isEmpty()) {
            "Unexpected runtime dependencies detected:\n${forbidden.joinToString("\n")}\n" +
                "Do not mask this with packaging excludes; restore the exact source workspace and dependency graph."
        }
        println("MCM runtime dependency integrity PASS: Debug + Release (${resolvedModules.size} resolved module-variant entries)")
    }
}

// Make the dependency gate unavoidable for assemble/test/lint tasks that enter the Android lifecycle.
tasks.matching { it.name == "preBuild" }.configureEach {
    dependsOn("verifyMcmRuntimeDependencies")
}
