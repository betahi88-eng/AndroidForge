package com.multicloud.mcm

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class RouterDnsResolverTest {
    private val expected = InetAddress.getByAddress(byteArrayOf(115, 78, (-48), 58))

    @Test fun usesAndroidResolverFirstAndDoesNotCallDoHWhenSuccessful() {
        var googleCalled = false
        var cloudflareCalled = false
        val chain = SystemFirstDnsChain(
            systemLookup = { listOf(expected) },
            googleLookup = { googleCalled = true; emptyList() },
            cloudflareLookup = { cloudflareCalled = true; emptyList() }
        )
        val result = chain.resolve("router.example")
        assertEquals("ANDROID_SYSTEM", result.source)
        assertEquals(listOf(expected), result.addresses)
        assertTrue(!googleCalled && !cloudflareCalled)
    }

    @Test fun triesGoogleBeforeCloudflareAndStopsAfterFirstSuccess() {
        val calls = mutableListOf<String>()
        val chain = SystemFirstDnsChain(
            systemLookup = { throw UnknownHostException("no system record") },
            googleLookup = { calls += "google"; listOf(expected) },
            cloudflareLookup = { calls += "cloudflare"; emptyList() }
        )
        val result = chain.resolve("router.example")
        assertEquals("GOOGLE_DOH", result.source)
        assertEquals(listOf("google"), calls)
    }

    @Test fun fallsBackToCloudflareOnlyAfterGoogleFails() {
        val calls = mutableListOf<String>()
        val chain = SystemFirstDnsChain(
            systemLookup = { throw UnknownHostException("no system record") },
            googleLookup = { calls += "google"; throw SocketTimeoutException("timeout") },
            cloudflareLookup = { calls += "cloudflare"; listOf(expected) }
        )
        val result = chain.resolve("router.example")
        assertEquals("CLOUDFLARE_DOH", result.source)
        assertEquals(listOf("google", "cloudflare"), calls)
    }

    @Test fun distinguishesAllResolverTimeoutFromUnresolvableHostname() {
        val timedOut = SystemFirstDnsChain(
            systemLookup = { throw SocketTimeoutException("timeout") },
            googleLookup = { throw SocketTimeoutException("timeout") },
            cloudflareLookup = { throw SocketTimeoutException("timeout") }
        )
        assertEquals("NETWORK_TIMEOUT", assertThrows(DnsResolutionException::class.java) {
            timedOut.resolve("router.example")
        }.failureCode)

        val missing = SystemFirstDnsChain(
            systemLookup = { throw UnknownHostException("NXDOMAIN") },
            googleLookup = { emptyList() },
            cloudflareLookup = { emptyList() }
        )
        assertEquals("DNS_FAILED", assertThrows(DnsResolutionException::class.java) {
            missing.resolve("missing.example")
        }.failureCode)
    }
}
