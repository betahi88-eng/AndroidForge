package com.multicloud.mcm

import org.junit.Assert.assertThrows
import org.junit.Test

class RouterOsReadOnlyPolicyTest {
    @Test fun allowsOnlyTheRequiredRestReadPaths() {
        listOf(
            "system/resource", "interface", "ip/cloud", "ppp/active", "ip/arp",
            "ip/dhcp-server/lease", "tool/netwatch", "interface/bridge/host",
            "interface/vlan", "interface/bridge/vlan"
        ).forEach(RouterOsReadOnlyPolicy::validateRestGet)
        assertThrows(IllegalArgumentException::class.java) { RouterOsReadOnlyPolicy.validateRestGet("system/reboot") }
        assertThrows(IllegalArgumentException::class.java) { RouterOsReadOnlyPolicy.validateRestGet("ip/firewall/filter") }
    }

    @Test fun restPostAllowsOnlyBoundedPing() {
        RouterOsReadOnlyPolicy.validateRestPing("ping", setOf("address", "count", "interval"), "1.1.1.1", "20", "200ms")
        assertThrows(IllegalArgumentException::class.java) {
            RouterOsReadOnlyPolicy.validateRestPing("system/reboot", emptySet(), "", "1", "200ms")
        }
        assertThrows(IllegalArgumentException::class.java) {
            RouterOsReadOnlyPolicy.validateRestPing("ping", setOf("address", "script"), "1.1.1.1", "20", "200ms")
        }
        assertThrows(IllegalArgumentException::class.java) {
            RouterOsReadOnlyPolicy.validateRestPing("ping", setOf("address", "count", "interval"), "1.1.1.1", "101", "200ms")
        }
    }

    @Test fun apiSslAllowsOnlyReadPrintAndBoundedPingCommands() {
        RouterOsReadOnlyPolicy.validateApiCommand("/system/resource/print", mapOf(".proplist" to "version,uptime,cpu-load"))
        RouterOsReadOnlyPolicy.validateApiCommand("/ping", mapOf("address" to "1.1.1.1", "count" to "10", "interval" to "200ms"))
        assertThrows(IllegalArgumentException::class.java) {
            RouterOsReadOnlyPolicy.validateApiCommand("/system/reboot", emptyMap())
        }
        assertThrows(IllegalArgumentException::class.java) {
            RouterOsReadOnlyPolicy.validateApiCommand("/ip/firewall/filter/add", emptyMap())
        }
        assertThrows(IllegalArgumentException::class.java) {
            RouterOsReadOnlyPolicy.validateApiCommand("/system/resource/print", mapOf("disabled" to "yes"))
        }
        assertThrows(IllegalArgumentException::class.java) {
            RouterOsReadOnlyPolicy.validateApiCommand("/ping", mapOf("address" to "1.1.1.1", "count" to "1000", "interval" to "200ms"))
        }
    }
}
