package com.multicloud.mcm

import com.multicloud.mcm.routeros.RouterOs6PingParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RouterOs6PingParserTest {
    @Test
    fun completedApiCommandUsesRequestedCountAndCountsOnlyEchoReplyRows() {
        val rows = listOf(
            mapOf("host" to "1.1.1.1", "seq" to "0", "time" to "9ms250us"),
            mapOf("host" to "1.1.1.1", "seq" to "2", "time" to "12ms")
        )
        val result = RouterOs6PingParser.parseCompleted("1.1.1.1", rows, 3, now = 123L)
        assertTrue(result is McmResult.Success)
        val sample = (result as McmResult.Success).value
        assertEquals(3, sample.sent)
        assertEquals(2, sample.received)
        assertEquals(1, sample.lost)
        assertEquals(33.3333, sample.lossPercent, 0.001)
        assertEquals(9.25, sample.minRttMs!!, 0.0001)
        assertEquals(123L, sample.measuredAtEpochMs)
    }

    @Test
    fun completedCommandWithNoEchoRepliesIsAValidTotalLossSample() {
        val result = RouterOs6PingParser.parseCompleted("192.0.2.1", emptyList(), 5)
        assertTrue(result is McmResult.Success)
        val sample = (result as McmResult.Success).value
        assertEquals(5, sample.sent)
        assertEquals(0, sample.received)
        assertEquals(100.0, sample.lossPercent, 0.0001)
    }

    @Test
    fun duplicateOrMalformedEchoReplyRecordsAreRejected() {
        val duplicate = listOf(
            mapOf("host" to "1.1.1.1", "seq" to "1"),
            mapOf("host" to "1.1.1.1", "seq" to "1")
        )
        val result = RouterOs6PingParser.parseCompleted("1.1.1.1", duplicate, 3)
        assertTrue(result is McmResult.Failure)
    }
}
