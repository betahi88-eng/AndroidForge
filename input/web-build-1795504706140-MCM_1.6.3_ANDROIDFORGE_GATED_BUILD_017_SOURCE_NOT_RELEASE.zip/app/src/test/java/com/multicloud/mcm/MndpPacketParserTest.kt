package com.multicloud.mcm

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class MndpPacketParserTest {
    @Test fun parsesIdentityMacVersionAndIpv4() {
        val packet = byteArrayOf(
            0, 0, 0, 1,
            0, 1, 0, 6, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55,
            0, 5, 0, 4, 'R'.code.toByte(), 'B'.code.toByte(), '5'.code.toByte(), '0'.code.toByte(),
            0, 7, 0, 5, '7'.code.toByte(), '.'.code.toByte(), '1'.code.toByte(), '3'.code.toByte(), '0'.code.toByte(),
            0, 17, 0, 4, 192.toByte(), 168.toByte(), 1, 1
        )
        val result = MndpPacketParser.parse(packet, 0, packet.size, "192.168.1.1")
        requireNotNull(result)
        assertEquals("00:11:22:33:44:55", result.mac)
        assertEquals("RB50", result.identity)
        assertEquals("7.130", result.version)
        assertEquals("192.168.1.1", result.advertisedIp)
    }

    @Test fun decodesLittleEndianUptimeAndBoardAndInterface() {
        val packet = byteArrayOf(
            0, 0, 0, 1,
            0, 5, 0, 4, 'R'.code.toByte(), 'B'.code.toByte(), '5'.code.toByte(), '0'.code.toByte(),
            0, 10, 0, 4, 0x80.toByte(), 0x51, 0x01, 0x00,
            0, 12, 0, 5, 'R'.code.toByte(), 'B'.code.toByte(), '5'.code.toByte(), '0'.code.toByte(), '0'.code.toByte(),
            0, 16, 0, 5, 'e'.code.toByte(), 't'.code.toByte(), 'h'.code.toByte(), 'e'.code.toByte(), 'r'.code.toByte()
        )
        val result = MndpPacketParser.parse(packet, 0, packet.size, "192.168.1.1")
        requireNotNull(result)
        assertEquals("1d 0h 0m", result.uptime)
        assertEquals("RB500", result.board)
        assertEquals("ether", result.interfaceName)
    }

    @Test fun ignoresUnknownTlvsWithoutLosingFollowingFields() {
        val packet = byteArrayOf(
            0, 0, 0, 1,
            0, 99, 0, 3, 1, 2, 3,
            0, 5, 0, 3, 'A'.code.toByte(), 'P'.code.toByte(), '1'.code.toByte()
        )
        val result = MndpPacketParser.parse(packet, 0, packet.size, "192.168.1.2")
        requireNotNull(result)
        assertEquals("AP1", result.identity)
    }

    @Test fun parsesIpv6Address() {
        val ipv6 = byteArrayOf(
            0x20, 0x01, 0x0d, 0xb8.toByte(), 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 1
        )
        val packet = byteArrayOf(0, 0, 0, 1, 0, 15, 0, 16) + ipv6 +
            byteArrayOf(0, 5, 0, 1, 'R'.code.toByte())
        val result = MndpPacketParser.parse(packet, 0, packet.size, "fe80::1")
        requireNotNull(result)
        assertEquals(true, result.advertisedIpv6.startsWith("2001:db8:"))
    }

    @Test fun rejectsPartialTrailingTlvHeader() {
        val packet = byteArrayOf(0, 0, 0, 1, 0, 5, 0, 1, 'A'.code.toByte(), 0)
        assertNull(MndpPacketParser.parse(packet, 0, packet.size, "192.168.1.3"))
    }

    @Test fun rejectsTruncatedTlv() {
        val packet = byteArrayOf(0, 0, 0, 0, 0, 5, 0, 9, 65)
        assertNull(MndpPacketParser.parse(packet, 0, packet.size, "192.168.1.2"))
    }
}
