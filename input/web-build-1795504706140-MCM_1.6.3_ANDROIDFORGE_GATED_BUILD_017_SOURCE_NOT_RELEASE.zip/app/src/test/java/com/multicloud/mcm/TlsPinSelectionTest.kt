package com.multicloud.mcm

import com.multicloud.mcm.data.RouterEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class TlsPinSelectionTest {
    private fun profile(
        activeTransport: String? = "REST_HTTPS",
        legacyPin: String = "L".repeat(64),
        restPin: String? = "R".repeat(64),
        restPort: Int? = 18443,
        apiPin: String? = "A".repeat(64),
        apiPort: Int? = 18443
    ) = RouterEntity(
        id = "router-1", name = "Office", siteName = "Office", host = "office.example.net",
        port = 18443, routerOsMajor = 7, username = "readonly", credentialAlias = "alias",
        tlsSha256Pin = legacyPin, createdAtEpochMs = 1L, lastSeenAtEpochMs = null,
        connectionMode = "AUTO", activeTransport = activeTransport,
        tlsRestSha256Pin = restPin, tlsRestPinPort = restPort,
        tlsApiSslSha256Pin = apiPin, tlsApiSslPinPort = apiPort
    )

    @Test fun selectsIndependentPinsForEachServiceAtTheSameWanPort() {
        val row = profile()
        assertEquals("R".repeat(64), row.tlsPinFor(RouterTransport.REST_HTTPS, 18443))
        assertEquals("A".repeat(64), row.tlsPinFor(RouterTransport.API_SSL, 18443))
        assertEquals(18443, row.tlsPinPortFor(RouterTransport.REST_HTTPS))
        assertEquals(18443, row.tlsPinPortFor(RouterTransport.API_SSL))
    }

    @Test fun neverReusesOneServicePinOnTheOtherPortOrTransport() {
        val row = profile(apiPin = null, apiPort = null)
        assertNull(row.tlsPinFor(RouterTransport.API_SSL, 18443))
        assertNull(row.tlsPinFor(RouterTransport.REST_HTTPS, 443))
        assertNull(row.tlsPinPortFor(RouterTransport.API_SSL))
    }

    @Test fun legacyPinIsUsableOnlyForItsSavedActiveTransportAndExactPort() {
        val row = profile(activeTransport = "API_SSL", restPin = null, restPort = null, apiPin = null, apiPort = null)
        assertEquals("L".repeat(64), row.tlsPinFor(RouterTransport.API_SSL, 18443))
        assertNull(row.tlsPinFor(RouterTransport.REST_HTTPS, 18443))
        assertNull(row.tlsPinFor(RouterTransport.API_SSL, 8729))
        assertEquals(18443, row.tlsPinPortFor(RouterTransport.API_SSL))
        assertNull(row.tlsPinPortFor(RouterTransport.REST_HTTPS))
    }

    @Test fun winboxNeverConsumesTlsPinsEvenWhenTheProfileHasOldTlsValues() {
        val row = profile(activeTransport = "WINBOX_CLI")
        assertNull(row.tlsPinFor(RouterTransport.WINBOX_CLI, 8291))
        assertNull(row.tlsPinPortFor(RouterTransport.WINBOX_CLI))
    }

    @Test fun legacyAutoProfileWithoutRecordedTransportMustReconfirmItsPin() {
        val row = profile(activeTransport = null, restPin = null, restPort = null, apiPin = null, apiPort = null)
        assertNull(row.tlsPinFor(RouterTransport.REST_HTTPS, 18443))
        assertNull(row.tlsPinFor(RouterTransport.API_SSL, 18443))
        assertNull(row.tlsPinPortFor(RouterTransport.REST_HTTPS))
        assertNull(row.tlsPinPortFor(RouterTransport.API_SSL))
    }

    @Test fun mutableFixedProtocolModeCannotReassignAnUnscopedLegacyPinAtRuntime() {
        val rest = profile(activeTransport = null, restPin = null, restPort = null, apiPin = null, apiPort = null)
            .copy(connectionMode = "REST_HTTPS")
        val api = profile(activeTransport = null, restPin = null, restPort = null, apiPin = null, apiPort = null)
            .copy(connectionMode = "API_SSL")
        assertNull(rest.tlsPinFor(RouterTransport.REST_HTTPS, 18443))
        assertNull(api.tlsPinFor(RouterTransport.API_SSL, 18443))
    }
}
