package com.multicloud.mcm

import com.multicloud.mcm.routeros.RouterOsApiCodec
import java.io.ByteArrayInputStream
import java.io.DataInputStream
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RouterOsApiCodecTest {
    @Test fun recognizesModernLoginCredentialRejection() {
        assertTrue(RouterOsApiCodec.isCredentialRejected(listOf("!trap", "=message=invalid user name or password (6)")))
        assertTrue(RouterOsApiCodec.isCredentialRejected(listOf("!fatal", "=message=login failure")))
    }

    @Test fun doesNotTreatLegacyLoginSyntaxTrapAsBadPassword() {
        assertFalse(RouterOsApiCodec.isCredentialRejected(listOf("!trap", "=message=unknown parameter name")))
        assertFalse(RouterOsApiCodec.isCredentialRejected(listOf("!done", "=ret=1234")))
    }

    @Test fun computesUtf8SentenceSizeForResponseBudget() {
        assertEquals(8, RouterOsApiCodec.sentenceUtf8Bytes(listOf("ok", "mạng")))
    }

    @Test fun rejectsOversizedApiWordBeforeAllocatingItsPayload() {
        // 1 MiB + 1 encoded as a RouterOS length prefix; the payload intentionally is absent.
        val oversizedLength = 1024 * 1024 + 1
        val prefix = byteArrayOf(
            0xF0.toByte(),
            (oversizedLength ushr 24).toByte(),
            (oversizedLength ushr 16).toByte(),
            (oversizedLength ushr 8).toByte(),
            oversizedLength.toByte()
        )
        assertThrows(IllegalArgumentException::class.java) {
            RouterOsApiCodec.readSentence(DataInputStream(ByteArrayInputStream(prefix)))
        }
    }

    @Test fun extractsLegacyChallengeReturnedWithDone() {
        assertEquals("93b438ec9b80057c06dd9fe67d56aa9a", RouterOsApiCodec.legacyChallenge(
            listOf("!done", "=ret=93b438ec9b80057c06dd9fe67d56aa9a")
        ))
        assertNull(RouterOsApiCodec.legacyChallenge(listOf("!done")))
        assertNull(RouterOsApiCodec.legacyChallenge(listOf("!done", "=ret=not-hex")))
    }
}
