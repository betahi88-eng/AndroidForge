package com.multicloud.mcm

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class InterfaceMetricKeyTest {
    @Test fun encodesInterfaceNameAsStableUrlSafeMetricKey() {
        assertEquals(
            "interface_rx_mbps_cHBwb2Utb3V0MQ",
            McmHistoryStore.interfaceMetricKey("rx", "pppoe-out1")
        )
        assertEquals(
            "interface_tx_mbps_ZXRoZXIx",
            McmHistoryStore.interfaceMetricKey("tx", "ether1")
        )
        assertEquals(
            "interface_rx_mbps_dmxhbi0xMA",
            McmHistoryStore.interfaceMetricKey("rx", "vlan-10")
        )
    }

    @Test fun rejectsInvalidDirectionAndBlankName() {
        assertThrows(IllegalArgumentException::class.java) {
            McmHistoryStore.interfaceMetricKey("down", "ether1")
        }
        assertThrows(IllegalArgumentException::class.java) {
            McmHistoryStore.interfaceMetricKey("rx", " ")
        }
    }
}
