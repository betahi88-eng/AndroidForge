package com.multicloud.mcm

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RouterOs7RepositoryTest {
    @Test
    fun parsesCompleteInterfaceRow() {
        val row = JSONObject()
            .put("name", "ether1-WAN")
            .put("type", "ether")
            .put("running", "true")
            .put("rx-byte", "1024")
            .put("tx-byte", "2048")
            .put("last-link-up-time", "00:12:34")

        val result = row.toInterfaceSnapshotOrNull()

        assertEquals("ether1-WAN", result?.name)
        assertEquals("ether", result?.type)
        assertTrue(result?.running == true)
        assertEquals(1024L, result?.rxBytes)
        assertEquals(2048L, result?.txBytes)
        assertEquals("00:12:34", result?.lastLinkUpTime)
    }

    @Test
    fun nullableOptionalFieldsUseSafeDefaults() {
        val row = JSONObject().put("name", "bridge-LAN")

        val result = row.toInterfaceSnapshotOrNull()

        assertEquals("bridge-LAN", result?.name)
        assertEquals("", result?.type)
        assertFalse(result?.running ?: true)
        assertNull(result?.rxBytes)
        assertNull(result?.txBytes)
        assertNull(result?.lastLinkUpTime)
    }

    @Test
    fun rejectsRowsWithoutAnInterfaceName() {
        assertNull(JSONObject().put("type", "ether").toInterfaceSnapshotOrNull())
    }

    @Test
    fun invalidRunningValueDefaultsToFalseAndInvalidCountersToNull() {
        val row = JSONObject()
            .put("name", "ether2")
            .put("running", "unknown")
            .put("rx-byte", "not-a-number")

        val result = row.toInterfaceSnapshotOrNull()

        assertFalse(result?.running ?: true)
        assertNull(result?.rxBytes)
    }
}
