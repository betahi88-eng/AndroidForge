package com.multicloud.mcm

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test
import java.io.ByteArrayInputStream

class RouterOs7ClientTest {
    @Test
    fun normalizesColonSeparatedAndWhitespaceSeparatedSha256Pins() {
        val compact = "0123456789ABCDEF".repeat(4)
        val colonSeparated = compact.chunked(2).joinToString(":")
        val whitespaceSeparated = compact.chunked(4).joinToString(" ")

        assertEquals(compact, RouterOs7Client.normalizePin(colonSeparated))
        assertEquals(compact, RouterOs7Client.normalizePin(whitespaceSeparated))
    }

    @Test
    fun rejectsMalformedSha256Pins() {
        assertThrows(IllegalArgumentException::class.java) {
            RouterOs7Client.normalizePin("not-a-certificate-fingerprint")
        }
    }

    @Test
    fun restResponseReaderBoundsDeclaredAndStreamedBodies() {
        assertEquals("[]", RestResponseBounds.readUtf8(ByteArrayInputStream("[]".toByteArray()), 2, 4))
        assertEquals(null, RestResponseBounds.readUtf8(ByteArrayInputStream("12345".toByteArray()), -1, 4))
        assertEquals(null, RestResponseBounds.readUtf8(ByteArrayInputStream(ByteArray(0)), 5, 4))
    }

    @Test
    fun restRowLimitIsBounded() {
        assertEquals(true, RestResponseBounds.allowsRows(10_000))
        assertEquals(false, RestResponseBounds.allowsRows(10_001))
        assertEquals(false, RestResponseBounds.allowsRows(-1))
    }
}
