package com.multicloud.mcm

import com.multicloud.mcm.security.PinnedTlsHostnameVerifier
import com.multicloud.mcm.security.RouterTlsHostnameVerifier
import com.multicloud.mcm.security.Sha256PinnedTrustManager
import org.junit.Assert.assertThrows
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate

class PinnedTlsPolicyTest {
    private fun fixture(): X509Certificate = javaClass.getResourceAsStream("/tls/routeros-selfsigned-cn-mismatch.fixture")!!.use {
        CertificateFactory.getInstance("X.509").generateCertificate(it) as X509Certificate
    }

    @Test fun acceptsSelfSignedCertificateOnlyWhenItsExactSha256PinMatches() {
        val certificate = fixture()
        val pin = RouterOs7Client.sha256(certificate.encoded)
        Sha256PinnedTrustManager(pin).checkServerTrusted(arrayOf(certificate), "RSA")
        assertThrows(java.security.cert.CertificateException::class.java) {
            Sha256PinnedTrustManager("00".repeat(32)).checkServerTrusted(arrayOf(certificate), "RSA")
        }
    }

    @Test fun exactPinStillRequiresCertificateValidityWindow() {
        val certificate = fixture()
        certificate.checkValidity()
        Sha256PinnedTrustManager(RouterOs7Client.sha256(certificate.encoded))
            .checkServerTrusted(arrayOf(certificate), "RSA")
    }

    @Test fun hostnameVerifierFailsClosedWhenSessionOrHostnameIsMissing() {
        assertFalse(PinnedTlsHostnameVerifier.verify("example.sn.mynetname.net", null))
        assertFalse(PinnedTlsHostnameVerifier.verify(null, null))
    }

    private fun sanFixture(): X509Certificate = javaClass.getResourceAsStream("/tls/routeros-hostname-san.fixture")!!.use {
        CertificateFactory.getInstance("X.509").generateCertificate(it) as X509Certificate
    }

    @Test fun dnsSanMustMatchAndOverridesMismatchingCommonName() {
        val cert = sanFixture()
        assertTrue(RouterTlsHostnameVerifier.verifyCertificate("router.example.test", cert))
        assertFalse(RouterTlsHostnameVerifier.verifyCertificate("router-local-only", cert))
        assertFalse(RouterTlsHostnameVerifier.verifyCertificate("other.example.test", cert))
    }

    @Test fun wildcardSanMatchesExactlyOneLeftmostLabel() {
        val cert = sanFixture()
        assertTrue(RouterTlsHostnameVerifier.verifyCertificate("edge.wild.example.test", cert))
        assertFalse(RouterTlsHostnameVerifier.verifyCertificate("wild.example.test", cert))
        assertFalse(RouterTlsHostnameVerifier.verifyCertificate("a.edge.wild.example.test", cert))
    }

    @Test fun ipAddressRequiresMatchingIpSan() {
        val cert = sanFixture()
        assertTrue(RouterTlsHostnameVerifier.verifyCertificate("127.0.0.1", cert))
        assertFalse(RouterTlsHostnameVerifier.verifyCertificate("127.0.0.2", cert))
    }

    @Test fun malformedHostnameAndMissingHostnameFailClosed() {
        val cert = sanFixture()
        assertFalse(RouterTlsHostnameVerifier.verifyCertificate(null, cert))
        assertFalse(RouterTlsHostnameVerifier.verifyCertificate("bad host", cert))
        assertFalse(RouterTlsHostnameVerifier.verifyCertificate("*", cert))
        assertFalse(RouterTlsHostnameVerifier.verifyCertificate("*.wild.example.test", cert))
    }

    @Test fun testFixtureReallyHasLocalOnlyCertificateName() {
        assertTrue(fixture().subjectX500Principal.name.contains("router-local-only"))
        assertTrue(RouterTlsHostnameVerifier.verifyCertificate("router-local-only", fixture()))
        assertFalse(RouterTlsHostnameVerifier.verifyCertificate("hmd0b6sqg3r.sn.mynetname.net", fixture()))
    }
}
