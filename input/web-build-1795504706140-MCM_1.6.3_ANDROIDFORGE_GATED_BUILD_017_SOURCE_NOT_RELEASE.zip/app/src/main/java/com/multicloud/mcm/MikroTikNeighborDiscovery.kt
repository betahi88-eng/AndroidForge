package com.multicloud.mcm

import android.content.Context
import android.net.wifi.WifiManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketTimeoutException

/** Passive/active MNDP discovery on the current Layer-2 Wi-Fi network. Never changes router config. */
class MikroTikNeighborDiscovery(private val context: Context) {
    suspend fun scan(timeoutMs: Int = 4_000): JSONArray = withContext(Dispatchers.IO) {
        require(timeoutMs in 1_000..10_000)
        val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val lock = wifi.createMulticastLock("mcm-mndp-discovery").apply { setReferenceCounted(false); acquire() }
        try {
            val found = linkedMapOf<String, JSONObject>()
            DatagramSocket(null).use { socket ->
                socket.reuseAddress = true
                socket.broadcast = true
                socket.soTimeout = 250
                socket.bind(InetSocketAddress(MNDP_PORT))
                val request = ByteArray(4)
                repeat(3) {
                    socket.send(DatagramPacket(request, request.size, InetAddress.getByName("255.255.255.255"), MNDP_PORT))
                    Thread.sleep(120)
                }
                val deadline = System.currentTimeMillis() + timeoutMs
                val buffer = ByteArray(4096)
                while (System.currentTimeMillis() < deadline) {
                    try {
                        val packet = DatagramPacket(buffer, buffer.size)
                        socket.receive(packet)
                        val parsed = MndpPacketParser.parse(packet.data, packet.offset, packet.length, packet.address.hostAddress.orEmpty())
                            ?: continue
                        val key = parsed.mac.ifBlank { parsed.sourceIp }
                        if (key.isNotBlank()) found[key] = parsed.toJson()
                    } catch (_: SocketTimeoutException) {
                        // Keep receiving until the bounded scan deadline.
                    }
                }
            }
            JSONArray().apply { found.values.forEach(::put) }
        } finally {
            if (lock.isHeld) lock.release()
        }
    }

    companion object { private const val MNDP_PORT = 5678 }
}

/** MNDP wire parser: four-byte header followed by big-endian type/length/value TLVs. */
internal data class MndpNeighbor(
    val sourceIp: String,
    val mac: String = "",
    val identity: String = "",
    val version: String = "",
    val platform: String = "",
    val uptime: String = "",
    val board: String = "",
    val interfaceName: String = "",
    val advertisedIp: String = "",
    val advertisedIpv6: String = ""
) {
    fun toJson(): JSONObject = JSONObject()
        .put("ip", sourceIp).put("mac", mac).put("identity", identity)
        .put("version", version).put("platform", platform).put("uptime", uptime)
        .put("board", board).put("interface", interfaceName)
        .put("advertisedIp", advertisedIp).put("advertisedIpv6", advertisedIpv6)
}

internal object MndpPacketParser {
    fun parse(data: ByteArray, offset: Int, length: Int, sourceIp: String): MndpNeighbor? {
        if (length < 8 || offset < 0 || offset + length > data.size) return null
        var cursor = offset + 4
        val end = offset + length
        var mac = ""
        var identity = ""
        var version = ""
        var platform = ""
        var uptime = ""
        var board = ""
        var interfaceName = ""
        var advertisedIp = ""
        var advertisedIpv6 = ""
        while (cursor + 4 <= end) {
            val type = u16(data, cursor)
            val size = u16(data, cursor + 2)
            cursor += 4
            if (size < 0 || cursor + size > end) return null
            val value = data.copyOfRange(cursor, cursor + size)
            cursor += size
            when (type) {
                1 -> if (size == 6) mac = value.joinToString(":") { "%02X".format(it.toInt() and 0xff) }
                5 -> identity = value.utf8()
                7 -> version = value.utf8()
                8 -> platform = value.utf8()
                10 -> if (size == 4) uptime = formatUptime(value)
                12 -> board = value.utf8()
                15 -> if (size == 16) advertisedIpv6 = runCatching {
                    java.net.InetAddress.getByAddress(value).hostAddress.orEmpty()
                }.getOrDefault("")
                16 -> interfaceName = value.utf8()
                17 -> if (size == 4) advertisedIp = value.joinToString(".") { (it.toInt() and 0xff).toString() }
            }
        }
        if (cursor != end) return null
        return MndpNeighbor(sourceIp, mac, identity, version, platform, uptime, board, interfaceName, advertisedIp, advertisedIpv6)
            .takeIf { it.identity.isNotBlank() || it.mac.isNotBlank() || it.board.isNotBlank() }
    }

    private fun u16(bytes: ByteArray, index: Int): Int =
        ((bytes[index].toInt() and 0xff) shl 8) or (bytes[index + 1].toInt() and 0xff)

    private fun formatUptime(bytes: ByteArray): String {
        val seconds = (bytes[0].toLong() and 0xff) or
            ((bytes[1].toLong() and 0xff) shl 8) or
            ((bytes[2].toLong() and 0xff) shl 16) or
            ((bytes[3].toLong() and 0xff) shl 24)
        val days = seconds / 86_400
        val hours = (seconds % 86_400) / 3_600
        val minutes = (seconds % 3_600) / 60
        val remainingSeconds = seconds % 60
        return if (days > 0) "${days}d ${hours}h ${minutes}m" else "${hours}h ${minutes}m ${remainingSeconds}s"
    }

    private fun ByteArray.utf8(): String = toString(Charsets.UTF_8).trim().take(256)
}
