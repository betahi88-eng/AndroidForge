package com.multicloud.mcm

import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import androidx.webkit.WebViewAssetLoader
import java.io.ByteArrayInputStream

/** Keeps the WebView and its privileged JS bridge confined to packaged, same-origin assets. */
class McmAssetWebViewClient(
    private val assetLoader: WebViewAssetLoader
) : android.webkit.WebViewClient() {
    override fun shouldInterceptRequest(
        view: WebView?,
        request: WebResourceRequest?
    ): WebResourceResponse? {
        val uri = request?.url ?: return blockedResponse()
        val localAsset = uri.scheme.equals("https", true) &&
            uri.host.equals(ASSET_HOST, true) &&
            (uri.port == -1 || uri.port == 443) &&
            uri.userInfo == null &&
            uri.path?.startsWith(ASSET_PREFIX) == true
        if (!localAsset) return blockedResponse()
        return assetLoader.shouldInterceptRequest(uri) ?: blockedResponse()
    }

    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
        val uri = request?.url ?: return true
        return !(uri.scheme.equals("https", true) && uri.host.equals(ASSET_HOST, true) &&
            (uri.port == -1 || uri.port == 443) && uri.userInfo == null &&
            uri.path?.startsWith(ASSET_PREFIX) == true)
    }

    private fun blockedResponse() = WebResourceResponse(
        "text/plain", "UTF-8", 403, "Blocked", emptyMap(), ByteArrayInputStream(ByteArray(0))
    )

    companion object {
        private const val ASSET_HOST = "appassets.androidplatform.net"
        private const val ASSET_PREFIX = "/assets/"
    }
}
