package com.multicloud.mcm

import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLSocket

/** A DNS failure is classified without merging authoritative NXDOMAIN with a network timeout. */
class DnsResolutionException(
    val failureCode: String,
    message: String,
    cause: Throwable? = null
) : UnknownHostException(message) {
    init { if (cause != null) initCause(cause) }
}

internal class SystemFirstDnsChain(
    private val systemLookup: (String) -> List<InetAddress>,
    private val googleLookup: (String) -> List<InetAddress>,
    private val cloudflareLookup: (String) -> List<InetAddress>
) {
    fun resolve(host: String): RouterDnsResolver.Resolution {
        var systemFailure: Throwable? = null
        try {
            val addresses = systemLookup(host).distinctBy { it.hostAddress }
            if (addresses.isNotEmpty()) return RouterDnsResolver.Resolution(addresses, "ANDROID_SYSTEM")
            systemFailure = UnknownHostException("Android DNS returned no addresses for $host")
        } catch (error: Exception) {
            systemFailure = error
        }

        var googleFailure: Throwable? = null
        try {
            val addresses = googleLookup(host).distinctBy { it.hostAddress }
            if (addresses.isNotEmpty()) return RouterDnsResolver.Resolution(addresses, "GOOGLE_DOH")
            googleFailure = UnknownHostException("Google DoH returned no A/AAAA records for $host")
        } catch (error: Exception) {
            googleFailure = error
        }

        var cloudflareFailure: Throwable? = null
        try {
            val addresses = cloudflareLookup(host).distinctBy { it.hostAddress }
            if (addresses.isNotEmpty()) return RouterDnsResolver.Resolution(addresses, "CLOUDFLARE_DOH")
            cloudflareFailure = UnknownHostException("Cloudflare DoH returned no A/AAAA records for $host")
        } catch (error: Exception) {
            cloudflareFailure = error
        }

        val failures = listOfNotNull(systemFailure, googleFailure, cloudflareFailure)
        val allTimedOut = failures.isNotEmpty() && failures.all(::isTimeout)
        val code = if (allTimedOut) "NETWORK_TIMEOUT" else "DNS_FAILED"
        throw DnsResolutionException(
            code,
            "Could not resolve $host. Android DNS=${describe(systemFailure)}; Google DoH=${describe(googleFailure)}; Cloudflare DoH=${describe(cloudflareFailure)}.",
            failures.firstOrNull()
        )
    }

    private fun isTimeout(error: Throwable): Boolean =
        error is SocketTimeoutException || error is java.util.concurrent.TimeoutException ||
            error.cause?.let(::isTimeout) == true

    private fun describe(error: Throwable?): String = error?.let {
        val detail = it.message?.replace(Regex("[\\r\\n\\t]+"), " ")?.take(180).orEmpty()
        if (detail.isBlank()) it.javaClass.simpleName else "${it.javaClass.simpleName}: $detail"
    } ?: "no result"
}

/** Shared resolver for diagnostics, REST, API-SSL and TLS inspection. */
object RouterDnsResolver {
    data class Resolution(val addresses: List<InetAddress>, val source: String)

    private val executor = Executors.newFixedThreadPool(2) { runnable ->
        Thread(runnable, "mcm-android-dns").apply { isDaemon = true }
    }

    private val resolutionChain by lazy {
        SystemFirstDnsChain(
            systemLookup = { host ->
                val future = executor.submit<List<InetAddress>> { InetAddress.getAllByName(host).toList() }
                try {
                    future.get(2, TimeUnit.SECONDS)
                } catch (error: java.util.concurrent.TimeoutException) {
                    future.cancel(true)
                    throw SocketTimeoutException("Android DNS lookup exceeded 2 seconds").apply { initCause(error) }
                } catch (error: java.util.concurrent.ExecutionException) {
                    throw (error.cause as? Exception ?: error)
                }
            },
            googleLookup = DohDnsResolver::resolveGoogle,
            cloudflareLookup = DohDnsResolver::resolveCloudflare
        )
    }

    fun resolve(rawHost: String): List<InetAddress> = resolveDetailed(rawHost).addresses

    fun resolveDetailed(rawHost: String): Resolution {
        val host = RouterHostValidator.normalize(rawHost)
        if (isIpLiteral(host)) {
            val literal = host.removePrefix("[").removeSuffix("]")
            return Resolution(listOf(InetAddress.getByName(literal)), "IP_LITERAL")
        }
        return resolutionChain.resolve(host)
    }

    /** Preserve DDNS SNI. The endpoint identity is authenticated by the independently confirmed SHA-256 leaf pin. */
    fun configureSni(socket: SSLSocket, rawHost: String) {
        val host = RouterHostValidator.normalize(rawHost)
        if (isIpLiteral(host)) return
        val parameters = socket.sslParameters
        parameters.serverNames = listOf(SNIHostName(host))
        socket.sslParameters = parameters
    }

    fun isIpLiteral(host: String): Boolean = runCatching {
        val candidate = host.removePrefix("[").removeSuffix("]")
        if (candidate.contains(':')) InetAddress.getByName(candidate).address.size == 16
        else {
            val parts = candidate.split('.')
            parts.size == 4 && parts.all { it.toIntOrNull()?.let { value -> value in 0..255 } == true }
        }
    }.getOrDefault(false)
}
