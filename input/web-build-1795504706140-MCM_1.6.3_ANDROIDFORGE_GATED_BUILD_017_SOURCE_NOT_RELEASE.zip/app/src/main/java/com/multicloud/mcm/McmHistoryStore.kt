package com.multicloud.mcm

import com.multicloud.mcm.data.McmDatabase
import com.multicloud.mcm.data.MetricHistoryEntity
import org.json.JSONArray
import org.json.JSONObject

class McmHistoryStore(private val database: McmDatabase) {
    suspend fun record(routerId: String, key: String, value: Double, unit: String, atEpochMs: Long) {
        database.metricDao().insert(
            MetricHistoryEntity(
                routerId = routerId,
                metricKey = key,
                value = value,
                unit = unit,
                recordedAtEpochMs = atEpochMs
            )
        )
        database.metricDao().deleteBefore(atEpochMs - RETENTION_MS)
    }

    suspend fun read(routerId: String, metricKey: String): JSONObject {
        require(
            metricKey in ALLOWED_KEYS || INTERFACE_METRIC_KEY.matches(metricKey)
        ) { "Metric key không hợp lệ." }
        val samples = database.metricDao().recent(routerId, metricKey, HISTORY_LIMIT).reversed()
        val points = JSONArray()
        samples.forEach { sample ->
            points.put(JSONObject().put("at", sample.recordedAtEpochMs).put("value", sample.value))
        }
        return JSONObject().put("ok", true).put("metric", metricKey).put("points", points)
    }

    companion object {
        private const val RETENTION_MS = 30L * 24L * 60L * 60L * 1_000L
        private const val HISTORY_LIMIT = 60
        private val ALLOWED_KEYS = setOf(
            "cpu_load", "memory_used", "icmp_loss", "pppoe_active",
            "arp_entries", "dhcp_leases", "netwatch_down"
        )
        private val INTERFACE_METRIC_KEY = Regex("interface_(rx|tx)_mbps_[A-Za-z0-9_-]{1,512}")

        /** Stable, SQL-safe history key for one interface and one direction. */
        fun interfaceMetricKey(direction: String, interfaceName: String): String {
            require(direction == "rx" || direction == "tx") { "Interface direction must be rx or tx." }
            require(interfaceName.isNotBlank()) { "Interface name is required." }
            val encoded = java.util.Base64.getUrlEncoder().withoutPadding()
                .encodeToString(interfaceName.toByteArray(Charsets.UTF_8))
            return "interface_${direction}_mbps_$encoded"
        }
    }
}
