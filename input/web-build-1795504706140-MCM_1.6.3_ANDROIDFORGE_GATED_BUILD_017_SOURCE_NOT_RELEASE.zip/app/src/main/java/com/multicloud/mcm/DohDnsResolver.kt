package com.multicloud.mcm

import okhttp3.Dns
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Google DoH followed by Cloudflare DoH. Each provider has a hard three-second budget. */
internal object DohDnsResolver {
    private data class Provider(
        val host: String,
        val path: String,
        val bootstrap: List<ByteArray>
    )

    private val google = Provider(
        host = "dns.google",
        path = "/resolve",
        bootstrap = listOf(
            byteArrayOf(8, 8, 8, 8), byteArrayOf(8, 8, 4, 4),
            addressBytes(0x20, 0x01, 0x48, 0x60, 0x48, 0x60, 0, 0, 0, 0, 0, 0, 0, 0, 0x88, 0x88),
            addressBytes(0x20, 0x01, 0x48, 0x60, 0x48, 0x60, 0, 0, 0, 0, 0, 0, 0, 0, 0x88, 0x44)
        )
    )
    private val cloudflare = Provider(
        host = "cloudflare-dns.com",
        path = "/dns-query",
        bootstrap = listOf(
            byteArrayOf(1, 1, 1, 1), byteArrayOf(1, 0, 0, 1),
            addressBytes(0x26, 0x06, 0x47, 0, 0x47, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x11, 0x11),
            addressBytes(0x26, 0x06, 0x47, 0, 0x47, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x10, 0x01)
        )
    )

    private val queryPool = Executors.newFixedThreadPool(4) { runnable ->
        Thread(runnable, "mcm-doh-query").apply { isDaemon = true }
    }

    fun resolveGoogle(host: String): List<InetAddress> = resolveProvider(google, host)

    fun resolveCloudflare(host: String): List<InetAddress> = resolveProvider(cloudflare, host)

    private fun resolveProvider(provider: Provider, host: String): List<InetAddress> {
        val client = OkHttpClient.Builder()
            .dns(object : Dns {
                override fun lookup(hostname: String): List<InetAddress> {
                    if (!hostname.equals(provider.host, ignoreCase = true)) return Dns.SYSTEM.lookup(hostname)
                    return provider.bootstrap.map(InetAddress::getByAddress)
                }
            })
            .connectTimeout(1500, TimeUnit.MILLISECONDS)
            .readTimeout(1500, TimeUnit.MILLISECONDS)
            .writeTimeout(1500, TimeUnit.MILLISECONDS)
            .callTimeout(3000, TimeUnit.MILLISECONDS)
            .retryOnConnectionFailure(false)
            .build()

        val futures = listOf("A", "AAAA").map { type ->
            queryPool.submit(Callable { query(client, provider, host, type) })
        }
        val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(3)
        val addresses = linkedMapOf<String, InetAddress>()
        var sawTimeout = false
        for (future in futures) {
            val remaining = deadline - System.nanoTime()
            if (remaining <= 0) {
                sawTimeout = true
                future.cancel(true)
                continue
            }
            try {
                future.get(remaining, TimeUnit.NANOSECONDS).forEach { address ->
                    addresses.putIfAbsent(address.hostAddress, address)
                }
            } catch (_: java.util.concurrent.TimeoutException) {
                sawTimeout = true
                future.cancel(true)
            } catch (_: Exception) {
                // The other address family may still succeed.
            }
        }
        if (addresses.isEmpty() && sawTimeout) {
            throw SocketTimeoutException("${provider.host} DoH timed out after 3 seconds")
        }
        return addresses.values.toList()
    }

    private fun query(client: OkHttpClient, provider: Provider, host: String, recordType: String): List<InetAddress> {
        val url = "https://${provider.host}${provider.path}".toHttpUrl().newBuilder()
            .addQueryParameter("name", host)
            .addQueryParameter("type", recordType)
            .build()
        val request = Request.Builder()
            .url(url)
            .header("Accept", "application/dns-json")
            .get()
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("${provider.host} returned HTTP ${response.code}")
            val body = response.body?.string() ?: throw IOException("${provider.host} returned an empty DNS response")
            val json = JSONObject(body)
            if (json.optInt("Status", -1) != 0) return emptyList()
            val answers = json.optJSONArray("Answer") ?: return emptyList()
            val results = linkedMapOf<String, InetAddress>()
            for (index in 0 until answers.length()) {
                val answer = answers.optJSONObject(index) ?: continue
                val address = parseAddress(answer.optString("data").trim(), answer.optInt("type")) ?: continue
                results.putIfAbsent(address.hostAddress, address)
            }
            return results.values.toList()
        }
    }

    private fun parseAddress(value: String, type: Int): InetAddress? = when (type) {
        1 -> parseIpv4(value)
        28 -> parseIpv6(value)
        else -> null
    }

    private fun parseIpv4(value: String): InetAddress? {
        val parts = value.split('.')
        if (parts.size != 4) return null
        val bytes = ByteArray(4)
        for (index in parts.indices) {
            val octet = parts[index].toIntOrNull() ?: return null
            if (octet !in 0..255) return null
            bytes[index] = octet.toByte()
        }
        return InetAddress.getByAddress(bytes)
    }

    private fun parseIpv6(value: String): InetAddress? {
        if (!value.contains(':') || !value.matches(Regex("[0-9a-fA-F:]+"))) return null
        return runCatching { InetAddress.getByName(value) }
            .getOrNull()
            ?.takeIf { it.address.size == 16 }
    }

    private fun addressBytes(vararg octets: Int): ByteArray = ByteArray(octets.size) { octets[it].toByte() }
}
