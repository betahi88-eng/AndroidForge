package com.multicloud.mcm.routeros

import com.multicloud.mcm.McmResult
import com.multicloud.mcm.PingMeasurement
import org.json.JSONArray
import org.json.JSONObject

/** Parses RouterOS ping's cumulative counters; never treats result-row count as sent count. */
object PingResponseParser {
    fun parse(
        target: String,
        rows: JSONArray,
        expectedSent: Int? = null,
        now: Long = System.currentTimeMillis()
    ): McmResult<PingMeasurement> {
        var finalCounters: Pair<Int, Int>? = null
        var previousReceived = 0
        val sequences = mutableSetOf<Int>()
        val rtts = mutableListOf<Double>()

        for (index in 0 until rows.length()) {
            val row = rows.optJSONObject(index)
                ?: return McmResult.Failure("PING_INVALID", "RouterOS trả bản ghi ping không hợp lệ.")
            if (!row.has("sent") || !row.has("received")) {
                return McmResult.Failure("PING_INVALID", "RouterOS trả thiếu bộ đếm sent/received.")
            }
            val sequence = row.optString("seq").trim().toIntOrNull()
                ?: return McmResult.Failure("PING_INVALID", "RouterOS trả echo reply thiếu sequence hợp lệ.")
            if (sequence < 0 || !sequences.add(sequence)) {
                return McmResult.Failure("PING_INVALID", "RouterOS trả sequence ping trùng hoặc không hợp lệ.")
            }
            if (row.optString("host").isBlank()) {
                return McmResult.Failure("PING_INVALID", "RouterOS trả echo reply thiếu host.")
            }
            val rowSent = parseCounter(row, "sent")
                ?: return McmResult.Failure("PING_INVALID", "Bộ đếm sent không hợp lệ.")
            val rowReceived = parseCounter(row, "received")
                ?: return McmResult.Failure("PING_INVALID", "Bộ đếm received không hợp lệ.")
            if (rowSent <= 0 || rowReceived !in 0..rowSent) {
                return McmResult.Failure("PING_INVALID", "Bộ đếm ICMP sent/received không hợp lệ.")
            }
            val previous = finalCounters
            if (previous != null && (rowSent < previous.first || rowReceived < previous.second)) {
                return McmResult.Failure("PING_INVALID", "Bộ đếm ICMP bị giảm giữa phép đo.")
            }
            if (rowReceived != previousReceived + 1) {
                return McmResult.Failure("PING_INVALID", "Bộ đếm received không khớp số echo reply RouterOS trả về.")
            }
            previousReceived = rowReceived
            finalCounters = rowSent to rowReceived
            val rtt = parseDurationMs(row.optString("time"))
                ?: return McmResult.Failure("PING_INVALID", "Bản ghi echo reply thiếu thời gian hợp lệ.")
            rtts.add(rtt)
        }

        val counters = finalCounters
            ?: return McmResult.Failure("PING_INVALID", "RouterOS không trả cặp bộ đếm sent/received; không thể xác định packet loss.")
        val finalSent = counters.first
        val finalReceived = counters.second
        if (finalSent <= 0 || finalReceived !in 0..finalSent) {
            return McmResult.Failure("PING_INVALID", "Bộ đếm ICMP sent/received không hợp lệ.")
        }
        if (expectedSent != null && finalSent != expectedSent) {
            return McmResult.Failure(
                "PING_INCOMPLETE",
                "Router chỉ xác nhận $finalSent/$expectedSent gói đã gửi; không tính packet loss từ mẫu chưa hoàn tất."
            )
        }
        if (finalReceived != rows.length()) {
            return McmResult.Failure(
                "PING_INVALID",
                "Bộ đếm received không khớp số bản ghi echo reply; từ chối phép đo không nhất quán."
            )
        }

        return McmResult.Success(
            PingMeasurement.fromCounts(
                target = target,
                sent = finalSent,
                received = finalReceived,
                minRtt = rtts.minOrNull(),
                avgRtt = rtts.average().takeIf { rtts.isNotEmpty() },
                maxRtt = rtts.maxOrNull(),
                now = now
            )
        )
    }

    private fun parseCounter(row: JSONObject, key: String): Int? {
        if (!row.has(key)) return null
        return row.optString(key).trim().toIntOrNull()?.takeIf { it >= 0 }
    }

    /** RouterOS durations such as 453us, 1.2ms, 1s. */
    fun parseDurationMs(raw: String?): Double? {
        val value = raw?.trim()?.lowercase() ?: return null
        val tokens = Regex("([0-9]+(?:\\.[0-9]+)?)(ms|us|µs|s)").findAll(value).toList()
        if (tokens.isEmpty() || tokens.joinToString("") { it.value } != value) return null
        var totalMilliseconds = 0.0
        for (token in tokens) {
            val amount = token.groupValues[1].toDoubleOrNull() ?: return null
            totalMilliseconds += when (token.groupValues[2]) {
                "us", "µs" -> amount / 1_000.0
                "ms" -> amount
                "s" -> amount * 1_000.0
                else -> return null
            }
        }
        return totalMilliseconds
    }
}
