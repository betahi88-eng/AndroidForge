package com.multicloud.mcm

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import org.json.JSONObject

/** Describes Android's active network only; it does not claim a VPN route to any router. */
class McmNetworkState(context: Context) {
    private val connectivity = context.applicationContext
        .getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    fun snapshot(): JSONObject {
        val network = connectivity.activeNetwork
        val capabilities = network?.let(connectivity::getNetworkCapabilities)
        val vpn = capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
        val wifi = capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        val cellular = capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
        val ethernet = capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true
        val validated = capabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
        val transport = when {
            vpn -> "VPN"
            wifi -> "WIFI"
            ethernet -> "ETHERNET"
            cellular -> "CELLULAR"
            else -> "UNKNOWN"
        }
        return JSONObject()
            .put("transport", transport)
            .put("vpnActive", vpn)
            .put("internetValidated", validated)
            .put("networkAvailable", capabilities != null)
    }
}
