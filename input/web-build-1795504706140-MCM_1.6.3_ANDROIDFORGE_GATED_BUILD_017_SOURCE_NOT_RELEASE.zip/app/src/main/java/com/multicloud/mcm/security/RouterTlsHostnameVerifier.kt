package com.multicloud.mcm.security

import java.net.IDN
import java.security.cert.X509Certificate
import java.io.ByteArrayOutputStream
import java.nio.charset.StandardCharsets
import javax.security.auth.x500.X500Principal
import javax.net.ssl.SSLPeerUnverifiedException
import javax.net.ssl.SSLSession

/** Strict RFC 6125-style endpoint identity check independent of Android/JVM default-verifier quirks. */
internal object RouterTlsHostnameVerifier {
    fun verify(hostname: String?, session: SSLSession?): Boolean {
        if (hostname.isNullOrBlank() || session == null) return false
        val leaf = try {
            session.peerCertificates.firstOrNull() as? X509Certificate
        } catch (_: SSLPeerUnverifiedException) {
            null
        } ?: return false
        return verifyCertificate(hostname, leaf)
    }

    fun verifyCertificate(hostname: String?, certificate: X509Certificate): Boolean {
        val host = hostname?.trim()?.removeSuffix(".")?.lowercase().orEmpty()
        if (host.isBlank() || host.length > 253 || host.any(Char::isWhitespace)) return false

        val ipBytes = parseIpv4(host)
        val names = try {
            certificate.subjectAlternativeNames.orEmpty()
        } catch (_: Exception) {
            return false
        }

        if (ipBytes != null) {
            // IP identity is only established by an iPAddress SAN, never by a CN or dNSName.
            return names.any { entry ->
                if (entry.size < 2 || (entry[0] as? Number)?.toInt() != 7) return@any false
                val value = entry[1]
                when (value) {
                    is ByteArray -> value.contentEquals(ipBytes)
                    is String -> parseIpv4(value)?.contentEquals(ipBytes) == true
                    else -> false
                }
            }
        }

        val dnsSans = names.mapNotNull { entry ->
            if (entry.size < 2 || (entry[0] as? Number)?.toInt() != 2) null
            else entry[1] as? String
        }
        if (dnsSans.isNotEmpty()) return dnsSans.any { matchesDnsName(host, it) }

        // Legacy CN fallback is permitted only when the certificate has no dNSName SAN.
        val commonName = extractCommonName(certificate.subjectX500Principal)
        return commonName?.let { matchesDnsName(host, it) } ?: false
    }


    /** Parses RFC2253 distinguished names without relying on JNDI, which is not part of Android's API surface. */
    private fun extractCommonName(principal: X500Principal): String? {
        val distinguishedName = try {
            principal.getName(X500Principal.RFC2253)
        } catch (_: Exception) {
            return null
        }
        for (rdn in splitUnescaped(distinguishedName, ',')) {
            for (attribute in splitUnescaped(rdn, '+')) {
                val equals = indexOfUnescaped(attribute, '=')
                if (equals <= 0) continue
                val type = attribute.substring(0, equals).trim()
                if (type.equals("CN", ignoreCase = true) || type == "2.5.4.3") {
                    return decodeDnValue(attribute.substring(equals + 1))
                }
            }
        }
        return null
    }

    private fun splitUnescaped(value: String, delimiter: Char): List<String> {
        val parts = mutableListOf<String>()
        var start = 0
        var index = 0
        while (index < value.length) {
            if (value[index] == '\\') {
                index += if (index + 2 < value.length && value[index + 1].isHexDigit() && value[index + 2].isHexDigit()) 3 else 2
                continue
            }
            if (value[index] == delimiter) {
                parts += value.substring(start, index)
                start = index + 1
            }
            index++
        }
        parts += value.substring(start)
        return parts
    }

    private fun indexOfUnescaped(value: String, target: Char): Int {
        var index = 0
        while (index < value.length) {
            if (value[index] == '\\') {
                index += if (index + 2 < value.length && value[index + 1].isHexDigit() && value[index + 2].isHexDigit()) 3 else 2
                continue
            }
            if (value[index] == target) return index
            index++
        }
        return -1
    }

    private fun decodeDnValue(rawValue: String): String? {
        val value = rawValue.trim().removeSurrounding("\"", "\"")
        if (value.startsWith('#')) return null // DER-encoded attribute values are not treated as DNS names.
        val bytes = ByteArrayOutputStream()
        var index = 0
        while (index < value.length) {
            if (value[index] == '\\' && index + 2 < value.length &&
                value[index + 1].isHexDigit() && value[index + 2].isHexDigit()) {
                bytes.write(value.substring(index + 1, index + 3).toInt(16))
                index += 3
            } else if (value[index] == '\\' && index + 1 < value.length) {
                bytes.write(value.substring(index + 1, index + 2).toByteArray(StandardCharsets.UTF_8))
                index += 2
            } else if (value[index] == '\\') {
                // A trailing escape is malformed. Do not spin with an unchanged index.
                return null
            } else {
                val nextEscape = value.indexOf('\\', index).let { if (it < 0) value.length else it }
                bytes.write(value.substring(index, nextEscape).toByteArray(StandardCharsets.UTF_8))
                index = nextEscape
            }
        }
        return runCatching { bytes.toString(StandardCharsets.UTF_8.name()) }.getOrNull()
    }

    private fun Char.isHexDigit(): Boolean = this in '0'..'9' || this in 'a'..'f' || this in 'A'..'F'

    private fun matchesDnsName(host: String, certificateName: String): Boolean {
        val pattern = certificateName.trim().removeSuffix(".").lowercase()
        if (pattern.isBlank() || pattern.length > 253 || pattern.any(Char::isWhitespace)) return false
        if (!pattern.startsWith("*.")) {
            if (pattern.contains('*')) return false
            val hostAscii = toAscii(host) ?: return false
            val patternAscii = toAscii(pattern) ?: return false
            return hostAscii == patternAscii
        }
        val suffix = pattern.substring(2)
        if (suffix.isBlank() || suffix.contains('*')) return false
        val hostAscii = toAscii(host) ?: return false
        val suffixAscii = toAscii(suffix) ?: return false
        if (!hostAscii.endsWith(".$suffixAscii")) return false
        val prefix = hostAscii.removeSuffix(".$suffixAscii")
        return prefix.isNotBlank() && !prefix.contains('.')
    }

    private fun toAscii(value: String): String? = try {
        IDN.toASCII(value, IDN.USE_STD3_ASCII_RULES).lowercase()
    } catch (_: IllegalArgumentException) {
        null
    }

    private fun parseIpv4(value: String): ByteArray? {
        val parts = value.split('.')
        if (parts.size != 4) return null
        val octets = parts.map { part ->
            if (part.isEmpty() || part.length > 3 || (part.length > 1 && part.startsWith('0'))) return null
            part.toIntOrNull()?.takeIf { it in 0..255 } ?: return null
        }
        return ByteArray(4) { octets[it].toByte() }
    }
}
