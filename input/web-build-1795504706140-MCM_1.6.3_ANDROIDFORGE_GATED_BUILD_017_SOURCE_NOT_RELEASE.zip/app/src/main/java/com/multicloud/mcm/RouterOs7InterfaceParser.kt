package com.multicloud.mcm

import org.json.JSONObject

/** Converts an optional RouterOS REST interface row without unsafe nullable calls. */
internal fun JSONObject.toInterfaceSnapshotOrNull(): InterfaceSnapshot? {
    val interfaceName = readNonBlankString("name") ?: return null
    val interfaceType = readNonBlankString("type") ?: ""
    val runningText = readNonBlankString("running") ?: "false"

    return InterfaceSnapshot(
        name = interfaceName,
        type = interfaceType,
        running = runningText.toBooleanStrictOrNull() ?: false,
        rxBytes = readNonBlankString("rx-byte")?.toLongOrNull(),
        txBytes = readNonBlankString("tx-byte")?.toLongOrNull(),
        lastLinkUpTime = readNonBlankString("last-link-up-time")
    )
}

private fun JSONObject.readNonBlankString(key: String): String? =
    if (!has(key) || isNull(key)) null else optString(key).takeIf(String::isNotBlank)
