package com.multicloud.mcm

import com.multicloud.mcm.routeros.PingResponseParser
import org.json.JSONObject

class RouterOs7Repository(private val client: RouterOs7Client) {
    suspend fun readSystemResource(): McmResult<SystemResource> {
        return when (val result = client.get("system/resource")) {
        is McmResult.Failure -> result
        is McmResult.Success -> {
            val row = result.value.optJSONObject(0)
                ?: return McmResult.Failure("RESOURCE_EMPTY", "Router không trả dữ liệu system/resource.")
            McmResult.Success(
                SystemResource(
                    version = row.stringValue("version"),
                    uptime = row.stringValue("uptime"),
                    cpuLoadPercent = row.stringValue("cpu-load")?.toIntOrNull()?.coerceIn(0, 100),
                    freeMemoryBytes = row.stringValue("free-memory")?.toLongOrNull(),
                    totalMemoryBytes = row.stringValue("total-memory")?.toLongOrNull()
                )
            )
        }
        }
    }

    suspend fun readInterfaces(): McmResult<List<InterfaceSnapshot>> = when (val result = client.get("interface")) {
        is McmResult.Failure -> result
        is McmResult.Success -> {
            val rows = buildList {
                for (i in 0 until result.value.length()) {
                    val row = result.value.optJSONObject(i) ?: continue
                    add(row.toInterfaceSnapshotOrNull() ?: continue)
                }
            }
            McmResult.Success(rows)
        }
    }

    suspend fun readPppoeInterfaces(): McmResult<List<PppoeStatus>> = when (val result = readInterfaces()) {
        is McmResult.Failure -> result
        is McmResult.Success -> McmResult.Success(
            result.value.filter { it.type.contains("pppoe", true) || it.name.contains("pppoe", true) }
                .map { PppoeStatus(it.name, it.running, it.lastLinkUpTime, null) }
        )
    }


    suspend fun readCloudStatus(): McmResult<Map<String, String>> = readFirstRow("ip/cloud")

    suspend fun readPppoeSessions(): McmResult<List<Map<String, String>>> = when (
        val result = readRows("ppp/active", listOf("name", "service", "caller-id", "address", "uptime", "encoding"))
    ) {
        is McmResult.Failure -> result
        is McmResult.Success -> McmResult.Success(result.value.filter {
            it["service"].equals("pppoe", ignoreCase = true)
        })
    }

    suspend fun readArpEntries(): McmResult<List<Map<String, String>>> =
        readRows("ip/arp", listOf("address", "mac-address", "interface", "complete", "dynamic", "disabled"))

    suspend fun readDhcpLeases(): McmResult<List<Map<String, String>>> =
        readRows("ip/dhcp-server/lease", listOf("address", "mac-address", "host-name", "server", "status", "expires-after", "dynamic", "disabled"))

    suspend fun readNetwatch(): McmResult<List<Map<String, String>>> =
        readRows("tool/netwatch", listOf("host", "status", "since", "comment", "disabled", "type"))

    suspend fun readBridgeHosts(): McmResult<List<Map<String, String>>> =
        readRows("interface/bridge/host", listOf("mac-address", "on-interface", "bridge", "vid", "local", "external"))

    suspend fun readVlans(): McmResult<List<Map<String, String>>> =
        readRows("interface/vlan", listOf("name", "vlan-id", "interface", "mtu", "running", "disabled"))

    suspend fun readBridgeVlans(): McmResult<List<Map<String, String>>> =
        readRows("interface/bridge/vlan", listOf("bridge", "vlan-ids", "tagged", "untagged", "current-tagged", "current-untagged", "dynamic"))

    private suspend fun readFirstRow(path: String): McmResult<Map<String, String>> {
        return when (val result = client.get(path)) {
            is McmResult.Failure -> result
            is McmResult.Success -> {
                val row = result.value.optJSONObject(0)
                if (row == null) McmResult.Failure("DATA_EMPTY", "Router không trả dữ liệu $path.")
                else McmResult.Success(row.toStringMap())
            }
        }
    }

    private suspend fun readRows(path: String, fields: List<String>): McmResult<List<Map<String, String>>> = when (val result = client.get(path)) {
        is McmResult.Failure -> result
        is McmResult.Success -> {
            val rows = buildList {
                for (index in 0 until result.value.length()) {
                    val row = result.value.optJSONObject(index) ?: continue
                    add(row.toStringMap(fields))
                }
            }
            McmResult.Success(rows)
        }
    }

    suspend fun ping(target: String, count: Int = 20): McmResult<PingMeasurement> {
        require(target.isNotBlank() && count in 1..100)
        val payload = JSONObject()
            .put("address", target)
            .put("count", count.toString())
            .put("interval", "200ms")
        return when (val result = client.post("ping", payload)) {
            is McmResult.Failure -> result
            is McmResult.Success -> PingResponseParser.parse(target, result.value, expectedSent = count)
        }
    }
}

private fun JSONObject.stringValue(key: String): String? =
    if (!has(key) || isNull(key)) null else optString(key).takeIf(String::isNotBlank)

private fun JSONObject.toStringMap(fields: List<String>? = null): Map<String, String> {
    return if (fields != null) fields.mapNotNull { key ->
        if (!has(key) || isNull(key)) null else key to optString(key)
    }.toMap() else buildMap {
        val iterator = keys()
        while (iterator.hasNext()) {
            val key = iterator.next()
            if (!isNull(key)) put(key, optString(key))
        }
    }
}

