package com.multicloud.mcm

/** Normalizes an IPv4 literal or ASCII DNS/DDNS hostname without DNS resolution. */
object RouterHostValidator {
    fun normalize(raw: String): String {
        var value = raw.trim()
        require(value.isNotBlank()) { "Nhập Cloud DDNS/domain hoặc địa chỉ IP." }
        if (value.startsWith("https://", ignoreCase = true)) value = value.substring(8)
        require(!value.startsWith("http://", ignoreCase = true)) {
            "Chỉ hỗ trợ HTTPS; không nhập địa chỉ http://."
        }
        value = value.removeSuffix("/").trim()
        require(value.isNotBlank() && value.length <= 253 && !value.contains('/') &&
            !value.contains('?') && !value.any(Char::isWhitespace)) {
            "Chỉ nhập hostname/IP, không nhập port hoặc đường dẫn."
        }
        if (value.startsWith('[') && value.endsWith(']')) value = value.substring(1, value.length - 1)

        require(!value.contains(':')) {
            "Địa chỉ IPv6 literal không nằm trong phạm vi MCM 1.6.3; hãy dùng DDNS/domain hoặc IPv4."
        }

        val host = (if (value.endsWith('.')) value.dropLast(1) else value).lowercase()
        val labels = host.split('.')
        val ipv4Candidate = labels.size == 4 && labels.all { it.toIntOrNull() != null }
        if (ipv4Candidate) {
            require(labels.all { part -> part.length == 1 || !part.startsWith('0') } && labels.all { it.toInt() in 0..255 }) { "Địa chỉ IPv4 không hợp lệ hoặc không ở dạng chuẩn." }
            return host
        }
        require(labels.all { label ->
            label.length in 1..63 && label.matches(Regex("[a-z0-9](?:[a-z0-9-]*[a-z0-9])?"))
        }) { "Tên miền không hợp lệ. Kiểm tra lại Cloud DDNS/domain." }
        return host
    }

    fun endpointKind(host: String): String = when {
        host.endsWith(".sn.mynetname.net", ignoreCase = true) -> "MIKROTIK_CLOUD"
        RouterDnsResolver.isIpLiteral(host) -> "IP"
        else -> "DDNS_DOMAIN"
    }
}
