package com.multicloud.mcm.routeros

import com.multicloud.mcm.InterfaceSnapshot
import com.multicloud.mcm.McmResult
import com.multicloud.mcm.PingMeasurement
import com.multicloud.mcm.PppoeStatus
import com.multicloud.mcm.SystemResource

class RouterOs6Repository(private val client: RouterOs6ApiClient) {
    suspend fun readSystemResource(): McmResult<SystemResource> {
        return when (
        val result = client.execute("/system/resource/print", mapOf(".proplist" to "version,uptime,cpu-load,free-memory,total-memory"))
    ) {
        is McmResult.Failure -> result
        is McmResult.Success -> {
            val row = result.value.firstOrNull()
                ?: return McmResult.Failure("RESOURCE_EMPTY", "Router không trả dữ liệu system/resource.")
            McmResult.Success(
                SystemResource(
                    version = row["version"],
                    uptime = row["uptime"],
                    cpuLoadPercent = row["cpu-load"]?.toIntOrNull()?.coerceIn(0, 100),
                    freeMemoryBytes = row["free-memory"]?.toLongOrNull(),
                    totalMemoryBytes = row["total-memory"]?.toLongOrNull()
                )
            )
        }
        }
    }

    suspend fun readInterfaces(): McmResult<List<InterfaceSnapshot>> = when (
        val result = client.execute(
            "/interface/print",
            mapOf(".proplist" to "name,type,running,rx-byte,tx-byte,last-link-up-time")
        )
    ) {
        is McmResult.Failure -> result
        is McmResult.Success -> McmResult.Success(
            result.value.mapNotNull { row ->
                val name = row["name"] ?: return@mapNotNull null
                InterfaceSnapshot(
                    name = name,
                    type = row["type"].orEmpty(),
                    running = row["running"].equals("true", true) || row["running"].equals("yes", true),
                    rxBytes = row["rx-byte"]?.toLongOrNull(),
                    txBytes = row["tx-byte"]?.toLongOrNull(),
                    lastLinkUpTime = row["last-link-up-time"]
                )
            }
        )
    }

    suspend fun readPppoeInterfaces(): McmResult<List<PppoeStatus>> = when (val result = readInterfaces()) {
        is McmResult.Failure -> result
        is McmResult.Success -> McmResult.Success(
            result.value.filter { it.type.contains("pppoe", true) || it.name.contains("pppoe", true) }
                .map { PppoeStatus(it.name, it.running, it.lastLinkUpTime, null) }
        )
    }


    // Do not hardcode a Cloud .proplist here: older RouterOS 6 minor versions expose
    // different read-only Cloud fields (IPv6 DDNS is available only on supported builds).
    suspend fun readCloudStatus(): McmResult<Map<String, String>> = readFirstRow("/ip/cloud/print")

    suspend fun readPppoeSessions(): McmResult<List<Map<String, String>>> = when (
        val result = readRows("/ppp/active/print", "name,service,caller-id,address,uptime,encoding")
    ) {
        is McmResult.Failure -> result
        is McmResult.Success -> McmResult.Success(result.value.filter {
            it["service"].equals("pppoe", ignoreCase = true)
        })
    }

    suspend fun readArpEntries(): McmResult<List<Map<String, String>>> = readRows(
        "/ip/arp/print", "address,mac-address,interface,complete,dynamic,disabled"
    )

    suspend fun readDhcpLeases(): McmResult<List<Map<String, String>>> = readRows(
        "/ip/dhcp-server/lease/print", "address,mac-address,host-name,server,status,expires-after,dynamic,disabled"
    )

    suspend fun readNetwatch(): McmResult<List<Map<String, String>>> = readRows(
        "/tool/netwatch/print", "host,status,since,comment,disabled,type"
    )

    suspend fun readBridgeHosts(): McmResult<List<Map<String, String>>> = readRows(
        "/interface/bridge/host/print", "mac-address,on-interface,bridge,vid,local,external"
    )

    suspend fun readVlans(): McmResult<List<Map<String, String>>> = readRows(
        "/interface/vlan/print", "name,vlan-id,interface,mtu,running,disabled"
    )

    suspend fun readBridgeVlans(): McmResult<List<Map<String, String>>> = readRows(
        "/interface/bridge/vlan/print", "bridge,vlan-ids,tagged,untagged,current-tagged,current-untagged,dynamic"
    )

    private suspend fun readFirstRow(command: String): McmResult<Map<String, String>> =
        when (val result = client.execute(command)) {
            is McmResult.Failure -> result
            is McmResult.Success -> result.value.firstOrNull()?.let { McmResult.Success(it) }
                ?: McmResult.Failure("DATA_EMPTY", "Router không trả dữ liệu $command.")
        }

    private suspend fun readRows(command: String, fields: String): McmResult<List<Map<String, String>>> =
        client.execute(command, mapOf(".proplist" to fields))

    suspend fun ping(target: String, count: Int = 20): McmResult<PingMeasurement> {
        require(target.isNotBlank() && count in 1..100)
        return when (
            val result = client.execute(
                "/ping",
                mapOf("address" to target, "count" to count.toString(), "interval" to "200ms")
            )
        ) {
            is McmResult.Failure -> result
            is McmResult.Success -> RouterOs6PingParser.parseCompleted(
                target = target,
                rows = result.value,
                requestedCount = count
            )
        }
    }
}
