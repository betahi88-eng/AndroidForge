package com.multicloud.mcm.routeros

import com.multicloud.mcm.McmResult
import com.multicloud.mcm.PingMeasurement

/**
 * RouterOS 6 API returns one !re record per ICMP echo reply, then !done when
 * the bounded command has completed. The requested count is the sent count;
 * only validated echo-reply records contribute to received.
 */
object RouterOs6PingParser {
    fun parseCompleted(
        target: String,
        rows: List<Map<String, String>>,
        requestedCount: Int,
        now: Long = System.currentTimeMillis()
    ): McmResult<PingMeasurement> {
        if (target.isBlank() || requestedCount !in 1..100) {
            return McmResult.Failure("PING_INVALID", "Tham số ping RouterOS 6 không hợp lệ.")
        }

        val sequences = mutableSetOf<Int>()
        val rtts = mutableListOf<Double>()
        for (row in rows) {
            val sequence = row["seq"]?.toIntOrNull()
                ?: return McmResult.Failure("PING_INVALID", "RouterOS 6 trả bản ghi ping thiếu sequence hợp lệ.")
            if (sequence !in 0 until requestedCount || !sequences.add(sequence)) {
                return McmResult.Failure("PING_INVALID", "RouterOS 6 trả sequence ping trùng hoặc ngoài phạm vi.")
            }
            if (row["host"].isNullOrBlank()) {
                return McmResult.Failure("PING_INVALID", "RouterOS 6 trả bản ghi ping thiếu host.")
            }
            // RouterOS may report a resolved address instead of the requested DNS name.
            // The record is an echo reply because the /ping API returned it as an !re row.
            val rtt = PingResponseParser.parseDurationMs(row["time"])
                ?: return McmResult.Failure("PING_INVALID", "RouterOS 6 trả bản ghi echo reply thiếu thời gian hợp lệ.")
            rtts.add(rtt)
        }

        val received = sequences.size
        if (received > requestedCount) {
            return McmResult.Failure("PING_INVALID", "Số echo reply vượt số gói đã yêu cầu.")
        }
        return McmResult.Success(
            PingMeasurement.fromCounts(
                target = target,
                sent = requestedCount,
                received = received,
                minRtt = rtts.minOrNull(),
                avgRtt = rtts.average().takeIf { rtts.isNotEmpty() },
                maxRtt = rtts.maxOrNull(),
                now = now
            )
        )
    }
}
