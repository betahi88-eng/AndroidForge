package com.multicloud.mcm

/** Central command allowlist: the mobile client must not have a path to RouterOS config writes. */
internal object RouterOsReadOnlyPolicy {
    private val restReadPaths = setOf(
        "system/resource",
        "interface",
        "ip/cloud",
        "ppp/active",
        "ip/arp",
        "ip/dhcp-server/lease",
        "tool/netwatch",
        "interface/bridge/host",
        "interface/vlan",
        "interface/bridge/vlan"
    )

    private val apiReadCommands = setOf(
        "/system/resource/print",
        "/interface/print",
        "/ip/cloud/print",
        "/ppp/active/print",
        "/ip/arp/print",
        "/ip/dhcp-server/lease/print",
        "/tool/netwatch/print",
        "/interface/bridge/host/print",
        "/interface/vlan/print",
        "/interface/bridge/vlan/print"
    )

    private val pingAttributes = setOf("address", "count", "interval")

    fun validateRestGet(path: String) {
        require(path.trim('/') in restReadPaths) { "REST operation is outside the MCM read-only allowlist." }
    }

    fun validateRestPing(path: String, keys: Set<String>, address: String, count: String, interval: String) {
        require(path.trim('/') == "ping") { "REST POST is reserved for bounded ping only." }
        require(keys.all { it in pingAttributes }) { "REST ping contains an unsupported parameter." }
        require(address.isNotBlank() && address.length <= 253 && !address.any(Char::isWhitespace)) {
            "Ping target is invalid."
        }
        require(count.toIntOrNull() in 1..100) { "Ping count must be from 1 to 100." }
        require(interval == "200ms") { "Ping interval is fixed at 200 ms in MCM 1.6.3." }
    }

    fun validateApiCommand(command: String, attributes: Map<String, String>) {
        if (command == "/ping") {
            require(attributes.keys.all { it in pingAttributes }) { "RouterOS API ping contains an unsupported parameter." }
            val address = attributes["address"].orEmpty()
            val count = attributes["count"].orEmpty()
            val interval = attributes["interval"].orEmpty()
            require(address.isNotBlank() && address.length <= 253 && !address.any(Char::isWhitespace)) {
                "Ping target is invalid."
            }
            require(count.toIntOrNull() in 1..100) { "Ping count must be from 1 to 100." }
            require(interval == "200ms") { "Ping interval is fixed at 200 ms in MCM 1.6.3." }
            return
        }
        require(command in apiReadCommands) { "RouterOS API command is outside the MCM read-only allowlist." }
        require(attributes.keys.all { it == ".proplist" }) {
            "RouterOS API read command contains an unsupported parameter."
        }
        attributes[".proplist"]?.let { fields ->
            require(fields.length <= 512 && fields.matches(Regex("[A-Za-z0-9_.,-]+"))) {
                "RouterOS API property list is invalid."
            }
        }
    }
}
