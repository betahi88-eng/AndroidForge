package com.multicloud.mcm.routeros

import com.multicloud.mcm.InterfaceSnapshot
import com.multicloud.mcm.McmResult
import com.multicloud.mcm.PingMeasurement
import com.multicloud.mcm.SystemResource
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetAddress
import java.util.Locale

/**
 * Read-only adapter for WinBox CLI. It uses DNS addresses resolved by MCM and tries them individually.
 * WinBox's EC-SRP5/M2 session is not TLS, so TLS pins are neither requested nor bypassed here.
 */
class WinboxCliRepository(
    private val addresses: List<InetAddress>,
    private val port: Int,
    private val username: String,
    private val password: String
) {
    suspend fun readSystemResource(): McmResult<SystemResource> = withContext(Dispatchers.IO) {
        connect(includeTables = false) { result -> parseSystemResource(result.resource.orEmpty()) }
    }

    /** One authenticated terminal session reads core resource and each optional table independently. */
    internal suspend fun readMonitoringSnapshot(target: String = ""): McmResult<WinboxMonitoringSnapshot> = withContext(Dispatchers.IO) {
        connect(includeTables = true) { result ->
            val resource = when (val parsed = parseSystemResource(result.resource.orEmpty())) {
                is McmResult.Failure -> return@connect parsed
                is McmResult.Success -> parsed.value
            }
            val major = resource.version?.substringBefore('.')?.toIntOrNull() ?: 0
            val minor = resource.version?.split('.')?.getOrNull(1)?.takeWhile(Char::isDigit)?.toIntOrNull() ?: 0
            val jsonMode = major > 7 || (major == 7 && minor >= 13)

            fun rows(path: String, fields: Set<String>): McmResult<List<Map<String, String>>> =
                parseTable(result, path, fields, jsonMode)
            fun first(path: String, fields: Set<String>): McmResult<Map<String, String>> = when (val value = rows(path, fields)) {
                is McmResult.Failure -> value
                is McmResult.Success -> value.value.firstOrNull()?.let { McmResult.Success(it) }
                    ?: McmResult.Failure("WINBOX_TABLE_EMPTY", "RouterOS không trả bản ghi cho $path.")
            }

            val interfaceRows = rows("interface", setOf("name", "type", "running", "rx-byte", "tx-byte", "last-link-up-time"))
            val interfaces = when (interfaceRows) {
                is McmResult.Failure -> interfaceRows
                is McmResult.Success -> {
                    val parsed = interfaceRows.value.mapNotNull { row ->
                        val name = row["name"] ?: return@mapNotNull null
                        InterfaceSnapshot(
                            name = name,
                            type = row["type"].orEmpty(),
                            running = row["running"].isRouterOsTrue(),
                            rxBytes = row["rx-byte"]?.toLongOrNull(),
                            txBytes = row["tx-byte"]?.toLongOrNull(),
                            lastLinkUpTime = row["last-link-up-time"]
                        )
                    }
                    if (interfaceRows.value.isNotEmpty() && parsed.isEmpty()) {
                        McmResult.Failure("WINBOX_INTERFACE_PARSE", "Bảng interface có dữ liệu nhưng không có trường name hợp lệ.")
                    } else McmResult.Success(parsed)
                }
            }
            val cloud = first("ip/cloud", emptySet())
            val ppp = rows("ppp/active", setOf("name", "service", "caller-id", "address", "uptime", "encoding"))
                .mapSuccess { it.filter { row -> row["service"].equals("pppoe", ignoreCase = true) } }
            val arp = rows("ip/arp", setOf("address", "mac-address", "interface", "complete", "dynamic", "disabled"))
            val dhcp = rows("ip/dhcp-server/lease", setOf("address", "mac-address", "host-name", "server", "status", "expires-after", "dynamic", "disabled"))
            val netwatch = rows("tool/netwatch", setOf("host", "status", "since", "disabled", "type"))
            val bridgeHosts = rows("interface/bridge/host", setOf("mac-address", "on-interface", "bridge", "vid", "local", "external"))
            val vlans = rows("interface/vlan", setOf("name", "vlan-id", "interface", "mtu", "running", "disabled"))
            val bridgeVlans = rows("interface/bridge/vlan", setOf("bridge", "vlan-ids", "tagged", "untagged", "current-tagged", "current-untagged", "dynamic"))
            val ping = target.trim().takeIf(String::isNotBlank)?.let {
                McmResult.Failure("WINBOX_CLI_PING_NOT_AVAILABLE", "Ping chủ động chưa được bật trong adapter WinBox CLI; không tạo kết quả ping giả.")
            }
            McmResult.Success(WinboxMonitoringSnapshot(resource, interfaces, cloud, ppp, arp, dhcp, netwatch, bridgeHosts, vlans, bridgeVlans, ping))
        }
    }

    private suspend fun <T> connect(includeTables: Boolean, transform: (WinboxCliConnector.Result) -> McmResult<T>): McmResult<T> {
        if (addresses.isEmpty()) return McmResult.Failure("DNS_EMPTY", "DNS không trả về địa chỉ IP để thử WinBox.")
        var lastFailure: McmResult.Failure? = null
        for (address in addresses) {
            try {
                val result = WinboxCliConnector(
                    host = address.hostAddress,
                    port = port,
                    username = username,
                    password = password,
                    connectTimeoutMs = 6_000,
                    ioTimeoutMs = 8_000
                ).use { it.connectAndRead(includeMonitoringTables = includeTables) }
                return transform(result)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: WinboxCliConnector.WinboxCliException) {
                lastFailure = McmResult.Failure(error.code, "${error.stage}: ${error.message ?: "WinBox CLI failed"}")
            } catch (error: Exception) {
                lastFailure = McmResult.Failure("WINBOX_READ_FAILED", error.message ?: error.javaClass.simpleName)
            }
        }
        return lastFailure ?: McmResult.Failure("WINBOX_FAILED", "Không thể kết nối WinBox CLI tới các địa chỉ DNS đã phân giải.")
    }

    private fun parseTable(
        result: WinboxCliConnector.Result,
        path: String,
        fields: Set<String>,
        jsonMode: Boolean
    ): McmResult<List<Map<String, String>>> {
        result.tableErrors[path]?.let { return McmResult.Failure("WINBOX_TABLE_READ_FAILED", "$path: $it") }
        val raw = result.tableOutputs[path]
            ?: return McmResult.Failure("WINBOX_TABLE_MISSING", "Không có phản hồi CLI cho bảng $path.")
        return try {
            val rows = if (jsonMode) parseJsonRows(raw, monitoringCommand(path, true), fields)
                else parseAsValueRows(raw, monitoringCommand(path, false), fields)
            McmResult.Success(rows)
        } catch (error: Exception) {
            McmResult.Failure("WINBOX_TABLE_PARSE_FAILED", "$path: ${error.message ?: error.javaClass.simpleName}")
        }
    }

    private fun parseSystemResource(raw: String): McmResult<SystemResource> {
        val values = parseKeyValueOutput(raw)
        val resource = SystemResource(
            version = values["version"]?.substringBefore(' ')?.trim(),
            uptime = values["uptime"],
            cpuLoadPercent = values["cpu-load"]?.removeSuffix("%")?.trim()?.toIntOrNull()?.coerceIn(0, 100),
            freeMemoryBytes = parseByteSize(values["free-memory"]),
            totalMemoryBytes = parseByteSize(values["total-memory"])
        )
        return if (resource.version.isNullOrBlank() || resource.uptime.isNullOrBlank()) {
            McmResult.Failure("WINBOX_RESOURCE_PARSE", "WinBox CLI đã xác thực nhưng không phân tích được version/uptime từ /system/resource/print.")
        } else McmResult.Success(resource)
    }

    companion object {
        private val pathWhitelist = setOf(
            "interface", "ip/cloud", "ppp/active", "ip/arp", "ip/dhcp-server/lease",
            "tool/netwatch", "interface/bridge/host", "interface/vlan", "interface/bridge/vlan"
        )

        internal fun monitoringCommand(path: String, useJson: Boolean): String {
            require(path in pathWhitelist) { "Monitoring path is outside the fixed allowlist." }
            return if (useJson) ":put [:serialize to=json [/$path print as-value]]" else ":put [/$path print as-value]"
        }

        internal fun parseJsonRows(raw: String, command: String, fields: Set<String> = emptySet()): List<Map<String, String>> {
            val body = extractPayload(raw, command)
            if (body.isBlank()) return emptyList()
            val start = listOf(body.indexOf('['), body.indexOf('{')).filter { it >= 0 }.minOrNull()
                ?: throw IllegalArgumentException("Không tìm thấy JSON trong phản hồi terminal.")
            val jsonText = body.substring(start).trim()
            val objects = when (jsonText.firstOrNull()) {
                '[' -> JSONArray(jsonText).let { array -> (0 until array.length()).map { index ->
                    array.optJSONObject(index) ?: throw IllegalArgumentException("JSON row $index không phải object.")
                } }
                '{' -> listOf(JSONObject(jsonText))
                else -> throw IllegalArgumentException("JSON response không phải object/array.")
            }
            return objects.map { row ->
                val map = linkedMapOf<String, String>()
                val keys = row.keys()
                while (keys.hasNext()) {
                    val key = keys.next().lowercase(Locale.ROOT)
                    if (fields.isNotEmpty() && key !in fields) continue
                    val value = row.opt(key)
                    if (value == null || value === JSONObject.NULL) continue
                    map[key] = when (value) {
                        is JSONArray -> (0 until value.length()).mapNotNull { index ->
                            val item = value.opt(index)
                            if (item == null || item === JSONObject.NULL) null else item.toString()
                        }.joinToString(",")
                        is JSONObject -> throw IllegalArgumentException("Trường '$key' có object lồng; từ chối biến đổi không rõ nghĩa.")
                        else -> value.toString()
                    }
                }
                map
            }
        }

        internal fun parseAsValueRows(raw: String, command: String, fields: Set<String>): List<Map<String, String>> {
            val body = extractPayload(raw, command).replace("\r\n", ";").replace('\r', ';').replace('\n', ';').trim().trimEnd(';')
            if (body.isBlank()) return emptyList()
            if (isCliError(body)) throw IllegalArgumentException("RouterOS CLI trả lỗi: ${body.take(180)}")
            val rows = mutableListOf<Map<String, String>>()
            var current = linkedMapOf<String, String>()
            var lastKey: String? = null
            fun flush() {
                if (current.isNotEmpty()) rows += current
                current = linkedMapOf()
                lastKey = null
            }
            for (part0 in body.split(';')) {
                val part = part0.trim()
                if (part.isEmpty()) continue
                val eq = part.indexOf('=')
                if (eq > 0) {
                    val key = part.substring(0, eq).trim().lowercase(Locale.ROOT)
                    if (key.matches(Regex("[a-z0-9._-]+"))) {
                        if (key == ".id") {
                            if (current.isNotEmpty()) flush()
                            current[key] = part.substring(eq + 1).trim()
                            lastKey = key
                        } else if (fields.isEmpty() || key in fields) {
                            if (key in current) flush()
                            current[key] = part.substring(eq + 1).trim()
                            lastKey = key
                        } else {
                            // A real but unrequested RouterOS field is a field boundary, not a
                            // continuation of the previously selected value. Clear the continuation
                            // target so hidden properties cannot corrupt a requested column.
                            lastKey = null
                        }
                        continue
                    }
                }
                // RouterOS 6's as-value format has no escaping. A semicolon continuation is
                // retained on the previous value; only whitelisted field names start a new field.
                val previous = lastKey
                if (previous != null && current.containsKey(previous)) {
                    current[previous] = current.getValue(previous) + if (previous in setOf("tagged", "untagged", "current-tagged", "current-untagged", "vlan-ids")) ",${part}" else ";${part}"
                }
            }
            flush()
            return rows.map { row -> row.filterKeys { it != ".id" && (fields.isEmpty() || it in fields) } }
                .filter { it.isNotEmpty() }
        }

        private fun extractPayload(raw: String, command: String): String {
            val clean = stripAnsi(raw).replace("\r\n", "\n").replace('\r', '\n')
            val commandAt = clean.lastIndexOf(command)
            var body = if (commandAt >= 0) clean.substring(commandAt + command.length) else clean
            val newline = body.indexOf('\n')
            if (newline >= 0) body = body.substring(newline + 1)
            body = body.replace(Regex("(?m)^\\[[^\\r\\n\\]]{1,128}\\]\\s*>\\s*$"), "")
            val trimmed = body.trim()
            if (isCliError(trimmed)) throw IllegalArgumentException("RouterOS CLI trả lỗi: ${trimmed.take(180)}")
            return trimmed
        }

        private fun isCliError(body: String): Boolean {
            val first = body.lineSequence().firstOrNull { it.isNotBlank() }?.trim().orEmpty()
            return listOf(
                "failure:", "bad command name", "input does not match", "expected end of command",
                "syntax error", "no such item", "no such command", "ambiguous value"
            ).any { first.startsWith(it, ignoreCase = true) }
        }

        private fun stripAnsi(value: String): String = value
            .replace(Regex("\\u001B\\[[0-?]*[ -/]*[@-~]"), "")
            .replace(Regex("\\u001B\\][^\\u0007]*(?:\\u0007|\\u001B\\\\)"), "")

        internal fun parseKeyValueOutput(raw: String): Map<String, String> = buildMap {
            raw.lineSequence().forEach { line ->
                val match = Regex("^\\s*([A-Za-z0-9._-]+)\\s*:\\s*(.*?)\\s*$").find(line) ?: return@forEach
                val key = match.groupValues[1].lowercase(Locale.ROOT)
                val value = match.groupValues[2].trim()
                if (value.isNotEmpty()) put(key, value)
            }
        }

        internal fun parseByteSize(raw: String?): Long? {
            if (raw.isNullOrBlank()) return null
            val match = Regex("(?i)^\\s*([0-9]+(?:\\.[0-9]+)?)\\s*([kmgt]?i?b?)?\\s*$").matchEntire(raw)
                ?: return raw.trim().toLongOrNull()
            val amount = match.groupValues[1].toDoubleOrNull() ?: return null
            val unit = match.groupValues[2].uppercase(Locale.ROOT)
            val exponent = when {
                unit.startsWith("K") -> 1
                unit.startsWith("M") -> 2
                unit.startsWith("G") -> 3
                unit.startsWith("T") -> 4
                else -> 0
            }
            val base = if (unit.contains("I")) 1024.0 else 1000.0
            return (amount * Math.pow(base, exponent.toDouble()))
                .takeIf { it.isFinite() && it <= Long.MAX_VALUE.toDouble() }?.toLong()
        }
    }
}

internal data class WinboxMonitoringSnapshot(
    val resource: SystemResource,
    val interfaces: McmResult<List<InterfaceSnapshot>>,
    val cloud: McmResult<Map<String, String>>,
    val pppActive: McmResult<List<Map<String, String>>>,
    val arp: McmResult<List<Map<String, String>>>,
    val dhcp: McmResult<List<Map<String, String>>>,
    val netwatch: McmResult<List<Map<String, String>>>,
    val bridgeHosts: McmResult<List<Map<String, String>>>,
    val vlans: McmResult<List<Map<String, String>>>,
    val bridgeVlans: McmResult<List<Map<String, String>>>,
    val ping: McmResult<PingMeasurement>?
)

private fun String?.isRouterOsTrue(): Boolean = this.equals("true", true) || this.equals("yes", true)

private inline fun <A, B> McmResult<A>.mapSuccess(transform: (A) -> B): McmResult<B> = when (this) {
    is McmResult.Success -> McmResult.Success(transform(value))
    is McmResult.Failure -> this
}
