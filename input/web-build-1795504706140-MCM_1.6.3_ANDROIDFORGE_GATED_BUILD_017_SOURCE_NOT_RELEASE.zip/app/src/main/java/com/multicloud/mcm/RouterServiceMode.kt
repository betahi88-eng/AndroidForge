package com.multicloud.mcm

import com.multicloud.mcm.data.RouterEntity

/** RouterOS management service used by MCM. WINBOX_CLI is a distinct encrypted terminal transport, not an API/TLS service. */
enum class RouterServiceMode(val storageValue: String) {
    AUTO("AUTO"),
    REST_HTTPS("REST_HTTPS"),
    API_SSL("API_SSL"),
    WINBOX_CLI("WINBOX_CLI");

    fun resolve(routerOsMajor: Int): RouterTransport {
        require(routerOsMajor == 6 || routerOsMajor == 7) { "Chỉ hỗ trợ RouterOS 6 hoặc 7." }
        return when (this) {
            AUTO -> if (routerOsMajor == 7) RouterTransport.REST_HTTPS else RouterTransport.API_SSL
            REST_HTTPS -> {
                require(routerOsMajor == 7) { "REST HTTPS yêu cầu RouterOS 7 trở lên; hãy chọn API-SSL cho RouterOS 6." }
                RouterTransport.REST_HTTPS
            }
            API_SSL -> RouterTransport.API_SSL
            WINBOX_CLI -> RouterTransport.WINBOX_CLI
        }
    }

    fun suggestedPort(routerOsMajor: Int): Int = resolve(routerOsMajor).port

    /** Resolve the actual transport accepted by READ_CHECK; AUTO must not guess again later. */
    fun resolveForProfile(routerOsMajor: Int, activeTransport: String?): RouterTransport =
        if (this == AUTO) RouterTransport.fromStorage(activeTransport)
            ?.takeUnless { it == RouterTransport.WINBOX_CLI }
            ?: resolve(routerOsMajor)
        else resolve(routerOsMajor)

    /** Select only a branch that passed authenticated READ_CHECK (or authenticated limited read). */
    fun selectAuthenticatedTransport(
        routerOsMajor: Int,
        restAuthenticated: Boolean,
        apiSslAuthenticated: Boolean
    ): RouterTransport? {
        require(routerOsMajor == 6 || routerOsMajor == 7) { "Chỉ hỗ trợ RouterOS 6 hoặc 7." }
        return when (this) {
            AUTO -> {
                val preferred = if (routerOsMajor == 7) RouterTransport.REST_HTTPS else RouterTransport.API_SSL
                val alternate = if (preferred == RouterTransport.REST_HTTPS) RouterTransport.API_SSL else RouterTransport.REST_HTTPS
                fun passed(transport: RouterTransport) = when (transport) {
                    RouterTransport.REST_HTTPS -> restAuthenticated
                    RouterTransport.API_SSL -> apiSslAuthenticated
                    RouterTransport.WINBOX_CLI -> false
                }
                when {
                    passed(preferred) -> preferred
                    passed(alternate) -> alternate
                    else -> null
                }
            }
            REST_HTTPS -> resolve(routerOsMajor).takeIf { restAuthenticated }
            API_SSL -> resolve(routerOsMajor).takeIf { apiSslAuthenticated }
            WINBOX_CLI -> RouterTransport.WINBOX_CLI
        }
    }

    /**
     * Build WAN probe endpoints. AUTO with no custom port probes the conventional
     * REST/API-SSL ports in parallel. AUTO with a custom port probes both protocols
     * on that same externally forwarded port. Explicit modes probe only that service.
     * A zero port means the user left the WAN port blank.
     */
    fun probePorts(requestedPort: Int): RouterProbePorts {
        require(requestedPort == 0 || requestedPort in 1..65535) {
            "Port phải là số nguyên từ 1 đến 65535."
        }
        return when (this) {
            AUTO -> RouterProbePorts(
                restPort = if (requestedPort == 0) RouterTransport.REST_HTTPS.port else requestedPort,
                apiSslPort = if (requestedPort == 0) RouterTransport.API_SSL.port else requestedPort
            )
            REST_HTTPS -> RouterProbePorts(requestedPort.takeIf { it > 0 } ?: RouterTransport.REST_HTTPS.port, null)
            API_SSL -> RouterProbePorts(null, requestedPort.takeIf { it > 0 } ?: RouterTransport.API_SSL.port)
            WINBOX_CLI -> RouterProbePorts(null, null)
        }
    }

    companion object {
        fun fromStorage(value: String?): RouterServiceMode =
            entries.firstOrNull { it.storageValue.equals(value?.trim(), ignoreCase = true) } ?: AUTO

        fun fromUserInput(value: String?): RouterServiceMode =
            entries.firstOrNull { it.storageValue.equals(value?.trim(), ignoreCase = true) }
                ?: throw IllegalArgumentException("Chọn giao thức kết nối hợp lệ: Tự động, REST HTTPS, API-SSL hoặc WinBox CLI.")
    }
}



internal fun normalizeTransportFailureCode(code: String): String = when (code) {
    "AUTH" -> "AUTH_FAILED"
    "PERMISSION", "READ_DENIED" -> "READ_DENIED"
    "TIMEOUT", "NETWORK_TIMEOUT" -> "NETWORK_TIMEOUT"
    "CONNECT_REFUSED", "TCP_REFUSED" -> "TCP_REFUSED"
    "TLS_FINGERPRINT_MISMATCH" -> "TLS_CHANGED"
    "TLS_PROTOCOL" -> "TLS_PROTOCOL"
    "TLS_HOSTNAME" -> "TLS_HOSTNAME"
    "TLS_CERT_VALIDITY" -> "TLS_CERT_VALIDITY"
    "TLS_HANDSHAKE" -> "TLS_HANDSHAKE"
    "TLS" -> "TLS_FAILED"
    else -> code
}

internal fun canTryAlternateTransport(
    serviceMode: RouterServiceMode,
    activeFailureCode: String,
    fallbackAttempted: Boolean,
    alternateFingerprintAvailable: Boolean
): Boolean = serviceMode == RouterServiceMode.AUTO && !fallbackAttempted && alternateFingerprintAvailable &&
    // Only endpoint reachability/protocol mismatch may trigger failover. Authentication,
    // permission and certificate identity/validity failures must remain visible and fatal.
    activeFailureCode in setOf(
        "NETWORK_TIMEOUT", "TIMEOUT", "CONNECT_REFUSED", "TCP_REFUSED", "NETWORK",
        "TLS_PROTOCOL", "API_PROTOCOL", "PORTS_UNREACHABLE", "HTTP_400", "HTTP_404", "HTTP_405", "REST_FORMAT"
    )


data class RouterProbePorts(val restPort: Int?, val apiSslPort: Int?)

enum class RouterTransport(val port: Int) {
    REST_HTTPS(443), API_SSL(8729), WINBOX_CLI(8291);

    companion object {
        fun fromStorage(value: String?): RouterTransport? =
            entries.firstOrNull { it.name.equals(value?.trim(), ignoreCase = true) }
    }
}


/**
 * Return only a pin previously accepted for this exact transport and WAN-facing port.
 * A legacy single pin is reusable only when the old profile explicitly recorded its active
 * transport or used a fixed protocol. AUTO + no recorded active transport is ambiguous and
 * must request a fresh explicit pin confirmation instead of guessing from RouterOS major version.
 */
fun RouterEntity.tlsPinPortFor(transport: RouterTransport): Int? {
    if (transport == RouterTransport.WINBOX_CLI) return null
    val (servicePin, servicePort) = when (transport) {
        RouterTransport.REST_HTTPS -> tlsRestSha256Pin to tlsRestPinPort
        RouterTransport.API_SSL -> tlsApiSslSha256Pin to tlsApiSslPinPort
        RouterTransport.WINBOX_CLI -> return null
    }
    if (!servicePin.isNullOrBlank()) return servicePort?.takeIf { it in 1..65535 }

    val legacyTransport = RouterTransport.fromStorage(activeTransport)
    return port.takeIf { it in 1..65535 && tlsSha256Pin.isNotBlank() && legacyTransport == transport }
}

fun RouterEntity.tlsPinFor(transport: RouterTransport, endpointPort: Int): String? {
    if (transport == RouterTransport.WINBOX_CLI || endpointPort !in 1..65535 || tlsPinPortFor(transport) != endpointPort) return null
    val servicePin = when (transport) {
        RouterTransport.REST_HTTPS -> tlsRestSha256Pin
        RouterTransport.API_SSL -> tlsApiSslSha256Pin
        RouterTransport.WINBOX_CLI -> return null
    }
    if (!servicePin.isNullOrBlank()) return servicePin
    return tlsSha256Pin.takeIf { it.isNotBlank() }
}

fun RouterTransport.alternate(): RouterTransport = when (this) {
    RouterTransport.REST_HTTPS -> RouterTransport.API_SSL
    RouterTransport.API_SSL -> RouterTransport.REST_HTTPS
    RouterTransport.WINBOX_CLI -> RouterTransport.REST_HTTPS
}
