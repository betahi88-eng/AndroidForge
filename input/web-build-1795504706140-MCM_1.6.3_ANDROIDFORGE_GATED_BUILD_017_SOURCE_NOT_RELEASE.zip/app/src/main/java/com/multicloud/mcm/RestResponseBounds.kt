package com.multicloud.mcm

import java.io.ByteArrayOutputStream
import java.io.InputStream

/** Enforces a strict memory/row ceiling on untrusted RouterOS REST responses. */
internal object RestResponseBounds {
    const val MAX_RESPONSE_BYTES = 16 * 1024 * 1024
    const val MAX_RESPONSE_ROWS = 10_000

    /** Returns null rather than retaining a body that exceeds the declared or observed byte limit. */
    fun readUtf8(input: InputStream, declaredContentLength: Long, maxBytes: Int = MAX_RESPONSE_BYTES): String? {
        require(maxBytes > 0)
        if (declaredContentLength > maxBytes) return null
        input.use { stream ->
            val output = ByteArrayOutputStream(minOf(maxBytes, declaredContentLength.coerceAtLeast(0).toInt().coerceAtLeast(8192)))
            val buffer = ByteArray(8192)
            var total = 0
            while (true) {
                val count = stream.read(buffer)
                if (count < 0) break
                if (count == 0) continue
                total += count
                if (total > maxBytes) return null
                output.write(buffer, 0, count)
            }
            return output.toString(Charsets.UTF_8.name())
        }
    }

    fun allowsRows(rowCount: Int): Boolean = rowCount in 0..MAX_RESPONSE_ROWS
}
