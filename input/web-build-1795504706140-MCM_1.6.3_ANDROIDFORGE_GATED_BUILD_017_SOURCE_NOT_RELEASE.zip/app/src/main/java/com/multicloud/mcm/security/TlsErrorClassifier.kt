package com.multicloud.mcm.security

import java.security.cert.CertificateExpiredException
import java.security.cert.CertificateNotYetValidException

/** Identifies TLS identity and protocol failures surfaced by different Android TLS providers. */
object TlsErrorClassifier {
    private val protocolMarkers = listOf(
        "UNSUPPORTED_PROTOCOL",
        "WRONG_VERSION_NUMBER",
        "UNRECOGNIZED SSL MESSAGE",
        "HTTP_REQUEST",
        "UNKNOWN PROTOCOL",
        "NO_PROTOCOLS_AVAILABLE"
    )

    fun isProtocolMismatch(error: Throwable): Boolean = generateSequence(error) { it.cause }
        .mapNotNull { it.message }
        .any { message -> protocolMarkers.any { marker -> message.contains(marker, ignoreCase = true) } }

    fun isFingerprintMismatch(error: Throwable): Boolean = generateSequence(error) { it.cause }
        .mapNotNull { it.message }
        .any { message -> message.contains("fingerprint", ignoreCase = true) }

    fun isCertificateValidityFailure(error: Throwable): Boolean = generateSequence(error) { it.cause }
        .any { it is CertificateExpiredException || it is CertificateNotYetValidException }
}
