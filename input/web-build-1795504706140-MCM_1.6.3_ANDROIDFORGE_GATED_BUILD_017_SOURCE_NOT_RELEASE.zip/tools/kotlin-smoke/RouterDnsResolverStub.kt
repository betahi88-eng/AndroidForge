package com.multicloud.mcm
object RouterDnsResolver {
 fun isIpLiteral(value:String):Boolean = value.matches(Regex("(?:[0-9]{1,3}\\.){3}[0-9]{1,3}"))
}
