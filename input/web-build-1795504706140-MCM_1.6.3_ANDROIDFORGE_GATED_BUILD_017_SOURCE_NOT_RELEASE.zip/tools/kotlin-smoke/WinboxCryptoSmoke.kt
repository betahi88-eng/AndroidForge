package com.multicloud.mcm.routeros

import java.math.BigInteger
import java.nio.charset.StandardCharsets

private fun hex(value: String) = value.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
private fun assertHex(expected: String, actual: ByteArray, label: String) {
    val got = actual.joinToString("") { "%02X".format(it) }
    check(got.equals(expected, ignoreCase = true)) { "$label mismatch: $got" }
}

fun main() {
    check(withRouterOsTerminalFlags("admin") == "admin+c") { "Terminal color flag must be added" }
    check(withRouterOsTerminalFlags("admin+t") == "admin+tc") { "Terminal flag must merge into the existing option group" }
    check(withRouterOsTerminalFlags("admin+tc") == "admin+tc") { "Terminal color flag must not be duplicated" }
    val privateA = ByteArray(32) { (it + 1).toByte() }
    val salt = ByteArray(16) { (0xA0 + it).toByte() }
    val publicA = WinboxCliConnector.EcSrp5.publicKey(privateA)
    assertHex("718F0034BA92AADE2EB5495170DB6AA13F5D8C29F2C575942EB2D6390788A50A", publicA.first, "EC-SRP5 public key")
    check(publicA.second == 1)
    val challenge = hex("680CE593193F1D7FF4764EDC0712EF541433F744516814B6A3C7577310F7DA0300A0A1A2A3A4A5A6A7A8A9AAABACADAEAF")
    val xB = challenge.copyOfRange(0, 32)
    val parityB = challenge[32].toInt() and 255
    val validator = WinboxCliConnector.EcSrp5.sha256(salt + WinboxCliConnector.EcSrp5.sha256("admin:t4n-secret".toByteArray(StandardCharsets.UTF_8)))
    val gamma = WinboxCliConnector.EcSrp5.publicKey(validator).first
    val v = WinboxCliConnector.EcSrp5.redp1(gamma, 1)
    val pointB = WinboxCliConnector.EcSrp5.liftX(BigInteger(1, xB), parityB)
    val j = WinboxCliConnector.EcSrp5.sha256(publicA.first + xB)
    val exponent = (BigInteger(1, validator).multiply(BigInteger(1, j)).mod(WinboxCliConnector.EcSrp5.r).add(BigInteger(1, privateA))).mod(WinboxCliConnector.EcSrp5.r)
    val z = WinboxCliConnector.EcSrp5.toMontgomery(WinboxCliConnector.EcSrp5.multiply(exponent, WinboxCliConnector.EcSrp5.add(pointB, v))).first
    val proof = WinboxCliConnector.EcSrp5.sha256(j + z)
    assertHex("E898C15526EA844B23196E7012747495652C1373D9F16908DA0AA44A9C58E5F0", proof, "EC-SRP5 client proof")
    assertHex("BAEAAF1A5C581D7B1984F13E50D7AF00694263854D2075B18C5F4EC74AF24689", WinboxCliConnector.EcSrp5.sha256(z), "EC-SRP5 shared secret")

    val cursor = WinboxCliConnector.RouterOsVt100Cursor()
    check(cursor.process("\u001b[H\u001b[9999B\u001b[6n") == listOf("\u001b[25;1R")) {
        "VT100 bottom-edge cursor report is incorrect"
    }
    check(cursor.process("\u001b[H\u001bD\u001b[9999A\u001b[6n") == listOf("\u001b[1;1R")) {
        "VT100 second cursor report is incorrect"
    }
    check(cursor.process("\u001b[H\u001b[9999C\u001b[6n") == listOf("\u001b[1;4096R")) {
        "VT100 width cursor report is incorrect"
    }
    check(cursor.process("\u001b[1;4096H \u001b[6n") == listOf("\u001b[2;1R")) {
        "VT100 wrap verification cursor report is incorrect"
    }
    check(cursor.process("\u001b[c").isEmpty()) { "CSI primary device attributes must remain unanswered" }
    check(cursor.process("\u001bZ") == listOf("\u001b[?1;0c")) { "DECID response is incorrect" }

    val promptConnector = WinboxCliConnector("127.0.0.1", 8291, "u", "p")
    check(promptConnector.isRouterOsPrompt("banner\r\n[admin@edge] > "))
    check(promptConnector.isRouterOsPrompt("[admin@edge] <SAFE> "))
    check(promptConnector.isRouterOsPrompt("[admin@edge] <SAFE> > "))
    check(!promptConnector.isRouterOsPrompt("[admin@edge] > command output continues"))
    promptConnector.close()

    val keys = WinboxCliConnector.StreamKeys.derive(hex("EC071E0A0136C837C051CEE6A7713EDBAEA6936712D1A3CA37E84FEE3226E61D"))
    assertHex("2C3320D2AF211ADFD4D2A9BCF57DDE04", keys.sendAes, "WinBox send AES key")
    assertHex("B47DE81D1EFF98797D76A47460905584", keys.receiveAes, "WinBox receive AES key")
    assertHex("BF5183A25889AD982C33B9B8F8DFA83FBD367745", keys.sendHmac, "WinBox send HMAC key")
    assertHex("54EEA56D698EA3A7A171DFEB3115E14BE77FF7D7", keys.receiveHmac, "WinBox receive HMAC key")

    val server = WinboxCliConnector.StreamKeys(keys.receiveAes, keys.sendAes, keys.receiveHmac, keys.sendHmac)
    for (size in listOf(0, 1, 11, 12, 13, 27, 28, 44, 300, 3531)) {
        val payload = ByteArray(size) { (it * 7 + 3).toByte() }
        val encrypted = keys.encrypt(payload)
        check(server.decrypt(encrypted).contentEquals(payload)) { "AES/HMAC roundtrip failed at $size bytes" }
    }
    val boundary = keys.encrypt(ByteArray(3531) { (it * 13).toByte() })
    check(boundary.size == 3570) { "Expected exact 14-chunk boundary frame, got ${boundary.size}" }
    val tampered = keys.encrypt("M2-integrity".toByteArray()).also { it[it.lastIndex] = (it.last().toInt() xor 1).toByte() }
    var rejected = false
    try { server.decrypt(tampered) } catch (_: Exception) { rejected = true }
    check(rejected) { "A tampered HMAC/frame must be rejected" }
    println("WinBox Crypto Smoke: PASS (EC-SRP5 vectors, VT100 PTY negotiation, normal/Safe Mode prompts, stream-key vectors, 10 AES/HMAC round trips, exact 14-chunk frame, tamper rejection)")
}
