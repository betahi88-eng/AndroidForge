package com.multicloud.mcm.data
data class RouterEntity(
 val id:String="r", val name:String="r", val siteName:String="", val host:String="router.example.test", val port:Int=443,
 val routerOsMajor:Int=7, val username:String="reader", val credentialAlias:String="alias", val tlsSha256Pin:String="", val createdAtEpochMs:Long=0,
 val lastSeenAtEpochMs:Long?=null, val lastStatus:String="UNKNOWN", val lastErrorCode:String?=null, val lastErrorMessage:String?=null,
 val lastCheckedAtEpochMs:Long?=null, val connectionMode:String="AUTO", val activeTransport:String?=null, val lastResolvedIp:String?=null,
 val dnsResolver:String?=null, val fallbackAvailable:Boolean=false, val routerOsVersion:String?=null, val accessLevel:String="UNKNOWN",
 val lastConnectionLatencyMs:Long?=null, val tlsPinConfirmedAtEpochMs:Long?=null, val tlsRestSha256Pin:String?=null,
 val tlsRestPinPort:Int?=null, val tlsApiSslSha256Pin:String?=null, val tlsApiSslPinPort:Int?=null
)
