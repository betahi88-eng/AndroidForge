package com.multicloud.mcm.routeros

fun main() {
    val command = WinboxCliRepository.monitoringCommand("interface/bridge/vlan", false)
    val raw = "[admin@chr6] > $command\r\n" +
        ".id=*1;bridge=br0;vlan-ids=10,20;tagged=br0;ether2;untagged=ether3;dynamic=false\r\n" +
        ".id=*2;bridge=br0;vlan-ids=30;tagged=br0;ether4;dynamic=true\r\n" +
        "[admin@chr6] > "
    val rows = WinboxCliRepository.parseAsValueRows(raw, command,
        setOf("bridge", "vlan-ids", "tagged", "untagged", "dynamic"))
    check(rows.size == 2) { "Expected two ROS6 rows, got $rows" }
    check(rows[0]["tagged"] == "br0,ether2") { "Tagged list parsing failed: $rows" }
    check(rows[0]["untagged"] == "ether3")
    check(rows[1]["dynamic"] == "true")

    val fieldBoundaryCommand = WinboxCliRepository.monitoringCommand("ip/dhcp-server/lease", false)
    val fieldBoundaryRaw = "[admin@chr6] > $fieldBoundaryCommand\n" +
        ".id=*3;address=192.0.2.10;host-name=work;interface=ether1;status=bound\n[admin@chr6] > "
    val fieldBoundaryRows = WinboxCliRepository.parseAsValueRows(fieldBoundaryRaw, fieldBoundaryCommand,
        setOf("address", "host-name", "status"))
    check(fieldBoundaryRows.single()["host-name"] == "work" && fieldBoundaryRows.single()["status"] == "bound") {
        "Unrequested property must be skipped as a field boundary: $fieldBoundaryRows"
    }

    val error = "[admin@chr6] > $command\nexpected end of command (line 1 column 8)\n[admin@chr6] > "
    var refused = false
    try { WinboxCliRepository.parseAsValueRows(error, command, setOf("bridge")) }
    catch (_: IllegalArgumentException) { refused = true }
    check(refused) { "RouterOS CLI error must not be interpreted as an empty successful table" }

    var commandRejected = false
    try { WinboxCliRepository.monitoringCommand("ip/firewall/filter", false) }
    catch (_: IllegalArgumentException) { commandRejected = true }
    check(commandRejected) { "Non-allowlisted menu must be rejected" }
    println("WinBox Repository Smoke: PASS (ROS6 rows/list continuation, unrequested-field boundaries, CLI refusal, command allowlist)")
}
