# Cổng nghiệm thu MCM 1.6.3

1. AndroidForge nạp ZIP 017 vào workspace mới và chạy đúng một lệnh `bash scripts/androidforge-build-and-verify.sh`.
2. Chỉ coi build đạt khi script in `ANDROIDFORGE BUILD GATE PASS`, có Debug/Release APK+AAB vừa sinh ở `app/build/mcm-acceptance/`, metadata APK đúng `com.multicloud.mcm` / `1.6.3` / `12`, và có SHA256SUMS.
3. Sau đó mới cài lên Android API 26+ và nghiệm thu UI, nhiều profile, lưu credential, lịch sử và foreground/background.
4. Nghiệm thu kết nối thật từ mạng ngoài: phân tách DNS, TCP, TLS hostname+pin, AUTH và READ_CHECK cho REST HTTPS, API-SSL và WinBox. Dùng RouterOS 6/7 lab được ủy quyền; ghi rõ dịch vụ/port nào thành công. Không suy rộng kết quả WinBox sang 443/8729.
5. Chỉ phát hành khi build, thiết bị và kết nối thật đều đạt. Hiện tại vẫn `SOURCE_NOT_RELEASE`; chưa có APK mới hoặc xác nhận live router trong runtime này.
