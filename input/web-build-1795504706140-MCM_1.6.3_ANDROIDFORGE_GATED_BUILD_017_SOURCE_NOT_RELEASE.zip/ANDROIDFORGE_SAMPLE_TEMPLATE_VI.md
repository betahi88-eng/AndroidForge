# ANDROIDFORGE — ĐẦU VÀO ZIP → APK MCM 1.6.3

## Nhận diện đúng gói

- Tên gói: `MCM_1.6.3_FULL_INTEGRATED_WINBOX_LAB_SOURCE_NOT_RELEASE.zip`
- Source ID: `MCM-1.6.3-ANDROIDFORGE-GATED-BUILD-017`
- Parent: bản 007 đã được người dùng xác nhận build APK thành công (SHA-256 `493cdf9ec77e15958073a63452e30fd3ea259a91e8a9bdd44ca35315584e6f96`)
- Project: MikroTik Multi-Cloud Monitor (MCM)
- Application ID: `com.multicloud.mcm`
- Version: `1.6.3` (`versionCode=12`)
- Loại: Android native / Kotlin / Gradle; module `:app`
- Min SDK: 26; Compile SDK / Target SDK: 35
- JDK: 17; Gradle: 8.9; AGP: 8.6.1; Kotlin: 2.0.21

Bản 014 tích hợp WinBox CLI vào luồng chính và bổ sung lab CHR. Đây là `SOURCE_NOT_RELEASE`; chưa có bằng chứng Android Gradle/APK hoặc live CHR thành công trong workspace. Không thay bằng parent 007 hoặc bản probe-only 013.

## Cấu trúc đầu vào bắt buộc

Giải nén ZIP trực tiếp thành project root. `settings.gradle.kts`, `build.gradle.kts`, `app/build.gradle.kts` và `app/src/main/AndroidManifest.xml` phải nằm ngay root. AndroidForge phải chạy Gradle từ đúng thư mục này và nhận module `:app`.

## Cấu hình build

Dùng đúng toolchain đã khóa: JDK 17, Gradle 8.7, AGP 8.6.1, Kotlin 2.0.21, Android SDK Platform 35 và Build Tools 35.0.0. Gói source không kèm Gradle Wrapper; runner phải cung cấp Gradle 8.7.

```bash
gradle --version
gradle --no-daemon clean
gradle --no-daemon :app:testDebugUnitTest
gradle --no-daemon :app:lintDebug
bash scripts/androidforge-build-and-verify.sh
```

Trước build có thể chạy:

```bash
bash scripts/androidforge-preflight.sh
MCM_SKIP_GRADLE=1 bash scripts/verify-source.sh
```

## Tiêu chí nhận APK

Chỉ chấp nhận artifact của chính lần chạy hiện tại khi `clean`, JUnit, lint, `assembleDebug`, `bundleDebug`, `assembleRelease` và `bundleRelease` đều trả mã 0. Kiểm tra metadata bằng `aapt dump badging`, ghi SHA-256 và log build. Không lấy APK cũ có sẵn hoặc suy luận thành công từ việc ZIP giải nén được.

## Kiểm thử RouterOS thật

Đọc `lab/README_VI.md`: RouterOS 7 chạy Containerlab + CHR chính thức; RouterOS 6 chạy GNS3/QEMU; dùng DNS/TCP fault injection, Android Emulator và Maestro. Lab quản trị Containerlab chỉ kiểm chứng management VRF; WAN/DDNS/NAT phải thử từ external VPS hoặc mạng ngoài riêng.

## Tình trạng hiện tại

Các preflight, kiểm tra tĩnh, migration, UI contract, regression guard và Kotlin/JVM smoke đã chạy. Android Gradle/KAPT/JUnit/lint/APK/AAB, emulator/Maestro, live CHR 6/7 và WAN/DDNS external vẫn `NOT_RUN`. Bản 014 chưa phải release.


Bản 017 bổ sung dependency guard tự động cho cả Debug và Release; build gate nằm trong `scripts/androidforge-build-and-verify.sh`.
