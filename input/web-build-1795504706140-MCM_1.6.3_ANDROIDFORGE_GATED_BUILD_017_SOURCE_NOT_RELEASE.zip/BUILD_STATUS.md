# MCM 1.6.3 — AndroidForge gated build 017

Source ID: `MCM-1.6.3-ANDROIDFORGE-GATED-BUILD-017`  
Parent source: `MCM-1.6.3-WORKSPACE-INTEGRITY-016`  
Integrated feature parent: `MCM-1.6.3-FULL-INTEGRATED-WINBOX-014`  
User-confirmed build-success baseline: `MCM_1.6.3_DDNS_RECONCILED_007_SOURCE_NOT_RELEASE.zip`  
Baseline SHA-256: `493cdf9ec77e15958073a63452e30fd3ea259a91e8a9bdd44ca35315584e6f96`  
Application ID: `com.multicloud.mcm` · Version `1.6.3` · versionCode `12`.

## What was redone in 017

- The dependency gate now checks **both** `debugRuntimeClasspath` and `releaseRuntimeClasspath` via Gradle's resolved component graph.
- The gate is automatically attached to Android `preBuild`, so a normal Debug or Release build cannot skip it accidentally.
- The gate rejects `com.github.mwiede:jsch`, any `org.bouncycastle` module, and artifacts named like JSch/BouncyCastle. No `packagingOptions` exclusion was added to conceal the collision.
- Added `scripts/androidforge-build-and-verify.sh`: one fail-fast command performs source preflight, `clean`, the dependency gate, Android unit tests, lint, Debug/Release APK+AAB builds, verifies APK applicationId/version metadata, and records SHA-256 hashes.
- Build outputs are collected under `app/build/mcm-acceptance/`, which remains excluded from the source package.
- The app transport logic and version code are unchanged from 016; this is build/workspace control, not a claim that live router connectivity has been verified.

## Rechecked evidence

The supplied AndroidForge logs show `SshRouterOsClient.kt` compilation and a runtime dependency metadata graph containing `com.github.mwiede:jsch:2.28.8` and `org.bouncycastle:bcprov-jdk18on:1.86`. The resource collision occurred at `mergeDebugJavaResource` / `mergeReleaseJavaResource`. The clean source tree from 007/014/016 does not declare these modules. Therefore the correct fix is to prevent the unexpected dependencies or mixed workspace from entering the build, not to suppress their duplicate metadata.

For this 017 source tree, the following were rerun in the current runtime:

- AndroidForge source preflight and exact source-tree inventory.
- Room SQL migration simulation v1→v8.
- UI contract and 19 historical build regression assertions.
- Kotlin/JVM WinBox crypto and repository smoke tests.
- Android XML parse, JavaScript syntax, Python compile and shell syntax. The one-command build script also passed an orchestration-only dry-run with fake Gradle/AAPT executables; this does NOT produce or validate a real APK.

## Not run / not claimed

- Android Gradle, KAPT, Android JUnit, Android lint, Debug/Release APK/AAB: **NOT RUN** here. This runtime has no Gradle installation and no Android SDK Platform 35.
- RouterOS CHR 6/7, Android emulator/device, external DDNS/WAN/NAT, REST HTTPS 443, API-SSL 8729 and WinBox 8291 against the user's router: **NOT RUN** here.
- The user's successful build of baseline 007 remains user-confirmed historical context, not a build result for 017.

**Release decision: SOURCE_NOT_RELEASE / NO-GO.** Do not treat static/JVM checks as an APK build or live connection acceptance. Run the one-command gate on AndroidForge; then perform the separate RouterOS live acceptance plan.
