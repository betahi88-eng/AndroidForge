# MCM — Thiết lập GitHub ZIP → APK

## Baseline

Repository này được bung từ `MCM_1.5.1_DIRECT_DDNS_MULTI_STORE_SOURCE_NOT_RELEASE.zip`.
SHA-256 ZIP gốc được ghi trong `SOURCE_BASELINE_SHA256.txt`.

Đây là Engineering Source, không phải bản Release và chưa được xác nhận tương thích
với router MikroTik thật hoặc mọi thiết bị Android.

## Tạo repository

1. Đăng nhập GitHub.
2. Tạo repository mới tên `mikrotik-multi-cloud-monitor`.
3. Chọn **Private** trong giai đoạn phát triển.
4. Không tạo README, .gitignore hoặc License tự động (đã có sẵn trong source).
5. Đẩy toàn bộ nội dung thư mục này lên nhánh `main`.

Dùng GitHub Desktop hoặc Git CLI:

```bash
git init
git add .
git commit -m "chore: import MCM 1.6.0 direct-DDNS custom-service rebuild"
git branch -M main
git remote add origin https://github.com/YOUR_ACCOUNT/mikrotik-multi-cloud-monitor.git
git push -u origin main
```

Thay `YOUR_ACCOUNT` bằng GitHub username của bạn.

## Chạy ZIP → APK

Workflow `.github/workflows/android-build.yml` tự chạy khi push lên `main`,
khi tạo Pull Request vào `main`, hoặc chạy thủ công:

1. Mở repository → **Actions**.
2. Chọn **MCM Android CI**.
3. Chọn **Run workflow** nếu muốn chạy thủ công.
4. Chờ các job hoàn tất.
5. Mở workflow run → phần **Artifacts**.
6. Tải artifact `MCM-1.6.0-debug-<commit SHA>`.

Bên trong artifact có `MCM-debug.apk`, `SHA256SUMS.txt` và `BUILD_METADATA.txt`.
Báo cáo unit test/lint được lưu thành artifact riêng.

## Toolchain được khóa

- JDK 17
- Gradle 8.7
- Android SDK Platform 35
- Android Build Tools 35.0.0
- Android Gradle Plugin 8.6.1 (đã khai báo trong `build.gradle.kts`)

AndroidForge cần xác minh Gradle 8.7, JDK 17 và Android SDK Platform 35 trong log. ZIP hiện chưa đóng gói Gradle Wrapper JAR; không tuyên bố có Wrapper trước khi workflow xác nhận đã khôi phục và sử dụng đúng phiên bản.

## Điều kiện nghiệm thu

- CI xanh cho đúng commit.
- APK tồn tại và checksum được tạo.
- Cài APK trên thiết bị Android thực tế.
- Kiểm tra router RouterOS 7 REST/HTTPS.
- Kiểm tra router RouterOS 6 API-SSL, gồm legacy challenge nếu router hỗ trợ.
- Kiểm tra TLS fingerprint pinning, lưu credential, polling, packet loss và lịch sử.
- Chỉ sau kiểm thử thiết bị thật mới xem xét bản Release ký chính thức.

## Bảo mật

Không commit `local.properties`, router credentials, private key, keystore hoặc
signing passwords. Debug APK chỉ dùng thử nghiệm.
