# CHECKLIST KIỂM THỬ MẪU — MCM 1.6.3

Đánh dấu `PASS` chỉ khi có log/ảnh/chứng cứ của lần chạy. Nếu chưa chạy ghi `NOT RUN`, không suy diễn.

## A. AndroidForge / ZIP
- [ ] ZIP tải lên đúng file source mẫu.
- [ ] Giải nén an toàn, không path traversal, không lỗi CRC.
- [ ] Project root có `settings.gradle.kts` và `build.gradle.kts`.
- [ ] Có module `:app` và `app/build.gradle.kts`.
- [ ] AndroidForge không chạy Gradle ở thư mục cha hoặc thư mục Repair Kit.
- [ ] Toolchain đúng JDK 17 / Gradle 8.7 / SDK 35.

## B. Build
- [ ] `clean` — PASS
- [ ] `:app:testDebugUnitTest` — PASS
- [ ] `:app:lintDebug` — PASS
- [ ] `:app:assembleDebug` — PASS
- [ ] APK được tạo mới trong đúng run — PASS
- [ ] APK manifest package/version/minSdk đúng — PASS
- [ ] APK SHA-256 và provenance được lưu — PASS

## C. Cài đặt và giao diện
- [ ] Cài APK trên Android API 26+.
- [ ] Cài/mở trên phiên bản Android mục tiêu.
- [ ] Mở app lần đầu không crash.
- [ ] Thêm/sửa/xóa profile.
- [ ] Khởi động lại app, profile và lịch sử vẫn đúng.
- [ ] Màn hình nhỏ, bàn phím, font lớn không che nút chính.

## D. RouterOS / mạng
- [ ] RouterOS 7 REST HTTPS.
- [ ] RouterOS 6 API-SSL.
- [ ] DDNS và IP trực tiếp.
- [ ] Port tùy chỉnh và NAT forward.
- [ ] TLS pin đúng / pin sai.
- [ ] DNS hệ thống lỗi và DoH fallback.
- [ ] Router offline / timeout / sai mật khẩu / thiếu quyền.
- [ ] Chuyển Wi-Fi ↔ mạng di động.
- [ ] Dashboard và tốc độ interface không hiển thị dữ liệu giả.

## E. Bảo mật
- [ ] Không có password/token trong log.
- [ ] TLS mismatch không bị bỏ qua.
- [ ] Không có lệnh cấu hình ghi ngoài dự kiến.
- [ ] Không yêu cầu mở dịch vụ quản trị ra toàn Internet.

## Mẫu ghi nhận
| Hạng mục | Trạng thái | Bằng chứng / log | Ghi chú |
|---|---|---|---|
| Build unit test | NOT RUN | | |
| Lint | NOT RUN | | |
| Assemble debug | NOT RUN | | |
| Cài trên điện thoại | NOT RUN | | |
| RouterOS 6 | NOT RUN | | |
| RouterOS 7 | NOT RUN | | |
