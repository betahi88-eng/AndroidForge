# MCM 1.6.3 — Direct DDNS, selectable service and custom port

## Product boundary

MCM Android connects directly to each router through that router's MikroTik Cloud DDNS hostname or another configured DDNS/domain/IPv4 address. Native IPv6 literal entry is outside the 1.6.3 scope; DNS names may still resolve to IPv4 and/or IPv6 records. There is no MCM backend, VPS, VPN, WireGuard, relay, router-side agent or tunnel provisioning. Profiles, secrets and history remain local on Android.

```text
Android MCM
  ├─ local multi-store/router profiles
  ├─ Room database + Android Keystore credentials
  └─ direct per-profile endpoint
       ├─ DNS: <router>.sn.mynetname.net
       ├─ user-entered WAN port (1..65535)
       ├─ selected service adapter
       │    ├─ REST HTTPS / www-ssl (RouterOS 7) — TLS pin + HTTP auth
       │    ├─ RouterOS API-SSL / api-ssl (RouterOS 6 or 7) — TLS pin + API auth
       │    └─ WinBox CLI / TCP 8291 (RouterOS 6.43+) — EC-SRP5 + encrypted M2/mepty
       └─ TLS pins apply only to TLS transports
```

## Endpoint data model

Each profile independently stores `host`, `port`, `routerOsMajor`, `connectionMode`, `username`, `credentialAlias` and independent REST/API-SSL leaf-certificate SHA-256 pins scoped to the WAN-facing port. `tlsSha256Pin` remains as a legacy active-transport compatibility field. The port is the external/WAN-facing port entered on the phone. When upstream NAT changes the public port to an internal port, the profile still stores the public port; the router/modem must map it to the correct service listener.

The legacy `tlsSha256Pin` column remains for upgrade compatibility, but the active implementation uses `tlsRestSha256Pin` + `tlsRestPinPort` and `tlsApiSslSha256Pin` + `tlsApiSslPinPort`. A saved fingerprint is accepted only for its exact service and WAN port. The Room v7→v8 migration maps the former single pin only to the service known to have been active.

The `connectionMode` values are:
- `AUTO`: RouterOS 7 → REST HTTPS; RouterOS 6 → API-SSL.
- `REST_HTTPS`: REST over `www-ssl`; requires RouterOS 7.
- `API_SSL`: native RouterOS API over TLS; supports RouterOS 6 and 7.
- `WINBOX_CLI`: encrypted WinBox terminal channel; supports RouterOS 6.43+ and 7. The channel is not TLS and does not use a certificate pin. Pre-6.43 legacy MD5 login is refused.

The read-only boundary is enforced in both transport clients, not merely by current repository usage. REST GET is restricted to the required monitoring menus; REST POST is restricted to bounded `/ping` with an allowlisted parameter set. API-SSL accepts only the monitoring `/print` commands and bounded `/ping`; unknown commands, mutation paths, and unexpected attributes are rejected before any socket request. Ping is diagnostic-only and uses a maximum count of 100 at a fixed 200 ms interval. RouterOS permissions should grant `read,api,rest-api`, plus `test` only if ping is required; no `write`, `reboot` or `sensitive` policy is needed for the dashboard.

The service choice is independent of the numeric WAN port. Suggested values 443 and 8729 are defaults, not hard-coded runtime ports. A manual port remains unchanged when the RouterOS/service selector changes. When editing an existing profile, the already saved port is always treated as user-owned, even if it happens to equal a standard default. The migration from Room v3 to v4 adds `connectionMode='AUTO'` to existing profiles and preserves all saved endpoint and history data.

## WinBox CLI transport

WinBox CLI is a fourth explicit transport, not a substitute for REST/API-SSL and not the WinBox graphical protocol. The implementation follows EC-SRP5 authentication, M2 chunk framing, AES-128-CBC + HMAC-SHA1 frames and the `mepty` terminal handler over TCP 8291 (or a configured WAN port). It is limited to RouterOS 6.43+; legacy pre-6.43 MD5 login is intentionally disabled. There is no TLS certificate/SNI/pin on this transport, so MCM must not request or silently bypass a TLS pin for it.

The adapter holds one authenticated terminal session for identity/resource and the optional monitoring reads. It answers VT100 cursor probes, pulls terminal output, acknowledges cumulative received bytes, waits for the actual RouterOS prompt before treating a command as complete and sends `/quit` on close. It accepts only a fixed allowlist of read-only commands/menus. ROS 7.13+ table reads use `:serialize to=json`; earlier RouterOS reads use the bounded as-value parser. Each menu failure is reported independently; a lost terminal prompt boundary stops subsequent commands rather than risking response misassociation. Active ping is not implemented on this transport and is surfaced as unavailable.

MCM’s main Save & Connect path now invokes WinBox CLI authentication and requires actual reads of `/system/identity/print` and `/system/resource/print` before saving the profile. Foreground monitoring reuses a single WinBox session to collect core resource and the allowlisted tables. WinBox is explicit opt-in, never selected automatically as an AUTO fallback.

## WAN dynamic address behavior

- Keep the hostname as the profile identity; do not save a resolved WAN IP as the permanent host.
- Resolve DNS again on each new connection so changed WAN addresses can be followed after DDNS updates.
- A DNS result or open TCP socket alone never marks the router ONLINE.
- Preserve distinct DNS, TCP, TLS, fingerprint, AUTH, PERMISSION and RouterOS data errors.

## Required network reachability

MikroTik IP Cloud DDNS maps a hostname to the public address reported by the router; it does not open a service port, create NAT, bypass CGNAT/double NAT or provide a relay. The configured WAN port must be reachable from the phone and terminate at the selected `www-ssl`, `api-ssl` or WinBox listener according to the explicit profile mode. If CGNAT or ISP inbound filtering prevents that, a port edit alone cannot fix it. This product boundary intentionally excludes VPN/relay workarounds.

## TLS and credentials

- Each profile stores separate leaf certificate SHA-256 pins for REST HTTPS and API-SSL, each bound to its WAN-facing port.
- Fingerprint reading is an untrusted capture; users must verify independently before saving.
- Every session verifies the configured service-specific pin for the exact WAN port. Pin mismatch fails closed.
- Passwords are encrypted using AES-256-GCM with a key in Android Keystore. Credential rotation writes a new alias before committing the profile and removes the old alias only after the database update succeeds.
- Never log passwords, authorization headers, or API sentence secrets.

## Monitoring contract

`/system/resource` success establishes core reachability. Optional snapshots fail independently and may produce PARTIAL. Refresh All is sequential. Background checks use the same stored service mode, service-scoped pin and WAN port as foreground checks. In AUTO, a failed endpoint/protocol can move to the alternate service only when that exact service + port already has an independently confirmed pin; the active transport and port are persisted after a successful core read. A missing alternate pin never triggers an untrusted connection. Authentication, permission, certificate validity, hostname and fingerprint/pin failures never trigger failover. Certificate-expiry/not-yet-valid errors have their own `TLS_CERT_VALIDITY` classification rather than being mislabeled as a closed port. Foreground refresh, Refresh All and WorkManager use the same rule. DNS failures set the profile OFFLINE with a DNS-specific code rather than leaving a stale ONLINE state.

## Explicit exclusions

No MCM server/VPS, VPN/WireGuard/Back To Home, relay, router-side agent, WinBox graphical client, plaintext API, automatic port opening, automatic firewall change, router configuration writes or cloud synchronization. LAN MNDP discovery is a local convenience only.


## TLS pin persistence (Room v8)

Room v8 stores `tlsRestSha256Pin` + `tlsRestPinPort` and `tlsApiSslSha256Pin` + `tlsApiSslPinPort`. Migration v7→v8 transfers the legacy active pin only to the transport implied by `activeTransport` or, for older profiles, the explicitly saved service / RouterOS family. A service pin is reusable only for its own protocol and exact WAN port. The old single-pin column remains for backward compatibility and is not a cross-service trust source.


## RouterOS command boundary

All native transport clients enforce the monitoring allowlist before network I/O. REST GET is limited to the system resource, interfaces, IP Cloud, PPP active, ARP, DHCP lease, Netwatch, Bridge Host, VLAN and Bridge VLAN paths; REST POST is reserved for bounded ping. API-SSL permits only the matching `/print` commands plus bounded `/ping`. WinBox CLI permits only identity/resource reads and a fixed list of monitoring print commands; the adapter does not send configuration mutations. API responses are bounded by word, sentence, total-byte and row limits. No add/set/remove/enable/disable/reboot/firewall/NAT/service/user command is reachable through the MCM transport adapter.

The RouterOS account should use a custom least-privilege group: `read,api,rest-api` for REST, `read,api` for API-SSL, and optional `test` only when in-app ping is required. `test` grants RouterOS permissions beyond ping when the account is used elsewhere; MCM itself still restricts the command to its bounded ping allowlist.


## TLS endpoint identity and pin migration (candidate 006)

The transport-specific SHA-256 leaf pins are independent for REST HTTPS and API-SSL and are scoped to the exact WAN-facing port. A matching pin does not waive certificate time validity or endpoint identity. DNS names are checked against dNSName SANs; IP literals require iPAddress SANs; a legacy subject CN is considered only when no dNSName SAN exists. A wildcard is accepted only as the complete left-most label and matches exactly one hostname label. REST, API-SSL and first-use fingerprint inspection share the same verifier.

On schema v8 migration, a legacy single pin is copied only when its protocol can be established from the recorded active transport or an explicitly fixed protocol mode. AUTO profiles without a recorded active transport keep the legacy value but require a new explicit service-specific pin confirmation.
