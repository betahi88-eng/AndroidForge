# Build and package

## Local prerequisites

- JDK 17
- Gradle 8.7
- Android SDK Platform 35
- Android Build Tools 35.0.0
- Android platform-tools for `adb install`

## Debug build

```bash
./scripts/setup-and-build.sh
```

The script runs unit tests, lint, Debug APK/AAB, and Release APK/AAB tasks. It verifies the package ID and version metadata of both APKs with Android `aapt`. The debug APK is automatically debug-signed and suitable for device acceptance. The Release APK is unsigned unless a controlled signing configuration is supplied; no signing key belongs in the source ZIP.

## Install over USB

```bash
./scripts/install-debug.sh
```

## Source archive

```bash
./scripts/package-source.sh
```

The archive is a source-only package, not a prebuilt APK. The package script excludes build caches, local SDK paths, certificates/private keys, keystores and APKs. It excludes build caches, Python bytecode, local SDK paths, certificates/private keys, keystores and APKs. Keep any production signing key outside the source archive and under owner-controlled secure storage.
