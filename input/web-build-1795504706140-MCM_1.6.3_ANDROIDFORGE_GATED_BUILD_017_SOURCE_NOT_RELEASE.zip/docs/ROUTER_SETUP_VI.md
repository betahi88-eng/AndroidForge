# Hướng dẫn kết nối MCM trực tiếp qua MikroTik Cloud DDNS

## 1. Cấu hình hồ sơ trên Android

Mỗi cửa hàng/router có các giá trị độc lập:

- Host: `xxxx.sn.mynetname.net`, DDNS/domain khác hoặc IP. Không nhập `https://`, port hay path vào ô Host.
- RouterOS major: 6 hoặc 7.
- Service protocol: `AUTO`, `REST HTTPS`, hoặc `RouterOS API-SSL`.
- WAN port: số 1–65535 mà điện thoại thực sự truy cập. Nếu có NAT/port-forward, đây là port phía WAN/ngoài.
- Username/password riêng cho MCM; tạo user và group riêng, không dùng tài khoản `full`.
- SHA-256 fingerprint của chứng chỉ TLS máy chủ tại đúng host + WAN port.

**Policy quyền tối thiểu:** REST HTTPS cần `read`, `api`, `rest-api`; API-SSL cần `read`, `api`. Chỉ thêm policy `test` khi muốn dùng phép ping tích hợp, vì RouterOS yêu cầu quyền này cho ping. Không cấp `write`, `policy`, `reboot`, `sensitive`, `ftp` hoặc quyền quản trị khác cho tài khoản giám sát. Nếu bỏ `test`, các chỉ số vẫn đọc được nhưng ping sẽ báo thiếu quyền. Ứng dụng tự chặn mọi lệnh ngoài allowlist đọc dữ liệu và ping giới hạn; tuy nhiên policy `test` của RouterOS có thể cho phép nhiều lệnh kiểm tra khác khi tài khoản được dùng ở công cụ khác.

`AUTO` gợi ý ROS7 → REST HTTPS/443 và ROS6 → API-SSL/8729. MCM cho phép người dùng đổi port theo từng hồ sơ. Khi thay RouterOS/service, app chỉ thay số gợi ý nếu port chưa được chỉnh thủ công; port tùy chỉnh đã lưu sẽ được giữ nguyên.

## 2. Quan trọng về MikroTik Cloud DDNS

MikroTik IP Cloud DDNS cập nhật hostname về địa chỉ public mà router báo lên. DDNS không mở port quản trị, không tạo NAT, không vượt CGNAT/double NAT và không cấp relay. Muốn truy cập trực tiếp, endpoint phải có đường inbound tới đúng dịch vụ và firewall/NAT phải cho phép nguồn được ủy quyền. MCM không sử dụng VPN/WireGuard/VPS/relay và không tự thay cấu hình router.

## 3. Chọn đúng service protocol

### REST HTTPS / www-ssl

- Chỉ hỗ trợ RouterOS 7 trong MCM.
- Bật `www-ssl` và gán certificate TLS. MCM yêu cầu cả SHA-256 pin đã được người dùng đối chiếu và SAN/CN của certificate khớp DDNS/IP dùng để kết nối. Pin không bỏ qua kiểm tra hostname hoặc thời hạn certificate.
- Port mặc định đề xuất 443; nhập port WAN tùy chỉnh nếu endpoint/NAT dùng port khác.
- MCM đọc REST qua HTTPS; không dùng dịch vụ `www` HTTP.

### RouterOS API-SSL / api-ssl

- Hỗ trợ RouterOS 6 và 7.
- Bật `api-ssl` và gán certificate TLS. MCM yêu cầu cả SHA-256 pin đã được người dùng đối chiếu và SAN/CN của certificate khớp DDNS/IP dùng để kết nối. Pin không bỏ qua kiểm tra hostname hoặc thời hạn certificate.
- Port mặc định đề xuất 8729; nhập port WAN tùy chỉnh nếu endpoint/NAT dùng port khác.
- MCM sử dụng giao thức RouterOS API native qua TLS, không phải WinBox.

### Automatic

- RouterOS 7 ưu tiên REST HTTPS; RouterOS 6 ưu tiên API-SSL.
- Nếu lỗi endpoint/giao thức xảy ra và dịch vụ còn lại có fingerprint được xác nhận riêng cho đúng cổng WAN, MCM có thể chuyển sang dịch vụ đó trong lần kết nối hoặc lần monitoring kế tiếp. Không chuyển giao thức để né lỗi đăng nhập, thiếu quyền hoặc lỗi danh tính chứng chỉ.
- Sau khi dịch vụ thay thế vượt qua phép đọc tài nguyên cốt lõi, MCM mới lưu giao thức/cổng đang hoạt động; trạng thái được đánh dấu `PARTIAL` để người dùng biết đã failover.

Trong chế độ AUTO, MCM dò hai endpoint nhưng chỉ xác thực một transport sau mỗi lần xác nhận pin. Fingerprint được ràng buộc với đúng dịch vụ và cổng đã chọn. Nếu giao thức ưu tiên không vượt qua READ_CHECK, MCM có thể yêu cầu xác nhận riêng fingerprint của endpoint thay thế; không cần dùng chung certificate giữa `www-ssl` và `api-ssl`.

Không có plaintext API hoặc HTTP fallback.

## 4. WinBox CLI TCP 8291

MCM có transport WinBox CLI riêng, dùng EC-SRP5 xác thực và M2/mepty terminal mã hóa. Chọn `WINBOX_CLI` trong Tùy chọn nâng cao; mặc định TCP 8291, có thể nhập WAN port khác nếu NAT chuyển tiếp đúng dịch vụ WinBox. Hỗ trợ RouterOS 6.43 trở lên. RouterOS trước 6.43 dùng legacy MD5 không được MCM chấp nhận.

WinBox CLI không dùng TLS nên không cần TLS fingerprint; không được nhập/chuyển fingerprint API-SSL/REST sang WinBox. MCM yêu cầu EC-SRP5 server proof, kiểm tra HMAC các frame và chỉ chạy lệnh đọc nằm trong allowlist. Transport này không phải WinBox GUI và không có tính năng cấu hình router. Ping chủ động chưa hỗ trợ; dữ liệu không đọc được sẽ hiển thị lỗi/PARTIAL, không tạo số 0 giả.

REST HTTPS (RouterOS 7) và API-SSL (RouterOS 6/7) vẫn là hai transport độc lập dùng TLS; WinBox hoạt động không chứng minh hai dịch vụ TLS cũng hoạt động.

## 5. Port WAN và NAT

- Nếu `www-ssl` nghe nội bộ 443 nhưng modem/NAT công bố 8443, nhập 8443 trong MCM; thiết bị trước router phải forward TCP 8443 → đúng IP MikroTik:443.
- Nếu `api-ssl` nghe nội bộ 8729 nhưng port ngoài là 18729, nhập 18729; NAT phải forward 18729 → router:8729.
- MCM không tự thêm firewall rule, bật service hoặc cấu hình port-forward.

Dùng firewall source restriction và user read-only. Không mở quản trị cho toàn Internet nếu chưa kiểm soát nguồn.

## 6. Lấy và xác minh fingerprint

1. Nhập host và đúng WAN port.
2. Nhấn **Kiểm tra DNS / TCP**. TCP open chỉ cho biết có socket trả lời, chưa xác nhận TLS hoặc giao thức.
3. Nhấn **Đọc fingerprint TLS** tại đúng endpoint.
4. Đối chiếu chuỗi SHA-256 64 ký tự với leaf certificate được quản trị viên xác minh độc lập qua WinBox/console/certificate export hoặc kênh tin cậy.
5. Chỉ lưu khi fingerprint được đối chiếu độc lập và certificate có SAN/CN phù hợp hostname. Pin sai hoặc hostname sai đều phải bị từ chối.

## 7. Chẩn đoán

| Mã | Ý nghĩa / kiểm tra |
|---|---|
| `DNS_FAILED` | Cloud DDNS/domain chưa phân giải hoặc DNS chưa cập nhật |
| `TCP_TIMEOUT` | IP đã phân giải nhưng cổng WAN không phản hồi; kiểm tra firewall, NAT, ISP, CGNAT và port mapping |
| `CONNECT_REFUSED` | Có phản hồi từ đích nhưng không có listener phù hợp hoặc cổng bị reject |
| `TLS_PROTOCOL` | Port không phải dịch vụ TLS phù hợp; có thể đã nhập cổng WinBox/HTTP hoặc NAT nhầm dịch vụ |
| `TLS_FINGERPRINT_MISMATCH` | Chứng chỉ tại endpoint khác pin đã lưu |
| `AUTH` | Sai username/password hoặc login bị RouterOS từ chối |
| `PERMISSION` | User thiếu quyền đọc |

Không tắt certificate pinning hoặc hostname verification, không chuyển sang HTTP và không tự đổi giao thức để né lỗi. Certificate phải có SAN/CN phù hợp với DDNS/IP. Nếu DNS thành công nhưng TCP timeout thì chưa đến bước fingerprint/TLS.

## 8. Kiểm tra WAN động

- Xác nhận `dns-name` trong `/ip cloud print` đúng với hostname MCM.
- Từ mạng di động bên ngoài cửa hàng, xác nhận hostname phân giải về public IP hiện tại.
- Đổi WAN IP: đợi Cloud DDNS cập nhật, sau đó refresh lại hồ sơ.
- Nếu router nằm sau modem/NAT, đối chiếu WAN modem và port-forward.
- Nếu CGNAT hoặc ISP chặn inbound, direct-DDNS không thể hoạt động cho đến khi có đường public inbound phù hợp.
