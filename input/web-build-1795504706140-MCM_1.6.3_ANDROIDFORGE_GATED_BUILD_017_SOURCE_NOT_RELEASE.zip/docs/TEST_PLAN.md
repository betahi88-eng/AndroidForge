# MCM 1.6.3 — Test plan and acceptance matrix

This file separates source-level checks from Android, RouterOS and remote-network acceptance. A source ZIP cannot be declared release-ready just because static scripts pass.

## A. Source and packaging

- AndroidForge preflight detects flat-root Gradle/Android/Kotlin project.
- `node --check` all WebView JavaScript.
- `python3 scripts/verify-room-migrations.py` checks the complete Room migration chain v1→v2→v3→v4→v5→v6→v7→v8 and verifies profile, metric, interface-counter and connection-log preservation.
- `python3 scripts/verify-ui-contract.py` checks duplicate/missing DOM IDs referenced by WebView JavaScript.
- `python3 -m py_compile tools/*.py`.
- `bash -n` every shell script.
- Parse Android Manifest, styles and Network Security Config XML.
- ZIP CRC, root layout, forbidden Flutter markers, private keys and APK presence.
- `:app:testDebugUnitTest`, `:app:lintDebug`, `:app:assembleDebug` on JDK 17 / Gradle 8.7 / SDK 35.
- Verify APK package `com.multicloud.mcm`, version and SHA-256.

## B. Multi-Cloud profiles

- Create separate `.sn.mynetname.net`, custom DDNS/domain and IPv4 profiles; reject native IPv6 literal entry.
- Create multiple groups/sites and multiple routers inside each group.
- Confirm no host, credentials or TLS pins are copied between profiles.
- Edit name, group, host, custom WAN port (1–65535), RouterOS family, service protocol, username and pin.
- Edit with blank password preserves old secret; edit with new password rotates credential alias.
- Simulate Room write failure during credential rotation; old profile/secret remain usable.
- Delete profile removes that profile's metrics/counters and secret alias only.
- App restart preserves groups, profiles and status history.
- Upgrade Room database v1→v2→v3→v4→v5→v6→v7→v8 without losing router profiles, ports, credentials, TLS pins, counters, connection logs or metric history.

- Verify main Add Router page contains exactly three inputs; service and port controls are in a closed-by-default Advanced section.
- AUTO + blank port probes REST/443 and API-SSL/8729 in parallel.
- AUTO + custom port probes both protocols at the same custom WAN port.
- REST_HTTPS + custom port probes only REST; API_SSL + custom port probes only API-SSL.
- Confirm the exact successful WAN port and selected mode are saved and reused by foreground monitoring and WorkManager.
- With both service pins independently confirmed, simulate the active service becoming unreachable or returning a protocol/REST-format/API-framing mismatch; verify foreground refresh, Refresh All and WorkManager can use only the alternate service + exact saved port pin, then persist that active endpoint and report PARTIAL/AUTO_FALLBACK.
- Verify AUTO does not switch on AUTH, READ_DENIED, TLS hostname mismatch, expired/not-yet-valid certificate (`TLS_CERT_VALIDITY`), TLS handshake failure, pin mismatch or a changed certificate; no unpinned alternate is attempted.
- Verify a first-use alternate service pauses for a separate fingerprint confirmation and a changed alternate certificate shows old/new fingerprint confirmation.
- Verify DNS resolver failure persists OFFLINE + DNS_FAILED/NETWORK_TIMEOUT in selected-router refresh and background worker, not just in the Refresh All summary.
- Change service selector after entering a custom port; custom port remains unchanged.
- AUTO resolves ROS7 to REST HTTPS and ROS6 to API-SSL; explicit API-SSL works with ROS6 and ROS7; explicit REST is rejected for ROS6.
- Save/reopen each profile and confirm selected service + custom port persist independently.
- WINBOX_CLI must perform EC-SRP5 server-proof verification, decrypt/verify M2 frames, open mepty, read identity/resource, and then read monitoring menus. TCP 8291 open alone is never success.

## C. RouterOS 7

- REST `www-ssl` reachable on correct host/port.
- Direct TLS certificate pin pass; mismatched pin fail closed.
- Test `UNSUPPORTED_PROTOCOL`, wrong HTTP port, timeout, DNS failure, refused port, bad credentials, insufficient read policy.
- Read `/system/resource`, `/interface`, `/ip/cloud`, `/ppp/active`, `/ip/arp`, `/ip/dhcp-server/lease`, `/tool/netwatch`.
- Test optional table permission denied: core dashboard remains available and status becomes PARTIAL.
- Ping success, partial loss, all-loss/incomplete counters, duplicate sequence and malformed rows.

- Test a custom WAN port NAT-forwarded to internal `www-ssl` and verify certificate pin remains correct.

## D. RouterOS 6

- `api-ssl` reachable at actual configured port (default 8729).
- Certificate pin mismatch, hostname mismatch, expired/not-yet-valid certificate and TLS protocol/port errors fail closed with distinct diagnostic codes where supported.
- Direct login and pre-6.43 legacy challenge-response login.
- Read system resource/interface/cloud/ppp active/ARP/DHCP lease/Netwatch.
- `!trap`, `!fatal`, `!empty`, disconnect, command timeout and missing `!done`.
- Ping with valid echo replies, partial loss, no replies after valid `!done`, duplicate/malformed/out-of-range sequences.
- Confirm the router is not overloaded by repeated sessions; app bounds concurrent commands to two.

- Test RouterOS 7 with explicit API-SSL service mode and a non-default WAN port.
- Test custom WAN port NAT-forwarded to internal `api-ssl`; verify background worker uses the same saved port and service mode.

## E. Dashboard and history

- Selected router refresh, 30-second visible refresh, app background/foreground.
- Refresh-all sequentially scans every saved router and preserves selected router snapshot.
- Per-router status `UNKNOWN/ONLINE/PARTIAL/OFFLINE`, timestamps and error details.
- CPU/RAM/interface rates, Cloud DDNS fields, PPPoE-only session count, ARP, DHCP, Netwatch.
- No-data/permission-denied/unsupported fields never become fake zero-valued success.
- History is separated by router ID; switch profiles and verify charts do not mix data.
- RX/TX interface history is separated by router and interface name; verify selected-interface charts load only matching counters and do not sum bridge/ether counters.
- First interface sample stores a counter baseline and does not report a fabricated Mbps value; counter reset/wrap/gap must not create a negative rate.
- Background worker records CPU/RAM only and respects retention.

## F. Remote DDNS network acceptance

For each remote site:
- Verify DDNS hostname resolves to the expected public IP/IPv6.
- Verify WAN routing/NAT and firewall path from the test network.
- Verify the endpoint port reaches the correct `www-ssl` (ROS7) or `api-ssl` (ROS6) service.
- Verify source-IP restriction and direct public WAN path; no VPN or relay.
- Test ISP dynamic IP change and DDNS convergence.
- Test CGNAT/double NAT and document when inbound connections cannot work.
- Confirm TLS certificate is valid for the hostname where hostname verification is used and pin matches independent export.

## G. Security and safety

- Password never appears in Room plaintext, WebView JSON or logs.
- Certificate mismatch blocks session; no fallback to HTTP or unpinned TLS.
- UI does not issue configuration writes.
- Inspect outbound API commands and confirm only read/print and bounded ping.
- Unit-test the transport-level command allowlist: block REST PUT/PATCH/DELETE paths, arbitrary REST POST, API add/set/remove/reboot/script commands, and unexpected API attributes before network I/O.
- Verify the only REST POST/API command is bounded ping (count 1..100, fixed 200 ms); the RouterOS user needs `test` for ping and does not need `write`.
- No Internet-wide management exposure in sample configs.

## Current environment gate

The packaging container does not have a full Android Gradle toolchain or live MikroTik hardware. Therefore Android Gradle tests, Room KAPT, lint, APK assembly, physical Android installation and RouterOS live tests must be reported as NOT RUN until executed on appropriate infrastructure.


## MNDP discovery tests (preserved from 1.4.0)

- `MndpPacketParserTest.parsesIdentityMacVersionAndIpv4`: valid TLVs produce the expected MAC, identity, version and advertised IPv4.
- `MndpPacketParserTest.rejectsTruncatedTlv`: truncated TLV payload is rejected.
- Device acceptance: scan while connected to the same Wi-Fi/L2 segment as a MikroTik with MNDP enabled; confirm identity/MAC/IP, select it, verify the host is prefilled, and verify no profile is saved until credentials and TLS pin are supplied.
- Negative acceptance: discovery across a routed VLAN must return no claim of success; manual IP entry remains available.


## DNS resolution fallback (1.6.3)

- Android system resolver succeeds: confirm DoH is not called and result identifies `ANDROID_SYSTEM`.
- Android system resolver returns `UnknownHostException`: confirm Google DoH resolves A/AAAA and result identifies `HTTPS_DOH_FALLBACK`.
- Google DoH unavailable: confirm Cloudflare DoH is attempted.
- All resolvers unavailable: confirm result remains `DNS_FAILED` and includes the system/DoH failure detail.
- Confirm diagnostics and the real REST/API-SSL/fingerprint paths resolve the same DDNS hostname.
- Confirm the connected socket targets the returned IP while TLS SNI and REST Host remain the original hostname.
- Confirm DNS fallback never changes router services, ports, firewall, NAT, DDNS, IP addresses or credentials.
- Run these checks on Android using both mobile data and Wi-Fi; validate the exact router hostname and expected WAN address.

### TLS identity and per-service pinning (candidate 006)

- Verify first-use TLS capture rejects an expired certificate and a certificate whose SAN/CN does not match the DDNS hostname, even if its SHA-256 fingerprint is shown.
- Verify a valid matching certificate still requires explicit independent SHA-256 confirmation before credentials are sent.
- Configure different certificates on `www-ssl` and `api-ssl`; confirm each profile stores independent REST/API-SSL fingerprints and WAN ports; never reuse one service pin for the other.
- Change the service selector on an existing profile; verify the old transport pin is not reused unless that service has its own previously confirmed pin for the exact WAN port.
- In AUTO, verify an alternate protocol requires a separate explicit pin confirmation the first time; later reuse is allowed only when that same service+WAN-port pin was previously confirmed.
- Rotate a pinned certificate; verify the old/new fingerprint dialog identifies the exact host, port and service, and no silent pin update occurs.


### Read-only transport enforcement and resource bounds (candidate 006)

- Verify REST GET rejects every path not in the monitoring allowlist; REST POST rejects all methods outside bounded `/ping` parameters.
- Verify API-SSL rejects add/set/remove/enable/disable/reboot and all commands outside the fixed monitoring `/print` list plus bounded `/ping`.
- Verify ping count is 1..100 and interval is fixed at 200 ms; `test` policy is optional for ping only.
- Verify API word/sentence/response byte/row limits abort oversized responses without reporting partial success.
- Verify no router configuration mutation occurs in setup, refresh, Refresh All or WorkManager.


## Additional candidate 006 TLS / API-SSL cases

- TLS hostname identity checks: DNS SAN exact match, SAN overrides mismatching CN, CN compatibility only without DNS SAN, IPv4 iPAddress SAN, and wildcard limited to exactly one left-most label.
- Certificate validity failure is distinct from TCP reachability and cannot trigger AUTO transport failover.
- API-SSL mock covers current login, legacy challenge login, read-only resource query, pre-network rejection of mutation commands, wrong-pin rejection and wrong-hostname rejection.
- First-use fingerprint inspection accepts a valid self-signed test certificate only after checking validity and hostname; mismatch fails closed.
- Room v7→v8: transport/port pins survive only when their old service is known; ambiguous AUTO pin is not assigned based on RouterOS major version.


## WinBox CLI integration acceptance (new)

1. Known-answer crypto tests: EC-SRP5 public key/client proof/server proof, stream-key derivation, AES/HMAC frame round-trip, wrong-HMAC rejection, exact 14-chunk boundary.
2. M2 framing/parser tests: TLV types, request IDs, session IDs, chunk continuation and frame length bounds.
3. Live CHR tests: RouterOS 7 WinBox CLI authentication, terminal open, startup prompt, identity/resource reads, large-output multi-pull, `/quit`; RouterOS 6.49 WinBox CLI same sequence. Verify the new VT100 dimensions/cursor negotiation and first-login password-nag handling against both versions.
4. Negative live tests: invalid credentials, unsupported legacy pre-6.43, permission denial, port closed, timeout, TCP reset, wrong/challenge frame tag, HMAC mismatch, terminal-open refusal.
5. Monitoring live tests: interface, IP Cloud, PPP active, ARP, DHCP lease, Netwatch, Bridge Host, VLAN and Bridge VLAN; compare against independent binary API reference client; test ROS7 JSON serialization and older as-value parsing.
6. UI automation: Android Emulator through Maestro or Appium enters a test profile, selects WINBOX_CLI, saves/connects, refreshes dashboard, verifies identity/resource and error/PARTIAL rendering.
7. Fault injection: CoreDNS changed A/AAAA, NXDOMAIN, SERVFAIL; Toxiproxy/NetEm delay, packet loss, reset, connect timeout and reconnect.
8. Data safety: confirm WinBox adapter sends only allowlisted read commands, never write/set/add/remove/enable/disable/reboot; no TLS pin is applied to WinBox; no passwords or proof material appear in logs. Verify switching an existing WINBOX_CLI profile back to AUTO does not leave WinBox selected or eligible as an automatic fallback.

## Lab toolchain

See [`../lab/README_VI.md`](../lab/README_VI.md). Containerlab 0.83+ supplies the RouterOS 7 CHR management-plane test; GNS3/QEMU supplies a RouterOS 6 CHR/data-plane topology. `tik4net` is the independent reference implementation for cross-checks, not an Android runtime dependency. Containerlab management-VRF tests are not evidence of Internet/WAN NAT reachability.

Release gate remains: Android Gradle/JUnit/lint/Debug+Release APK+AAB, Android Emulator automation, live CHR RouterOS 6/7 integration and external DDNS probe must pass before release status.
