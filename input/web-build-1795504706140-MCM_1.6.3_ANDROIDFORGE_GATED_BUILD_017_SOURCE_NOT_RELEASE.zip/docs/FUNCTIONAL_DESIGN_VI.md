# MCM 1.6.3 — Thiết kế Direct-DDNS đa cửa hàng

## 1. Mục tiêu

Một ứng dụng Android theo dõi nhiều cửa hàng/MikroTik. Mỗi hồ sơ kết nối trực tiếp qua MikroTik Cloud DDNS, DDNS/domain hoặc IP. Không VPN/WireGuard, VPS, MCM backend, relay hoặc agent.

## 2. Mỗi hồ sơ có cấu hình kết nối độc lập

1. Tên cửa hàng/router.
2. Hostname Cloud DDNS/domain/IP.
3. Phiên bản RouterOS 6 hoặc 7 (để kiểm tra tương thích dữ liệu).
4. Giao thức dịch vụ: `AUTO`, `REST_HTTPS`, `API_SSL` hoặc `WINBOX_CLI`.
5. Port WAN do người dùng nhập, số nguyên 1–65535. Khi có NAT, nhập port bên ngoài mà Android truy cập.
6. Username/password riêng; password mã hóa bằng Android Keystore.
7. SHA-256 fingerprint của leaf TLS certificate tại đúng hostname + port.

`AUTO` giữ mặc định cũ: ROS7 → REST HTTPS/443; ROS6 → API-SSL/8729. `REST_HTTPS` chỉ chấp nhận ROS7. `API_SSL` dùng được với ROS6/ROS7. Người dùng đổi OS/service thì port mặc định chỉ được gợi ý khi chưa nhập port thủ công; port tùy chỉnh được giữ nguyên và lưu riêng từng router.

**WinBox CLI là transport riêng của MCM.** MCM sử dụng terminal protocol WinBox mã hóa EC-SRP5/M2 qua TCP 8291 hoặc WAN port tùy chỉnh; không phải giao diện WinBox đồ họa, không dùng TLS fingerprint. Hỗ trợ RouterOS 6.43 trở lên; từ chối legacy MD5 trước 6.43. Không tự động fallback sang WinBox trong AUTO.

## 3. Luồng thêm/cập nhật router

1. Màn hình chính chỉ hiển thị ba trường DDNS/Hostname, Username, Password và một nút “Lưu & Kết nối”. Service mode và port WAN nằm trong mục Tùy chọn nâng cao, mặc định đóng; khi sửa hồ sơ, các giá trị đã lưu được nạp lại nhưng mục nâng cao vẫn không tự mở.
2. Nhập hostname; OS được xác định từ phản hồi RouterOS đã xác thực, không yêu cầu người dùng đoán phiên bản.
3. Với AUTO và để trống port, dò REST/443 và API-SSL/8729 song song. Với AUTO và port tùy chỉnh, thử cả hai giao thức tại cùng WAN port. Với mode chỉ định, chỉ thử giao thức đã chọn tại port nhập vào hoặc port mặc định tương ứng.
4. Đọc fingerprint TLS từ đúng host:port; đối chiếu ngoài ứng dụng qua nguồn tin cậy.
5. Đăng nhập tài khoản read-only, thực hiện READ_CHECK `/system/resource`, xác định RouterOS 6/7 từ dữ liệu thật và kiểm tra tương thích giao thức.
6. Chỉ lưu đúng port và service mode đã qua TLS + READ_CHECK; foreground/background monitoring phải tái sử dụng chính xác endpoint đã lưu.
7. Khi sửa profile, port không bị tự đổi khi thay OS/service. Để trống password giữ credential mã hóa hiện có.

## 4. Chẩn đoán phân tầng

- `DNS_FAILED`: hostname chưa phân giải/Cloud DDNS chưa cập nhật.
- `TCP_TIMEOUT` / `TCP_UNREACHABLE`: WAN, firewall, NAT, ISP hoặc port/service không tiếp cận được.
- `TLS_PROTOCOL`: endpoint TLS không đúng giao thức; nếu port đang trỏ WinBox thì chọn mode `WINBOX_CLI` thay vì REST/API-SSL.
- `TLS_HANDSHAKE`: TLS/chứng chỉ không thương lượng được.
- `TLS_FINGERPRINT_MISMATCH`: leaf certificate khác pin đã lưu.
- `AUTH`: RouterOS từ chối username/password.
- `PERMISSION`: tài khoản thiếu quyền đọc.
- `PARTIAL`: core resource thành công nhưng bảng phụ lỗi.
- `ONLINE`: đọc core resource thành công và không có lỗi bảng phụ.

Không bỏ pin và không fallback HTTP. Chế độ AUTO chỉ dò hai endpoint ở giai đoạn nhận diện ban đầu; khi người dùng chọn REST_HTTPS hoặc API_SSL, MCM không tự chuyển sang giao thức khác. Không tự đổi port ngoài ý người dùng.

## 5. WAN IP động và port mapping

- MCM lưu hostname để DNS được phân giải lại trong mỗi kết nối mới.
- Đổi WAN IP: chờ DDNS cập nhật; không khóa profile vào IP cũ.
- Nếu cổng WAN được đổi hoặc forward sang cổng trong khác, người dùng sửa port WAN trong hồ sơ MCM.
- Port phải kết thúc ở đúng dịch vụ `www-ssl` hoặc `api-ssl`; thay đổi số port trong app không tự bật service, firewall hay NAT ở router.
- CGNAT/inbound ISP block/double NAT chưa forward không thể được khắc phục chỉ bằng cách đổi port.

## 6. Bảo toàn dữ liệu

Room v3→v4 thêm `connectionMode` mặc định `AUTO`. Migration giữ nguyên host, port, OS, username, credential alias, fingerprint, trạng thái và lịch sử. Không yêu cầu người dùng thêm lại cửa hàng.

## 7. Phạm vi chỉ đọc

MCM chỉ truy vấn system resource, interface, IP Cloud, PPPoE active, ARP, DHCP, Netwatch, bridge hosts/VLAN và ping giới hạn. Không thay đổi cấu hình RouterOS, dịch vụ, port, firewall, NAT, IP hoặc DDNS.


## WinBox CLI — luồng tích hợp

- Save & Connect phân giải DDNS qua DNS chain đang có, thử từng IP tại TCP port đã nhập (mặc định 8291), thực hiện EC-SRP5, kiểm tra server proof, mở terminal M2/mepty và đọc identity/resource thật trước khi lưu profile.
- Không sử dụng TLS pin cho WinBox vì giao thức này không phải TLS. Điều này không làm giảm xác minh; EC-SRP5 server proof và HMAC của từng frame được kiểm tra.
- Monitoring giữ một terminal session, chạy các lệnh `print` nằm trong allowlist. RouterOS 7.13+ dùng JSON serialization; RouterOS cũ dùng as-value parser. Bảng lỗi được trả riêng và profile thành PARTIAL, không thay dữ liệu thiếu bằng 0.
- Không hỗ trợ RouterOS WinBox legacy MD5 trước 6.43; không bật cơ chế fallback không mã hóa. Ping chủ động chưa được hỗ trợ trong adapter WinBox và sẽ được báo unavailable.
