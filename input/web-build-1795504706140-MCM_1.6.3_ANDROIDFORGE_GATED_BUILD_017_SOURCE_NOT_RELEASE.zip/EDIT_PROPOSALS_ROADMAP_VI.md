# ĐỀ XUẤT CHỈNH SỬA — MCM 1.6.3

Tài liệu này là backlog đề xuất, không tự ý thay đổi chức năng hiện có. Mỗi mục nên được thực hiện thành một thay đổi nhỏ, có tiêu chí nghiệm thu rõ ràng.

## P0 — Bảo đảm build và phát hành được
1. Chạy build AndroidForge thật bằng JDK 17 / Gradle 8.7 / SDK 35.
2. Chốt lỗi compile/KAPT/manifest/lint nếu log build chỉ ra lỗi cụ thể.
3. Xác minh APK debug: `applicationId=com.multicloud.mcm`, `versionName=1.6.3`, `versionCode=12`, minSdk 26.
4. Lưu build provenance (source SHA-256, workflow run ID, commit SHA, toolchain, APK SHA-256).
5. Cài APK trên thiết bị Android API 26+ và bản Android hiện hành; mở app, tạo/sửa/xóa profile mẫu.

## P1 — Chất lượng kết nối và độ tin cậy
1. Kiểm thử RouterOS 6 API-SSL và RouterOS 7 REST HTTPS độc lập.
2. Kiểm thử hostname DDNS, IP trực tiếp, port WAN tùy chỉnh và NAT forward.
3. Kiểm thử TLS pin đúng/sai; pin sai phải chặn kết nối, không hạ cấp HTTP.
4. Kiểm thử Android DNS lỗi và DoH fallback; hiển thị đúng giai đoạn lỗi.
5. Kiểm thử timeout, mất mạng, router offline, thiếu quyền API và phản hồi không đầy đủ.
6. Kiểm thử chạy nền, chuyển Wi-Fi/4G, khôi phục tiến trình và lưu lịch sử.

## P2 — Trải nghiệm người dùng
1. Rà soát luồng thêm router lần đầu để người mới hiểu Host, Port, RouterOS và protocol.
2. Phân biệt rõ trạng thái ONLINE / PARTIAL / OFFLINE / UNKNOWN bằng nguyên nhân cụ thể.
3. Không hiển thị số 0 giả khi dữ liệu không được router cung cấp.
4. Kiểm tra bố cục trên màn hình nhỏ, font lớn, chế độ tối/sáng và xoay màn hình.
5. Thêm nút xuất log đã khử thông tin nhạy cảm để hỗ trợ xử lý lỗi.

## P3 — Bảo mật và vận hành
1. Rà soát toàn bộ log để bảo đảm không ghi password, token hoặc Authorization header.
2. Dùng tài khoản RouterOS chỉ đọc, giới hạn IP nguồn và chỉ mở dịch vụ cần thiết.
3. Kiểm tra lưu trữ credential bằng Android Keystore; kiểm tra backup/restore không làm lộ bí mật.
4. Rà soát quyền Android, foreground/background service và thông báo.
5. Không bật tự động cập nhật hoặc tự phát hành Release khi chưa có phê duyệt.

## Nguyên tắc sửa
- Không thay applicationId hoặc versionCode nếu chưa có yêu cầu nâng phiên bản.
- Không đổi mặc định RouterOS/protocol/port nếu chưa có kiểm thử tương ứng.
- Không bỏ TLS verification hoặc thêm HTTP fallback để “làm cho kết nối chạy”.
- Không tuyên bố đã kiểm thử thiết bị/router thật nếu chỉ chạy unit tests.
- Mỗi sửa đổi phải ghi: file thay đổi, lý do, ảnh hưởng, cách tái hiện lỗi, kết quả test và cách rollback.
