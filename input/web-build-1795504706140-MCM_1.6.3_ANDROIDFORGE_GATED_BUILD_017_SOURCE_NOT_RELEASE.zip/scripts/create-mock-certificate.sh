#!/usr/bin/env bash
set -euo pipefail
HOST="${1:-127.0.0.1}"
OUT_DIR="${2:-.mcm-test-cert}"
mkdir -p "$OUT_DIR"
if [[ "$HOST" =~ ^[0-9]+(\.[0-9]+){3}$ ]]; then
  SAN="IP:${HOST},DNS:localhost"
else
  SAN="DNS:${HOST},DNS:localhost"
fi
openssl req -x509 -nodes -newkey rsa:2048 \
  -keyout "$OUT_DIR/router.key" \
  -out "$OUT_DIR/router.crt" \
  -days 365 \
  -subj "/CN=${HOST}" \
  -addext "subjectAltName=${SAN}" \
  -addext "keyUsage=digitalSignature,keyEncipherment,keyCertSign" \
  -addext "extendedKeyUsage=serverAuth"
echo "SHA-256 fingerprint (compare independently before entering it in MCM):"
openssl x509 -in "$OUT_DIR/router.crt" -noout -fingerprint -sha256
printf 'Certificate: %s/router.crt\nPrivate key: %s/router.key\n' "$OUT_DIR" "$OUT_DIR"
