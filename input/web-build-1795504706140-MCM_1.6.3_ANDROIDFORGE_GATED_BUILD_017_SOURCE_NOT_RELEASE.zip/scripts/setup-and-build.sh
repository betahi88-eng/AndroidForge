#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

command -v java >/dev/null || { echo "JDK 17 is required." >&2; exit 1; }
JAVA_VERSION="$(java -version 2>&1 | sed -n '1s/.*version \"\([0-9]*\).*/\1/p')"
[[ "$JAVA_VERSION" == "17" ]] || {
  echo "This project is configured for JDK 17; detected ${JAVA_VERSION:-unknown}." >&2
  exit 1
}
command -v gradle >/dev/null || {
  echo "Gradle 8.7 is required. This source package does not bundle the Gradle Wrapper JAR." >&2
  exit 1
}
GRADLE_VERSION="$(gradle --version | awk '/^Gradle / { print $2; exit }')"
[[ "$GRADLE_VERSION" == "8.7" ]] || {
  echo "This build baseline is pinned to Gradle 8.7; detected $GRADLE_VERSION." >&2
  exit 1
}
SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [[ -z "$SDK_ROOT" && -f local.properties ]]; then
  SDK_ROOT="$(sed -n 's/^sdk.dir=//p' local.properties | head -n1 | sed 's#\\:#:#g')"
fi
[[ -n "$SDK_ROOT" && -f "$SDK_ROOT/platforms/android-35/android.jar" ]] || {
  echo "Android SDK Platform 35 is required. Set ANDROID_SDK_ROOT or ANDROID_HOME." >&2
  exit 1
}
[[ -d "$SDK_ROOT/build-tools/35.0.0" ]] || {
  echo "Android Build Tools 35.0.0 are required in $SDK_ROOT." >&2
  exit 1
}
AAPT="$SDK_ROOT/build-tools/35.0.0/aapt"
[[ -x "$AAPT" ]] || { echo "Android aapt is missing: $AAPT" >&2; exit 1; }
printf 'Environment OK: JDK %s, Gradle %s, Android SDK %s\n' "$JAVA_VERSION" "$GRADLE_VERSION" "$SDK_ROOT"

gradle --no-daemon clean
gradle --no-daemon :app:testDebugUnitTest :app:lintDebug
gradle --no-daemon :app:assembleDebug :app:bundleDebug
gradle --no-daemon :app:assembleRelease :app:bundleRelease

DEBUG_APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
RELEASE_APK="$ROOT/app/build/outputs/apk/release/app-release-unsigned.apk"
test -s "$DEBUG_APK" || { echo "Debug APK was not produced." >&2; exit 1; }
test -s "$RELEASE_APK" || { echo "Unsigned Release APK was not produced." >&2; exit 1; }
for APK in "$DEBUG_APK" "$RELEASE_APK"; do
  BADGING="$("$AAPT" dump badging "$APK")"
  grep -Fq "package: name='com.multicloud.mcm'" <<<"$BADGING" || { echo "Wrong package in $APK" >&2; exit 1; }
  grep -Fq "versionCode='12'" <<<"$BADGING" || { echo "Wrong versionCode in $APK" >&2; exit 1; }
  grep -Fq "versionName='1.6.3'" <<<"$BADGING" || { echo "Wrong versionName in $APK" >&2; exit 1; }
  echo "Verified APK metadata: $APK"
  sha256sum "$APK"
done
