#!/usr/bin/env python3
"""Verify the source identity and SHA-256 manifest before packaging."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
manifest = json.loads((ROOT / "SOURCE_PROVENANCE.json").read_text(encoding="utf-8"))
identity = (ROOT / "SOURCE_IDENTITY.txt").read_text(encoding="utf-8").splitlines()[0].strip()
expected = "MCM_SOURCE_ID=" + manifest["source_id"]
if identity != expected:
    raise SystemExit(f"Source identity mismatch: {identity!r} != {expected!r}")
if manifest.get("patch_id") != manifest.get("source_id"):
    raise SystemExit("Patch ID and source ID differ")

seen: set[str] = set()
for item in manifest.get("changed_files", []):
    rel = item["path"]
    if rel in seen:
        raise SystemExit(f"Duplicate provenance path: {rel}")
    seen.add(rel)
    path = (ROOT / rel).resolve()
    if ROOT.resolve() not in path.parents or not path.is_file():
        raise SystemExit(f"Provenance path missing or outside source tree: {rel}")
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if digest.lower() != item["sha256"].lower():
        raise SystemExit(f"SHA-256 mismatch: {rel}")

print(f"Source provenance PASS: {manifest['source_id']} ({len(seen)} file hashes)")
