#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

fail() { echo "ANDROIDFORGE BUILD GATE FAIL: $*" >&2; exit 1; }
command -v java >/dev/null 2>&1 || fail "Java is not installed. JDK 17 is required."
command -v gradle >/dev/null 2>&1 || fail "Gradle is not installed. Gradle 8.7 or newer compatible with AGP 8.6.1 is required."
command -v python3 >/dev/null 2>&1 || fail "Python 3 is required for toolchain checks."
JAVA_MAJOR="$(java -version 2>&1 | sed -nE 's/.*version "([0-9]+).*/\1/p' | head -1)"
[[ -n "$JAVA_MAJOR" ]] || fail "Could not determine Java version."
(( JAVA_MAJOR >= 17 )) || fail "JDK 17 or newer is required (found Java $JAVA_MAJOR)."
GRADLE_VERSION="$(gradle --version | awk '/^Gradle / { print $2; exit }')"
[[ -n "$GRADLE_VERSION" ]] || fail "Could not determine Gradle version."
python3 - "$GRADLE_VERSION" <<'PYVER' || fail "Gradle $GRADLE_VERSION is below the 8.7 minimum for AGP 8.6.1."
import re, sys
m = re.match(r"^(\d+)\.(\d+)", sys.argv[1])
if not m or tuple(map(int, m.groups())) < (8, 7):
    raise SystemExit(1)
PYVER

SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
[[ -n "$SDK_ROOT" ]] || fail "ANDROID_SDK_ROOT/ANDROID_HOME is not set."
[[ -s "$SDK_ROOT/platforms/android-35/android.jar" ]] || fail "Android SDK Platform 35 is missing."
AAPT="$SDK_ROOT/build-tools/35.0.0/aapt"
[[ -x "$AAPT" ]] || fail "Android Build Tools 35.0.0 aapt is missing."

# Source identity and exact-tree checks happen before Gradle is allowed to resolve/build the app.
bash scripts/androidforge-preflight.sh
MCM_RUN_ANDROID_GRADLE=0 bash scripts/verify-source.sh

WORK_OUT="$ROOT/.mcm-build-acceptance"
OUT="$ROOT/app/build/mcm-acceptance"
rm -rf "$WORK_OUT"
mkdir -p "$WORK_OUT"
BUILD_LOG="$WORK_OUT/gradle-build.log"

{
  echo "Source ID: $(sed -n 's/^MCM_SOURCE_ID=//p' SOURCE_IDENTITY.txt | head -1)"
  echo "Build started: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "Gradle version:"
  gradle --version
  echo "Java version:"
  java -version 2>&1
} | tee "$WORK_OUT/BUILD_ENVIRONMENT.txt"

# preBuild is wired to verify both Debug and Release runtime dependency graphs.
# A stale SSH/JSch/BouncyCastle dependency therefore stops before resource merging.
gradle --no-daemon --stacktrace \
  clean \
  :app:verifyMcmRuntimeDependencies \
  :app:testDebugUnitTest \
  :app:lint \
  :app:assembleDebug \
  :app:bundleDebug \
  :app:assembleRelease \
  :app:bundleRelease 2>&1 | tee "$BUILD_LOG"

DEBUG_APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
DEBUG_AAB="$ROOT/app/build/outputs/bundle/debug/app-debug.aab"
RELEASE_AAB="$ROOT/app/build/outputs/bundle/release/app-release.aab"
[[ -s "$DEBUG_APK" ]] || fail "Debug APK not produced by this build."
[[ -s "$DEBUG_AAB" ]] || fail "Debug AAB not produced by this build."
[[ -s "$RELEASE_AAB" ]] || fail "Release AAB not produced by this build."

shopt -s nullglob
release_candidates=("$ROOT"/app/build/outputs/apk/release/app-release*.apk)
shopt -u nullglob
((${#release_candidates[@]} > 0)) || fail "Release APK not produced by this build."
RELEASE_APK="${release_candidates[0]}"

mkdir -p "$OUT"
cp "$BUILD_LOG" "$OUT/gradle-build.log"
cp "$WORK_OUT/BUILD_ENVIRONMENT.txt" "$OUT/BUILD_ENVIRONMENT.txt"
for apk in "$DEBUG_APK" "$RELEASE_APK"; do
  BADGING="$OUT/$(basename "$apk").badging.txt"
  "$AAPT" dump badging "$apk" > "$BADGING"
  grep -Fq "package: name='com.multicloud.mcm'" "$BADGING" || fail "Wrong applicationId in $(basename "$apk")."
  grep -Fq "versionCode='12'" "$BADGING" || fail "Wrong versionCode in $(basename "$apk")."
  grep -Fq "versionName='1.6.3'" "$BADGING" || fail "Wrong versionName in $(basename "$apk")."
done

cp "$DEBUG_APK" "$OUT/MCM-1.6.3-debug.apk"
cp "$RELEASE_APK" "$OUT/MCM-1.6.3-release.apk"
cp "$DEBUG_AAB" "$OUT/MCM-1.6.3-debug.aab"
cp "$RELEASE_AAB" "$OUT/MCM-1.6.3-release.aab"
(
  cd "$OUT"
  sha256sum MCM-1.6.3-debug.apk MCM-1.6.3-release.apk MCM-1.6.3-debug.aab MCM-1.6.3-release.aab > SHA256SUMS.txt
)
cat > "$OUT/BUILD_RESULT.txt" <<EOF
Result: PASS
Source ID: $(sed -n 's/^MCM_SOURCE_ID=//p' SOURCE_IDENTITY.txt | head -1)
Application ID: com.multicloud.mcm
Version: 1.6.3 (versionCode 12)
Checks: exact source tree, Debug+Release runtime dependency guard, Android unit tests, lint, Debug/Release APK and AAB, APK package/version metadata.
Release signing: inspect the AndroidForge build log and signing configuration; this source does not contain a production signing key.
RouterOS/DDNS live acceptance: NOT INCLUDED IN THIS BUILD GATE.
EOF

echo "ANDROIDFORGE BUILD GATE PASS"
echo "Artifacts and checksums: $OUT"
cat "$OUT/SHA256SUMS.txt"
rm -rf "$WORK_OUT"
