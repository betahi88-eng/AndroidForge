#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
KOTLINC="${KOTLINC:-$(command -v kotlinc || true)}"
JAVA="${JAVA:-$(command -v java || true)}"
if [[ -z "$KOTLINC" || -z "$JAVA" ]]; then
  echo "WinBox JVM smoke tests require kotlinc and java." >&2
  exit 2
fi
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
"$KOTLINC" \
  app/src/main/java/com/multicloud/mcm/routeros/WinboxCliConnector.kt \
  tools/kotlin-smoke/WinboxCryptoSmoke.kt \
  -include-runtime -d "$TMP/winbox-crypto-smoke.jar"
"$JAVA" -jar "$TMP/winbox-crypto-smoke.jar"
cat > "$TMP/stubs.kt" <<'KOTLIN'
package com.multicloud.mcm
 data class InterfaceSnapshot(val name:String,val type:String,val running:Boolean,val rxBytes:Long?,val txBytes:Long?,val lastLinkUpTime:String?)
 data class PingMeasurement(val a:Int=0)
 data class SystemResource(val version:String?,val uptime:String?,val cpuLoadPercent:Int?,val freeMemoryBytes:Long?,val totalMemoryBytes:Long?)
 sealed interface McmResult<out T>{ data class Success<T>(val value:T):McmResult<T>; data class Failure(val code:String,val message:String):McmResult<Nothing> }
KOTLIN
cat > "$TMP/coroutines.kt" <<'KOTLIN'
package kotlinx.coroutines
object Dispatchers { val IO: Any = Any() }
suspend fun <T> withContext(context: Any, block: suspend () -> T): T = block()
class CancellationException: IllegalStateException()
KOTLIN
cat > "$TMP/json.kt" <<'KOTLIN'
package org.json
class JSONArray(s:String) { fun length():Int=0; fun optJSONObject(i:Int):JSONObject?=null; fun opt(i:Int):Any?=null }
class JSONObject(s:String) { fun keys():MutableIterator<String> = mutableListOf<String>().iterator(); fun opt(k:String):Any?=null; companion object { val NULL=Any() } }
KOTLIN
"$KOTLINC" \
  "$TMP/stubs.kt" "$TMP/coroutines.kt" "$TMP/json.kt" \
  app/src/main/java/com/multicloud/mcm/routeros/WinboxCliConnector.kt \
  app/src/main/java/com/multicloud/mcm/routeros/WinboxCliRepository.kt \
  tools/kotlin-smoke/WinboxRepositorySmoke.kt \
  -include-runtime -d "$TMP/winbox-repository-smoke.jar"
"$JAVA" -jar "$TMP/winbox-repository-smoke.jar"
