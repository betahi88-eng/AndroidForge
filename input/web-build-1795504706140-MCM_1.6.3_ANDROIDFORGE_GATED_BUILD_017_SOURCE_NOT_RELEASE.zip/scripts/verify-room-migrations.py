#!/usr/bin/env python3
"""Exercise Room schema migrations through v8 and verify data + service/port TLS pin scoping."""
from __future__ import annotations

import sqlite3


def columns(connection: sqlite3.Connection, table: str) -> set[str]:
    return {row[1] for row in connection.execute(f'PRAGMA table_info("{table}")')}


def seed_v1() -> sqlite3.Connection:
    connection = sqlite3.connect(":memory:")
    connection.execute(
        """CREATE TABLE router_profiles (
            id TEXT NOT NULL PRIMARY KEY, name TEXT NOT NULL, host TEXT NOT NULL,
            port INTEGER NOT NULL, routerOsMajor INTEGER NOT NULL, username TEXT NOT NULL,
            credentialAlias TEXT NOT NULL, tlsSha256Pin TEXT NOT NULL,
            createdAtEpochMs INTEGER NOT NULL, lastSeenAtEpochMs INTEGER
        )"""
    )
    connection.execute(
        "INSERT INTO router_profiles VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        ("router-1", "Office", "office.sn.mynetname.net", 8443, 7, "monitor", "alias-1", "A" * 64, 1, 2),
    )
    connection.execute("CREATE TABLE metric_history (id INTEGER PRIMARY KEY, routerId TEXT, metricKey TEXT, value REAL)")
    connection.execute("INSERT INTO metric_history VALUES (1, 'router-1', 'cpu_load', 12.0)")
    connection.execute("CREATE TABLE interface_counters (routerId TEXT, interfaceName TEXT, rxBytes INTEGER)")
    connection.execute("INSERT INTO interface_counters VALUES ('router-1', 'ether1', 1000)")
    return connection


def migrate_1_to_2(connection: sqlite3.Connection) -> None:
    connection.execute("ALTER TABLE router_profiles ADD COLUMN siteName TEXT NOT NULL DEFAULT ''")


def migrate_2_to_3(connection: sqlite3.Connection) -> None:
    connection.execute("ALTER TABLE router_profiles ADD COLUMN lastStatus TEXT NOT NULL DEFAULT 'UNKNOWN'")
    connection.execute("ALTER TABLE router_profiles ADD COLUMN lastErrorCode TEXT")
    connection.execute("ALTER TABLE router_profiles ADD COLUMN lastErrorMessage TEXT")
    connection.execute("ALTER TABLE router_profiles ADD COLUMN lastCheckedAtEpochMs INTEGER")


def migrate_3_to_4(connection: sqlite3.Connection) -> None:
    connection.execute("ALTER TABLE router_profiles ADD COLUMN connectionMode TEXT NOT NULL DEFAULT 'AUTO'")


def check_v1_to_v4() -> None:
    connection = seed_v1()
    migrate_1_to_2(connection)
    migrate_2_to_3(connection)
    migrate_3_to_4(connection)
    expected = {
        "siteName", "lastStatus", "lastErrorCode", "lastErrorMessage",
        "lastCheckedAtEpochMs", "connectionMode",
    }
    assert expected.issubset(columns(connection, "router_profiles"))
    row = connection.execute(
        "SELECT id, name, host, port, credentialAlias, siteName, lastStatus, connectionMode "
        "FROM router_profiles WHERE id = 'router-1'"
    ).fetchone()
    assert row == ("router-1", "Office", "office.sn.mynetname.net", 8443, "alias-1", "", "UNKNOWN", "AUTO")
    assert connection.execute("SELECT value FROM metric_history WHERE routerId = 'router-1'").fetchone() == (12.0,)
    assert connection.execute("SELECT rxBytes FROM interface_counters WHERE routerId = 'router-1'").fetchone() == (1000,)
    connection.close()



def migrate_4_to_5(connection: sqlite3.Connection) -> None:
    connection.execute("ALTER TABLE router_profiles ADD COLUMN lastResolvedIp TEXT")
    connection.execute("ALTER TABLE router_profiles ADD COLUMN dnsResolver TEXT")
    connection.execute("ALTER TABLE router_profiles ADD COLUMN fallbackAvailable INTEGER NOT NULL DEFAULT 0")
    connection.execute("ALTER TABLE router_profiles ADD COLUMN routerOsVersion TEXT")
    connection.execute("ALTER TABLE router_profiles ADD COLUMN accessLevel TEXT NOT NULL DEFAULT 'UNKNOWN'")
    connection.execute("ALTER TABLE router_profiles ADD COLUMN lastConnectionLatencyMs INTEGER")
    connection.execute("ALTER TABLE router_profiles ADD COLUMN tlsPinConfirmedAtEpochMs INTEGER")


def migrate_5_to_6(connection: sqlite3.Connection) -> None:
    connection.execute("""CREATE TABLE IF NOT EXISTS connection_attempt_logs (
        id TEXT NOT NULL PRIMARY KEY, routerId TEXT NOT NULL, attemptedAtEpochMs INTEGER NOT NULL,
        durationMs INTEGER NOT NULL, dnsResolver TEXT, resolvedIps TEXT NOT NULL,
        restResult TEXT NOT NULL, apiSslResult TEXT NOT NULL, restProbeDetails TEXT NOT NULL,
        apiSslProbeDetails TEXT NOT NULL, restAuthDurationMs INTEGER NOT NULL,
        apiSslAuthDurationMs INTEGER NOT NULL, selectedProtocol TEXT, finalState TEXT NOT NULL, detail TEXT
    )""")
    connection.execute("CREATE INDEX IF NOT EXISTS index_connection_attempt_logs_routerId_attemptedAtEpochMs ON connection_attempt_logs(routerId, attemptedAtEpochMs)")


def migrate_6_to_7(connection: sqlite3.Connection) -> None:
    connection.execute("ALTER TABLE router_profiles ADD COLUMN activeTransport TEXT")


def migrate_7_to_8(connection: sqlite3.Connection) -> None:
    connection.execute("ALTER TABLE router_profiles ADD COLUMN tlsRestSha256Pin TEXT")
    connection.execute("ALTER TABLE router_profiles ADD COLUMN tlsRestPinPort INTEGER")
    connection.execute("ALTER TABLE router_profiles ADD COLUMN tlsApiSslSha256Pin TEXT")
    connection.execute("ALTER TABLE router_profiles ADD COLUMN tlsApiSslPinPort INTEGER")
    connection.execute("""UPDATE router_profiles
        SET tlsRestSha256Pin=tlsSha256Pin, tlsRestPinPort=port
        WHERE tlsSha256Pin != '' AND (
            activeTransport='REST_HTTPS' OR
            (activeTransport IS NULL AND connectionMode='REST_HTTPS')
        )""")
    connection.execute("""UPDATE router_profiles
        SET tlsApiSslSha256Pin=tlsSha256Pin, tlsApiSslPinPort=port
        WHERE tlsSha256Pin != '' AND (
            activeTransport='API_SSL' OR
            (activeTransport IS NULL AND connectionMode='API_SSL')
        )""")


def check_v1_to_v8() -> None:
    connection = seed_v1()
    migrate_1_to_2(connection)
    migrate_2_to_3(connection)
    migrate_3_to_4(connection)
    migrate_4_to_5(connection)
    migrate_5_to_6(connection)
    expected = {
        "siteName", "lastStatus", "lastErrorCode", "lastErrorMessage", "lastCheckedAtEpochMs",
        "connectionMode", "lastResolvedIp", "dnsResolver", "fallbackAvailable", "routerOsVersion",
        "accessLevel", "lastConnectionLatencyMs", "tlsPinConfirmedAtEpochMs",
    }
    assert expected.issubset(columns(connection, "router_profiles"))
    row = connection.execute(
        "SELECT id, host, port, credentialAlias, tlsSha256Pin, lastStatus, connectionMode, accessLevel "
        "FROM router_profiles WHERE id='router-1'"
    ).fetchone()
    assert row == ("router-1", "office.sn.mynetname.net", 8443, "alias-1", "A" * 64, "UNKNOWN", "AUTO", "UNKNOWN")
    assert connection.execute("SELECT value FROM metric_history WHERE routerId='router-1'").fetchone() == (12.0,)
    assert connection.execute("SELECT rxBytes FROM interface_counters WHERE routerId='router-1'").fetchone() == (1000,)
    # New log table and index exist, and data remains isolated by routerId.
    connection.execute("INSERT INTO connection_attempt_logs VALUES ('log-1','router-1',10,20,'ANDROID_SYSTEM','[]','OK','OK','{}','{}',1,1,'REST_HTTPS','READY',NULL)")
    assert connection.execute("SELECT routerId, finalState FROM connection_attempt_logs").fetchone() == ("router-1", "READY")
    index_names = {row[1] for row in connection.execute("PRAGMA index_list('connection_attempt_logs')")}
    assert "index_connection_attempt_logs_routerId_attemptedAtEpochMs" in index_names
    migrate_6_to_7(connection)
    assert "activeTransport" in columns(connection, "router_profiles")
    # AUTO profiles with no recorded transport are ambiguous; keep the legacy pin unassigned.
    assert connection.execute("SELECT activeTransport FROM router_profiles WHERE id='router-1'").fetchone() == (None,)
    connection.execute(
        "INSERT INTO router_profiles (id,name,host,port,routerOsMajor,username,credentialAlias,tlsSha256Pin,createdAtEpochMs,connectionMode,activeTransport) "
        "VALUES ('router-2','Branch','branch.example.net',9443,6,'monitor','alias-2',?,3,'AUTO','API_SSL')",
        ("B" * 64,),
    )
    connection.execute(
        "INSERT INTO router_profiles (id,name,host,port,routerOsMajor,username,credentialAlias,tlsSha256Pin,createdAtEpochMs,connectionMode,activeTransport) "
        "VALUES ('router-3','Other','other.example.net',10443,7,'monitor','alias-3',?,4,'REST_HTTPS','REST_HTTPS')",
        ("C" * 64,),
    )
    connection.execute(
        "INSERT INTO router_profiles (id,name,host,port,routerOsMajor,username,credentialAlias,tlsSha256Pin,createdAtEpochMs,connectionMode) "
        "VALUES ('router-4','Fixed API','fixed-api.example.net',8729,7,'monitor','alias-4',?,5,'API_SSL')",
        ("D" * 64,),
    )
    connection.execute(
        "INSERT INTO router_profiles (id,name,host,port,routerOsMajor,username,credentialAlias,tlsSha256Pin,createdAtEpochMs,connectionMode,activeTransport) "
        "VALUES ('router-5','AUTO REST','auto-rest.example.net',8443,7,'monitor','alias-5',?,6,'AUTO','REST_HTTPS')",
        ("E" * 64,),
    )
    migrate_7_to_8(connection)
    expected_v8 = {"tlsRestSha256Pin", "tlsRestPinPort", "tlsApiSslSha256Pin", "tlsApiSslPinPort"}
    assert expected_v8.issubset(columns(connection, "router_profiles"))
    assert connection.execute(
        "SELECT tlsRestSha256Pin,tlsRestPinPort,tlsApiSslSha256Pin,tlsApiSslPinPort FROM router_profiles WHERE id='router-1'"
    ).fetchone() == (None, None, None, None)
    assert connection.execute(
        "SELECT tlsRestSha256Pin,tlsRestPinPort,tlsApiSslSha256Pin,tlsApiSslPinPort FROM router_profiles WHERE id='router-2'"
    ).fetchone() == (None, None, "B" * 64, 9443)
    assert connection.execute(
        "SELECT tlsRestSha256Pin,tlsRestPinPort,tlsApiSslSha256Pin,tlsApiSslPinPort FROM router_profiles WHERE id='router-3'"
    ).fetchone() == ("C" * 64, 10443, None, None)
    assert connection.execute(
        "SELECT tlsRestSha256Pin,tlsRestPinPort,tlsApiSslSha256Pin,tlsApiSslPinPort FROM router_profiles WHERE id='router-4'"
    ).fetchone() == (None, None, "D" * 64, 8729)
    assert connection.execute(
        "SELECT tlsRestSha256Pin,tlsRestPinPort,tlsApiSslSha256Pin,tlsApiSslPinPort FROM router_profiles WHERE id='router-5'"
    ).fetchone() == ("E" * 64, 8443, None, None)
    # Updating an active protocol never rewrites the independent pin for the other protocol.
    connection.execute("UPDATE router_profiles SET tlsApiSslSha256Pin=?,tlsApiSslPinPort=8729 WHERE id='router-1'", ("D" * 64,))
    assert connection.execute("SELECT tlsRestSha256Pin,tlsApiSslSha256Pin FROM router_profiles WHERE id='router-1'").fetchone() == (None, "D" * 64)
    assert connection.execute("SELECT value FROM metric_history WHERE routerId='router-1'").fetchone() == (12.0,)
    assert connection.execute("SELECT rxBytes FROM interface_counters WHERE routerId='router-1'").fetchone() == (1000,)
    connection.close()

def check_v2_to_v4() -> None:
    connection = sqlite3.connect(":memory:")
    connection.execute(
        """CREATE TABLE router_profiles (
            id TEXT NOT NULL PRIMARY KEY, name TEXT NOT NULL, host TEXT NOT NULL,
            port INTEGER NOT NULL, routerOsMajor INTEGER NOT NULL, username TEXT NOT NULL,
            credentialAlias TEXT NOT NULL, tlsSha256Pin TEXT NOT NULL,
            createdAtEpochMs INTEGER NOT NULL, lastSeenAtEpochMs INTEGER,
            siteName TEXT NOT NULL DEFAULT ''
        )"""
    )
    connection.execute(
        "INSERT INTO router_profiles (id, name, host, port, routerOsMajor, username, credentialAlias, tlsSha256Pin, createdAtEpochMs, siteName) "
        "VALUES ('router-2', 'Branch', 'branch.example.net', 9443, 6, 'monitor', 'alias-2', ?, 1, 'Branch A')",
        ("B" * 64,),
    )
    migrate_2_to_3(connection)
    migrate_3_to_4(connection)
    row = connection.execute(
        "SELECT siteName, port, lastStatus, connectionMode FROM router_profiles WHERE id = 'router-2'"
    ).fetchone()
    assert row == ("Branch A", 9443, "UNKNOWN", "AUTO")
    connection.close()


def check_v3_to_v4() -> None:
    connection = sqlite3.connect(":memory:")
    connection.execute(
        """CREATE TABLE router_profiles (
            id TEXT NOT NULL PRIMARY KEY, name TEXT NOT NULL, host TEXT NOT NULL,
            port INTEGER NOT NULL, routerOsMajor INTEGER NOT NULL, username TEXT NOT NULL,
            credentialAlias TEXT NOT NULL, tlsSha256Pin TEXT NOT NULL,
            createdAtEpochMs INTEGER NOT NULL, lastSeenAtEpochMs INTEGER,
            siteName TEXT NOT NULL DEFAULT '', lastStatus TEXT NOT NULL DEFAULT 'UNKNOWN',
            lastErrorCode TEXT, lastErrorMessage TEXT, lastCheckedAtEpochMs INTEGER
        )"""
    )
    connection.execute(
        "INSERT INTO router_profiles (id, name, host, port, routerOsMajor, username, credentialAlias, tlsSha256Pin, createdAtEpochMs) "
        "VALUES ('router-3', 'Shop', 'shop.sn.mynetname.net', 8291, 7, 'monitor', 'alias-3', ?, 1)",
        ("C" * 64,),
    )
    migrate_3_to_4(connection)
    row = connection.execute(
        "SELECT host, port, routerOsMajor, connectionMode FROM router_profiles WHERE id = 'router-3'"
    ).fetchone()
    assert row == ("shop.sn.mynetname.net", 8291, 7, "AUTO")
    connection.close()


if __name__ == "__main__":
    check_v1_to_v4()
    check_v2_to_v4()
    check_v3_to_v4()
    check_v1_to_v8()
    print("Room SQL migration preservation checks: PASS (v1→v8; profiles/history preserved, service pins scoped by transport + port; ambiguous AUTO legacy pins require reconfirmation)")
