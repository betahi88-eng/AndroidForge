#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
test -f "$APK" || { echo "Debug APK not found. Run setup-and-build.sh first."; exit 1; }
command -v adb >/dev/null || { echo "Android platform-tools (adb) required"; exit 1; }
adb install -r "$APK"
