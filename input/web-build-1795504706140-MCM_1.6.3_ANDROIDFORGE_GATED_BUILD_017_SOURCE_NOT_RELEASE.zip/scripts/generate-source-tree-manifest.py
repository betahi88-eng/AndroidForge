#!/usr/bin/env python3
"""Regenerate exact source inventory; run only when intentionally creating a new source ID."""
import hashlib, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
manifest_path = ROOT / 'SOURCE_TREE_MANIFEST.json'
ignored_dirs = {'.git', '.gradle', 'build', '__pycache__', '.kotlin', '.mcm-build-acceptance'}
ignored_names = {'local.properties', '.DS_Store'}
ignored_suffixes = {'.pyc', '.apk', '.aab', '.log'}
files = {}
for p in sorted(ROOT.rglob('*')):
    if not p.is_file() or p == manifest_path:
        continue
    rel = p.relative_to(ROOT)
    if any(part in ignored_dirs for part in rel.parts): continue
    if p.name in ignored_names or p.suffix in ignored_suffixes: continue
    if p.name.endswith(('.jks', '.keystore', '.pem', '.key', '.p12', '.pfx')): continue
    files[rel.as_posix()] = hashlib.sha256(p.read_bytes()).hexdigest()
identity = (ROOT / 'SOURCE_IDENTITY.txt').read_text(encoding='utf-8').splitlines()[0].split('=',1)[1]
manifest_path.write_text(json.dumps({'schema_version':1,'source_id':identity,'files':files},indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(f'Generated exact source inventory: {len(files)} files')
