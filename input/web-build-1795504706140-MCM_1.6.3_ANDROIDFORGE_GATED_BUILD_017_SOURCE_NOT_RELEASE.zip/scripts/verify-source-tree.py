#!/usr/bin/env python3
"""Fail closed when AndroidForge workspace differs from the packaged source tree."""
from __future__ import annotations
import hashlib, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / 'SOURCE_TREE_MANIFEST.json'
manifest = json.loads(MANIFEST.read_text(encoding='utf-8'))
identity = (ROOT / 'SOURCE_IDENTITY.txt').read_text(encoding='utf-8').splitlines()[0].strip()
if identity != 'MCM_SOURCE_ID=' + manifest['source_id']:
    raise SystemExit(f'FAIL: source identity mismatch: {identity}')
ignored_dirs = {'.git', '.gradle', 'build', '__pycache__', '.kotlin', '.mcm-build-acceptance'}
ignored_names = {'local.properties', '.DS_Store'}
ignored_suffixes = {'.pyc', '.apk', '.aab', '.log'}
actual = {}
for p in ROOT.rglob('*'):
    if not p.is_file() or p == MANIFEST:
        continue
    rel = p.relative_to(ROOT)
    if any(part in ignored_dirs for part in rel.parts):
        continue
    if p.name in ignored_names or p.suffix in ignored_suffixes:
        continue
    if p.name.endswith(('.jks', '.keystore', '.pem', '.key', '.p12', '.pfx')):
        continue
    actual[rel.as_posix()] = hashlib.sha256(p.read_bytes()).hexdigest()
expected = manifest.get('files', {})
missing = sorted(set(expected) - set(actual))
extra = sorted(set(actual) - set(expected))
changed = sorted(k for k in set(expected) & set(actual) if expected[k] != actual[k])
if missing or extra or changed:
    for label, values in [('MISSING', missing), ('UNEXPECTED', extra), ('HASH_MISMATCH', changed)]:
        for value in values[:80]: print(f'{label}: {value}', file=sys.stderr)
    raise SystemExit(f'FAIL: workspace differs from source package: missing={len(missing)} unexpected={len(extra)} changed={len(changed)}')
print(f'Source-tree integrity PASS: {len(actual)} files exactly match {manifest["source_id"]}')
