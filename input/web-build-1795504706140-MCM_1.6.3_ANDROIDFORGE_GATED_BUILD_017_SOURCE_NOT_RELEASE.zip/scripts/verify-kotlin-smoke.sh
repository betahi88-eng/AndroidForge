#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
KOTLINC="${KOTLINC:-$(command -v kotlinc || true)}"
[[ -n "$KOTLINC" ]] || { echo "kotlinc is required for the standalone JVM smoke suite." >&2; exit 1; }
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
S="$ROOT/tools/kotlin-smoke"
A="$ROOT/app/src/main/java/com/multicloud/mcm"
"$KOTLINC" \
  "$S/RouterEntityStub.kt" "$S/RouterDnsResolverStub.kt" "$S/Smoke.kt" \
  "$A/RouterOsReadOnlyPolicy.kt" \
  "$A/RouterHostValidator.kt" \
  "$A/RouterServiceMode.kt" \
  "$A/RestResponseBounds.kt" \
  "$A/routeros/RouterOsApiCodec.kt" \
  "$A/security/RouterTlsHostnameVerifier.kt" \
  "$A/security/TlsErrorClassifier.kt" \
  -include-runtime -d "$TMP/mcm-kotlin-smoke.jar"
java -jar "$TMP/mcm-kotlin-smoke.jar" \
  "$ROOT/app/src/test/resources/tls/routeros-hostname-san.fixture" \
  "$ROOT/app/src/test/resources/tls/routeros-selfsigned-cn-mismatch.fixture"
