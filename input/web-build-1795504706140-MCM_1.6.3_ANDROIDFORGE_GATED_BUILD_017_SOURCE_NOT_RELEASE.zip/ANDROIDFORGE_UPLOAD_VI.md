# AndroidForge — build MCM 1.6.3 source 017

## Why this revision exists

The supplied failed logs show the build reaching Java resource merge, then failing because `META-INF/versions/15/OSGI-INF/MANIFEST.MF` is duplicated by JSch 2.28.8 and BouncyCastle 1.86. The same workspace's Kotlin compiler also sees `SshRouterOsClient.kt`. The accompanying `sdkDependencies.txt` lists both libraries under the `base` module runtime dependency graph. These files are not declared by the clean MCM source project. This is strong evidence that AndroidForge compiled a different, mixed or stale workspace.

017 keeps the integrated app source from the 014 line and adds two fail-closed build controls: exact source-tree SHA-256 verification and an automatic Gradle dependency guard for **both Debug and Release**. It does not add SSH/JSch/BouncyCastle and does not hide duplicate files with packaging exclusions.

## One-time import and build

1. Create a fresh AndroidForge project/workspace. Do not extract over the old workspace.
2. Upload `MCM_1.6.3_ANDROIDFORGE_GATED_BUILD_017_SOURCE_NOT_RELEASE.zip` as the whole project root. The ZIP root must contain `settings.gradle.kts`, `build.gradle.kts`, `app/build.gradle.kts`, and `SOURCE_IDENTITY.txt`.
3. Ensure AndroidForge provides JDK 17, Gradle 8.7+ compatible with AGP 8.6.1 (workflow pinned to 8.9), Android SDK Platform 35, and Build Tools 35.0.0.
4. Run this one command from the extracted project root:

```bash
bash scripts/androidforge-build-and-verify.sh
```

The script runs the exact source preflight, resolves both Android runtime dependency graphs, runs clean/unit tests/lint, builds Debug and Release APK+AAB, validates APK package/version metadata, and writes build logs/checksums under `app/build/mcm-acceptance/`.

## How to interpret failure

- If preflight reports `UNEXPECTED`, `MISSING` or `HASH_MISMATCH`, the workspace does not exactly match the uploaded ZIP. Start from a fresh workspace; do not overlay files.
- If the dependency guard reports JSch or BouncyCastle, stop. Do not add packaging excludes; inspect which dependency or plugin introduced it.
- If the dependency guard passes and a later Gradle task fails, the error is a new build issue and must be fixed from that exact log.
- Only `ANDROIDFORGE BUILD GATE PASS` plus four newly produced artifacts and `SHA256SUMS.txt` count as build-gate success. Never use an older APK already present in the workspace.

## Scope not covered by the Android build gate

A successful Gradle build does not prove connectivity to the user's router. The separate live acceptance must test DNS system/DoH, TCP reachability, TLS identity/pin, authentication and read-only data retrieval independently for REST HTTPS, API-SSL and WinBox from the relevant external network. WinBox 8291 success does not imply REST 443 or API-SSL 8729 works. No router port check is being requested again here.

Baseline 007 (user-confirmed APK build success): SHA-256 `493cdf9ec77e15958073a63452e30fd3ea259a91e8a9bdd44ca35315584e6f96`. Integrated feature parent 014. Revision 017 remains **SOURCE_NOT_RELEASE** until both build and separate live-router acceptance pass.
