# MCM 1.6.3 — Đối chiếu và hợp nhất source

## Baseline và nguồn đối chiếu

- Baseline được giữ: MCM 1.6.0, SHA-256 `a35e4519a818544b96fb3b17f6ea3bdc042e47f72bd752a71f4c8a2305546ec1`.
- Đối chiếu thêm: MCM 1.6.1, SHA-256 `d17beb126d430d35a29de2dc29d58e39f934ff18dd5f2e808318b10a8e266c17`.
- Đối chiếu thêm: MCM 1.6.2, SHA-256 `95d5fc9d0e04e06b7685854832ca437de6afb5f547b00cedc42834edbe9bb66a`.
- MCM 1.5.1 được kiểm tra như mốc trước 1.6.0, SHA-256 `d4494f331c4d0e642c0a6799dfc871ecb2d60deec391c08e5206e152fa63a77b`.

## Kết quả đối chiếu

| Hạng mục | 1.6.0 | 1.6.1 | 1.6.2 | Hợp nhất 1.6.3 |
|---|---|---|---|---|
| Multi-router/store, custom port, service mode, Room v4 | Có | Giữ | Giữ | Giữ nguyên |
| DNS Android hệ thống | Có | Có | Có | Có |
| DNS-over-HTTPS fallback Google/Cloudflare | Không | Thêm | Giữ | Giữ |
| Dùng chung resolver cho diagnostics, REST, API-SSL, TLS pin inspection | Không | Thêm | Giữ | Giữ |
| Parser interface null-safe tách riêng | Inline | Inline | Thêm | Giữ |
| Unit test parser nullable | Không | Không | Thêm 4 | Giữ |
| Android app identity | 1.6.0 / 9 | 1.6.1 / 10 | 1.6.2 / 11 | 1.6.3 / 12 |

## Sửa chữa được giữ trong 1.6.3

1. Lấy nguyên nền native Android/Gradle và chức năng 1.6.0 làm baseline. Không đổi applicationId, SDK, AGP, Kotlin plugin, dependency versions, Room schema hay kiến trúc kết nối.
2. Cherry-pick DNS fallback từ 1.6.1/1.6.2: Android DNS trước; nếu không có kết quả thì Google DoH; tiếp theo Cloudflare DoH. Resolver được dùng thống nhất trong kiểm tra TCP, RouterOS 7 REST, RouterOS API-SSL và TLS fingerprint inspection. REST giữ hostname gốc; raw TLS sockets kết nối IP đã phân giải và gửi SNI hostname gốc.
3. Giữ parser `RouterOs7InterfaceParser.kt` từ 1.6.2. `name` thiếu thì bỏ dòng; `type` thiếu thành chuỗi rỗng; `running` thiếu/không hợp lệ thành false; counter không hợp lệ thành null. Có bốn unit tests hồi quy.
4. Giữ phần UI hiển thị nguồn DNS và chi tiết DNS fallback. Không thay đổi màn hình hoặc luồng quản lý profile ngoài việc cập nhật nhãn version.
5. Tăng versionName/versionCode lên 1.6.3/12 để tránh nhầm với source cũ trong AndroidForge cache. Thêm preflight kiểm tra source identity và parser cụ thể.

## Log AndroidForge và giới hạn kết luận

- Một log chạy `flutter build apk` trong `harmony_patched` và thất bại vì Gradle 8.9 thấp hơn mức Flutter yêu cầu 8.14. Đây là workspace Flutter sai, không phải build native MCM.
- Log native chạy trong `workspace/app` và dừng ở `compileDebugKotlin`/`compileReleaseKotlin` tại `RouterOs7Repository.kt:37:65`, báo nullable `String?`.
- ZIP 1.6.0 đã đối chiếu có `row.stringValue("type").orEmpty()` ở dòng đó. Đây là extension hợp lệ của Kotlin standard library; log không cung cấp nội dung source thực tế đã biên dịch. Vì vậy không thể kết luận chỉ từ log rằng lỗi nằm trong ZIP 1.6.0; có sự không khớp source/workspace hoặc source compiler thực tế cần xác minh.
- 1.6.3 chuyển phép chuyển đổi sang parser riêng, thêm test và marker/version mới. Lần build kế tiếp phải dùng job/workspace mới. Nếu log vẫn báo compile `RouterOs7Repository.kt:37:65` với source cũ, AndroidForge chưa lấy đúng ZIP mới.

## Giới hạn xác minh

- ZIP CRC, root layout, source checks, JavaScript/Python/shell/XML checks và Room/UI contract checks được chạy cục bộ.
- Không có Gradle 8.7 + Android SDK Platform 35 + JDK 17 đầy đủ trong môi trường này; do đó không tuyên bố đã chạy Android Gradle/KAPT/JUnit/Lint hoặc tạo APK.
- DoH gửi hostname được tra cứu tới nhà cung cấp DNS công cộng phản hồi. Không thay đổi router, NAT, firewall, DDNS hoặc port. Không thêm VPN, relay hay WinBox transport.
