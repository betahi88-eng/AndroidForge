# BUILD FIX 003 — Kotlin sealed-result branch narrowing

## Evidence
`AndroidForge-logs (1).zip` reports `Unresolved reference 'code'` at:
- `McmBackgroundWorker.kt:69:132` during `assembleDebug` and `bundleDebug`
- `McmMonitoringService.kt:102:130` during `assembleRelease`

Both sites accessed `alternateResult.code` in an `else` branch after checking only `alternateResult is McmResult.Success`. Kotlin does not narrow the opposite branch to `McmResult.Failure` for this property access. The failure is a source-level Kotlin compile error; it is not a TLS, RouterOS, signing or APK packaging error. The supplied log archive contains no APK/AAB.

## Correction in source 007
Both sites now use an exhaustive `when (alternateResult)` expression with separate `McmResult.Success` and `McmResult.Failure` branches. The `.code` and `.message` reads occur only inside `is McmResult.Failure`. The success behavior, saved transport/port/pin update, and original failure code/message preservation are unchanged.

## Verification status
- Added two regression assertions to `scripts/verify-build-regressions.py` to ensure the background and foreground reads occur within the `Failure` branches.
- Source/static checks and focused Kotlin/JVM checks are to be rerun on this exact candidate.
- Android Gradle/KAPT/JUnit/lint and Debug/Release APK/AAB tasks remain **NOT RUN** in this runtime because JDK 17, Gradle and Android SDK 35 are not installed. Candidate 007 is not an APK release and must not be described as build-successful until AndroidForge produces and verifies the artifacts.
