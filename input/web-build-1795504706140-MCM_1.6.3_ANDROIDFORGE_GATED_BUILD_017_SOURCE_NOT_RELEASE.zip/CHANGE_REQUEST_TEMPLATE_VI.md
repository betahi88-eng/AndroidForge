# PHIẾU ĐỀ XUẤT SỬA ĐỔI

- Mã yêu cầu:
- Ngày:
- Phiên bản nguồn:
- Mức ưu tiên: P0 / P1 / P2 / P3

## 1. Vấn đề hiện tại
Mô tả hiện tượng, màn hình, thiết bị và điều kiện xảy ra.

## 2. Cách tái hiện
1.
2.
3.

## 3. Kết quả hiện tại
Mô tả đúng điều app đang làm, kèm log/ảnh đã che thông tin nhạy cảm.

## 4. Kết quả mong muốn
Mô tả hành vi mới và trường hợp biên.

## 5. Phạm vi ảnh hưởng
- UI:
- Kotlin/native:
- Database/migration:
- RouterOS/network:
- Android permission/background:
- AndroidForge/build:

## 6. Tiêu chí nghiệm thu
- [ ] Hành vi chính đúng.
- [ ] Trường hợp lỗi có thông báo chính xác.
- [ ] Không làm hỏng dữ liệu cũ.
- [ ] Unit tests phù hợp được cập nhật.
- [ ] Build/lint/test liên quan đạt.
- [ ] Có hướng dẫn rollback.
