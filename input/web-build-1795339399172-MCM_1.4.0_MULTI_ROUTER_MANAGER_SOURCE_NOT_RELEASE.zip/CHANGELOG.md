# Changelog

## 1.4.0 — Network awareness and discovery correctness

- Corrected MNDP uptime TLV decoding: 32-bit little-endian seconds, rather than UTF-8 text.
- Added IPv6 advertised address parsing and surfaced interface/uptime/IPv6 in LAN discovery results.
- Unknown MNDP TLVs remain safely skippable; added tests for uptime, board/interface, unknown TLVs and truncated payloads.
- Added Android active-network transport and VPN-active indicator with explicit route-validation caveat.
- Added Vietnamese functional architecture covering inventory, monitoring, QR metadata, VPN workflow, read-before-write configuration, audit and release gates.
- Bumped Android version to 1.4.0 / versionCode 6.
- No router configuration writes, VPN provisioning, QR import/export or APK release are claimed.

## 1.3.0 — Multi-Router Manager foundation

- Fixed nullable parsing of RouterOS 7 interface `running` state reported by AndroidForge.
- Added MikroTik MNDP LAN discovery (UDP/5678), bounded scan, TLV parsing and duplicate suppression.
- Added LAN discovery UI; selecting a neighbor prefills the add-router form but requires credentials and independent TLS verification.
- Added MNDP parser tests and updated AndroidForge/CI version gates.
- This remains monitor-only; QR scanner, VPN provisioning and advanced configuration writes are not included.

# Changelog

## 1.3.0 — Multi-Cloud DDNS rebuild (engineering source)

- Added grouped site/Cloud labels and multiple independent MikroTik endpoint profiles.
- Added router edit workflow; blank password preserves the current encrypted credential, changed password rotates to a new Keystore alias.
- Added Room v1→v2→v3 migrations for site grouping and per-router health/error state.
- Added persisted per-router UNKNOWN/ONLINE/PARTIAL/OFFLINE state and sequential refresh-all.
- Added RouterOS 7 REST and RouterOS 6 API-SSL reads for IP Cloud DDNS, PPPoE active sessions, ARP, DHCP leases and Netwatch.
- Added per-interface RX/TX Mbps history and selector-driven charts without aggregating overlapping bridge/physical counters.
- Added DDNS public IPv4/IPv6 and status presentation; PPPoE active list filters to service=pppoe.
- Bounded concurrent requests to two per monitoring service to limit RouterOS API-SSL pressure.
- Added TLS protocol mismatch classification for Android/BoringSSL `UNSUPPORTED_PROTOCOL` errors.
- Added tests for host validation and TLS error classification; refreshed REST and API-SSL mock data.
- Updated Vietnamese architecture, RouterOS setup, test and build documentation.

This remains an engineering source NOT RELEASE. Android Gradle build, APK assembly, Android device installation and live RouterOS tests must pass before calling it a release.

## 1.0.1 — previous engineering source

- RouterOS 6 API-SSL and RouterOS 7 REST adapters.
- TLS certificate pinning and Android Keystore AES-256-GCM credential storage.
- Packet-loss parser validation and local metric history.


## 1.3.0 — Network visibility expansion

- Added read-only RouterOS 6/7 collection for Bridge Host MAC learning table.
- Added read-only VLAN interface and Bridge VLAN membership snapshots.
- Added conservative on-device snapshot analysis for duplicate IP-to-MAC observations, DHCP/ARP visibility differences, Netwatch DOWN and ICMP loss evidence.
- Added Top 5 interface throughput view based only on measured RX/TX interface counter deltas. This is not represented as per-device bandwidth.
- Kept Direct Cloud DDNS/domain connection, local profile storage and RouterOS 6 API-SSL / RouterOS 7 REST adapters.
- No router configuration mutation, queue creation, traffic-flow activation or firewall changes.
