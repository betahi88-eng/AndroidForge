"use strict";

$("showAddBtn").addEventListener("click", () => { resetRouterForm(); showPanel(true); });
$("discoverBtn").addEventListener("click", discoverMikroTik);
$("closeDiscoveryBtn").addEventListener("click", () => { $("discoveryPanel").hidden = true; });
$("closeAddBtn").addEventListener("click", () => showPanel(false));
$("cancelAddBtn").addEventListener("click", () => showPanel(false));
$("inspectTlsBtn").addEventListener("click", inspectTls);
$("routerForm").addEventListener("submit", saveRouter);
$("refreshBtn").addEventListener("click", refreshSelected);
$("removeBtn").addEventListener("click", removeSelected);
$("editBtn").addEventListener("click", editSelectedRouter);
$("refreshAllBtn").addEventListener("click", refreshAllRouters);
$("interfaceHistorySelect").addEventListener("change", () => {
  state.selectedInterfaceName = $("interfaceHistorySelect").value || null;
  loadInterfaceHistory();
});
$("routerOs").addEventListener("change", () => {
  $("routerPort").value = $("routerOs").value === "6" ? "8729" : "443";
});

async function refreshNetworkContext() {
  const node = $("networkContext");
  if (!node) return;
  try {
    const response = await nativeCall("getNetworkState");
    if (!response.ok) throw new Error(response.error || "Không đọc được trạng thái mạng.");
    const network = response.network || {};
    const labels = { WIFI: "Wi-Fi", CELLULAR: "Di động", ETHERNET: "Ethernet", VPN: "VPN", UNKNOWN: "Chưa xác định" };
    const transport = labels[network.transport] || "Chưa xác định";
    node.textContent = network.vpnActive
      ? `VPN Android đang bật · ${transport}`
      : `${transport} · ${network.internetValidated ? "Internet đã xác thực" : "Chưa xác thực Internet"}`;
    node.className = `network-context${network.vpnActive ? " vpn" : network.networkAvailable ? "" : " offline"}`;
    node.title = network.vpnActive
      ? "Android đang có VPN hoạt động. Cần kiểm tra riêng tuyến VPN có tới được địa chỉ router hay không."
      : "Chưa phát hiện VPN Android hoạt động. DDNS public vẫn có thể kết nối trực tiếp nếu router cho phép.";
  } catch (error) {
    node.textContent = "Không đọc được trạng thái mạng";
    node.className = "network-context offline";
  }
}

document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible") {
    refreshNetworkContext();
    if (state.selectedId) refreshSelected();
  }
});

(async function boot() {
  try {
    await loadRouters();
    await refreshNetworkContext();
    setStatus("Sẵn sàng", "good");
    if (state.selectedId) refreshSelected();
  } catch (error) {
    setStatus("Native bridge lỗi", "bad");
    toast(error.message);
  }
  state.timer = window.setInterval(() => {
    if (document.visibilityState === "visible") {
      refreshNetworkContext();
      if (state.selectedId) refreshSelected();
    }
  }, 30000);
})();
