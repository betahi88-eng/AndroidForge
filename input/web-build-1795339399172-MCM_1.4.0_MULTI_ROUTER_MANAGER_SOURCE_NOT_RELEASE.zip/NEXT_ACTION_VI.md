# MCM — Next Action

**One next gate:** build this exact source ZIP in AndroidForge and inspect the resulting build log before any release claim.

1. Upload `MCM_1.4.0_MULTI_ROUTER_MANAGER_SOURCE_NOT_RELEASE.zip` using AndroidForge web UI.
2. Confirm detector reports Gradle / Android / Kotlin and project root contains `settings.gradle.kts` and `app/build.gradle.kts`.
3. Confirm `:app:testDebugUnitTest`, `:app:lintDebug` and `:app:assembleDebug` finish successfully.
4. Confirm `app-debug.apk` exists, package is `com.multicloud.mcm`, version is `1.4.0`, and artifact SHA-256 matches the downloaded APK.
5. Install on Android and test one RouterOS 7 and one RouterOS 6 device over the intended LAN/VPN/DDNS route.

Do not call this a release until Android installation and physical router acceptance pass. Do not change MikroTik configuration, firewall, NAT, DDNS or VPN from MCM during testing.
