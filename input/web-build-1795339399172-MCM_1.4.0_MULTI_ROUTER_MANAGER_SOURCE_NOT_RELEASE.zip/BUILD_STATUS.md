# MCM 1.4.0 — Build status

**Status: AndroidForge-ready engineering source / NOT RELEASE. No APK is included or claimed.**

## Project
- Native Android Gradle/Kotlin project; application ID `com.multicloud.mcm`; version 1.4.0 / versionCode 6.
- Android phone APK is the sole product interface. Local HTML/CSS/JS assets run inside the native Android WebView; network requests and credentials are handled by Kotlin native code.
- Multi-router Cloud DDNS/domain/IP profiles; local-only storage; RouterOS 7 REST HTTPS and RouterOS 6 API-SSL read adapters.
- Added read-only ARP, DHCP, PPPoE active, Netwatch, Bridge Host, VLAN interface and Bridge VLAN snapshots.
- Added MNDP LAN discovery on UDP/5678 with bounded scan, TLV parser, deduplication and UI selection. Parser now decodes the 32-bit little-endian uptime TLV, IPv6 and ignores unknown TLVs safely.
- Added Android active-network transport and VPN-state indicator. It does not claim a VPN route to any router; endpoint reachability remains the authority.
- Added conservative snapshot alerts and Top 5 interface RX/TX rates. Interface throughput is not misrepresented as per-device bandwidth.
- Router configuration writes, QR scanning, VPN provisioning and MikroTik Pro-equivalent advanced configuration screens are not implemented in this source. No router configuration writes or automatic changes.

## Validation performed in this workspace
- AndroidForge root/preflight structure: PASS.
- JavaScript syntax: PASS.
- Python syntax and mock scripts: PASS.
- Shell syntax: PASS.
- Android XML parse: PASS.
- Room migration source checks: PASS.
- WebView DOM contract: PASS.
- MNDP parser tests cover identity/MAC/version/IPv4, uptime/board/interface, unknown TLVs and malformed truncation; not executed through Gradle because Gradle is unavailable.
- Added functional architecture/phase plan in `docs/FUNCTIONAL_DESIGN_VI.md`.
- ZIP integrity and flat Android Gradle project root: must be rechecked on final archive.

## Not verified
- Full Gradle/Kotlin Android compile, KAPT, JUnit Gradle task, Android Lint and APK assembly were not run because Gradle and Android SDK Platform 35 are unavailable in this workspace.
- RouterOS 6/7 hardware and Android phone runtime acceptance not run.
- No APK/AAB or production signing key is included.

## AndroidForge build gate
Use this exact ZIP as a native Android Gradle project. The project root contains `settings.gradle.kts`, `build.gradle.kts` and `app/build.gradle.kts`; do not select Flutter or any nested project. Required toolchain: JDK 17, Gradle 8.7, AGP 8.6.1, Kotlin 2.0.21, Android SDK 35. Run `:app:testDebugUnitTest`, `:app:lintDebug`, `:app:assembleDebug`. Accept only if `app/build/outputs/apk/debug/app-debug.apk` exists and package/version are verified.
