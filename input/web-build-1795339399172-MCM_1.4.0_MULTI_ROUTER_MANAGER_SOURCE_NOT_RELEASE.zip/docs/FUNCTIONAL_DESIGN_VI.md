# MCM — Thiết kế chức năng tổng thể

## 1. Mục tiêu sản phẩm

MCM là ứng dụng Android quản lý nhiều router MikroTik độc lập. Mỗi router có hồ sơ, endpoint, giao thức, tài khoản, fingerprint TLS, lịch sử và trạng thái riêng. Không có backend/VPS MCM bắt buộc; dữ liệu lưu trên điện thoại. Kết nối router đi trực tiếp qua LAN, DDNS/domain hoặc tuyến VPN do Android/ứng dụng VPN khác cung cấp.

## 2. Phân lớp chức năng

### A. Inventory & kết nối
- Thêm thủ công bằng IP/domain/MikroTik Cloud DDNS.
- MNDP discovery trong broadcast domain hiện tại; kết quả chỉ là gợi ý, không tự lưu hoặc tự tin cậy.
- Nhóm theo địa điểm/site; hỗ trợ nhiều hồ sơ không đặt giới hạn cứng tùy tiện.
- ROS7 REST HTTPS và ROS6 API-SSL; profile giữ cổng và xác thực riêng.
- TLS SHA-256 pinning; thay host/chứng chỉ cần xác minh lại có chủ ý.

### B. Giám sát
- System resource: CPU, RAM, RouterOS version, uptime.
- Interface: trạng thái link, byte counters, tốc độ RX/TX từ hai mẫu hợp lệ.
- Cloud DDNS, PPPoE active, ARP, DHCP lease, Bridge Host, VLAN, Bridge VLAN, Netwatch.
- ICMP đo riêng, có sent/received/lost/RTT; không lấy tốc độ interface để suy luận packet loss.
- Lịch sử theo router và metric; dữ liệu stale phải gắn thời điểm, không hiển thị như snapshot mới.

### C. Cảnh báo & phân tích
- Phân biệt OFFLINE (lỗi kết nối/core) với PARTIAL (mục phụ lỗi).
- Cảnh báo chỉ dựa trên snapshot có thời điểm và nguồn dữ liệu xác định.
- Giai đoạn sau: ngưỡng do người dùng đặt, chống báo lặp, lịch sử chuyển trạng thái Netwatch và thông báo Android.

### D. Mạng LAN và VPN
- MNDP là discovery Layer 2, không phải IP scan toàn mạng và không xuyên VLAN.
- Trạng thái VPN Android chỉ cho biết có transport VPN; không khẳng định route tới IP router đã tồn tại. Cần kiểm tra kết nối endpoint thực tế.
- WireGuard/Back To Home provisioning không được giả lập bằng cách sửa cấu hình router âm thầm. Nếu bổ sung, phải là wizard có preview, xác nhận từng bước, rollback và không tự mở firewall rộng.

### E. QR & chuyển hồ sơ
- QR chỉ mang metadata profile không bí mật: schema version, name, site, host, port, RouterOS family, TLS pin.
- Tuyệt đối không encode password, token, credential alias hoặc key VPN vào QR mặc định.
- Import phải hiển thị preview, kiểm tra schema/host/port, yêu cầu nhập credential và xác minh TLS trước khi lưu.
- Export nhiều router phải có lựa chọn; không xuất credential. QR một profile và bundle file là hai luồng riêng.

### F. Cấu hình nâng cao (giai đoạn có ghi cấu hình)
- Chia module: System/Identity, Interfaces, IP/Address, Routes, DNS, DHCP, Firewall, NAT, VLAN/Bridge, PPP/PPPoE, WireGuard, Users/Services.
- Mỗi module phải có capability check theo RouterOS major/minor và policy user.
- Quy trình bắt buộc: đọc trạng thái hiện tại → form có giá trị hiện tại → validate phía app → preview lệnh/thay đổi → xác nhận rõ ràng → gửi tuần tự → đọc lại xác minh → audit log.
- Không có thao tác bulk write mặc định. Không tự reboot, không tự bật dịch vụ quản trị public, không tự mở firewall/port.
- Nếu không xác minh được kết quả sau write, hiển thị trạng thái chưa xác định và hướng dẫn kiểm tra; không báo thành công lạc quan.

## 3. Kiến trúc kỹ thuật

- Android native Kotlin: mạng, Room, Keystore, VPN/network state, discovery, lifecycle.
- WebView chỉ hiển thị asset nội bộ và gọi bridge allow-list; không truy cập router trực tiếp từ JavaScript.
- Repository ROS6/ROS7 tách biệt; model snapshot dùng chung; trường không hỗ trợ phải báo unavailable, không tự suy diễn.
- Room lưu profile metadata, lịch sử và counter; password chỉ nằm trong Android Keystore AES-GCM.
- Mọi tác vụ mạng chạy IO coroutine; giới hạn timeout, concurrency và số lượng mẫu.

## 4. Trình tự phát triển và cổng nghiệm thu

1. **Nền tảng ổn định:** compile, migrations, TLS, credential lifecycle, MNDP parser, network state.
2. **Inventory hoàn chỉnh:** QR import/export metadata, backup/restore không chứa secret, duplicate detection, profile validation.
3. **Giám sát nâng cao:** thêm thông tin route/interface/health có kiểm soát quyền; dashboard multi-router, stale-state và alert history.
4. **VPN workflow:** phát hiện VPN, kiểm tra reachability từng profile, hướng dẫn Back To Home/WireGuard; chỉ quản lý tunnel nếu API Android/permission và quy trình an toàn được xác nhận.
5. **Configuration read-only browser:** liệt kê cấu hình theo module và capability matrix ROS6/ROS7.
6. **Configuration write:** từng module độc lập, preview/diff, explicit confirmation, verify-after-write, audit, rollback phù hợp.
7. **Release:** Gradle unit tests, lint, Debug/Release APK, cài trên Android thật, thử router ROS6 và ROS7, LAN và VPN, mất mạng/đổi IP/chứng chỉ.

## 5. Tiêu chí không thỏa hiệp

- Không tự đổi cấu hình router khi discovery, import hoặc monitor.
- Không đưa secret ra WebView, QR, log hoặc source ZIP.
- Không tuyên bố VPN hoạt động chỉ dựa vào biểu tượng VPN Android.
- Không coi static checks là build APK thành công.
- Không gọi là release khi chưa cài và thử trên thiết bị/router thật.
