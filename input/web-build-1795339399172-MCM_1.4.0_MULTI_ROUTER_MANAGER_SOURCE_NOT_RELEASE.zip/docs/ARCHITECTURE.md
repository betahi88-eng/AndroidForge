# MCM 1.4.0 — Architecture

## Purpose and connection model

MCM is an Android-only, local-first multi-router monitor. “Multi-Cloud” means multiple independently configured MikroTik endpoint profiles, including MikroTik IP Cloud DDNS hostnames, custom DDNS/domains and direct IP addresses. It does not mean a cloud backend. There is no MCM server, VPS, account system or cloud synchronization service.

```text
Android MCM
  ├─ local profile inventory (site / Cloud group)
  ├─ Room profile + history database
  ├─ Android Keystore / AES-256-GCM credentials
  └─ per-router direct transport
       ├─ RouterOS 7 → HTTPS www-ssl → REST API
       └─ RouterOS 6 → TLS api-ssl → RouterOS API protocol
```

Each profile has its own host, port, RouterOS family, username, encrypted credential alias and SHA-256 certificate pin. Profiles are grouped by a user-defined site/cloud label. A domain profile does not share credentials or state with another profile even when both endpoints belong to the same owner.

## Application layers

- **WebView UI:** local HTML/CSS/JS; no remote scripts or arbitrary network access.
- **Native JavaScript bridge:** allow-listed operations for list, add/update/remove, TLS fingerprint inspection, refresh, refresh-all and history.
- **Profile service:** host validation, CRUD and credential alias rotation.
- **Monitoring service:** bounded parallel reads (maximum two active requests per service instance); one router at a time during refresh-all.
- **RouterOS 7 REST client:** HTTPS only, SHA-256 leaf-certificate pin, bounded OkHttp timeouts.
- **RouterOS 6 API-SSL client:** TLS pin, direct login plus legacy challenge-response path, bounded socket timeouts and RouterOS sentence codec.
- **Room:** profiles, interface counters, local metrics; schema migrations preserve existing profiles.
- **WorkManager:** best-effort background CPU/RAM samples only.

## Snapshot contract

Core `system/resource` data determines whether the router can be marked reachable. Optional reads fail independently and become warnings:

- interface counters/state
- `/ip/cloud`
- `/ppp/active` filtered to `service=pppoe`
- `/ip/arp`
- `/ip/dhcp-server/lease`
- `/tool/netwatch`
- bounded ICMP ping

The status is:

- `ONLINE`: core and optional reads all succeeded.
- `PARTIAL`: core resource succeeded but one or more optional reads failed.
- `OFFLINE`: core resource read failed or refresh could not complete.
- `UNKNOWN`: no successful check yet.

`lastSeenAt` indicates last successful core resource read, not a guarantee of current availability. `lastCheckedAt` indicates last check. Status may be stale until the next refresh.

## Read-only boundary

The normal app never sends RouterOS configuration mutations. REST GET and API-SSL `print` commands are used for monitoring. The one POST operation is RouterOS 7 `/ping`; ROS6 `/ping` is bounded by requested `count`. No write, set, add, remove, reboot, firewall or DHCP changes are issued.

## Database migrations

- Version 1 → 2: adds `siteName` for site/Cloud grouping.
- Version 2 → 3: adds last check status, error code/message and timestamp.
- Both Room migration paths are registered in the foreground app and WorkManager worker.

Credentials are stored by Android Keystore-backed AES-256-GCM using independent aliases. When a password changes, MCM writes a new encrypted alias, commits Room, then removes the previous alias; if Room write fails, it removes the new alias and leaves the previous secret untouched.

## Operational network requirement

MikroTik IP Cloud DDNS supplies a resolvable DNS name; it does not establish VPN or automatically expose management services. Remote access still requires reachable routing/NAT and router firewall rules. Use VPN/WireGuard or a restricted management network; never expose the management API to all Internet sources.

## Deliberate limitations

No MCM cloud server or sync, no VPN tunnel client, no push notifications, no custom alert rules, no chart export, no Netwatch event ingestion, no ARP/DHCP device identity history. ARP/DHCP/Netwatch are current snapshots on refresh. Background monitoring records CPU/RAM only. Literal IPv6 host input is not supported by the host field in this version.
