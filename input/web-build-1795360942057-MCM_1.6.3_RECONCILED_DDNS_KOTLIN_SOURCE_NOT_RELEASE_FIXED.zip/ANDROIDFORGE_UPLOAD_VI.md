# Build MCM 1.6.3 bằng AndroidForge

## ZIP cần upload

Dùng duy nhất `MCM_1.6.3_RECONCILED_DDNS_KOTLIN_SOURCE_NOT_RELEASE.zip`. Đây là dự án Android Native Gradle/Kotlin, không phải Flutter. Tất cả file Gradle đặt trực tiếp tại root ZIP.

Root phải có `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `app/build.gradle.kts` và `app/src/main/AndroidManifest.xml`. Không có `pubspec.yaml` hoặc `harmony_patched`.

## Cấu hình build

- Project: `MikroTikMultiCloudMonitor`
- Application ID: `com.multicloud.mcm`
- Version: `1.6.3` / versionCode `12`
- JDK: 17
- Gradle: 8.7
- Android Gradle Plugin: 8.6.1
- Kotlin: 2.0.21
- compileSdk/targetSdk: 35; minSdk: 26
- Gradle tasks: `:app:testDebugUnitTest :app:lintDebug :app:assembleDebug :app:bundleDebug`

## Bắt buộc tạo build job/workspace mới

Không chạy tiếp trên job cũ và không dùng cache/workspace `harmony_patched` hoặc `workspace/app` của các lần upload trước. Tạo job mới, upload duy nhất ZIP 1.6.3. Trước khi build, xác nhận file `SOURCE_IDENTITY.txt` có `MCM_SOURCE_ID=MCM-1.6.3-RECONCILED-001`, `versionName=1.6.3`, `versionCode=12`.

## Kiểm tra AndroidForge chọn đúng project

1. Upload duy nhất ZIP `1.6.3`; không upload source ZIP khác cùng lúc.
2. Chọn Android / Gradle nếu UI có project selector.
3. Detector phải nhận root có `settings.gradle.kts` và `app/build.gradle.kts`.
4. Nếu log chạy `flutter build apk`, tìm `pubspec.yaml` hoặc chọn `harmony_patched`, dừng build vì đã chọn nhầm workspace. Nếu Kotlin lỗi vẫn trỏ tới `RouterOs7Repository.kt:37:65` như log cũ, kiểm tra lại ZIP và workspace: bản 1.6.3 chuyển parser sang `RouterOs7InterfaceParser.kt`.
5. Xác nhận toolchain Gradle 8.7 + JDK 17 + Android SDK Platform 35.

APK dự kiến: `app/build/outputs/apk/debug/app-debug.apk`. Chỉ xác nhận build khi assemble thành công, APK tồn tại, package `com.multicloud.mcm`, version `1.6.3` được xác minh và SHA-256 khớp file tải về.

## Lỗi cũ đã xác định và sửa

Log AndroidForge trước đó cho thấy cả `bundleDebug`, `assembleDebug` và `assembleRelease` đều dừng tại `RouterOs7Repository.kt:37:65`: gọi tiếp trên `String?` khi giá trị có thể null. Bản 1.6.3 tách parser interface thành hàm riêng, dùng Elvis defaults rõ ràng và thêm 4 unit tests hồi quy.

Không sửa Gradle lên 8.14 để chữa lỗi này: log Android Native đã chạy đến `compileDebugKotlin`/`compileReleaseKotlin`; lỗi 8.14 thuộc một workspace Flutter cũ (`harmony_patched`), không liên quan MCM Native. Nếu AndroidForge lại chạy `flutter build apk` hoặc dùng `harmony_patched`, đó vẫn là chọn sai workspace.

## Trạng thái

ZIP là **engineering source NOT RELEASE**. Không kèm APK hoặc release keystore. Cần chạy full Gradle/JUnit/KAPT/lint/assemble, cài Android thật và thử RouterOS 6/7 qua mạng di động trước khi công nhận release.
