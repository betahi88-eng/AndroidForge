# MCM 1.6.3 — candidate 010 build and acceptance status

Source identity: `MCM-1.6.3-SSH-RECONCILED-010`  
Parent: candidate 009 (AndroidForge build failed); original known-good APK baseline remains 007  
Application ID: `com.multicloud.mcm`  
Version: `1.6.3` (`versionCode=12`)  
Room schema: `9`

## Repair made from AndroidForge log (3)

The new log confirms that candidate 009 still failed at `:app:mergeDebugJavaResource` and `:app:mergeReleaseJavaResource`. JSch 2.28.8 and Bouncy Castle 1.86 contain the same resource path:

`META-INF/versions/15/OSGI-INF/MANIFEST.MF`

Candidate 009 excluded only the `versions/9` path, so it did not match this `versions/15` collision. Candidate 010 changes the Android packaging exclusion to the version-independent glob:

`META-INF/versions/**/OSGI-INF/MANIFEST.MF`

The source verifier now checks for this exact wildcard rule. No dependency versions or application behavior were changed in this repair.

## Verification status

- AndroidForge log diagnosis: **CONFIRMED** (Debug, Release and BundleDebug all fail on the duplicate `versions/15` resource).
- Packaging rule and source-verifier consistency: **CHECKED**.
- ZIP integrity / CRC and archive root: to be checked during packaging.
- Full source static checks: to be run during packaging.
- Android Gradle compile, KAPT, JUnit, lint, Debug APK, Release APK and AAB: **NOT RUN in this workspace**.
- Live RouterOS 6/7 SSH host-key and read-only CLI validation: **NOT RUN**.

**Status: SOURCE REPAIR — NOT YET ANDROIDFORGE BUILD-VERIFIED.** Candidate 007 remains the last user-confirmed APK-buildable baseline. Do not treat 010 as a successful APK until AndroidForge reruns it.

## Required AndroidForge verification

Run the same AndroidForge build tasks. Confirm `mergeDebugJavaResource` and `mergeReleaseJavaResource` pass, then confirm `assembleDebug`, `assembleRelease` and `bundleRelease` complete. If another failure occurs, use the exact new log.
