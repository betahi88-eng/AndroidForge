# MikroTik Multi-Cloud Monitor (MCM)

**Version:** 1.0.1 engineering build  
**License:** Apache-2.0  
**Platform:** Android 8.0+ (API 26+)  
**Stack:** Kotlin, Android WebView (local assets), Room, Android Keystore, OkHttp, WorkManager

MCM is a read-only Android monitor for mixed RouterOS 6 and RouterOS 7 networks. RouterOS 7 uses HTTPS REST; RouterOS 6 uses native API-SSL. The application does not provision, edit, or otherwise change router configuration. Its only router-side POST operation is a bounded diagnostic ping.

## Implemented in this source milestone

- Multi-router profiles stored locally with Room.
- RouterOS 7 HTTPS REST: system resource, interface counters, bounded `/rest/ping`.
- RouterOS 6 API-SSL: binary word/sentence framing, direct login and legacy MD5 challenge-response login, read resource/interface and bounded ping commands. RouterOS 6 ping samples are calculated only after the bounded command ends with `!done`; sent is the requested `count`, received is the number of validated echo-reply records.
- Required SHA-256 pin for the router's TLS leaf certificate. The normal clients fail closed when the pin is missing or mismatched.
- Explicit fingerprint inspection UI. Inspection only reads and displays a fingerprint; the user must compare it out-of-band and explicitly confirm before saving. The permissive inspector is never used for normal API sessions.
- Password encryption with AES-256-GCM and a non-exportable Android Keystore key. Raw passwords are not stored in the Room database.
- CPU, memory use, interface up/down, PPPoE client presence/state, RX/TX Mbps from interface counter deltas, and ICMP packet loss.
- Local history (up to 60 latest points per chart, 30-day retention).
- Local WebView Content Security Policy: no remote scripts, no external connections, no cleartext router API.
- Foreground refresh while the app is visible (30-second interval) and best-effort background CPU/RAM samples via WorkManager (15-minute minimum periodic interval, network-connected constraint).
- Separate RouterOS 7 REST and RouterOS API-SSL mock servers, test certificate helper, and ping parser unit tests.

## Packet-loss measurement rules

Packet loss is measured independently from interface traffic counters:

- RouterOS 7 REST: uses the router's cumulative `sent` and `received` fields. Because the REST ping result returns records for echo replies, a total-loss sample or a trailing timeout without a final counter cannot prove the complete sample; MCM marks it invalid/incomplete rather than publishing an understated loss rate.
- RouterOS 6 API-SSL: sends a bounded `/ping` command with a known `count`. Only after the command completes with `!done` does MCM use that requested count as `sent`; validated, distinct `!re` echo-reply records are counted as `received`. An interrupted command is a failure, not a sample.
- Neither path uses interface RX/TX traffic counters or guesses the sent count from the number of result rows.

This is deliberately conservative. Actual RouterOS 6 firmware must be checked to confirm its `/ping` API `!re` records contain `seq` and `host` for each echo reply.

RTT fields are normalized to milliseconds, including compound RouterOS values such as `14ms612us`.

## Router requirements

### RouterOS 7

- Enable `www-ssl` with a server certificate and use HTTPS only.
- REST user group needs `read`, `api`, and `rest-api`; the diagnostic ping also needs `test`.
- Use a dedicated least-privilege account, not `admin`.
- Default app port: `443` (can be changed per router).

Example group/user setup to be run manually by the router owner after reviewing the RouterOS manual:

```routeros
/user/group/add name=mcm-monitor policy=read,test,api,rest-api
/user/add name=mcm-monitor group=mcm-monitor password="USE-A-LONG-UNIQUE-PASSWORD"
```

Ensure `www-ssl` has the intended certificate and restrict its `available-from` / firewall access to the LAN or VPN management subnet. Disable plain REST access.

### RouterOS 6

- Enable `api-ssl` on TCP `8729` and assign a TLS certificate. MCM intentionally does not support certificate-less anonymous-DH API-SSL.
- Use a dedicated group with only the permissions required for read and ping (`read`, `test`, `api`); do not grant write/policy/reboot/sensitive access.
- Default app port: `8729` (can be changed per router).

RouterOS 6 API-SSL certificate, legacy login and `/ping` reply-row behavior must still be verified on the exact RouterOS minor versions in the deployment environment. The RouterOS 6 parser expects `!re` records to represent echo replies; it rejects missing/duplicate/out-of-range sequence values.

## Build requirements

- JDK 17
- Gradle 8.7
- Android SDK Platform 35 and Build Tools 35.0.0
- Android platform-tools (only needed for USB install)

The official Gradle Wrapper JAR is not included in this source package. Install Gradle 8.7 and run:

```bash
./scripts/setup-and-build.sh
```

The build script checks JDK, Gradle and Android SDK versions, runs the JVM unit tests, and builds the debug APK. For source-only static checks without the Android toolchain, run `./scripts/verify-source.sh`. Install a built APK with:

```bash
./scripts/install-debug.sh
```

Expected APK path after a successful local build:

`app/build/outputs/apk/debug/app-debug.apk`

## Mock verification

Create a test-only TLS certificate. The fingerprint printed by OpenSSL is what should be compared independently and entered in the MCM router form.

```bash
./scripts/create-mock-certificate.sh 192.168.88.10
```

RouterOS 7 REST fixture:

```bash
python3 tools/mock_router.py --bind 0.0.0.0 --port 8443 \
  --cert .mcm-test-cert/router.crt --key .mcm-test-cert/router.key
```

RouterOS API-SSL fixture (current login):

```bash
python3 tools/mock_routeros_api_ssl.py --bind 0.0.0.0 --port 8729 \
  --cert .mcm-test-cert/router.crt --key .mcm-test-cert/router.key
```

Legacy API login simulation:

```bash
python3 tools/mock_routeros_api_ssl.py --bind 0.0.0.0 --port 8729 \
  --cert .mcm-test-cert/router.crt --key .mcm-test-cert/router.key --legacy-login
```

Use the mock credentials printed by the fixture (`mcm-test` / `test-only-change-me`) or set `MCM_TEST_USER` and `MCM_TEST_PASSWORD`. The mock servers are test tools, not router replacements. Do not expose them to an untrusted network. The REST mock without `--cert/--key` is HTTP-only for curl tests; MCM rejects it by design.

## Explicitly not release-verified yet

This is a more complete engineering source milestone, **not a signed production release**. The current workspace has no Android SDK installation and no Gradle installation, and cannot reach external package repositories. Therefore:

- Android Gradle compilation and APK assembly have not been run here.
- The Kotlin unit tests have been added but have not been executed via Gradle here.
- No physical Android device test has been run.
- No live RouterOS 6/7 router has been used to validate response variations, API-SSL certificate behavior, user policies, interface field availability, or ping loss edge cases.
- Netwatch event ingestion, chart export, router edit workflow, signed release APK, and cloud synchronization are not included in this milestone.

Do not label this ZIP or any debug APK produced elsewhere as a validated production release until the test plan in `docs/TEST_PLAN.md` has been completed on representative routers and Android devices.

## Project structure

```text
app/src/main/java/com/multicloud/mcm/
  data/                 Room entities and DAOs
  routeros/             RouterOS API framing and ping parser
  security/             Android Keystore and TLS fingerprint inspection
  MainActivity.kt       Android WebView host
  McmJavascriptBridge   Strict native/WebView bridge
  Mcm*Service           Profile, monitoring, interface-rate, history logic
app/src/main/assets/www/
  index.html            Local UI
  *.js                  Split native bridge, router UI, dashboard, charts
  style.css             Responsive UI
scripts/                Build, install, mock certificate scripts
tools/                  Read-only RouterOS test fixtures
```

## GitHub Actions: ZIP → APK

Hướng dẫn tạo repository và tải APK từ GitHub Actions: [GITHUB_SETUP_VI.md](GITHUB_SETUP_VI.md).
Workflow: `.github/workflows/android-build.yml`.
CI dùng JDK 17, Gradle 8.7, Android SDK 35 và tạo Debug APK artifact.
CI xanh không thay thế kiểm thử router và điện thoại thực tế.
