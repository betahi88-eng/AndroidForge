# Changelog

## 1.0.1 engineering source

- Added separate RouterOS 6 API-SSL and RouterOS 7 REST adapters.
- Added pinned TLS certificate verification and explicit out-of-band fingerprint confirmation.
- Added AES-256-GCM credential storage backed by Android Keystore and Room-based local profiles/history.
- Corrected packet-loss accounting: RouterOS 7 REST requires cumulative sent/received counters; RouterOS 6 uses a bounded command completion plus validated echo-reply sequence records.
- Added mock endpoints for REST, API-SSL direct login and legacy challenge login.
- Added parser/framing unit tests, source validation scripts and Vietnamese setup/test documentation.

This is an engineering source milestone, not a production release. See `README.md` and `docs/TEST_PLAN.md` for validation gaps.

## 1.0.1 source audit refresh (2026-11-22)

- Bound TLS fingerprint inspection connect and handshake reads with explicit 8-second timeouts.
- Hardened RouterOS 7 REST ping parsing: require host and unique sequence per reply, monotonic counters, one received-counter increment per returned echo reply, and final received count consistency.
- Added regression coverage for duplicate RouterOS 7 echo-reply sequences.
- Corrected AndroidForge instructions to distinguish web UI Release-asset upload from manual `input-directory` / `zip_path` workflow execution.
- Repackaged as a flat-root native Android Gradle/Kotlin ZIP with source preflight and archive integrity checks.

