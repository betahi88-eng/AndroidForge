# Hướng dẫn chuẩn bị MikroTik cho MCM

MCM không tự bật API, tạo user, sửa firewall hoặc cài chứng chỉ. Quản trị viên cấu hình router thủ công theo chính sách của mạng và chỉ nhập thông tin vào app sau khi xác minh.

## RouterOS 7

1. Chuẩn bị chứng chỉ TLS cho địa chỉ IP/DNS mà điện thoại sẽ dùng để kết nối.
2. Gán chứng chỉ cho `www-ssl`, bật dịch vụ HTTPS và giới hạn `available-from` vào mạng quản trị LAN/VPN.
3. Tắt REST qua HTTP (`rest-plain=no`). Không mở dịch vụ quản trị ra Internet công cộng; ưu tiên VPN.
4. Tạo group riêng có quyền `read,test,api,rest-api` và user riêng trong group đó. Quyền `test` là cần thiết cho ping; không cấp `write`, `policy`, `reboot` hoặc `sensitive`.
5. Mở đúng cổng `www-ssl` (mặc định 443) từ điện thoại tới router.

Ví dụ tham khảo:

```routeros
/user/group/add name=mcm-monitor policy=read,test,api,rest-api
/user/add name=mcm-monitor group=mcm-monitor password="LONG-UNIQUE-PASSWORD"
/ip/service/set www-ssl disabled=no certificate=rest-https
/ip/service/webserver/set rest-plain=no
/ip/service/set www-ssl available-from=192.168.88.0/24
```

Tên chứng chỉ và subnet trong ví dụ cần thay bằng giá trị thực tế. Không copy nguyên các địa chỉ ví dụ vào mạng đang chạy.

## RouterOS 6

1. Chuẩn bị và gán chứng chỉ cho service `api-ssl`.
2. Bật `api-ssl`, mặc định TCP 8729.
3. Tạo tài khoản riêng chỉ có quyền cần thiết để đọc dữ liệu và chạy ping; thường gồm `read,test,api`.
4. Giới hạn source IP bằng `available-from` và firewall.
5. MCM yêu cầu TLS certificate pin. Nếu `api-ssl` không có certificate và chỉ cung cấp anonymous Diffie-Hellman, kết nối sẽ thất bại có chủ đích.

## Lấy và xác nhận TLS fingerprint

1. Trong MCM nhập host và port.
2. Nhấn **Đọc fingerprint TLS** để xem SHA-256 của certificate mà endpoint đang trình bày.
3. Đối chiếu fingerprint với chứng chỉ lấy từ nguồn độc lập đáng tin cậy (ví dụ xuất chứng chỉ từ router/thiết bị quản trị riêng).
4. Chỉ sau khi trùng khớp mới lưu router và xác nhận hộp thoại.

Nút đọc fingerprint chỉ có mục đích hiển thị. Nó không lưu pin, không cấp quyền tin cậy cho certificate và không được sử dụng để thực hiện phiên API thật.

## Kiểm tra sau khi thêm

- Kiểm tra `system/resource` có version, uptime, CPU và RAM hợp lệ.
- Kiểm tra danh sách interface và các counter `rx-byte`/`tx-byte`.
- Làm mới lần thứ hai sau khoảng 30 giây để xem tốc độ Mbps (lần đọc đầu chỉ lập baseline counter).
- Chạy ping tới một địa chỉ kiểm soát được. RouterOS 7 REST phải trả cặp `sent`/`received` xác nhận đủ số gói; RouterOS 6 chỉ được chấp nhận sau khi lệnh ping giới hạn `count` kết thúc `!done`, các bản ghi `!re` có `seq` duy nhất và `host` hợp lệ. Khi RouterOS 7 không có bản ghi kết thúc do mất gói cuối/toàn bộ, MCM hiển thị phép đo chưa hoàn tất thay vì tự đoán.
- Nếu ping bị từ chối nhưng đọc resource thành công, kiểm tra quyền `test` của user.

Mọi lệnh cấu hình trong tài liệu này do quản trị viên tự cân nhắc và tự chạy. MCM không chạy các lệnh trên router.
