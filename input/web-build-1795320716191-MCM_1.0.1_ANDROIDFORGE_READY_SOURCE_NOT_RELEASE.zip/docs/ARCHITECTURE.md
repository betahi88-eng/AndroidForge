# MCM architecture

## Layers

- **UI:** local HTML/CSS/JavaScript assets served through AndroidX WebViewAssetLoader. No CDN or remote scripts; a restrictive Content Security Policy blocks remote resources and WebView network fetches.
- **Bridge:** a narrow `@JavascriptInterface` allow-list. Calls return callback IDs; Room and network work run on `Dispatchers.IO`.
- **Application services:** router profile, monitoring, interface-rate calculation and history services.
- **Persistence:** Room stores non-secret router metadata, interface counter baselines and metric history. The credential store encrypts passwords separately.
- **Security:** one Android Keystore AES-256-GCM key per credential alias. Every production API client requires a manually verified SHA-256 certificate pin. No cleartext router API path exists.
- **RouterOS adapters:** independent implementations for RouterOS 7 REST and RouterOS 6 API-SSL.

## RouterOS 7 adapter

- HTTPS `GET /rest/system/resource`
- HTTPS `GET /rest/interface`
- HTTPS `POST /rest/ping` with bounded `count`
- HTTP Basic Auth carried by OkHttp
- Pin verification of the leaf certificate; OkHttp's normal hostname verification remains enabled

## RouterOS 6 adapter

- TLS socket to API-SSL (default TCP 8729)
- RouterOS API length-prefixed words, zero-length sentence terminator and `!re`/`!trap`/`!done` reply handling
- Direct `/login name=... password=...` for v6.43+; on rejected direct-login response, reconnect and attempt the legacy `ret`/MD5 challenge exchange
- Read-only commands for system resource, interface print and bounded `/ping`

## Polling and history

- UI foreground refresh: 30-second timer while page is visible.
- WorkManager periodic background sample: best effort, 15-minute minimum interval, network-connected constraint; current worker records CPU and memory only.
- Interface Mbps is computed from monotonic time delta and successive byte counters. Counter reset/decrease causes a new baseline and no rate for that sample.
- History stores CPU, memory-used and ICMP loss values, capped to 30 days; charts show at most 60 latest records.

## Trust boundaries

The fingerprint inspector uses a temporary certificate-capture trust manager only to display a fingerprint. It does not store or trust the result. Before persistence, UI confirmation is required after out-of-band comparison. Production REST/API-SSL clients use a separate strict trust manager that rejects all pins except the configured SHA-256 leaf fingerprint.

The app does not implement certificate auto-rotation. A changed certificate is rejected until the user re-verifies and updates the profile.

## ICMP accounting by protocol

RouterOS 7 REST supplies cumulative `sent` and `received` fields in ping records. The parser requires a complete requested count before accepting a sample, so trailing loss or total loss is shown as incomplete when the REST response has no terminal counter row. RouterOS 6 API-SSL is handled separately: `/ping` is bounded with a requested `count`; only a successfully completed command (`!done`) establishes the sent count, and distinct valid `!re` echo-reply sequences establish received. Neither path infers sent from result-row count or from interface traffic. The RouterOS 6 `!re` shape remains a hardware-validation item.
