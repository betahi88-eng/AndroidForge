# MCM 1.0.1 implementation and verification status

## Implemented in this engineering source

1. Android application skeleton using Kotlin, local WebView assets and a native JavaScript bridge.
2. Router profile CRUD, Room metadata/history storage and Android Keystore AES-256-GCM credential encryption.
3. RouterOS 7 HTTPS REST resource/interface reads and bounded ping.
4. RouterOS 6 API-SSL word framing, direct login, legacy MD5 challenge-response login, resource/interface reads and bounded ping.
5. Strict SHA-256 leaf certificate pinning in normal clients plus an inspection-only fingerprint flow requiring out-of-band user confirmation.
6. CPU/RAM/PPPoE/interface state, interface-rate calculations, ICMP loss and local history/chart UI.
7. Foreground polling, best-effort WorkManager CPU/RAM sampling, REST/API-SSL mock tools and source/test scripts.

## Remaining release gates

1. Run the full Gradle unit-test and Android assemble tasks with JDK 17+, Gradle 8.7+ and Android SDK 35.
2. Verify the REST/API-SSL field mappings and ping reply shapes on representative RouterOS 6 and 7 minor versions.
3. Test certificate pinning, Android Keystore persistence/recovery, router CRUD and WebView bridge behavior on actual Android devices.
4. Verify network-loss, VPN reconnect, DNS/IP addressing, battery impact and long-running polling behavior.
5. Add Netwatch ingestion, chart export and router profile edit workflow if they remain in the accepted product scope.
6. Create an owner-controlled signing key, generate a signed release APK and publish SHA-256 checksums.

## Packet-loss correctness

Do not infer the number of sent probes from the number of returned rows or interface RX/TX counters. RouterOS 7 REST must provide a complete cumulative `sent`/`received` count. RouterOS 6 API-SSL requires a bounded `/ping count=...` command to complete with `!done`; the requested count is sent, and only validated distinct echo-reply `!re` records count as received. RouterOS 6 reply-row behavior still requires confirmation against the target firmware.

## Read-only policy

Production adapters only read monitoring data and issue a bounded diagnostic ping. No configuration-changing RouterOS commands are present in the app adapters.
