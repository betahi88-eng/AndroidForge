# MCM verification plan

## Automated checks

- [ ] `node --check` passes for every local JavaScript file.
- [ ] `python3 -m py_compile tools/*.py` passes.
- [ ] `gradle :app:testDebugUnitTest` passes, especially `PingResponseParserTest`, `RouterOs6PingParserTest` and `RouterOsApiCodecTest`.
- [ ] `gradle :app:assembleDebug` succeeds with JDK 17+, Gradle 8.7, Android SDK 35.
- [ ] Confirm ZIP contains source/docs/mock tools and no private key, keystore, local.properties, build output or APK presented as a signed release.

## RouterOS 7 tests

- [ ] RouterOS 7.1 or other minimum supported version: REST service available over HTTPS.
- [ ] Current RouterOS 7.x: `system/resource` parses CPU, free/total RAM and uptime.
- [ ] Interface list parses running state and byte counters.
- [ ] Second read after a timed interval produces a plausible Mbps rate.
- [ ] Ping with zero loss, intermittent loss, trailing loss and total loss.
- [ ] A response without a complete `sent` count is marked invalid/incomplete, never guessed.
- [ ] Wrong pin, missing pin, malformed pin, wrong password, missing `rest-api`, missing `api` and missing `test` each fail safely with a useful message.
- [ ] HTTP/cleartext REST is rejected.

## RouterOS 6 tests

- [ ] At least one RouterOS 6.49.x device with an assigned API-SSL certificate.
- [ ] Direct login succeeds.
- [ ] Legacy MD5 challenge path succeeds against an old firmware/test endpoint.
- [ ] API word lengths at 1/2/3/4-byte boundaries round-trip.
- [ ] `system/resource`, `interface/print`, and bounded `/ping` parse. Confirm `/ping` produces one `!re` row per echo reply and that the final `!done` means the configured count completed.
- [ ] Missing API certificate, wrong pin, wrong port, rejected credentials and missing `test` policy fail safely.

## Android device tests

- [ ] Android 8+, a current Android release and at least one small-screen phone.
- [ ] Create several router profiles; restart app; confirm persistence.
- [ ] Confirm password is encrypted and never returned to the WebView or Room profile row.
- [ ] Remove router; confirm its credential, metrics and counters are removed.
- [ ] Test no LAN, VPN disconnected/reconnected, DNS name and IP host.
- [ ] Background worker does not stop foreground app; confirm Android may defer its 15-minute best-effort schedule.
- [ ] Check battery use and memory after 24-hour operation.

## Release gates

Do not mark production-ready until all tests above are evidenced on actual RouterOS hardware and Android devices, any protocol variations are resolved, an app signing key is created/held by the project owner, and a signed APK plus SHA-256 checksum is generated.
