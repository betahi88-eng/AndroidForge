#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${1:-$(dirname "$ROOT")/MCM_1.0.1_FULL_AUDITED_SOURCE_NOT_RELEASE.zip}"
case "$OUT" in
  /*) ;;
  *) OUT="$PWD/$OUT" ;;
esac
case "$OUT" in
  "$ROOT"/*) echo "Choose an archive destination outside the source tree." >&2; exit 1 ;;
esac

"$ROOT/scripts/androidforge-preflight.sh"
"$ROOT/scripts/verify-source.sh"
mkdir -p "$(dirname "$OUT")"
rm -f "$OUT"
cd "$ROOT"
zip -qr "$OUT" . \
  -x '.git/*' '.gradle/*' '*/build/*' 'build/*' 'local.properties' \
     '*/__pycache__/*' '*.pyc' '*.apk' '*.aab' '*.jks' '*.keystore' \
     '*.pem' '*.key' '*.crt' '.mcm-test-cert/*'
unzip -t "$OUT" >/dev/null

# AndroidForge detects the project root from these files. They must be at ZIP root.
for entry in settings.gradle.kts build.gradle.kts app/build.gradle.kts app/src/main/AndroidManifest.xml; do
  unzip -Z1 "$OUT" | grep -Fxq "$entry" || {
    echo "Archive root validation failed: missing $entry" >&2
    exit 1
  }
done
if unzip -Z1 "$OUT" | grep -Eq '(^|/)(pubspec\.yaml|harmony_patched)(/|$)'; then
  echo "Archive contains Flutter project markers; refusing to package." >&2
  exit 1
fi

echo "Source archive: $OUT"
sha256sum "$OUT"
