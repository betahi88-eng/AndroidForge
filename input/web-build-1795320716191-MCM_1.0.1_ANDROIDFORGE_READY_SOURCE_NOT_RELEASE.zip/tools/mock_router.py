#!/usr/bin/env python3
"""Read-only RouterOS 7 REST fixture. Use TLS for the Android app integration test."""
from __future__ import annotations

import argparse
import base64
import json
import os
import ssl
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


class MockRouterHandler(BaseHTTPRequestHandler):
    server_version = "MCM-RouterOS7-Mock/1.0"

    def _reply(self, payload: object, status: int = 200) -> None:
        body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _authorized(self) -> bool:
        expected_user = self.server.mock_user
        expected_password = self.server.mock_password
        token = base64.b64encode(f"{expected_user}:{expected_password}".encode()).decode()
        if self.headers.get("Authorization") == f"Basic {token}":
            return True
        self._reply({"error": 401, "message": "Unauthorized"}, 401)
        return False

    def do_GET(self) -> None:
        if not self._authorized():
            return
        if self.path == "/rest/system/resource":
            self._reply([{
                "version": "7.16.2 (mock)", "uptime": "2d4h15m", "cpu-load": "12",
                "free-memory": "536870912", "total-memory": "1073741824"
            }])
        elif self.path == "/rest/interface":
            self._reply([
                {"name": "ether1", "type": "ether", "running": "true", "rx-byte": "102400000", "tx-byte": "204800000"},
                {"name": "pppoe-out1", "type": "pppoe-out", "running": "true", "rx-byte": "50240000", "tx-byte": "30480000"},
                {"name": "ether2", "type": "ether", "running": "false", "rx-byte": "0", "tx-byte": "0"}
            ])
        else:
            self._reply({"error": 404, "message": "Not Found"}, 404)

    def do_POST(self) -> None:
        if not self._authorized():
            return
        if self.path != "/rest/ping":
            self._reply({"error": 405, "message": "Only diagnostic ping POST is enabled"}, 405)
            return
        try:
            payload = json.loads(self.rfile.read(int(self.headers.get("Content-Length", "0"))))
            count = int(payload.get("count", "4"))
            target = str(payload.get("address", "198.51.100.1"))
            if not 1 <= count <= 100:
                raise ValueError("count out of range")
        except (ValueError, TypeError, json.JSONDecodeError):
            self._reply({"error": 400, "message": "Invalid ping request"}, 400)
            return

        received = 0
        rows = []
        for sequence in range(count):
            # A deterministic drop every fifth sequence lets tests exercise loss parsing.
            # Simulate a dropped probe every fifth packet, but keep the final packet a reply
            # so the last returned cumulative counter confirms the full requested sample.
            reply = (sequence + 1) % 5 != 0 or sequence == count - 1
            if not reply:
                continue
            received += 1
            rows.append({
                "host": target,
                "seq": str(sequence),
                "sent": str(sequence + 1),
                "received": str(received),
                "packet-loss": str(round(((sequence + 1 - received) * 100) / (sequence + 1), 2)),
                "time": "8.5ms"
            })
        self._reply(rows)

    def do_PUT(self) -> None:
        self._reply({"error": 405, "message": "Read-only mock"}, 405)

    do_PATCH = do_PUT
    do_DELETE = do_PUT

    def log_message(self, fmt: str, *args: object) -> None:
        print("[mock-rest] " + fmt % args)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bind", default="127.0.0.1", help="Use 0.0.0.0 only on a trusted test LAN")
    parser.add_argument("--port", type=int, default=8443)
    parser.add_argument("--cert", help="PEM certificate; required for HTTPS test mode")
    parser.add_argument("--key", help="PEM private key matching --cert")
    parser.add_argument("--user", default=os.getenv("MCM_TEST_USER", "mcm-test"))
    parser.add_argument("--password", default=os.getenv("MCM_TEST_PASSWORD", "test-only-change-me"))
    args = parser.parse_args()
    if bool(args.cert) != bool(args.key):
        parser.error("--cert and --key must be supplied together")

    server = ThreadingHTTPServer((args.bind, args.port), MockRouterHandler)
    server.mock_user = args.user
    server.mock_password = args.password
    scheme = "https" if args.cert else "http"
    if args.cert:
        tls = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        tls.minimum_version = ssl.TLSVersion.TLSv1_2
        tls.load_cert_chain(args.cert, args.key)
        server.socket = tls.wrap_socket(server.socket, server_side=True)
    else:
        print("WARNING: HTTP mode is for curl/local tests only; MCM Android rejects cleartext HTTP.")
    print(f"MCM REST mock listening on {scheme}://{args.bind}:{args.port}/rest")
    print(f"Test credentials: {args.user} / (password supplied separately)")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping mock server")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
