package com.multicloud.mcm

import com.multicloud.mcm.data.InterfaceCounterEntity
import com.multicloud.mcm.data.McmDatabase
import org.json.JSONArray
import org.json.JSONObject

class McmInterfaceRateService(private val database: McmDatabase) {
    suspend fun enrich(routerId: String, interfaces: List<InterfaceSnapshot>, measuredAt: Long): JSONArray {
        val output = JSONArray()
        val counterDao = database.interfaceCounterDao()
        interfaces.forEach { item ->
            var rxMbps: Double? = null
            var txMbps: Double? = null
            val rx = item.rxBytes
            val tx = item.txBytes
            if (rx != null && tx != null && rx >= 0 && tx >= 0) {
                val previous = counterDao.get(routerId, item.name)
                if (previous != null && measuredAt > previous.recordedAtEpochMs &&
                    rx >= previous.rxBytes && tx >= previous.txBytes) {
                    val seconds = (measuredAt - previous.recordedAtEpochMs) / 1_000.0
                    if (seconds > 0) {
                        rxMbps = (rx - previous.rxBytes) * 8.0 / seconds / 1_000_000.0
                        txMbps = (tx - previous.txBytes) * 8.0 / seconds / 1_000_000.0
                    }
                }
                counterDao.upsert(InterfaceCounterEntity(routerId, item.name, rx, tx, measuredAt))
            }
            output.put(
                JSONObject()
                    .put("name", item.name)
                    .put("type", item.type)
                    .put("running", item.running)
                    .put("rxMbps", rxMbps ?: JSONObject.NULL)
                    .put("txMbps", txMbps ?: JSONObject.NULL)
            )
        }
        return output
    }
}
