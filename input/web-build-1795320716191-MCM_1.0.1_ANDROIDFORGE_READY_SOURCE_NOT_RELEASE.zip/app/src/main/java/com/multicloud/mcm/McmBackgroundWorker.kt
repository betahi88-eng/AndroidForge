package com.multicloud.mcm

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.multicloud.mcm.data.McmDatabase
import com.multicloud.mcm.data.MetricHistoryEntity
import com.multicloud.mcm.security.SecureCredentialStore
import com.multicloud.mcm.routeros.RouterOs6ApiClient
import com.multicloud.mcm.routeros.RouterOs6Repository
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.CancellationException
import androidx.room.Room

/** Best-effort background health samples. WorkManager's periodic minimum interval is 15 minutes. */
class McmBackgroundWorker(context: Context, parameters: WorkerParameters) : CoroutineWorker(context, parameters) {
    override suspend fun doWork(): Result = withTimeout(10 * 60 * 1_000L) {
        val database = Room.databaseBuilder(applicationContext, McmDatabase::class.java, "mcm.db").build()
        val credentials = SecureCredentialStore(applicationContext)
        try {
            val routers = database.routerDao().getAll()
            routers.forEach { router ->
                val password = runCatching { credentials.get(router.credentialAlias) }.getOrNull() ?: return@forEach
                val now = System.currentTimeMillis()
                val resource = if (router.routerOsMajor == 7) {
                    RouterOs7Repository(RouterOs7Client(router.host, router.port, router.username, password, router.tlsSha256Pin))
                        .readSystemResource()
                } else {
                    RouterOs6Repository(RouterOs6ApiClient(router.host, router.port, router.username, password, router.tlsSha256Pin))
                        .readSystemResource()
                }
                val values = (resource as? McmResult.Success)?.value ?: return@forEach
                database.routerDao().upsert(router.copy(lastSeenAtEpochMs = now))
                values.cpuLoadPercent?.let {
                    database.metricDao().insert(MetricHistoryEntity(routerId = router.id, metricKey = "cpu_load", value = it.toDouble(), unit = "%", recordedAtEpochMs = now))
                }
                if (values.freeMemoryBytes != null && values.totalMemoryBytes != null && values.totalMemoryBytes > 0) {
                    val used = 100.0 * (values.totalMemoryBytes - values.freeMemoryBytes).coerceAtLeast(0) / values.totalMemoryBytes.toDouble()
                    database.metricDao().insert(MetricHistoryEntity(routerId = router.id, metricKey = "memory_used", value = used, unit = "%", recordedAtEpochMs = now))
                }
            }
            database.metricDao().deleteBefore(System.currentTimeMillis() - 30L * 24L * 60L * 60L * 1_000L)
            Result.success()
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            Result.retry()
        } finally {
            database.close()
        }
    }
}
