package com.multicloud.mcm.routeros

import com.multicloud.mcm.InterfaceSnapshot
import com.multicloud.mcm.McmResult
import com.multicloud.mcm.PingMeasurement
import com.multicloud.mcm.PppoeStatus
import com.multicloud.mcm.SystemResource

class RouterOs6Repository(private val client: RouterOs6ApiClient) {
    suspend fun readSystemResource(): McmResult<SystemResource> {
        return when (
        val result = client.execute("/system/resource/print", mapOf(".proplist" to "version,uptime,cpu-load,free-memory,total-memory"))
    ) {
        is McmResult.Failure -> result
        is McmResult.Success -> {
            val row = result.value.firstOrNull()
                ?: return McmResult.Failure("RESOURCE_EMPTY", "Router không trả dữ liệu system/resource.")
            McmResult.Success(
                SystemResource(
                    version = row["version"],
                    uptime = row["uptime"],
                    cpuLoadPercent = row["cpu-load"]?.toIntOrNull()?.coerceIn(0, 100),
                    freeMemoryBytes = row["free-memory"]?.toLongOrNull(),
                    totalMemoryBytes = row["total-memory"]?.toLongOrNull()
                )
            )
        }
        }
    }

    suspend fun readInterfaces(): McmResult<List<InterfaceSnapshot>> = when (
        val result = client.execute(
            "/interface/print",
            mapOf(".proplist" to "name,type,running,rx-byte,tx-byte,last-link-up-time")
        )
    ) {
        is McmResult.Failure -> result
        is McmResult.Success -> McmResult.Success(
            result.value.mapNotNull { row ->
                val name = row["name"] ?: return@mapNotNull null
                InterfaceSnapshot(
                    name = name,
                    type = row["type"].orEmpty(),
                    running = row["running"].equals("true", true) || row["running"].equals("yes", true),
                    rxBytes = row["rx-byte"]?.toLongOrNull(),
                    txBytes = row["tx-byte"]?.toLongOrNull(),
                    lastLinkUpTime = row["last-link-up-time"]
                )
            }
        )
    }

    suspend fun readPppoeInterfaces(): McmResult<List<PppoeStatus>> = when (val result = readInterfaces()) {
        is McmResult.Failure -> result
        is McmResult.Success -> McmResult.Success(
            result.value.filter { it.type.contains("pppoe", true) || it.name.contains("pppoe", true) }
                .map { PppoeStatus(it.name, it.running, it.lastLinkUpTime, null) }
        )
    }

    suspend fun ping(target: String, count: Int = 20): McmResult<PingMeasurement> {
        require(target.isNotBlank() && count in 1..100)
        return when (
            val result = client.execute(
                "/ping",
                mapOf("address" to target, "count" to count.toString(), "interval" to "200ms")
            )
        ) {
            is McmResult.Failure -> result
            is McmResult.Success -> RouterOs6PingParser.parseCompleted(
                target = target,
                rows = result.value,
                requestedCount = count
            )
        }
    }
}
