package com.multicloud.mcm

import com.multicloud.mcm.data.McmDatabase
import com.multicloud.mcm.data.RouterEntity
import com.multicloud.mcm.security.SecureCredentialStore
import com.multicloud.mcm.security.TlsFingerprintInspector
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class McmRouterProfileService(
    private val database: McmDatabase,
    private val credentialStore: SecureCredentialStore
) {
    suspend fun listRouters(): JSONArray {
        val result = JSONArray()
        database.routerDao().getAll().forEach { result.put(it.toPublicJson()) }
        return result
    }

    suspend fun inspectTls(host: String, port: Int): String =
        TlsFingerprintInspector.inspect(host.trim(), port)

    suspend fun saveRouter(payloadJson: String) {
        val payload = JSONObject(payloadJson)
        val name = payload.getString("name").trim()
        val host = payload.getString("host").trim()
        val major = payload.getInt("routerOsMajor")
        val port = payload.optInt("port", if (major == 6) 8729 else 443)
        val username = payload.getString("username").trim()
        val password = payload.getString("password")
        val pin = RouterOs7Client.normalizePin(payload.getString("tlsSha256Pin"))

        require(name.isNotBlank() && name.length <= 64) { "Tên router phải có từ 1 đến 64 ký tự." }
        require(host.matches(Regex("[A-Za-z0-9.-]+"))) { "Host chỉ được là IP hoặc tên DNS; không nhập scheme/path." }
        require(major == 6 || major == 7) { "Chỉ hỗ trợ RouterOS 6 hoặc 7." }
        require(port in 1..65535 && username.isNotBlank() && password.isNotEmpty()) {
            "Port, username hoặc password không hợp lệ."
        }

        val id = UUID.randomUUID().toString()
        val credentialAlias = "mcm_credential_$id"
        credentialStore.put(credentialAlias, password)
        try {
            database.routerDao().upsert(
                RouterEntity(
                    id = id,
                    name = name,
                    host = host,
                    port = port,
                    routerOsMajor = major,
                    username = username,
                    credentialAlias = credentialAlias,
                    tlsSha256Pin = pin,
                    createdAtEpochMs = System.currentTimeMillis(),
                    lastSeenAtEpochMs = null
                )
            )
        } catch (error: Exception) {
            credentialStore.remove(credentialAlias)
            throw error
        }
    }

    suspend fun removeRouter(routerId: String) {
        val router = database.routerDao().getById(routerId)
            ?: throw IllegalArgumentException("Không tìm thấy router.")
        database.routerDao().delete(routerId)
        database.metricDao().deleteForRouter(routerId)
        database.interfaceCounterDao().deleteForRouter(routerId)
        credentialStore.remove(router.credentialAlias)
    }

    private fun RouterEntity.toPublicJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("name", name)
        .put("host", host)
        .put("port", port)
        .put("routerOsMajor", routerOsMajor)
        .put("username", username)
        .put("lastSeenAt", lastSeenAtEpochMs ?: JSONObject.NULL)
}
