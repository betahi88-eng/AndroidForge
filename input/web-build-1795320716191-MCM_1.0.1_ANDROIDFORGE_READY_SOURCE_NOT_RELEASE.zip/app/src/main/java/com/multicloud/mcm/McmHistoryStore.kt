package com.multicloud.mcm

import com.multicloud.mcm.data.McmDatabase
import com.multicloud.mcm.data.MetricHistoryEntity
import org.json.JSONArray
import org.json.JSONObject

class McmHistoryStore(private val database: McmDatabase) {
    suspend fun record(routerId: String, key: String, value: Double, unit: String, atEpochMs: Long) {
        database.metricDao().insert(
            MetricHistoryEntity(
                routerId = routerId,
                metricKey = key,
                value = value,
                unit = unit,
                recordedAtEpochMs = atEpochMs
            )
        )
        database.metricDao().deleteBefore(atEpochMs - RETENTION_MS)
    }

    suspend fun read(routerId: String, metricKey: String): JSONObject {
        require(metricKey in ALLOWED_KEYS) { "Metric key không hợp lệ." }
        val samples = database.metricDao().recent(routerId, metricKey, HISTORY_LIMIT).reversed()
        val points = JSONArray()
        samples.forEach { sample ->
            points.put(JSONObject().put("at", sample.recordedAtEpochMs).put("value", sample.value))
        }
        return JSONObject().put("ok", true).put("metric", metricKey).put("points", points)
    }

    companion object {
        private const val RETENTION_MS = 30L * 24L * 60L * 60L * 1_000L
        private const val HISTORY_LIMIT = 60
        private val ALLOWED_KEYS = setOf("cpu_load", "memory_used", "icmp_loss")
    }
}
