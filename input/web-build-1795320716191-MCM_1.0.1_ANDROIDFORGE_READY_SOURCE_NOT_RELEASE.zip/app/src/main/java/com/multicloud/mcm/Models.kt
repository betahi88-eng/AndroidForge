package com.multicloud.mcm

/** RouterOS protocol family. ROS 6 uses native API-SSL; ROS 7 uses HTTPS REST. */
enum class RouterOsFamily(val majorVersion: Int) { ROS6(6), ROS7(7) }

data class RouterProfile(
    val id: String,
    val name: String,
    val host: String,
    val port: Int,
    val routerOsMajor: Int,
    val username: String,
    val credentialAlias: String,
    val tlsSha256Pin: String
)

data class SystemResource(
    val version: String?,
    val uptime: String?,
    val cpuLoadPercent: Int?,
    val freeMemoryBytes: Long?,
    val totalMemoryBytes: Long?
)

data class PingMeasurement(
    val target: String,
    val sent: Int,
    val received: Int,
    val lost: Int,
    val lossPercent: Double,
    val minRttMs: Double?,
    val avgRttMs: Double?,
    val maxRttMs: Double?,
    val measuredAtEpochMs: Long
) {
    companion object {
        fun fromCounts(
            target: String,
            sent: Int,
            received: Int,
            minRtt: Double?,
            avgRtt: Double?,
            maxRtt: Double?,
            now: Long = System.currentTimeMillis()
        ): PingMeasurement {
            require(target.isNotBlank())
            require(sent > 0 && received in 0..sent)
            val lost = sent - received
            val loss = lost.toDouble() * 100.0 / sent.toDouble()
            return PingMeasurement(target, sent, received, lost, loss, minRtt, avgRtt, maxRtt, now)
        }
    }
}

data class TrafficRate(val rxBitsPerSecond: Long, val txBitsPerSecond: Long)

data class InterfaceSnapshot(
    val name: String,
    val type: String,
    val running: Boolean,
    val rxBytes: Long?,
    val txBytes: Long?,
    val lastLinkUpTime: String?
)

data class PppoeStatus(
    val interfaceName: String,
    val running: Boolean,
    val uptime: String?,
    val traffic: TrafficRate?
)

sealed interface McmResult<out T> {
    data class Success<T>(val value: T) : McmResult<T>
    data class Failure(val code: String, val message: String) : McmResult<Nothing>
}
