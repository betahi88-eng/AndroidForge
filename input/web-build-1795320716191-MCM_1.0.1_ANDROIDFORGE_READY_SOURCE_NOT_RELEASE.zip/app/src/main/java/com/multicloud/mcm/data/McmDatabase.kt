package com.multicloud.mcm.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase

@Entity(tableName = "router_profiles")
data class RouterEntity(
    @PrimaryKey val id: String,
    val name: String,
    val host: String,
    val port: Int,
    val routerOsMajor: Int,
    val username: String,
    val credentialAlias: String,
    val tlsSha256Pin: String,
    val createdAtEpochMs: Long,
    val lastSeenAtEpochMs: Long?
)

@Entity(tableName = "metric_history", indices = [androidx.room.Index(value = ["routerId", "recordedAtEpochMs"])])
data class MetricHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val routerId: String,
    val metricKey: String,
    val value: Double,
    val unit: String,
    val recordedAtEpochMs: Long
)

@Dao
interface RouterDao {
    @Query("SELECT * FROM router_profiles ORDER BY name COLLATE NOCASE")
    suspend fun getAll(): List<RouterEntity>

    @Query("SELECT * FROM router_profiles WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): RouterEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(router: RouterEntity)

    @Query("DELETE FROM router_profiles WHERE id = :id")
    suspend fun delete(id: String)
}

@Dao
interface MetricDao {
    @Insert
    suspend fun insert(sample: MetricHistoryEntity)

    @Query("SELECT * FROM metric_history WHERE routerId = :routerId AND metricKey = :metricKey ORDER BY recordedAtEpochMs DESC LIMIT :limit")
    suspend fun recent(routerId: String, metricKey: String, limit: Int): List<MetricHistoryEntity>

    @Query("DELETE FROM metric_history WHERE recordedAtEpochMs < :beforeEpochMs")
    suspend fun deleteBefore(beforeEpochMs: Long)

    @Query("DELETE FROM metric_history WHERE routerId = :routerId")
    suspend fun deleteForRouter(routerId: String)
}

@Entity(tableName = "interface_counters", primaryKeys = ["routerId", "interfaceName"])
data class InterfaceCounterEntity(
    val routerId: String,
    val interfaceName: String,
    val rxBytes: Long,
    val txBytes: Long,
    val recordedAtEpochMs: Long
)

@Dao
interface InterfaceCounterDao {
    @Query("SELECT * FROM interface_counters WHERE routerId = :routerId AND interfaceName = :interfaceName LIMIT 1")
    suspend fun get(routerId: String, interfaceName: String): InterfaceCounterEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(counter: InterfaceCounterEntity)

    @Query("DELETE FROM interface_counters WHERE routerId = :routerId")
    suspend fun deleteForRouter(routerId: String)
}

@Database(entities = [RouterEntity::class, MetricHistoryEntity::class, InterfaceCounterEntity::class], version = 1, exportSchema = false)
abstract class McmDatabase : RoomDatabase() {
    abstract fun routerDao(): RouterDao
    abstract fun metricDao(): MetricDao
    abstract fun interfaceCounterDao(): InterfaceCounterDao
}
