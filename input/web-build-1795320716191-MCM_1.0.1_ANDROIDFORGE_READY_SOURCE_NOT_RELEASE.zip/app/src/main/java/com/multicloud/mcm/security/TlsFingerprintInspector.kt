package com.multicloud.mcm.security

import com.multicloud.mcm.RouterOs7Client
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.SecureRandom
import java.net.InetSocketAddress
import java.security.cert.X509Certificate
import javax.net.ssl.SSLContext
import javax.net.ssl.X509TrustManager

/**
 * Reads a server certificate fingerprint for display only. This intentionally does not
 * authenticate the certificate; the user must compare it through a trusted independent
 * channel before saving it. Normal router sessions never use this permissive trust manager.
 */
object TlsFingerprintInspector {
    suspend fun inspect(host: String, port: Int): String = withContext(Dispatchers.IO) {
        require(host.matches(Regex("[A-Za-z0-9.-]+")) && port in 1..65535)
        val captureTrustManager = object : X509TrustManager {
            var leaf: X509Certificate? = null
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
            override fun checkClientTrusted(chain: Array<out X509Certificate>, authType: String) = Unit
            override fun checkServerTrusted(chain: Array<out X509Certificate>, authType: String) {
                leaf = chain.firstOrNull() ?: throw java.security.cert.CertificateException("No server certificate")
            }
        }
        val context = SSLContext.getInstance("TLS").apply {
            init(null, arrayOf(captureTrustManager), SecureRandom())
        }
        val socket = context.socketFactory.createSocket() as javax.net.ssl.SSLSocket
        try {
            socket.connect(InetSocketAddress(host, port), CONNECT_TIMEOUT_MS)
            socket.soTimeout = READ_TIMEOUT_MS
            socket.startHandshake()
            val certificate = captureTrustManager.leaf
                ?: throw IllegalStateException("Router did not present a TLS certificate")
            RouterOs7Client.sha256(certificate.encoded)
        } finally {
            socket.close()
        }
    }

    private const val CONNECT_TIMEOUT_MS = 8_000
    private const val READ_TIMEOUT_MS = 8_000
}
