package com.multicloud.mcm.routeros

import com.multicloud.mcm.McmResult
import com.multicloud.mcm.RouterOs7Client
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.X509TrustManager

/** RouterOS 6 API-SSL client with current and legacy login support. */
class RouterOs6ApiClient(
    private val host: String,
    private val port: Int,
    private val username: String,
    private val password: String,
    expectedPinHex: String
) {
    private val pin = RouterOs7Client.normalizePin(expectedPinHex)
    private val trustManager = object : X509TrustManager {
        override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
        override fun checkClientTrusted(chain: Array<out X509Certificate>, authType: String) {
            throw CertificateException("Client certificate authentication is not supported")
        }
        override fun checkServerTrusted(chain: Array<out X509Certificate>, authType: String) {
            val certificate = chain.firstOrNull() ?: throw CertificateException("Router sent no certificate")
            val actual = RouterOs7Client.sha256(certificate.encoded)
            if (!MessageDigest.isEqual(actual.toByteArray(), pin.toByteArray())) {
                throw CertificateException("Router TLS certificate fingerprint mismatch")
            }
        }
    }
    private val sslContext = SSLContext.getInstance("TLS").apply {
        init(null, arrayOf(trustManager), SecureRandom())
    }

    suspend fun execute(
        command: String,
        attributes: Map<String, String> = emptyMap()
    ): McmResult<List<Map<String, String>>> = withContext(Dispatchers.IO) {
        require(command.startsWith('/') && command.matches(Regex("/[A-Za-z0-9_/-]+")))
        try {
            openAuthenticatedSocket().use { socket ->
                socket.soTimeout = COMMAND_READ_TIMEOUT_MS
                val input = DataInputStream(BufferedInputStream(socket.inputStream))
                val output = DataOutputStream(BufferedOutputStream(socket.outputStream))
                val words = listOf(command) + attributes.map { (key, value) -> "=$key=$value" }
                RouterOsApiCodec.writeSentence(output, words)
                val rows = mutableListOf<Map<String, String>>()
                while (true) {
                    val sentence = RouterOsApiCodec.readSentence(input)
                    when (sentence.firstOrNull()) {
                        "!re" -> rows.add(RouterOsApiCodec.parseAttributes(sentence.drop(1)))
                        "!trap", "!fatal" -> {
                            val message = RouterOsApiCodec.parseAttributes(sentence.drop(1))["message"]
                                ?: sentence.first()
                            return@withContext McmResult.Failure("API_COMMAND", "RouterOS API: $message")
                        }
                        "!done" -> return@withContext McmResult.Success(rows)
                        "!empty" -> return@withContext McmResult.Failure(
                            "API_EMPTY",
                            "RouterOS kết thúc lệnh bằng !empty thay vì !done; không xác nhận phép đo ping hoàn tất."
                        )
                    }
                }
                @Suppress("UNREACHABLE_CODE")
                McmResult.Failure("API_PROTOCOL", "RouterOS API response ended unexpectedly.")
            }
        } catch (error: javax.net.ssl.SSLException) {
            McmResult.Failure("TLS", "Không xác minh được chứng chỉ TLS của router. Kiểm tra SHA-256 fingerprint.")
        } catch (error: Exception) {
            McmResult.Failure("NETWORK", error.message ?: "Không thể kết nối RouterOS API-SSL.")
        }
    }

    private fun openAuthenticatedSocket(): SSLSocket {
        val modernSocket = connectSocket()
        try {
            val input = DataInputStream(BufferedInputStream(modernSocket.inputStream))
            val output = DataOutputStream(BufferedOutputStream(modernSocket.outputStream))
            RouterOsApiCodec.writeSentence(output, listOf("/login", "=name=$username", "=password=$password"))
            val reply = RouterOsApiCodec.readUntilTerminal(input)
            val rejected = reply.any { it == "!trap" || it == "!fatal" }
            if (!rejected) return modernSocket
        } catch (_: Exception) {
            // Older RouterOS releases require the challenge-response login below.
        }
        runCatching { modernSocket.close() }
        return connectAndLegacyLogin()
    }

    private fun connectAndLegacyLogin(): SSLSocket {
        val socket = connectSocket()
        try {
            val input = DataInputStream(BufferedInputStream(socket.inputStream))
            val output = DataOutputStream(BufferedOutputStream(socket.outputStream))
            RouterOsApiCodec.writeSentence(output, listOf("/login"))
            val firstReply = RouterOsApiCodec.readUntilTerminal(input)
            val challenge = firstReply.asSequence()
                .filter { it.startsWith("=") }
                .mapNotNull { RouterOsApiCodec.parseAttribute(it)?.takeIf { pair -> pair.first == "ret" }?.second }
                .firstOrNull()
                ?: throw IllegalStateException("RouterOS API did not return a legacy login challenge")
            val response = RouterOsApiCodec.legacyLoginResponse(password, challenge)
            RouterOsApiCodec.writeSentence(output, listOf("/login", "=name=$username", "=response=$response"))
            val loginReply = RouterOsApiCodec.readUntilTerminal(input)
            if (loginReply.any { it == "!trap" || it == "!fatal" }) {
                val message = RouterOsApiCodec.parseAttributes(loginReply.drop(1))["message"]
                    ?: "Authentication rejected"
                throw IllegalStateException("RouterOS API login failed: $message")
            }
            return socket
        } catch (error: Exception) {
            runCatching { socket.close() }
            throw error
        }
    }

    private fun connectSocket(): SSLSocket {
        require(host.isNotBlank() && port in 1..65535)
        val socket = sslContext.socketFactory.createSocket() as SSLSocket
        socket.useClientMode = true
        socket.soTimeout = LOGIN_READ_TIMEOUT_MS
        socket.connect(InetSocketAddress(host, port), CONNECT_TIMEOUT_MS)
        socket.startHandshake()
        return socket
    }

    companion object {
        private const val CONNECT_TIMEOUT_MS = 8_000
        private const val LOGIN_READ_TIMEOUT_MS = 10_000
        private const val COMMAND_READ_TIMEOUT_MS = 20_000
    }
}
