package com.multicloud.mcm

import com.multicloud.mcm.data.McmDatabase
import com.multicloud.mcm.data.RouterEntity
import com.multicloud.mcm.routeros.RouterOs6ApiClient
import com.multicloud.mcm.routeros.RouterOs6Repository
import com.multicloud.mcm.security.SecureCredentialStore
import org.json.JSONObject

class McmMonitoringService(
    private val database: McmDatabase,
    private val credentialStore: SecureCredentialStore
) {
    private val history = McmHistoryStore(database)
    private val interfaceRates = McmInterfaceRateService(database)

    suspend fun refreshRouter(routerId: String, target: String): JSONObject {
        val router = database.routerDao().getById(routerId)
            ?: throw IllegalArgumentException("Không tìm thấy router.")
        val password = credentialStore.get(router.credentialAlias)
            ?: throw IllegalStateException("Không giải mã được thông tin đăng nhập. Hãy xóa và thêm lại router.")

        val resourceResult: McmResult<SystemResource>
        val interfaceResult: McmResult<List<InterfaceSnapshot>>
        val pingResult: McmResult<PingMeasurement>?
        if (router.routerOsMajor == 7) {
            val repository = RouterOs7Repository(
                RouterOs7Client(router.host, router.port, router.username, password, router.tlsSha256Pin)
            )
            resourceResult = repository.readSystemResource()
            interfaceResult = repository.readInterfaces()
            pingResult = target.trim().takeIf(String::isNotBlank)?.let { repository.ping(it) }
        } else {
            val repository = RouterOs6Repository(
                RouterOs6ApiClient(router.host, router.port, router.username, password, router.tlsSha256Pin)
            )
            resourceResult = repository.readSystemResource()
            interfaceResult = repository.readInterfaces()
            pingResult = target.trim().takeIf(String::isNotBlank)?.let { repository.ping(it) }
        }

        val resource = (resourceResult as? McmResult.Success)?.value
            ?: run {
                val failure = resourceResult as McmResult.Failure
                throw IllegalStateException("${failure.code}: ${failure.message}")
            }
        val measuredAt = System.currentTimeMillis()
        database.routerDao().upsert(router.copy(lastSeenAtEpochMs = measuredAt))
        resource.cpuLoadPercent?.let { history.record(router.id, "cpu_load", it.toDouble(), "%", measuredAt) }
        val free = resource.freeMemoryBytes
        val total = resource.totalMemoryBytes
        if (free != null && total != null && total > 0) {
            val used = 100.0 * (total - free).coerceAtLeast(0) / total.toDouble()
            history.record(router.id, "memory_used", used, "%", measuredAt)
        }

        val interfaceValues = (interfaceResult as? McmResult.Success)?.value.orEmpty()
        val interfaceJson = interfaceRates.enrich(router.id, interfaceValues, measuredAt)
        val pingJson: Any = when (pingResult) {
            is McmResult.Success -> {
                history.record(router.id, "icmp_loss", pingResult.value.lossPercent, "%", pingResult.value.measuredAtEpochMs)
                pingResult.value.toJson()
            }
            is McmResult.Failure -> JSONObject().put("error", pingResult.message).put("code", pingResult.code)
            null -> JSONObject.NULL
        }

        val warnings = buildList {
            if (interfaceResult is McmResult.Failure) add("Không đọc được danh sách interface: ${interfaceResult.message}")
            if (pingResult is McmResult.Failure) add("Ping không hợp lệ/thất bại: ${pingResult.message}")
        }
        val warningJson = org.json.JSONArray().apply { warnings.forEach(::put) }

        return JSONObject()
            .put("ok", true)
            .put("router", router.toPublicJson())
            .put("resource", JSONObject()
                .put("version", resource.version ?: JSONObject.NULL)
                .put("uptime", resource.uptime ?: JSONObject.NULL)
                .put("cpuLoadPercent", resource.cpuLoadPercent ?: JSONObject.NULL)
                .put("freeMemoryBytes", free ?: JSONObject.NULL)
                .put("totalMemoryBytes", total ?: JSONObject.NULL))
            .put("interfaces", interfaceJson)
            .put("ping", pingJson)
            .put("warnings", warningJson)
            .put("refreshedAt", measuredAt)
    }

    suspend fun metricHistory(routerId: String, metricKey: String): JSONObject = history.read(routerId, metricKey)

    private fun PingMeasurement.toJson(): JSONObject = JSONObject()
        .put("target", target)
        .put("sent", sent)
        .put("received", received)
        .put("lost", lost)
        .put("lossPercent", lossPercent)
        .put("minRttMs", minRttMs ?: JSONObject.NULL)
        .put("avgRttMs", avgRttMs ?: JSONObject.NULL)
        .put("maxRttMs", maxRttMs ?: JSONObject.NULL)

    private fun RouterEntity.toPublicJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("name", name)
        .put("host", host)
        .put("port", port)
        .put("routerOsMajor", routerOsMajor)
        .put("username", username)
        .put("lastSeenAt", lastSeenAtEpochMs ?: JSONObject.NULL)
}
