"use strict";

$("showAddBtn").addEventListener("click", () => showPanel(true));
$("closeAddBtn").addEventListener("click", () => showPanel(false));
$("cancelAddBtn").addEventListener("click", () => showPanel(false));
$("inspectTlsBtn").addEventListener("click", inspectTls);
$("routerForm").addEventListener("submit", saveRouter);
$("refreshBtn").addEventListener("click", refreshSelected);
$("removeBtn").addEventListener("click", removeSelected);
$("routerOs").addEventListener("change", () => {
  $("routerPort").value = $("routerOs").value === "6" ? "8729" : "443";
});

document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible" && state.selectedId) refreshSelected();
});

(async function boot() {
  try {
    await loadRouters();
    setStatus("Sẵn sàng", "good");
    if (state.selectedId) refreshSelected();
  } catch (error) {
    setStatus("Native bridge lỗi", "bad");
    toast(error.message);
  }
  state.timer = window.setInterval(() => {
    if (document.visibilityState === "visible" && state.selectedId) refreshSelected();
  }, 30000);
})();
