"use strict";
const $ = (id) => document.getElementById(id);
const state = { routers: [], selectedId: null, pending: new Map(), sequence: 0, refreshing: false, timer: null };

function toast(message) {
  const node = $("toast");
  node.textContent = message;
  node.classList.add("show");
  window.setTimeout(() => node.classList.remove("show"), 2600);
}

function nativeCall(method, ...args) {
  return new Promise((resolve, reject) => {
    if (!window.McmBridge || typeof window.McmBridge[method] !== "function") {
      reject(new Error("Native bridge chưa sẵn sàng."));
      return;
    }
    const callbackId = `cb_${++state.sequence}`;
    const timeout = window.setTimeout(() => {
      state.pending.delete(callbackId);
      reject(new Error("Thiết bị phản hồi quá thời gian."));
    }, 35000);
    state.pending.set(callbackId, { resolve, reject, timeout });
    try {
      window.McmBridge[method](...args, callbackId);
    } catch (error) {
      window.clearTimeout(timeout);
      state.pending.delete(callbackId);
      reject(error);
    }
  });
}

window.mcmReceive = (callbackId, jsonText) => {
  const pending = state.pending.get(callbackId);
  if (!pending) return;
  state.pending.delete(callbackId);
  window.clearTimeout(pending.timeout);
  try {
    pending.resolve(JSON.parse(jsonText));
  } catch {
    pending.reject(new Error("Dữ liệu trả về từ ứng dụng không hợp lệ."));
  }
};

function setStatus(message, mode = "idle") {
  $("statusText").textContent = message;
  $("statusDot").parentElement.className = `connection ${mode}`;
}
