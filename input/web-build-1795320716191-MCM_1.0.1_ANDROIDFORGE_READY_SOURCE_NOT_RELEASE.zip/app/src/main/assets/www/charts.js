"use strict";

function drawChart(svgId, points) {
  const svg = $(svgId);
  svg.replaceChildren();
  const values = points.map((point) => Number(point.value)).filter(Number.isFinite);
  if (!values.length) {
    const text = document.createElementNS("http://www.w3.org/2000/svg", "text");
    text.setAttribute("x", "150");
    text.setAttribute("y", "36");
    text.setAttribute("text-anchor", "middle");
    text.textContent = "Chưa có dữ liệu";
    svg.append(text);
    return;
  }
  const min = Math.min(...values);
  const max = Math.max(...values);
  const spread = Math.max(1, max - min);
  const coordinates = values.map((value, index) => {
    const x = 4 + (index / Math.max(1, values.length - 1)) * 292;
    const y = 56 - ((value - min) / spread) * 48;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  });
  const line = document.createElementNS("http://www.w3.org/2000/svg", "polyline");
  line.setAttribute("points", coordinates.join(" "));
  line.setAttribute("fill", "none");
  line.setAttribute("stroke", "#2874d2");
  line.setAttribute("stroke-width", "2.5");
  line.setAttribute("stroke-linecap", "round");
  line.setAttribute("stroke-linejoin", "round");
  svg.append(line);
}

async function loadHistory() {
  if (!state.selectedId) return;
  const keys = ["cpu_load", "memory_used", "icmp_loss"];
  const chartIds = ["cpuChart", "ramChart", "lossChart"];
  for (let index = 0; index < keys.length; index += 1) {
    try {
      const result = await nativeCall("metricHistory", state.selectedId, keys[index]);
      drawChart(chartIds[index], result.ok ? result.points : []);
    } catch {
      drawChart(chartIds[index], []);
    }
  }
}
