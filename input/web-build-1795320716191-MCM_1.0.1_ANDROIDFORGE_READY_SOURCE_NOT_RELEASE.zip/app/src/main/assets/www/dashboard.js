"use strict";

async function refreshSelected() {
  const routerId = state.selectedId;
  if (!routerId || state.refreshing) return;
  state.refreshing = true;
  $("refreshBtn").disabled = true;
  $("refreshBtn").textContent = "Đang đọc…";
  setStatus("Đang kết nối router", "idle");
  try {
    const result = await nativeCall("refreshRouter", routerId, $("pingTarget").value.trim());
    if (state.selectedId !== routerId) return;
    if (!result.ok) throw new Error(result.error || "Đọc dữ liệu router thất bại.");
    renderSnapshot(result);
    setStatus("Đã kết nối", "good");
    await loadHistory();
  } catch (error) {
    if (state.selectedId === routerId) {
      setStatus("Không kết nối được", "bad");
      toast(error.message);
    }
  } finally {
    state.refreshing = false;
    $("refreshBtn").disabled = !state.selectedId;
    $("refreshBtn").textContent = "↻ Làm mới";
    if (state.selectedId && state.selectedId !== routerId) refreshSelected();
  }
}

function clearDashboard() {
  $("cpuValue").textContent = "—";
  $("ramValue").textContent = "—";
  $("pppoeValue").textContent = "—";
  $("pppoeHint").textContent = "Chưa có dữ liệu";
  $("lossValue").textContent = "—";
  $("lossHint").textContent = "Đo độc lập bằng ping";
  $("versionValue").textContent = "—";
  $("uptimeValue").textContent = "—";
  $("interfaceList").replaceChildren();
  $("warnings").hidden = true;
  $("warnings").textContent = "";
  $("lastUpdated").textContent = "Chưa cập nhật";
  for (const id of ["cpuChart", "ramChart", "lossChart"]) {
    drawChart(id, []);
  }
}

function renderSnapshot(data) {
  const resource = data.resource || {};
  $("cpuValue").textContent = resource.cpuLoadPercent == null ? "—" : `${resource.cpuLoadPercent}%`;
  $("versionValue").textContent = resource.version || "—";
  $("uptimeValue").textContent = resource.uptime || "—";
  let ram = null;
  if (Number.isFinite(resource.freeMemoryBytes) && Number.isFinite(resource.totalMemoryBytes) && resource.totalMemoryBytes > 0) {
    ram = Math.max(0, 100 * (resource.totalMemoryBytes - resource.freeMemoryBytes) / resource.totalMemoryBytes);
  }
  $("ramValue").textContent = ram == null ? "—" : `${ram.toFixed(1)}%`;

  const interfaces = Array.isArray(data.interfaces) ? data.interfaces : [];
  const pppoe = interfaces.filter((item) => (item.type || "").toLowerCase().includes("pppoe") || item.name.toLowerCase().includes("pppoe"));
  const active = pppoe.filter((item) => item.running).length;
  $("pppoeValue").textContent = pppoe.length ? `${active}/${pppoe.length}` : "Không có";
  $("pppoeHint").textContent = pppoe.length ? `${active} interface đang chạy` : "Không tìm thấy PPPoE client";

  const ping = data.ping || null;
  if (ping && Number.isFinite(ping.lossPercent)) {
    $("lossValue").textContent = `${ping.lossPercent.toFixed(1)}%`;
    $("lossHint").textContent = `${ping.received}/${ping.sent} nhận · ${ping.lost} mất · ${ping.target}`;
  } else {
    $("lossValue").textContent = "—";
    $("lossHint").textContent = ping?.error || "Chưa có phép đo ICMP hợp lệ";
  }

  renderInterfaces(interfaces);
  const warnings = data.warnings || [];
  $("warnings").hidden = warnings.length === 0;
  $("warnings").textContent = warnings.join(" · ");
  $("lastUpdated").textContent = `Cập nhật ${new Date(data.refreshedAt).toLocaleTimeString()}`;
}

function renderInterfaces(interfaces) {
  const list = $("interfaceList");
  list.replaceChildren();
  if (!interfaces.length) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = "Router chưa trả danh sách interface.";
    list.append(empty);
    return;
  }
  interfaces.forEach((item) => {
    const row = document.createElement("article");
    row.className = "interface-row";
    const header = document.createElement("header");
    const name = document.createElement("b");
    name.textContent = item.name;
    const status = document.createElement("em");
    status.className = item.running ? "" : "down";
    status.textContent = item.running ? "RUNNING" : "DOWN";
    header.append(name, status);
    const rates = document.createElement("div");
    rates.className = "rates";
    const rx = Number.isFinite(item.rxMbps) ? `${item.rxMbps.toFixed(2)} Mbps` : "—";
    const tx = Number.isFinite(item.txMbps) ? `${item.txMbps.toFixed(2)} Mbps` : "—";
    rates.innerHTML = `<span>↓ <strong>${rx}</strong></span><span>↑ <strong>${tx}</strong></span>`;
    row.append(header, rates);
    list.append(row);
  });
}
