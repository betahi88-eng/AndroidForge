"use strict";

function renderRouters() {
  const list = $("routerList");
  $("routerCount").textContent = String(state.routers.length);
  list.replaceChildren();
  if (state.routers.length === 0) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = "Chưa có router. Thêm thiết bị bên dưới.";
    list.append(empty);
    state.selectedId = null;
    clearDashboard();
    $("refreshBtn").disabled = true;
    $("removeBtn").disabled = true;
    $("selectedName").textContent = "Chưa chọn router";
    $("selectedMeta").textContent = "Thêm router để bắt đầu giám sát";
    return;
  }
  if (!state.routers.some((router) => router.id === state.selectedId)) {
    state.selectedId = state.routers[0].id;
    clearDashboard();
  }
  for (const router of state.routers) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = `router-item${router.id === state.selectedId ? " active" : ""}`;
    const title = document.createElement("b");
    title.textContent = router.name;
    const meta = document.createElement("span");
    meta.textContent = `${router.host}:${router.port} · RouterOS ${router.routerOsMajor}`;
    const badge = document.createElement("em");
    badge.textContent = router.routerOsMajor === 7 ? "REST" : "API-SSL";
    button.append(title, meta, badge);
    button.addEventListener("click", () => {
      if (state.selectedId !== router.id) clearDashboard();
      state.selectedId = router.id;
      renderRouters();
      renderSelectedMeta();
      refreshSelected();
    });
    list.append(button);
  }
  $("refreshBtn").disabled = false;
  $("removeBtn").disabled = false;
  renderSelectedMeta();
}

function renderSelectedMeta() {
  const router = state.routers.find((item) => item.id === state.selectedId);
  if (!router) return;
  $("selectedName").textContent = router.name;
  $("selectedMeta").textContent = `${router.host}:${router.port} · RouterOS ${router.routerOsMajor} · ${router.username}`;
}

async function loadRouters() {
  const result = await nativeCall("listRouters");
  if (!result.ok) throw new Error(result.error || "Không đọc được danh sách router.");
  state.routers = Array.isArray(result.routers) ? result.routers : [];
  renderRouters();
}

function showPanel(show) {
  $("addPanel").hidden = !show;
  if (show) $("routerName").focus();
}

async function inspectTls() {
  const host = $("routerHost").value.trim();
  const major = Number($("routerOs").value);
  const port = Number($("routerPort").value) || (major === 6 ? 8729 : 443);
  if (!host) return toast("Nhập địa chỉ router trước.");
  $("inspectTlsBtn").disabled = true;
  $("inspectTlsBtn").textContent = "Đang đọc…";
  try {
    const result = await nativeCall("inspectTls", host, port);
    if (!result.ok) throw new Error(result.error || "Không đọc được fingerprint.");
    $("routerPin").value = result.fingerprint;
    toast("Đã đọc fingerprint. Hãy đối chiếu độc lập trước khi lưu.");
  } catch (error) {
    toast(error.message);
  } finally {
    $("inspectTlsBtn").disabled = false;
    $("inspectTlsBtn").textContent = "Đọc fingerprint TLS";
  }
}

async function saveRouter(event) {
  event.preventDefault();
  const payload = {
    name: $("routerName").value.trim(),
    host: $("routerHost").value.trim(),
    routerOsMajor: Number($("routerOs").value),
    port: Number($("routerPort").value),
    username: $("routerUsername").value.trim(),
    password: $("routerPassword").value,
    tlsSha256Pin: $("routerPin").value.trim()
  };
  if (!window.confirm("Bạn đã đối chiếu SHA-256 fingerprint với nguồn đáng tin cậy độc lập và xác nhận đúng chứng chỉ của router?")) return;
  const submit = $("routerForm").querySelector("button[type=submit]");
  submit.disabled = true;
  try {
    const result = await nativeCall("saveRouter", JSON.stringify(payload));
    if (!result.ok) throw new Error(result.error || "Không lưu được router.");
    $("routerForm").reset();
    $("routerPort").value = "443";
    showPanel(false);
    await loadRouters();
    if (state.selectedId) refreshSelected();
    toast("Đã lưu router. Đang kiểm tra kết nối.");
  } catch (error) {
    toast(error.message);
  } finally {
    submit.disabled = false;
    $("routerPassword").value = "";
  }
}

async function removeSelected() {
  const router = state.routers.find((item) => item.id === state.selectedId);
  if (!router || !window.confirm(`Xóa router “${router.name}” khỏi MCM?`)) return;
  try {
    const result = await nativeCall("removeRouter", router.id);
    if (!result.ok) throw new Error(result.error || "Không xóa được router.");
    await loadRouters();
    if (state.selectedId) refreshSelected();
    toast("Đã xóa router và dữ liệu lịch sử.");
  } catch (error) {
    toast(error.message);
  }
}
