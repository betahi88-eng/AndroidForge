# MCM 1.6.2 — Thiết kế Direct-DDNS đa cửa hàng

## 1. Mục tiêu

Một ứng dụng Android theo dõi nhiều cửa hàng/MikroTik. Mỗi hồ sơ kết nối trực tiếp qua MikroTik Cloud DDNS, DDNS/domain hoặc IP. Không VPN/WireGuard, VPS, MCM backend, relay hoặc agent.

## 2. Mỗi hồ sơ có cấu hình kết nối độc lập

1. Tên cửa hàng/router.
2. Hostname Cloud DDNS/domain/IP.
3. Phiên bản RouterOS 6 hoặc 7 (để kiểm tra tương thích dữ liệu).
4. Giao thức dịch vụ: `AUTO`, `REST_HTTPS` hoặc `API_SSL`.
5. Port WAN do người dùng nhập, số nguyên 1–65535. Khi có NAT, nhập port bên ngoài mà Android truy cập.
6. Username/password riêng; password mã hóa bằng Android Keystore.
7. SHA-256 fingerprint của leaf TLS certificate tại đúng hostname + port.

`AUTO` giữ mặc định cũ: ROS7 → REST HTTPS/443; ROS6 → API-SSL/8729. `REST_HTTPS` chỉ chấp nhận ROS7. `API_SSL` dùng được với ROS6/ROS7. Người dùng đổi OS/service thì port mặc định chỉ được gợi ý khi chưa nhập port thủ công; port tùy chỉnh được giữ nguyên và lưu riêng từng router.

**WinBox không phải giao thức MCM.** TCP 8291 thường là WinBox. MCM không nói WinBox protocol. MCM chỉ dùng 8291 khi chính cổng đó phục vụ hoặc được NAT chuyển tới REST HTTPS/API-SSL đã chọn; đăng nhập WinBox thành công không chứng minh MCM đọc API được.

## 3. Luồng thêm/cập nhật router

1. Nhập hostname, OS, service mode và port WAN.
2. Kiểm tra DNS và TCP đến đúng host:port. TCP open chỉ xác nhận socket, không chứng minh service protocol.
3. Đọc fingerprint TLS từ đúng host:port; đối chiếu ngoài ứng dụng qua nguồn tin cậy.
4. Nhập account read-only, chọn giao thức tương ứng, lưu profile.
5. Refresh để xác minh TLS pin, đăng nhập và đọc `/system/resource`. Chỉ báo ONLINE sau khi core read thành công.
6. Khi sửa profile, port không bị tự đổi khi thay OS/service. Để trống password giữ credential mã hóa hiện có.

## 4. Chẩn đoán phân tầng

- `DNS_FAILED`: hostname chưa phân giải/Cloud DDNS chưa cập nhật.
- `TCP_TIMEOUT` / `TCP_UNREACHABLE`: WAN, firewall, NAT, ISP hoặc port/service không tiếp cận được.
- `TLS_PROTOCOL`: port không phục vụ TLS tương thích; có thể đang trỏ vào WinBox, HTTP hoặc dịch vụ khác.
- `TLS_HANDSHAKE`: TLS/chứng chỉ không thương lượng được.
- `TLS_FINGERPRINT_MISMATCH`: leaf certificate khác pin đã lưu.
- `AUTH`: RouterOS từ chối username/password.
- `PERMISSION`: tài khoản thiếu quyền đọc.
- `PARTIAL`: core resource thành công nhưng bảng phụ lỗi.
- `ONLINE`: đọc core resource thành công và không có lỗi bảng phụ.

Không bỏ pin, không fallback HTTP, không thử tự động giao thức khác và không tự đổi port ngoài ý người dùng.

## 5. WAN IP động và port mapping

- MCM lưu hostname để DNS được phân giải lại trong mỗi kết nối mới.
- Đổi WAN IP: chờ DDNS cập nhật; không khóa profile vào IP cũ.
- Nếu cổng WAN được đổi hoặc forward sang cổng trong khác, người dùng sửa port WAN trong hồ sơ MCM.
- Port phải kết thúc ở đúng dịch vụ `www-ssl` hoặc `api-ssl`; thay đổi số port trong app không tự bật service, firewall hay NAT ở router.
- CGNAT/inbound ISP block/double NAT chưa forward không thể được khắc phục chỉ bằng cách đổi port.

## 6. Bảo toàn dữ liệu

Room v3→v4 thêm `connectionMode` mặc định `AUTO`. Migration giữ nguyên host, port, OS, username, credential alias, fingerprint, trạng thái và lịch sử. Không yêu cầu người dùng thêm lại cửa hàng.

## 7. Phạm vi chỉ đọc

MCM chỉ truy vấn system resource, interface, IP Cloud, PPPoE active, ARP, DHCP, Netwatch, bridge hosts/VLAN và ping giới hạn. Không thay đổi cấu hình RouterOS, dịch vụ, port, firewall, NAT, IP hoặc DDNS.
