package com.multicloud.mcm

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class RouterServiceModeTest {
    @Test fun autoUsesLegacyServiceAndPortSuggestions() {
        assertEquals(RouterTransport.REST_HTTPS, RouterServiceMode.AUTO.resolve(7))
        assertEquals(RouterTransport.API_SSL, RouterServiceMode.AUTO.resolve(6))
        assertEquals(443, RouterServiceMode.AUTO.suggestedPort(7))
        assertEquals(8729, RouterServiceMode.AUTO.suggestedPort(6))
        assertEquals(443, RouterTransport.REST_HTTPS.port)
        assertEquals(8729, RouterTransport.API_SSL.port)
    }

    @Test fun apiSslCanBeSelectedIndependentlyOnRouterOs6Or7() {
        assertEquals(RouterTransport.API_SSL, RouterServiceMode.API_SSL.resolve(6))
        assertEquals(RouterTransport.API_SSL, RouterServiceMode.API_SSL.resolve(7))
        assertEquals(8729, RouterServiceMode.API_SSL.suggestedPort(7))
    }

    @Test fun restHttpsRequiresRouterOs7() {
        assertEquals(RouterTransport.REST_HTTPS, RouterServiceMode.REST_HTTPS.resolve(7))
        assertThrows(IllegalArgumentException::class.java) { RouterServiceMode.REST_HTTPS.resolve(6) }
    }

    @Test fun invalidStoredModeFallsBackButInvalidUserInputIsRejected() {
        assertEquals(RouterServiceMode.AUTO, RouterServiceMode.fromStorage("OLD_VALUE"))
        assertThrows(IllegalArgumentException::class.java) { RouterServiceMode.fromUserInput("WINBOX") }
    }
}
