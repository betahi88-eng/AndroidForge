package com.multicloud.mcm

/** RouterOS management service used by MCM. WinBox is intentionally not an API transport. */
enum class RouterServiceMode(val storageValue: String) {
    AUTO("AUTO"),
    REST_HTTPS("REST_HTTPS"),
    API_SSL("API_SSL");

    fun resolve(routerOsMajor: Int): RouterTransport {
        require(routerOsMajor == 6 || routerOsMajor == 7) { "Chỉ hỗ trợ RouterOS 6 hoặc 7." }
        return when (this) {
            AUTO -> if (routerOsMajor == 7) RouterTransport.REST_HTTPS else RouterTransport.API_SSL
            REST_HTTPS -> {
                require(routerOsMajor == 7) { "REST HTTPS yêu cầu RouterOS 7 trở lên; hãy chọn API-SSL cho RouterOS 6." }
                RouterTransport.REST_HTTPS
            }
            API_SSL -> RouterTransport.API_SSL
        }
    }

    fun suggestedPort(routerOsMajor: Int): Int = when (resolve(routerOsMajor)) {
        RouterTransport.REST_HTTPS -> 443
        RouterTransport.API_SSL -> 8729
    }

    companion object {
        fun fromStorage(value: String?): RouterServiceMode =
            entries.firstOrNull { it.storageValue.equals(value?.trim(), ignoreCase = true) } ?: AUTO

        fun fromUserInput(value: String?): RouterServiceMode =
            entries.firstOrNull { it.storageValue.equals(value?.trim(), ignoreCase = true) }
                ?: throw IllegalArgumentException("Chọn giao thức kết nối hợp lệ: Tự động, REST HTTPS hoặc API-SSL.")
    }
}

enum class RouterTransport(val port: Int) { REST_HTTPS(443), API_SSL(8729) }
