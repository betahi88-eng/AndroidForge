package com.multicloud.mcm.security

import com.multicloud.mcm.RouterDnsResolver
import com.multicloud.mcm.RouterHostValidator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.ConnectException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLException
import javax.net.ssl.SSLSocket
import javax.net.ssl.X509TrustManager

internal data class TlsProbeResult(
    val fingerprint: String,
    val resolvedIp: String,
    val tcpDurationMs: Long,
    val tlsDurationMs: Long
)

internal class TlsProbeException(
    val failureCode: String,
    val failureStage: String,
    message: String,
    cause: Throwable? = null
) : Exception(message, cause)

/** Captures a leaf SHA-256 only for an explicit user trust decision; it never silently pins it. */
object TlsFingerprintInspector {
    suspend fun inspect(host: String, port: Int): String = withContext(Dispatchers.IO) {
        val normalizedHost = RouterHostValidator.normalize(host)
        require(port in 1..65535)
        val addresses = RouterDnsResolver.resolve(normalizedHost)
        probe(normalizedHost, port, addresses).fingerprint
    }

    internal suspend fun probe(
        rawHost: String,
        port: Int,
        addresses: List<InetAddress>
    ): TlsProbeResult = withContext(Dispatchers.IO) {
        val host = RouterHostValidator.normalize(rawHost)
        require(port in 1..65535 && addresses.isNotEmpty())
        val captureTrustManager = object : X509TrustManager {
            @Volatile var leaf: X509Certificate? = null
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
            override fun checkClientTrusted(chain: Array<out X509Certificate>, authType: String) = Unit
            override fun checkServerTrusted(chain: Array<out X509Certificate>, authType: String) {
                leaf = chain.firstOrNull() ?: throw java.security.cert.CertificateException("No server certificate")
            }
        }
        val context = SSLContext.getInstance("TLS").apply {
            init(null, arrayOf(captureTrustManager), SecureRandom())
        }
        var lastFailure: Throwable? = null
        var sawConnectTimeout = false
        var sawTlsTimeout = false
        for (address in addresses) {
            val tcpSocket = Socket()
            var tcpDuration = 0L
            try {
                val tcpStarted = System.nanoTime()
                tcpSocket.connect(InetSocketAddress(address, port), CONNECT_TIMEOUT_MS)
                tcpDuration = elapsedMs(tcpStarted)
                val tlsStarted = System.nanoTime()
                val tlsSocket = context.socketFactory.createSocket(tcpSocket, host, port, true) as SSLSocket
                tlsSocket.useClientMode = true
                tlsSocket.soTimeout = TLS_TIMEOUT_MS
                RouterDnsResolver.configureSni(tlsSocket, host)
                tlsSocket.startHandshake()
                RouterDnsResolver.verifyPeerIdentity(host, tlsSocket.session)
                val cert = captureTrustManager.leaf
                    ?: throw java.security.cert.CertificateException("Router sent no TLS certificate")
                return@withContext TlsProbeResult(
                    fingerprint = sha256(cert.encoded),
                    resolvedIp = address.hostAddress ?: address.toString(),
                    tcpDurationMs = tcpDuration,
                    tlsDurationMs = elapsedMs(tlsStarted)
                )
            } catch (error: SocketTimeoutException) {
                if (tcpDuration > 0) sawTlsTimeout = true else sawConnectTimeout = true
                lastFailure = error
            } catch (error: ConnectException) {
                lastFailure = error
            } catch (error: SSLException) {
                lastFailure = error
                // A TLS protocol/certificate identity failure is meaningful; do not try another IP.
                throw TlsProbeException("TLS_FAILED", "TLS_HANDSHAKE", "TLS handshake or peer identity verification failed at $host:$port", error)
            } catch (error: Exception) {
                lastFailure = error
            } finally {
                runCatching { tcpSocket.close() }
            }
        }
        val code = when {
            sawTlsTimeout || sawConnectTimeout -> "NETWORK_TIMEOUT"
            lastFailure is ConnectException -> "TCP_REFUSED"
            else -> "PORTS_UNREACHABLE"
        }
        val stage = when {
            sawTlsTimeout && sawConnectTimeout -> "TCP_AND_TLS_TIMEOUT"
            sawTlsTimeout -> "TLS_HANDSHAKE_TIMEOUT"
            sawConnectTimeout -> "TCP_CONNECT_TIMEOUT"
            lastFailure is ConnectException -> "TCP_CONNECT"
            else -> "TLS_OR_SOCKET"
        }
        throw TlsProbeException(code, stage, "Could not establish TCP/TLS to $host:$port", lastFailure)
    }

    private fun elapsedMs(startNanos: Long): Long = ((System.nanoTime() - startNanos) / 1_000_000).coerceAtLeast(0)

    private const val CONNECT_TIMEOUT_MS = 5_000
    private const val TLS_TIMEOUT_MS = 5_000

    fun sha256(bytes: ByteArray): String = java.security.MessageDigest.getInstance("SHA-256")
        .digest(bytes).joinToString("") { "%02X".format(it.toInt() and 0xFF) }
}
