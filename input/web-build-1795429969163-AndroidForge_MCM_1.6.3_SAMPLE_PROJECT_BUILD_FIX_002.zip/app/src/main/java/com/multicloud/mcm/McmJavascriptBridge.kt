package com.multicloud.mcm

import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.multicloud.mcm.data.McmDatabase
import com.multicloud.mcm.security.SecureCredentialStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.cancel
import org.json.JSONObject

/** Thin, allow-listed bridge; all database and network work runs off the WebView thread. */
class McmJavascriptBridge(
    private val webView: WebView,
    database: McmDatabase,
    credentials: SecureCredentialStore
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val profiles = McmRouterProfileService(database, credentials)
    private val connectionCoordinator = RouterConnectionCoordinator(database, credentials)
    private val monitor = McmMonitoringService(database, credentials)
    private val discovery = MikroTikNeighborDiscovery(webView.context)
    private val networkState = McmNetworkState(webView.context)
    private val diagnostics = McmConnectionDiagnostics()

    @JavascriptInterface
    fun listRouters(callbackId: String) = respond(callbackId) {
        JSONObject().put("ok", true).put("routers", profiles.listRouters())
    }

    @JavascriptInterface
    fun discoverMikroTik(callbackId: String) = respond(callbackId) {
        JSONObject().put("ok", true).put("devices", discovery.scan())
    }

    @JavascriptInterface
    fun getNetworkState(callbackId: String) = respond(callbackId) {
        JSONObject().put("ok", true).put("network", networkState.snapshot())
    }

    @JavascriptInterface
    fun inspectTls(host: String, port: Int, callbackId: String) = respond(callbackId) {
        JSONObject().put("ok", true).put("fingerprint", profiles.inspectTls(host, port))
    }

    @JavascriptInterface
    fun diagnoseEndpoint(host: String, port: Int, callbackId: String) = respond(callbackId) {
        diagnostics.inspect(host, port)
    }

    @JavascriptInterface
    fun connectRouter(host: String, username: String, password: String, callbackId: String) = respond(callbackId) {
        connectionCoordinator.start(host, username, password)
    }

    @JavascriptInterface
    fun confirmConnection(attemptId: String, decision: String, callbackId: String) = respond(callbackId) {
        connectionCoordinator.confirm(attemptId, decision)
    }

    @JavascriptInterface
    fun cancelConnection(attemptId: String, callbackId: String) = respond(callbackId) {
        connectionCoordinator.cancel(attemptId)
    }

    @JavascriptInterface
    fun connectionLogs(routerId: String, callbackId: String) = respond(callbackId) {
        JSONObject().put("ok", true).put("logs", profiles.connectionLogs(routerId))
    }

    @JavascriptInterface
    fun saveRouter(payloadJson: String, callbackId: String) = respond(callbackId) {
        val routerId = profiles.saveRouter(payloadJson)
        JSONObject().put("ok", true).put("id", routerId).put("message", "Đã lưu router an toàn.")
    }

    @JavascriptInterface
    fun removeRouter(routerId: String, callbackId: String) = respond(callbackId) {
        profiles.removeRouter(routerId)
        JSONObject().put("ok", true)
    }

    @JavascriptInterface
    fun refreshRouter(routerId: String, target: String, callbackId: String) = respond(callbackId) {
        monitor.refreshRouter(routerId, target)
    }

    @JavascriptInterface
    fun refreshAllRouters(target: String, selectedRouterId: String, callbackId: String) = respond(callbackId) {
        monitor.refreshAll(target, selectedRouterId)
    }

    @JavascriptInterface
    fun metricHistory(routerId: String, metricKey: String, callbackId: String) = respond(callbackId) {
        monitor.metricHistory(routerId, metricKey)
    }

    fun close() {
        scope.cancel()
    }

    private fun respond(callbackId: String, operation: suspend () -> JSONObject) {
        if (!callbackId.matches(Regex("[A-Za-z0-9_-]{1,64}"))) return
        scope.launch {
            val result = try {
                operation()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                JSONObject().put("ok", false).put("error", error.message ?: "Thao tác thất bại.")
            }
            val quoted = JSONObject.quote(result.toString())
            webView.post {
                webView.evaluateJavascript("window.mcmReceive('$callbackId', $quoted)", null)
            }
        }
    }
}
