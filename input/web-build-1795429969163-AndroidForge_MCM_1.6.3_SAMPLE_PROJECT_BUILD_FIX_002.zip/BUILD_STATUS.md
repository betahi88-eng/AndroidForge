# MCM 1.6.3 — Build status

Source identity: `MCM-1.6.3-RECONCILED-001`  
Application ID: `com.multicloud.mcm`  
Version: `1.6.3` (`versionCode=12`)  
Derived patch: `MCM-1.6.3-ANDROIDFORGE-HARDENED-001`

## Verified in this environment

- The locked input source ZIP SHA-256 is preserved and verified: `6313e1b28d2e7fa18fd56f20f8a4d91d6abf81a0027d1fe44e33e48a94ea1f0b`.
- Derived source ZIP has a separate SHA-256 and provenance manifest.
- JavaScript syntax, Python syntax, shell syntax, Android XML, source identity and the UI contract passed static checks.
- Room migration preservation was checked from legacy schema v1 through schema v6, including router profiles, metric history, interface counters and connection-attempt logs.
- UI contract check found exactly three inputs on Add Router and one primary action.

## Not verified / blocked

No Kotlin/Android Gradle compile, Android unit-test task, lint, `assembleDebug`, APK manifest validation, emulator run, physical-device run, or real RouterOS connection test has been completed. This runtime does not have the pinned JDK 17, Gradle 8.7 and Android SDK Platform 35/build-tools; network DNS is unavailable for provisioning them. Do not represent static checks as an APK build or product acceptance.

The source is a derived engineering candidate, not a release APK. The original locked source archive remains unchanged.
