#!/usr/bin/env python3
"""Validate the mobile-first DDNS form and WebView DOM bindings."""
from __future__ import annotations
import re
from pathlib import Path

root = Path(__file__).resolve().parents[1]
www = root / "app/src/main/assets/www"
html = (www / "index.html").read_text(encoding="utf-8")
ids = re.findall(r'\bid=["\']([^"\']+)["\']', html)
if len(ids) != len(set(ids)):
    duplicates = sorted({item for item in ids if ids.count(item) > 1})
    raise SystemExit("Duplicate HTML id(s): " + ", ".join(duplicates))

lookups: dict[str, set[str]] = {}
for path in www.glob("*.js"):
    content = path.read_text(encoding="utf-8")
    for dom_id in re.findall(r'\$\(["\']([^"\']+)["\']\)', content):
        lookups.setdefault(dom_id, set()).add(path.name)
missing = sorted(set(lookups) - set(ids))
if missing:
    raise SystemExit("Missing HTML element id(s): " + "; ".join(missing))

required_inputs = {"routerHost", "routerUsername", "routerPassword"}
if not required_inputs.issubset(set(ids)):
    raise SystemExit("Missing required DDNS inputs: " + ", ".join(sorted(required_inputs - set(ids))))
for forbidden in ("routerPort", "routerConnectionMode", "routerProtocol", "routerTlsFingerprint", "routerDoh"):
    if forbidden in ids:
        raise SystemExit(f"Technical option {forbidden} must not appear on the primary Add Router form.")
form = re.search(r'<form id="routerForm">(.*?)</form>', html, re.S)
if not form:
    raise SystemExit("Router form is missing")
form_html = form.group(1)
input_ids = set(re.findall(r'<input\b[^>]*\bid="([^"]+)"', form_html))
if input_ids != required_inputs:
    raise SystemExit(f"Router form must expose exactly three inputs; found {sorted(input_ids)}")
if form_html.count('type="submit"') != 1 or "Lưu &amp; Kết nối" not in form_html:
    raise SystemExit("Router form must have one primary 'Lưu & Kết nối' action")
if "openConnectionLogsBtn" not in form_html or "Nhật ký kỹ thuật" not in form_html:
    raise SystemExit("Connection diagnostics must remain available in the advanced section")
if "<p>" in form_html:
    raise SystemExit("Unnecessary explanatory notes remain in the Add Router form")
router_ui = (www / "router-ui.js").read_text(encoding="utf-8")
bridge = (www / "native-bridge.js").read_text(encoding="utf-8")
if "window.McmBridge" not in bridge:
    raise SystemExit("Native Android bridge is not connected")
for required in ("FIRST_TIME_PIN", "TLS_CHANGED", "PORTS_UNREACHABLE", "READY_LIMITED", "connectionLogs"):
    if required not in router_ui:
        raise SystemExit(f"Missing connection UI behavior: {required}")
if 'connectionDialog.addEventListener("cancel"' not in router_ui:
    raise SystemExit("Back/Escape cancellation is not wired for trust dialogs")
print(f"Mobile DDNS UI contract: PASS ({len(ids)} unique IDs, {len(lookups)} JS literal lookups, exactly 3 inputs)")
