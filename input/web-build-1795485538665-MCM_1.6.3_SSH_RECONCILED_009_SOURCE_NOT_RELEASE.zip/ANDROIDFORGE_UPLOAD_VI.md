# AndroidForge — nạp candidate MCM 1.6.3 SSH 008

## Gói và baseline

- Gói: `MCM_1.6.3_SSH_RECONCILED_009_SOURCE_NOT_RELEASE.zip`
- Source ID: `MCM-1.6.3-SSH-RECONCILED-009`
- Baseline phát triển: 007, đã được người dùng xác nhận build APK thành công trên AndroidForge.
- Candidate 009 thêm SSH v2; **chưa được xác nhận build APK**.

Đây là project Android native Gradle, không phải Repair Kit, không phải APK. Giải nén ZIP trực tiếp vào project root. Các file `settings.gradle.kts`, `build.gradle.kts`, `app/build.gradle.kts`, `app/src/main/AndroidManifest.xml` phải nằm ở root.

## Toolchain giữ nguyên như 007

JDK 17, Gradle 8.7, AGP 8.6.1, Kotlin 2.0.21, Android SDK Platform 35, Build Tools 35.0.0. Không tự đổi toolchain để ép build.

## Tác vụ bắt buộc

```bash
gradle --no-daemon clean
gradle --no-daemon :app:testDebugUnitTest
gradle --no-daemon :app:lintDebug
gradle --no-daemon :app:assembleDebug :app:bundleDebug
gradle --no-daemon :app:assembleRelease :app:bundleRelease
```

Tất cả phải trả exit code 0. Kiểm tra APK/AAB của đúng lần chạy hiện tại, package `com.multicloud.mcm`, version `1.6.3`, versionCode `12`, asset source ID `MCM-1.6.3-SSH-RECONCILED-009` và SHA-256. Không lấy APK tồn tại từ lần build trước.

## Kiểm thử chức năng bắt buộc

- REST HTTPS/API-SSL không hồi quy so với 007.
- SSH lần đầu chỉ thu host key, chưa gửi password; xác nhận fingerprint mới cho phép đăng nhập.
- SSH host key thay đổi phải fail closed trước xác thực.
- Sai password phải trả AUTH, không đổi pin.
- RouterOS 6.49.x và RouterOS 7.x: system/resource, interface stats, IP Cloud, PPP active, ARP, DHCP, Netwatch, bridge host, VLAN.
- Lệnh SSH ngoài allowlist bị từ chối; không có lệnh thay đổi cấu hình.
- Foreground và background refresh, chuyển Wi-Fi/4G, DDNS resolution.

Chỉ sau khi các bước trên đạt mới nâng 008 thành baseline build-success. Giữ lại APK/log của 007 để rollback và đối chứng.
