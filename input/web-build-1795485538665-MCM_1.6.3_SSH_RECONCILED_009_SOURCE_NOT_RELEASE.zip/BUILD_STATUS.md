# MCM 1.6.3 — candidate 009 build and acceptance status

Source identity: `MCM-1.6.3-SSH-RECONCILED-009`  
Parent: candidate 008, itself derived from user-confirmed build baseline 007  
Application ID: `com.multicloud.mcm`  
Version: `1.6.3` (`versionCode=12`)  
Room schema: `9`

## Repair made from AndroidForge log (2)

- Preserved all source and SSH functionality from candidate 008.
- Fixed the reported fatal `mergeDebugJavaResource` / `mergeReleaseJavaResource` collision by excluding only `META-INF/versions/9/OSGI-INF/MANIFEST.MF` in `app/build.gradle.kts` under `android.packaging.resources.excludes`.
- Added a source-verification regression check to ensure this exclusion is not accidentally removed.
- The log's Kotlin compilation completed; the fatal error was resource merging between `com.github.mwiede:jsch:2.28.8` and `org.bouncycastle:bcprov-jdk18on:1.86`. The reported nullable/deprecation diagnostics were warnings, not the build-stopping error.

## Verification status

- ZIP integrity / CRC: to be checked during packaging.
- Source static checks and provenance hashes: to be run during packaging.
- Android Gradle compile, KAPT, JUnit, lint, Debug APK, Release APK and AAB: **NOT RUN in this workspace**.
- Live RouterOS 6/7 SSH host-key and read-only CLI validation: **NOT RUN**.

**Status: SOURCE REPAIR — NOT YET ANDROIDFORGE BUILD-VERIFIED.** Candidate 007 remains the last user-confirmed APK-buildable baseline. Do not treat 009 as a successful APK until AndroidForge reruns the same tasks.

## Required AndroidForge verification

Run `scripts/androidforge-preflight.sh`, `scripts/verify-source.sh`, `:app:testDebugUnitTest`, `:app:lintDebug`, `:app:assembleDebug`, `:app:assembleRelease` and `:app:bundleRelease`. If another resource collision appears, use the exact new log rather than broad exclusions.
